package dev.mixtape.player.download

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import dev.mixtape.player.spotify.SpotifyPublic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.cancellation.CancellationException

enum class JobStatus { Queued, Running, Done, Skipped, Failed, Canceled }

data class DownloadJob(
    val id: String,
    /** What the list shows, e.g. "Artist - Title" or a video title. */
    val label: String,
    /** A URL, or "ytsearch1:..." to take the best YouTube match. */
    val source: String,
    /** Tags to write instead of YouTube's (songs from Spotify). */
    val title: String?,
    val artist: String?,
    /** File name without extension, or null to use the video title. */
    val fileBase: String?,
    val quality: Quality,
    val status: JobStatus = JobStatus.Queued,
    val progress: Float = 0f,
    val message: String? = null,
) {
    val finished: Boolean get() = status != JobStatus.Queued && status != JobStatus.Running
}

/**
 * Lives as long as the app process. DownloadService keeps the process alive while work is pending.
 */
object DownloadQueue {

    private const val PARALLEL = 3
    private const val UPDATE_EVERY_MS = 24L * 60 * 60 * 1000

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val slots = Semaphore(PARALLEL)
    private val initLock = Mutex()
    private val running = ConcurrentHashMap<String, Job>()
    @Volatile private var initialized = false
    private lateinit var app: Context

    private val _jobs = MutableStateFlow<List<DownloadJob>>(emptyList())
    val jobs: StateFlow<List<DownloadJob>> = _jobs

    /** Links being read right now (before their songs are added to the list). */
    private val _reading = MutableStateFlow(0)
    val reading: StateFlow<Int> = _reading

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages

    fun init(context: Context) {
        app = context.applicationContext
    }

    val isWorking: Boolean
        get() = _reading.value > 0 || _jobs.value.any { !it.finished }

    // ---------- Adding work ----------

    /** A YouTube link (video or playlist), a Spotify link (track, album or playlist), or any yt-dlp site. */
    fun addLink(link: String, quality: Quality) {
        _reading.update { it + 1 }
        startService()
        scope.launch {
            try {
                ensureReady()
                val jobs = if (SpotifyPublic.isSpotifyLink(link)) {
                    SpotifyPublic.fetch(link).tracks.map { t -> songJob(t.title, t.artists.joinToString(", "), quality) }
                } else {
                    listLink(link, quality)
                }
                if (jobs.isEmpty()) _messages.tryEmit("Nothing to download at that link.")
                enqueue(jobs)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Couldn't read that link: ${shortError(e)}")
            } finally {
                _reading.update { it - 1 }
            }
        }
    }

    /** Songs known by name (e.g. missing songs of an imported playlist). Each is matched on YouTube. */
    fun addSongs(songs: List<Pair<String, String>>, quality: Quality) {
        if (songs.isEmpty()) return
        _reading.update { it + 1 }
        startService()
        scope.launch {
            try {
                ensureReady()
                enqueue(songs.map { (title, artist) -> songJob(title, artist, quality) })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Couldn't start the downloader: ${shortError(e)}")
            } finally {
                _reading.update { it - 1 }
            }
        }
    }

    fun retry(id: String) {
        val job = _jobs.value.find { it.id == id } ?: return
        if (job.status != JobStatus.Failed && job.status != JobStatus.Canceled) return
        setJob(id) { it.copy(status = JobStatus.Queued, progress = 0f, message = null) }
        startService()
        start(job.id)
    }

    fun cancelAll() {
        _jobs.value.filter { !it.finished }.forEach { job ->
            setJob(job.id) { it.copy(status = JobStatus.Canceled) }
            runCatching { YoutubeDL.getInstance().destroyProcessById(job.id) }
            running.remove(job.id)?.cancel()
        }
    }

    fun clearFinished() {
        _jobs.update { list -> list.filterNot { it.finished } }
    }

    // ---------- Internals ----------

    private fun songJob(title: String, artist: String, quality: Quality): DownloadJob {
        val label = if (artist.isBlank()) title else "$artist - $title"
        return DownloadJob(
            id = UUID.randomUUID().toString(),
            label = label,
            source = "ytsearch1:$label audio",
            title = title,
            artist = artist.ifBlank { null },
            fileBase = safeName(label),
            quality = quality,
        )
    }

    /** Lists the videos behind a link without downloading anything (fast, one request). */
    private fun listLink(link: String, quality: Quality): List<DownloadJob> {
        val request = YoutubeDLRequest(link).apply {
            addOption("--flat-playlist")
            // A video opened from inside a playlist means just that video.
            addOption("--no-playlist")
            addOption("--dump-single-json")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(request, null, null).out
        val json = JSONObject(out.substring(out.indexOf('{')))
        val entries = json.optJSONArray("entries")
        if (entries == null) {
            return listOf(videoJob(json.optString("title"), json.optString("webpage_url").ifEmpty { link }, quality))
        }
        val jobs = ArrayList<DownloadJob>()
        for (i in 0 until entries.length()) {
            val e = entries.optJSONObject(i) ?: continue
            val url = e.optString("url").ifEmpty { e.optString("webpage_url") }
            if (url.isEmpty()) continue
            jobs += videoJob(e.optString("title"), url, quality)
        }
        return jobs
    }

    private fun videoJob(title: String, url: String, quality: Quality) = DownloadJob(
        id = UUID.randomUUID().toString(),
        label = title.ifEmpty { url },
        source = url,
        title = null,
        artist = null,
        fileBase = null,
        quality = quality,
    )

    private fun enqueue(jobs: List<DownloadJob>) {
        if (jobs.isEmpty()) return
        _jobs.update { it + jobs }
        jobs.forEach { start(it.id) }
    }

    private fun start(id: String) {
        val handle = scope.launch {
            slots.withPermit {
                val job = _jobs.value.find { it.id == id }
                if (job == null || job.status != JobStatus.Queued) return@withPermit
                setJob(id) { it.copy(status = JobStatus.Running, progress = 0f) }
                try {
                    val result = download(job)
                    setJob(id) { it.copy(status = result, progress = 100f) }
                } catch (e: CancellationException) {
                    setJob(id) { it.copy(status = JobStatus.Canceled) }
                    throw e
                } catch (e: YoutubeDL.CanceledException) {
                    setJob(id) { it.copy(status = JobStatus.Canceled) }
                } catch (e: Exception) {
                    val current = _jobs.value.find { it.id == id }
                    if (current?.status != JobStatus.Canceled) {
                        setJob(id) { it.copy(status = JobStatus.Failed, message = shortError(e)) }
                    }
                }
            }
        }
        running[id] = handle
        handle.invokeOnCompletion { running.remove(id) }
    }

    private fun download(job: DownloadJob): JobStatus {
        val q = job.quality
        if (job.fileBase != null && MediaSaver.exists(app, job.fileBase, q.ext)) return JobStatus.Skipped

        val dir = File(app.cacheDir, "downloads/${job.id}")
        dir.deleteRecursively()
        dir.mkdirs()
        try {
            val name = (job.fileBase ?: "%(title).150B") + ".%(ext)s"
            val request = YoutubeDLRequest(job.source).apply {
                addOption("-f", q.format)
                addOption("-x")
                addOption("--audio-format", q.codec)
                q.bitrate?.let { addOption("--audio-quality", it) }
                addOption("--embed-metadata")
                addOption("--embed-thumbnail")
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--no-warnings")
                addOption("--retries", 5)
                addOption("-o", File(dir, name).absolutePath)
                // Write the Spotify title/artist into the file instead of the video's.
                val commands = ArrayList<String>()
                if (job.title != null) {
                    commands += listOf("--parse-metadata", ":(?P<meta_title>)")
                    commands += listOf("--replace-in-metadata", "meta_title", "^$", escapeReplacement(job.title))
                }
                if (job.artist != null) {
                    commands += listOf("--parse-metadata", ":(?P<meta_artist>)")
                    commands += listOf("--replace-in-metadata", "meta_artist", "^$", escapeReplacement(job.artist))
                }
                if (commands.isNotEmpty()) addCommands(commands)
            }

            var lastShown = -1
            val onProgress: (Float, Long, String) -> Unit = { progress, _, _ ->
                val whole = progress.toInt()
                if (whole != lastShown && progress >= 0f) {
                    lastShown = whole
                    setJob(job.id) { it.copy(progress = progress) }
                }
            }
            YoutubeDL.getInstance().execute(request, job.id, onProgress)

            val file = dir.listFiles()
                ?.filter { it.isFile && it.extension.equals(q.ext, ignoreCase = true) }
                ?.maxByOrNull { it.length() }
                ?: throw IllegalStateException("No ${q.ext} file came out of the download.")
            MediaSaver.save(app, file)
            return JobStatus.Done
        } finally {
            dir.deleteRecursively()
        }
    }

    private suspend fun ensureReady() {
        initLock.withLock {
            if (initialized) return@withLock
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            initialized = true
            updateIfStale()
        }
    }

    /** YouTube changes often; keep yt-dlp current (at most one check a day). */
    private fun updateIfStale() {
        val prefs = app.getSharedPreferences("downloader", Context.MODE_PRIVATE)
        val last = prefs.getLong("lastUpdate", 0L)
        val now = System.currentTimeMillis()
        if (now - last < UPDATE_EVERY_MS) return
        try {
            YoutubeDL.getInstance().updateYoutubeDL(app)
            prefs.edit().putLong("lastUpdate", now).apply()
        } catch (e: Exception) {
            // Offline or GitHub unreachable: keep the current version and try again next time.
        }
    }

    private fun setJob(id: String, change: (DownloadJob) -> DownloadJob) {
        _jobs.update { list -> list.map { if (it.id == id) change(it) else it } }
    }

    private fun startService() {
        runCatching {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        }
    }

    /** Python's re.sub treats backslashes in the replacement specially. */
    private fun escapeReplacement(text: String): String = text.replace("\\", "\\\\")

    fun safeName(text: String): String =
        text.replace(Regex("""[\\/:*?"<>|]+"""), "").trim().take(150).ifEmpty { "track" }

    private fun shortError(e: Throwable): String {
        val lines = (e.message ?: e.javaClass.simpleName).lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.lastOrNull { it.startsWith("ERROR:") } ?: lines.firstOrNull() ?: "Unknown error"
        return line.removePrefix("ERROR:").trim().take(160)
    }
}
