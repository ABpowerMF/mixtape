package dev.mixtape.player.spotify

import dev.mixtape.player.data.SpotifyTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Reads song lists from public Spotify links (track, album or playlist) without logging in.
 * Uses the same page Spotify's embeddable player uses. Only names, artists and lengths are read.
 * All calls are blocking: use Dispatchers.IO.
 */
object SpotifyPublic {

    data class Result(
        val kind: String,
        val id: String,
        val name: String,
        val imageUrl: String?,
        val tracks: List<SpotifyTrack>,
    )

    private val LINK = Regex("""open\.spotify\.com/(?:intl-[a-zA-Z-]+/)?(track|album|playlist)/([A-Za-z0-9]+)""")
    private val NEXT_DATA = Regex("""<script id="__NEXT_DATA__"[^>]*>(.*?)</script>""", RegexOption.DOT_MATCHES_ALL)
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36"

    fun isSpotifyLink(text: String): Boolean = LINK.containsMatchIn(text)

    /** ("playlist" | "album" | "track", id), or null if [text] has no Spotify link. */
    fun parseLink(text: String): Pair<String, String>? =
        LINK.find(text)?.let { it.groupValues[1] to it.groupValues[2] }

    fun fetch(link: String): Result {
        val (kind, id) = parseLink(link) ?: throw IOException("That isn't a Spotify track, album or playlist link.")
        return fetch(kind, id)
    }

    fun fetch(kind: String, id: String): Result {
        val page = get("https://open.spotify.com/embed/$kind/$id")
        val json = NEXT_DATA.find(page)?.groupValues?.get(1)
            ?: throw IOException("Spotify didn't return the song list. Check that the link is public.")
        val root = JSONObject(json)
        val entity = findKey(root, "entity") as? JSONObject
            ?: throw IOException("Spotify didn't return the song list. Check that the link is public.")

        val name = entity.optString("name").ifEmpty { entity.optString("title") }.ifEmpty { "Spotify $kind" }
        val image = (findKey(entity, "sources") as? JSONArray)?.optJSONObject(0)?.optString("url")?.ifEmpty { null }

        var tracks = if (kind == "track") {
            val artists = namesOf(entity.optJSONArray("artists"))
                .ifEmpty { splitArtists(entity.optString("subtitle")) }
            listOf(SpotifyTrack(id, name, artists, "", entity.optLong("duration")))
        } else {
            embedTrackList(entity.optJSONArray("trackList"))
        }

        // The embed page stops at 100 songs. Try to page through the full list.
        if (kind != "track" && tracks.size >= 50) {
            val token = findKey(root, "accessToken") as? String
            if (!token.isNullOrEmpty()) {
                val full = runCatching { fullList(kind, id, token) }.getOrNull()
                if (full != null && full.size > tracks.size) tracks = full
            }
        }
        if (tracks.isEmpty()) throw IOException("That Spotify link has no songs.")
        return Result(kind, id, name, image, tracks)
    }

    private fun embedTrackList(list: JSONArray?): List<SpotifyTrack> {
        if (list == null) return emptyList()
        val out = ArrayList<SpotifyTrack>()
        for (i in 0 until list.length()) {
            val t = list.optJSONObject(i) ?: continue
            val title = t.optString("title").trim()
            if (title.isEmpty()) continue
            val artists = splitArtists(t.optString("subtitle"))
            val uri = t.optString("uri")
            val id = uri.substringAfterLast(':').ifEmpty { "embed:$title|${artists.joinToString(",")}" }
            out += SpotifyTrack(id, title, artists, "", t.optLong("duration"))
        }
        return out
    }

    private fun fullList(kind: String, id: String, token: String): List<SpotifyTrack> {
        val out = ArrayList<SpotifyTrack>()
        var url: String? = if (kind == "album") {
            "https://api.spotify.com/v1/albums/$id/tracks?limit=50"
        } else {
            "https://api.spotify.com/v1/playlists/$id/tracks?limit=100"
        }
        var pages = 0
        while (url != null && pages < 100) {
            pages++
            val page = JSONObject(get(url, token))
            val items = page.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val wrapper = items.optJSONObject(i) ?: continue
                val t = wrapper.optJSONObject("track") ?: wrapper.optJSONObject("item") ?: wrapper
                if (t.optString("type", "track") != "track") continue
                val title = t.optString("name").trim()
                if (title.isEmpty()) continue
                val artists = namesOf(t.optJSONArray("artists"))
                val trackId = t.optString("id").ifEmpty { "embed:$title|${artists.joinToString(",")}" }
                out += SpotifyTrack(
                    id = trackId,
                    title = title,
                    artists = artists,
                    album = t.optJSONObject("album")?.optString("name").orEmpty(),
                    durationMs = t.optLong("duration_ms"),
                )
            }
            url = page.optString("next").takeIf { it.startsWith("http") }
        }
        return out
    }

    private fun namesOf(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            arr.optJSONObject(i)?.optString("name")?.trim()?.ifEmpty { null }
        }
    }

    private fun splitArtists(subtitle: String): List<String> =
        subtitle.replace('\u00a0', ' ').split(", ").map { it.trim() }.filter { it.isNotEmpty() }

    /** Depth-first search for the first value stored under [key]. */
    private fun findKey(node: Any?, key: String): Any? {
        when (node) {
            is JSONObject -> {
                if (node.has(key) && !node.isNull(key)) return node.opt(key)
                val keys = node.keys()
                while (keys.hasNext()) {
                    val found = findKey(node.opt(keys.next()), key)
                    if (found != null) return found
                }
            }
            is JSONArray -> for (i in 0 until node.length()) {
                val found = findKey(node.opt(i), key)
                if (found != null) return found
            }
        }
        return null
    }

    private fun get(url: String, bearer: String? = null): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept-Language", "en")
            if (bearer != null) setRequestProperty("Authorization", "Bearer $bearer")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Spotify returned error $code.")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }
}
