package dev.mixtape.player.download

/**
 * Audio formats for downloads. YouTube's best audio is about 160 kbps Opus, so "original"
 * formats keep that as-is, and higher MP3 bitrates or FLAC can't add quality on top of it.
 */
enum class Quality(
    val label: String,
    val note: String,
    val ext: String,
    val format: String,
    val codec: String,
    val bitrate: String?,
) {
    MP3_128("MP3 128 kbps", "Smallest files", "mp3", "bestaudio/best", "mp3", "128K"),
    MP3_192("MP3 192 kbps", "Good balance", "mp3", "bestaudio/best", "mp3", "192K"),
    MP3_320("MP3 320 kbps", "Largest MP3", "mp3", "bestaudio/best", "mp3", "320K"),
    M4A("M4A original", "Fastest, no conversion", "m4a", "bestaudio[ext=m4a]/bestaudio/best", "m4a", null),
    OPUS("Opus original", "Best real quality, no conversion", "opus", "bestaudio[acodec=opus]/bestaudio/best", "opus", null),
    FLAC("FLAC lossless", "Big files, sounds the same as Opus", "flac", "bestaudio/best", "flac", null);

    companion object {
        val DEFAULT = MP3_192
        fun fromName(name: String?): Quality = entries.firstOrNull { it.name == name } ?: DEFAULT
    }
}
