package dev.mixtape.player.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.download.DownloadJob
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.download.JobStatus
import dev.mixtape.player.download.MediaSaver
import dev.mixtape.player.download.Quality
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadScreen(vm: MainViewModel) {
    val jobs by DownloadQueue.jobs.collectAsStateWithLifecycle()
    val reading by DownloadQueue.reading.collectAsStateWithLifecycle()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var askedForNotifications by remember { mutableStateOf(false) }
    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun download() {
        if (Build.VERSION.SDK_INT >= 33 && !askedForNotifications &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedForNotifications = true
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        vm.startDownload()
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Download", style = MaterialTheme.typography.titleLarge) },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )

        Column(Modifier.padding(horizontal = 20.dp)) {
            OutlinedTextField(
                value = vm.linkDraft,
                onValueChange = { vm.linkDraft = it },
                singleLine = true,
                placeholder = { Text("YouTube or Spotify link") },
                trailingIcon = {
                    IconButton(onClick = { clipboard.getText()?.text?.let { vm.linkDraft = it.trim() } }) {
                        Icon(Icons.Filled.ContentPaste, contentDescription = "Paste")
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                QualityPicker(vm.quality, vm::chooseQuality, Modifier.weight(1f))
                Spacer(Modifier.width(12.dp))
                Button(
                    onClick = ::download,
                    enabled = vm.linkDraft.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                ) {
                    Text("Download")
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "Songs, albums and playlists from YouTube or Spotify. Saved to ${MediaSaver.FOLDER}. " +
                    "Tip: share a link to Mixtape from any app.",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
            )
        }

        if (reading > 0) {
            Row(
                Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CircularProgressIndicator(Modifier.size(18.dp), color = Mix.Tape, strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Text("Reading link…", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
            }
        }

        if (jobs.isEmpty()) {
            if (reading == 0) {
                Box(Modifier.weight(1f)) {
                    EmptyState(
                        title = "Nothing downloading",
                        body = "Paste a link above. In a playlist, you can also tap Download missing " +
                            "to fetch only the songs you don't have yet.",
                    )
                }
            }
        } else {
            val finished = jobs.count { it.finished }
            val failed = jobs.count { it.status == JobStatus.Failed }
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    buildString {
                        append("$finished of ${jobs.size} done")
                        if (failed > 0) append(" · $failed failed")
                    },
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                if (finished < jobs.size) {
                    TextButton(onClick = DownloadQueue::cancelAll) { Text("Stop all", color = Mix.Alert) }
                }
                if (finished > 0) {
                    TextButton(onClick = DownloadQueue::clearFinished) { Text("Clear done", color = Mix.Tape) }
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(jobs, key = { it.id }) { job -> JobRow(job) }
            }
        }
    }
}

@Composable
private fun QualityPicker(current: Quality, onPick: (Quality) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(current.label, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            Quality.entries.forEach { q ->
                DropdownMenuItem(
                    text = {
                        Column {
                            Text(
                                q.label,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (q == current) Mix.Tape else Mix.Paper,
                            )
                            Text(q.note, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                        }
                    },
                    onClick = {
                        open = false
                        onPick(q)
                    },
                )
            }
        }
    }
}

@Composable
private fun JobRow(job: DownloadJob) {
    val canRetry = job.status == JobStatus.Failed || job.status == JobStatus.Canceled
    Column(
        Modifier
            .fillMaxWidth()
            .then(if (canRetry) Modifier.clickable { DownloadQueue.retry(job.id) } else Modifier)
            .padding(horizontal = 20.dp, vertical = 10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(job.label, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    statusText(job),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (job.status == JobStatus.Failed) Mix.Alert else Mix.Fog,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.width(12.dp))
            when (job.status) {
                JobStatus.Done, JobStatus.Skipped ->
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = Mix.Tape, modifier = Modifier.size(20.dp))
                JobStatus.Failed ->
                    Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = Mix.Alert, modifier = Modifier.size(20.dp))
                JobStatus.Canceled ->
                    Icon(Icons.Filled.Refresh, contentDescription = "Retry", tint = Mix.Fog, modifier = Modifier.size(20.dp))
                else -> Unit
            }
        }
        if (job.status == JobStatus.Running) {
            Spacer(Modifier.height(6.dp))
            if (job.progress in 0.5f..99.5f) {
                LinearProgressIndicator(
                    progress = { job.progress / 100f },
                    modifier = Modifier.fillMaxWidth(),
                    color = Mix.Tape,
                    trackColor = Mix.Gap,
                )
            } else {
                LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mix.Tape, trackColor = Mix.Gap)
            }
        }
    }
}

private fun statusText(job: DownloadJob): String = when (job.status) {
    JobStatus.Queued -> "Waiting · ${job.quality.label}"
    JobStatus.Running -> when {
        job.progress <= 0.5f -> "Finding the song…"
        job.progress >= 99.5f -> "Converting…"
        else -> "Downloading ${job.progress.toInt()}%"
    }
    JobStatus.Done -> "Saved · ${job.quality.label}"
    JobStatus.Skipped -> "Already on this phone"
    JobStatus.Failed -> "Failed: ${job.message ?: "unknown error"} · tap to retry"
    JobStatus.Canceled -> "Stopped · tap to retry"
}
