package dev.mixtape.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import dev.mixtape.player.R

/** Night-drive palette: ink-blue dashboard, paper text, cassette-label yellow for what's on the phone. */
object Mix {
    val Ink = Color(0xFF16202E)     // background
    val Deep = Color(0xFF1E2A3A)    // sheets, player bar
    val Raised = Color(0xFF2A3950)  // artwork placeholders, chips
    val Gap = Color(0xFF34455C)     // missing songs in the match strip
    val Paper = Color(0xFFEAF0F7)   // main text
    val Fog = Color(0xFF8FA1B8)     // secondary text
    val Tape = Color(0xFFF2C14E)    // accent: songs found, play
    val Alert = Color(0xFFFF8A7A)
}

val Barlow = FontFamily(
    Font(R.font.barlow_regular, FontWeight.Normal),
    Font(R.font.barlow_medium, FontWeight.Medium),
    Font(R.font.barlow_semibold, FontWeight.SemiBold),
    Font(R.font.barlow_bold, FontWeight.Bold),
)

private val scheme = darkColorScheme(
    primary = Mix.Tape,
    onPrimary = Mix.Ink,
    primaryContainer = Mix.Raised,
    onPrimaryContainer = Mix.Paper,
    secondary = Mix.Fog,
    onSecondary = Mix.Ink,
    secondaryContainer = Mix.Raised,
    onSecondaryContainer = Mix.Paper,
    background = Mix.Ink,
    onBackground = Mix.Paper,
    surface = Mix.Ink,
    onSurface = Mix.Paper,
    surfaceVariant = Mix.Raised,
    onSurfaceVariant = Mix.Fog,
    surfaceContainerLowest = Mix.Ink,
    surfaceContainerLow = Mix.Deep,
    surfaceContainer = Mix.Deep,
    surfaceContainerHigh = Mix.Raised,
    surfaceContainerHighest = Mix.Raised,
    inverseSurface = Mix.Paper,
    inverseOnSurface = Mix.Ink,
    outline = Mix.Gap,
    outlineVariant = Mix.Gap,
    error = Mix.Alert,
    onError = Mix.Ink,
)

private val base = Typography()
private fun TextStyle.barlow(size: Int? = null, weight: FontWeight? = null, line: Int? = null) = copy(
    fontFamily = Barlow,
    fontSize = size?.sp ?: fontSize,
    fontWeight = weight ?: fontWeight,
    lineHeight = line?.sp ?: lineHeight,
)

private val type = Typography(
    displayLarge = base.displayLarge.barlow(),
    displayMedium = base.displayMedium.barlow(),
    displaySmall = base.displaySmall.barlow(size = 30, weight = FontWeight.SemiBold, line = 36),
    headlineLarge = base.headlineLarge.barlow(weight = FontWeight.SemiBold),
    headlineMedium = base.headlineMedium.barlow(weight = FontWeight.SemiBold),
    headlineSmall = base.headlineSmall.barlow(weight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.barlow(size = 24, weight = FontWeight.SemiBold, line = 30),
    titleMedium = base.titleMedium.barlow(size = 17, weight = FontWeight.Medium, line = 22),
    titleSmall = base.titleSmall.barlow(weight = FontWeight.Medium),
    bodyLarge = base.bodyLarge.barlow(size = 17, line = 24),
    bodyMedium = base.bodyMedium.barlow(size = 15, line = 20),
    bodySmall = base.bodySmall.barlow(size = 13, line = 18),
    labelLarge = base.labelLarge.barlow(size = 16, weight = FontWeight.SemiBold),
    labelMedium = base.labelMedium.barlow(size = 14, weight = FontWeight.Medium),
    labelSmall = base.labelSmall.barlow(),
)

@Composable
fun MixtapeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}
