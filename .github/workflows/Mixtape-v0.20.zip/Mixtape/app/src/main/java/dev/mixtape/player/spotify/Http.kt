package dev.mixtape.player.spotify

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

internal data class HttpResult(val code: Int, val body: String, val retryAfterSec: Long?)

/** Tiny blocking HTTP helper. Always call from Dispatchers.IO. */
internal object Http {

    fun get(url: String, bearer: String): HttpResult {
        val conn = open(url).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "Bearer $bearer")
        }
        return read(conn)
    }

    fun postForm(url: String, form: Map<String, String>): HttpResult {
        val body = form.entries.joinToString("&") { (k, v) ->
            "${URLEncoder.encode(k, "UTF-8")}=${URLEncoder.encode(v, "UTF-8")}"
        }
        val conn = open(url).apply {
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return read(conn)
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
        }

    private fun read(conn: HttpURLConnection): HttpResult {
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            val retry = conn.getHeaderField("Retry-After")?.trim()?.toLongOrNull()
            return HttpResult(code, body, retry)
        } finally {
            conn.disconnect()
        }
    }
}
