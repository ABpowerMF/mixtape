package dev.mixtape.player.spotify

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Catches Spotify's login redirect to http://127.0.0.1:PORT/callback.
 * The browser on the phone opens that address, and this tiny server inside the app answers it.
 */
class LoopbackReceiver(private val port: Int) {

    /** Starts listening and returns the socket. Call on a background thread, before opening the login page. */
    fun open(): ServerSocket = ServerSocket().apply {
        reuseAddress = true
        soTimeout = TIMEOUT_MS
        bind(InetSocketAddress(InetAddress.getByName("127.0.0.1"), port))
    }

    /** Waits for the redirect and returns its query parameters (code + state, or error). */
    suspend fun awaitCallback(server: ServerSocket): Map<String, String> = withContext(Dispatchers.IO) {
        var result: Map<String, String>? = null
        while (result == null) {
            val socket = server.accept()
            // A stray connection (browser preconnect, favicon) must not end the login.
            result = socket.use { runCatching { handle(it) }.getOrNull() }
        }
        checkNotNull(result)
    }

    private fun handle(socket: Socket): Map<String, String>? {
        socket.soTimeout = 10_000
        val reader = socket.getInputStream().bufferedReader()
        val requestLine = reader.readLine() ?: return null
        // Read the rest of the headers so closing the socket doesn't reset the connection.
        while (true) {
            val line = reader.readLine() ?: break
            if (line.isEmpty()) break
        }
        val target = requestLine.split(' ').getOrNull(1) ?: return null
        val uri = Uri.parse("http://127.0.0.1$target")
        if (uri.path != "/callback") {
            write(socket, 404, "Not Found", "")
            return null
        }
        val params = uri.queryParameterNames.associateWith { uri.getQueryParameter(it).orEmpty() }
        write(socket, 200, "OK", if (params.containsKey("code")) SUCCESS_PAGE else FAILED_PAGE)
        return params
    }

    private fun write(socket: Socket, status: Int, reason: String, html: String) {
        val out = socket.getOutputStream()
        val body = html.toByteArray(Charsets.UTF_8)
        val head = "HTTP/1.1 $status $reason\r\n" +
            "Content-Type: text/html; charset=utf-8\r\n" +
            "Content-Length: ${body.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.US_ASCII))
        out.write(body)
        out.flush()
        socket.shutdownOutput()
    }

    private companion object {
        const val TIMEOUT_MS = 5 * 60 * 1000

        val STYLE = "body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;" +
            "background:#16202E;color:#EAF0F7;font-family:sans-serif;text-align:center;padding:24px;box-sizing:border-box}" +
            "p{color:#8FA1B8}a{display:inline-block;margin-top:16px;padding:14px 28px;border-radius:28px;" +
            "background:#F2C14E;color:#16202E;font-weight:600;text-decoration:none}"

        val SUCCESS_PAGE = "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<title>Mixtape</title><style>$STYLE</style></head><body><div>" +
            "<h2>Spotify is connected</h2><p>Your playlists are loading in Mixtape.</p>" +
            "<a href=\"mixtape://back\">Back to Mixtape</a></div></body></html>"

        val FAILED_PAGE = "<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<title>Mixtape</title><style>$STYLE</style></head><body><div>" +
            "<h2>Spotify login didn't finish</h2><p>Go back to Mixtape and tap Connect Spotify to try again.</p>" +
            "<a href=\"mixtape://back\">Back to Mixtape</a></div></body></html>"
    }
}
