package dev.mixtape.player.spotify

import dev.mixtape.player.data.SpotifyTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

/**
 * Reads playlists from files the user brings, fully offline:
 *  - Spotify's "Download your data" zip (YourLibrary.json = liked songs, Playlist1.json… = playlists),
 *    or those JSON files on their own
 *  - CSV exports from TuneMyMusic, Soundiiz, Exportify… (a "playlist" column splits it into playlists)
 *  - plain text with one "Artist - Title" per line
 */
object LibraryImport {

    data class ImportedPlaylist(val name: String, val tracks: List<SpotifyTrack>)

    fun read(bytes: ByteArray, fileName: String?): List<ImportedPlaylist> {
        val isZip = bytes.size > 4 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'K'.code.toByte()
        if (isZip) return fromZip(bytes)
        val text = String(bytes, Charsets.UTF_8).removePrefix("\uFEFF")
        if (text.trimStart().startsWith("{")) {
            fromSpotifyJson(fileName.orEmpty(), text).takeIf { it.isNotEmpty() }?.let { return it }
        }
        return fromText(text, fileName)
    }

    private fun fromZip(bytes: ByteArray): List<ImportedPlaylist> {
        val out = ArrayList<ImportedPlaylist>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.substringAfterLast('/')
                val wanted = name.equals("YourLibrary.json", true) ||
                    (name.startsWith("Playlist", true) && name.endsWith(".json", true))
                if (!entry.isDirectory && wanted) {
                    out += fromSpotifyJson(name, zip.readBytes().toString(Charsets.UTF_8))
                }
            }
        }
        return out
    }

    private fun fromSpotifyJson(fileName: String, text: String): List<ImportedPlaylist> {
        val root = runCatching { JSONObject(text) }.getOrNull() ?: return emptyList()
        val out = ArrayList<ImportedPlaylist>()

        // YourLibrary.json: liked songs
        root.optJSONArray("tracks")?.let { arr ->
            val tracks = (0 until arr.length()).mapNotNull { i ->
                val t = arr.optJSONObject(i) ?: return@mapNotNull null
                track(t.optString("track"), t.optString("artist"), t.optString("album"), t.optString("uri"), i)
            }
            if (tracks.isNotEmpty()) out += ImportedPlaylist("Liked Songs", tracks)
        }

        // Playlist1.json, Playlist2.json…: every playlist, private ones too
        root.optJSONArray("playlists")?.let { lists ->
            for (p in 0 until lists.length()) {
                val pl = lists.optJSONObject(p) ?: continue
                val items = pl.optJSONArray("items") ?: JSONArray()
                val tracks = (0 until items.length()).mapNotNull { i ->
                    val t = items.optJSONObject(i)?.optJSONObject("track") ?: return@mapNotNull null
                    track(t.optString("trackName"), t.optString("artistName"), t.optString("albumName"), t.optString("trackUri"), i)
                }
                if (tracks.isNotEmpty()) out += ImportedPlaylist(pl.optString("name").ifEmpty { "Playlist ${p + 1}" }, tracks)
            }
        }
        return out
    }

    private fun track(title: String, artist: String, album: String, uri: String, index: Int): SpotifyTrack? {
        if (title.isBlank()) return null
        val id = uri.substringAfterLast(':').takeIf { uri.startsWith("spotify:track:") && it.length == 22 }
            ?: "file:$index:$title"
        val artists = artist.split(", ").map { it.trim() }.filter { it.isNotEmpty() }
        return SpotifyTrack(id, title.trim(), artists, album.trim(), 0L)
    }

    private fun fromText(text: String, fileName: String?): List<ImportedPlaylist> {
        val defaultName = fileName?.substringBeforeLast('.')?.ifBlank { null } ?: "Imported playlist"
        val first = text.lineSequence().firstOrNull().orEmpty().lowercase()
        if (first.contains(",") && first.contains("artist")) {
            val rows = WebParsing.parseCsv(text)
            val header = rows.first().map { it.trim().lowercase() }
            val listCol = header.indexOfFirst { it.contains("playlist") }
            if (listCol >= 0) {
                val songs = WebParsing.songsFromText(text)
                // Same order as the rows, grouped by the playlist column.
                val names = rows.drop(1).filter { r -> r.any { it.isNotBlank() } }.map { it.getOrNull(listCol)?.trim().orEmpty() }
                if (names.size == songs.size) {
                    return songs.zip(names).groupBy({ it.second.ifEmpty { defaultName } }, { it.first }).map { (name, list) ->
                        ImportedPlaylist(name, list.mapIndexed { i, (title, artists) -> SpotifyTrack("file:$i:$title", title, artists, "", 0L) })
                    }
                }
            }
        }
        val songs = WebParsing.songsFromText(text)
        if (songs.isEmpty()) return emptyList()
        return listOf(ImportedPlaylist(defaultName, songs.mapIndexed { i, (title, artists) -> SpotifyTrack("file:$i:$title", title, artists, "", 0L) }))
    }
}
