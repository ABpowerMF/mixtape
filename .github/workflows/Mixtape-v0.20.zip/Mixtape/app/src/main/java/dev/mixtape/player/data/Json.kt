package dev.mixtape.player.data

import org.json.JSONObject

/** Reads a string field, treating missing, JSON null and "" as null. */
fun JSONObject.str(key: String): String? =
    if (isNull(key)) null else optString(key).takeIf { it.isNotEmpty() }
