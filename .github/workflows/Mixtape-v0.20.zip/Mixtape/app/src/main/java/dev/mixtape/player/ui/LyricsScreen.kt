package dev.mixtape.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.lyrics.Lrc
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsScreen(vm: MainViewModel) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    var menu by remember { mutableStateOf(false) }
    var pasting by remember { mutableStateOf(false) }

    // Follow the song: new song, new lyrics.
    LaunchedEffect(now.mediaId) { vm.loadLyrics(now.mediaId) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text("~/lyrics", style = MaterialTheme.typography.titleLarge)
                    if (now.title.isNotEmpty()) {
                        Text(
                            "${now.title} · ${now.artist}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            actions = {
                IconButton(onClick = { menu = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Search again") }, onClick = {
                        menu = false
                        vm.loadLyrics(now.mediaId, force = true)
                    })
                    DropdownMenuItem(text = { Text("Paste my own lyrics") }, onClick = {
                        menu = false
                        pasting = true
                    })
                    DropdownMenuItem(text = { Text("Remove saved lyrics", color = Mix.Alert) }, onClick = {
                        menu = false
                        vm.removeLyrics()
                    })
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )

        when (val state = vm.lyricsState) {
            MainViewModel.LyricsState.Idle, MainViewModel.LyricsState.Loading -> Message("searching for lyrics…")
            MainViewModel.LyricsState.NotFound -> Column(Modifier.padding(20.dp)) {
                Text(
                    if (vm.lyricsOnline) "No lyrics found for this song." else "No saved lyrics. Online search is off in Settings.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Mix.Fog,
                )
                Spacer(Modifier.height(12.dp))
                Row {
                    TextButton(onClick = { vm.loadLyrics(now.mediaId, force = true) }) { Text("[ search again ]", color = Mix.Tape) }
                    TextButton(onClick = { pasting = true }) { Text("[ paste lyrics ]", color = Mix.Tape) }
                }
            }
            is MainViewModel.LyricsState.Found -> {
                val lyrics = state.lyrics
                when {
                    lyrics.synced.isNotEmpty() -> SyncedLyrics(vm, lyrics.synced, now.positionMs)
                    lyrics.plain != null -> Text(
                        lyrics.plain,
                        style = MaterialTheme.typography.bodyLarge.copy(lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.3f),
                        color = Mix.Paper,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(20.dp),
                    )
                    else -> Message("♪ instrumental")
                }
            }
        }
    }

    if (pasting) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { pasting = false },
            title = { Text("> paste lyrics") },
            text = {
                Column {
                    Text(
                        "Plain text, or LRC with [mm:ss] times for synced lyrics. Saved on this phone only.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 160.dp, max = 320.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    pasting = false
                    vm.pasteLyrics(text)
                }) { Text("Save", color = Mix.Tape) }
            },
            dismissButton = { TextButton(onClick = { pasting = false }) { Text("Cancel", color = Mix.Paper) } },
            containerColor = Mix.Deep,
        )
    }
}

@Composable
private fun Message(text: String) {
    Box(Modifier.padding(20.dp)) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = Mix.Fog)
    }
}

/** Synced lyrics: the current line lights up and stays near the top; tap a line to jump there. */
@Composable
private fun SyncedLyrics(vm: MainViewModel, lines: List<dev.mixtape.player.lyrics.LyricLine>, positionMs: Long) {
    val listState = rememberLazyListState()
    val current = Lrc.currentIndex(lines, positionMs + 300)
    LaunchedEffect(current) {
        if (current >= 0 && !listState.isScrollInProgress) {
            listState.animateScrollToItem((current - 2).coerceAtLeast(0))
        }
    }
    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 24.dp)) {
        itemsIndexed(lines) { i, line ->
            val active = i == current
            Text(
                line.text.ifEmpty { "♪" },
                style = if (active) {
                    MaterialTheme.typography.titleLarge
                } else {
                    MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Normal)
                },
                color = when {
                    active -> Mix.Tape
                    i < current -> Mix.Fog
                    else -> Mix.Paper
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.player.seekTo(line.timeMs) }
                    .padding(horizontal = 20.dp, vertical = 8.dp),
            )
        }
    }
}
