package dev.mixtape.player.playback

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import dev.mixtape.player.library.LocalTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class NowPlaying(
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val artworkUri: Uri? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
)

/** One song in the play queue. [index] is its place in the player's list. */
data class QueueEntry(val index: Int, val mediaId: String, val title: String, val artist: String, val current: Boolean)

/** Talks to [PlaybackService] and exposes what's playing as a StateFlow. Use from the main thread. */
class PlayerConnection(context: Context, scope: CoroutineScope) {

    private val _state = MutableStateFlow(NowPlaying())
    val state: StateFlow<NowPlaying> = _state.asStateFlow()

    /** The current song followed by what plays next, in play order (shuffle included). */
    private val _queue = MutableStateFlow<List<QueueEntry>>(emptyList())
    val queue: StateFlow<List<QueueEntry>> = _queue.asStateFlow()

    private var controller: MediaController? = null
    private val pending = mutableListOf<(MediaController) -> Unit>()
    private val future: ListenableFuture<MediaController>

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh()
            if (events.containsAny(
                    Player.EVENT_TIMELINE_CHANGED,
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED,
                )
            ) {
                refreshQueue()
            }
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            refresh()
            refreshQueue()
            pending.forEach { it(c) }
            pending.clear()
        }, ContextCompat.getMainExecutor(context))

        // Keep the progress bar moving while music plays.
        scope.launch {
            while (true) {
                delay(500)
                if (controller?.isPlaying == true) refresh()
            }
        }
    }

    /** Replaces the queue with [tracks] and starts at [startIndex]. [shuffle] null keeps the current setting. */
    fun play(tracks: List<LocalTrack>, startIndex: Int, shuffle: Boolean?) = withController { c ->
        c.setMediaItems(tracks.map { it.toMediaItem() }, startIndex.coerceIn(0, tracks.lastIndex), 0L)
        if (shuffle != null) c.shuffleModeEnabled = shuffle
        c.prepare()
        c.play()
    }

    /** Swaps the playing song for another file (e.g. a different quality), keeping the position. */
    fun replaceCurrent(track: LocalTrack) = withController { c ->
        val index = c.currentMediaItemIndex
        val position = c.currentPosition
        val wasPlaying = c.isPlaying
        c.replaceMediaItem(index, track.toMediaItem())
        c.seekTo(index, position)
        if (wasPlaying) c.play()
    }

    /** Puts [tracks] right after the current song. */
    fun playNext(tracks: List<LocalTrack>) = withController { c ->
        if (tracks.isEmpty()) return@withController
        if (c.mediaItemCount == 0) {
            c.setMediaItems(tracks.map { it.toMediaItem() }, 0, 0L)
            c.prepare()
            c.play()
        } else {
            c.addMediaItems(c.currentMediaItemIndex + 1, tracks.map { it.toMediaItem() })
        }
    }

    /** Adds [tracks] to the end of the queue. */
    fun addToQueue(tracks: List<LocalTrack>) = withController { c ->
        if (tracks.isEmpty()) return@withController
        if (c.mediaItemCount == 0) {
            c.setMediaItems(tracks.map { it.toMediaItem() }, 0, 0L)
            c.prepare()
            c.play()
        } else {
            c.addMediaItems(tracks.map { it.toMediaItem() })
        }
    }

    fun jumpTo(index: Int) = withController { c ->
        if (index in 0 until c.mediaItemCount) {
            c.seekTo(index, 0L)
            c.play()
        }
    }

    fun removeFromQueue(index: Int) = withController { c ->
        if (index in 0 until c.mediaItemCount && index != c.currentMediaItemIndex) c.removeMediaItem(index)
    }

    /** Keeps only the song that's playing. */
    fun clearQueue() = withController { c ->
        val current = c.currentMediaItemIndex
        if (current + 1 < c.mediaItemCount) c.removeMediaItems(current + 1, c.mediaItemCount)
        if (current > 0) c.removeMediaItems(0, current)
    }

    private fun refreshQueue() {
        val c = controller ?: return
        val timeline = c.currentTimeline
        if (timeline.isEmpty || c.mediaItemCount == 0) {
            _queue.value = emptyList()
            return
        }
        val out = ArrayList<QueueEntry>()
        var i = c.currentMediaItemIndex
        while (i != C.INDEX_UNSET && out.size < c.mediaItemCount) {
            val item = c.getMediaItemAt(i)
            out += QueueEntry(
                index = i,
                mediaId = item.mediaId,
                title = item.mediaMetadata.title?.toString().orEmpty(),
                artist = item.mediaMetadata.artist?.toString().orEmpty(),
                current = i == c.currentMediaItemIndex,
            )
            i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
        }
        _queue.value = out
    }

    /** Back to the song played before (not just the start of this one). */
    fun previousSong() = withController { it.seekToPreviousMediaItem() }

    fun toggle() = withController { c -> if (c.isPlaying) c.pause() else c.play() }
    fun next() = withController { it.seekToNext() }
    fun previous() = withController { it.seekToPrevious() }
    fun seekTo(ms: Long) = withController { it.seekTo(ms) }
    fun toggleShuffle() = withController { it.shuffleModeEnabled = !it.shuffleModeEnabled }

    fun cycleRepeat() = withController { c ->
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun release() {
        controller?.removeListener(listener)
        controller = null
        MediaController.releaseFuture(future)
    }

    private fun withController(action: (MediaController) -> Unit) {
        val c = controller
        if (c != null) action(c) else pending += action
    }

    private fun refresh() {
        val c = controller ?: return
        val md = c.mediaMetadata
        val duration = c.duration
        _state.value = NowPlaying(
            mediaId = c.currentMediaItem?.mediaId,
            title = md.title?.toString().orEmpty(),
            artist = md.artist?.toString().orEmpty(),
            artworkUri = md.artworkUri,
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = if (duration == C.TIME_UNSET) 0L else duration.coerceAtLeast(0L),
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
        )
    }

    private fun LocalTrack.toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist.ifEmpty { null })
                    .setAlbumTitle(album.ifEmpty { null })
                    .setArtworkUri(artUri)
                    .build()
            )
            .build()
}
