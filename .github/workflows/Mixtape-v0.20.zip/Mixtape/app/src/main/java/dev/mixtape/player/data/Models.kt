package dev.mixtape.player.data

import dev.mixtape.player.library.LocalTrack

/** Id used for the Liked Songs "playlist". */
const val LIKED_ID = "liked"

/** A song as listed in a Spotify playlist (metadata only, no audio). */
data class SpotifyTrack(
    val id: String,
    val title: String,
    val artists: List<String>,
    val album: String,
    val durationMs: Long,
)

/** A Spotify playlist summary, used on the import screen. */
data class SpotifyPlaylistSummary(
    val id: String,
    val name: String,
    val imageUrl: String?,
    val trackCount: Int,
    val ownerName: String,
    /** Spotify only returns songs for playlists you own or collaborate on. */
    val canImport: Boolean,
)

/** An imported playlist, stored on the phone. */
data class SavedPlaylist(
    val id: String,
    val name: String,
    val imageUrl: String?,
    val tracks: List<SpotifyTrack>,
    val importedAt: Long,
)

/** One playlist position and the file on this phone that fills it (if any). */
data class PlaylistRow(
    val track: SpotifyTrack,
    val local: LocalTrack?,
    /** True when you picked the file yourself instead of the automatic match. */
    val manual: Boolean,
)
