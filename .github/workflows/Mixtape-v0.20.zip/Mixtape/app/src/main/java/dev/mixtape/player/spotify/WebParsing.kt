package dev.mixtape.player.spotify

import java.nio.ByteBuffer
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Small pure helpers used to read Spotify's web player and playlist exports. No Android or network code. */
object WebParsing {

    /** Spotify web player TOTP: the secret is XOR-scrambled, joined as decimal text, then used as an HMAC-SHA1 key. */
    fun totp(secret: IntArray, timeMs: Long): String {
        val joined = secret.mapIndexed { t, e -> e xor ((t % 33) + 9) }.joinToString("")
        val key = joined.toByteArray(Charsets.US_ASCII)
        val counter = timeMs / 1000 / 30
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(key, "HmacSHA1"))
        val h = mac.doFinal(ByteBuffer.allocate(8).putLong(counter).array())
        val o = h[h.size - 1].toInt() and 0xf
        val bin = ((h[o].toInt() and 0x7f) shl 24) or
            ((h[o + 1].toInt() and 0xff) shl 16) or
            ((h[o + 2].toInt() and 0xff) shl 8) or
            (h[o + 3].toInt() and 0xff)
        return (bin % 1_000_000).toString().padStart(6, '0')
    }

    /** Finds the persisted-query hash for [operation] in web player JavaScript, or null. */
    fun findQueryHash(js: String, operation: String): String? =
        Regex("\"" + Regex.escape(operation) + "\",\"(?:query|mutation)\",\"([0-9a-f]{64})\"")
            .find(js)?.groupValues?.get(1)

    private val JS_MAP = Regex("""\{(\d+:"[^"]+"(?:,\d+:"[^"]+")*)\}""")
    private val JS_ENTRY = Regex("""(\d+):"([^"]+)"""")
    private val SHORT_HEX = Regex("^[0-9a-f]{6,20}$")

    /**
     * The web player loads its code in chunks named "name.hash.js". Its main file holds two maps
     * (chunk id -> name, chunk id -> hash). Finds them by shape rather than position, and returns
     * the file names, the ones that look playlist-related first.
     */
    fun chunkFiles(js: String): List<String> {
        val maps = JS_MAP.findAll(js).map { m ->
            JS_ENTRY.findAll(m.groupValues[1]).associate { it.groupValues[1].toInt() to it.groupValues[2] }
        }.filter { it.size >= 5 }.toList()

        val hashMaps = maps.filter { map -> map.values.all { SHORT_HEX.matches(it) } }
        val nameMaps = maps.filter { map -> map.values.count { !SHORT_HEX.matches(it) } > map.size / 2 }

        var best: Pair<Map<Int, String>, Map<Int, String>>? = null
        var bestOverlap = 0
        for (names in nameMaps) for (hashes in hashMaps) {
            val overlap = names.keys.count { it in hashes }
            if (overlap > bestOverlap) {
                bestOverlap = overlap
                best = names to hashes
            }
        }
        val (names, hashes) = best ?: return emptyList()
        val files = names.mapNotNull { (id, name) -> hashes[id]?.let { "$name.$it.js" } }
        return files.sortedByDescending { name ->
            when {
                name.contains("playlist", ignoreCase = true) -> 2
                name.contains("xpui", ignoreCase = true) -> 1
                else -> 0
            }
        }
    }

    /** Splits CSV text into rows (handles quotes, commas and line breaks inside quotes). */
    fun parseCsv(text: String): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') {
                        cell.append('"')
                        i++
                    } else {
                        quoted = false
                    }
                } else {
                    cell.append(c)
                }
            } else {
                when (c) {
                    '"' -> quoted = true
                    ',', ';', '\t' -> if (c == ',' || !text.contains(',')) {
                        row.add(cell.toString()); cell.setLength(0)
                    } else {
                        cell.append(c)
                    }
                    '\r' -> Unit
                    '\n' -> {
                        row.add(cell.toString()); cell.setLength(0)
                        if (row.any { it.isNotBlank() }) rows.add(row)
                        row = ArrayList()
                    }
                    else -> cell.append(c)
                }
            }
            i++
        }
        row.add(cell.toString())
        if (row.any { it.isNotBlank() }) rows.add(row)
        return rows
    }

    /**
     * Songs from a playlist export (CSV with track/artist columns, e.g. Exportify or TuneMyMusic)
     * or a text file with one "Artist - Title" per line. Returns (title, artists).
     */
    fun songsFromText(text: String): List<Pair<String, List<String>>> {
        val clean = text.removePrefix("\uFEFF")
        val firstLine = clean.lineSequence().firstOrNull().orEmpty().lowercase()
        val looksCsv = firstLine.contains(",") &&
            (firstLine.contains("track") || firstLine.contains("title") || firstLine.contains("song")) &&
            firstLine.contains("artist")
        if (looksCsv) {
            val rows = parseCsv(clean)
            val header = rows.first().map { it.trim().lowercase() }
            val titleCol = header.indexOfFirst { it == "track name" || it == "title" || it == "song" || it == "song name" || it == "name" || it == "track" }
                .takeIf { it >= 0 } ?: header.indexOfFirst { it.contains("track name") || it.contains("title") }
            val artistCol = header.indexOfFirst { it.contains("artist") }
            if (titleCol >= 0) {
                return rows.drop(1).filter { r -> r.any { it.isNotBlank() } }.map { r ->
                    val title = r.getOrNull(titleCol)?.trim().orEmpty().ifEmpty { "Unknown song" }
                    val artists = r.getOrNull(artistCol)?.split(';', ',')?.map { it.trim() }?.filter { it.isNotEmpty() }
                        ?: emptyList()
                    title to artists
                }
            }
        }
        return clean.lines().mapNotNull { raw ->
            val line = raw.trim().replace(Regex("^\\d{1,4}[.)]\\s+"), "")
            if (line.isEmpty() || line.startsWith("#")) return@mapNotNull null
            val parts = line.split(" - ", " – ", " — ", limit = 2)
            if (parts.size == 2) parts[1].trim() to listOf(parts[0].trim()) else line to emptyList()
        }
    }
}
