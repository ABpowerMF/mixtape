package dev.mixtape.player.ui

import androidx.compose.foundation.layout.width
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.download.Quality
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix

@Composable
fun NowPlayingScreen(vm: MainViewModel, now: NowPlaying) {
    // While dragging the slider, show the drag position instead of the live one.
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = now.durationMs.coerceAtLeast(1L)
    val fraction = dragging ?: (now.positionMs.toFloat() / duration).coerceIn(0f, 1f)
    val shownPosition = if (dragging != null) (fraction * duration).toLong() else now.positionMs

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 28.dp),
    ) {
        IconButton(
            onClick = vm::pop,
            modifier = Modifier
                .padding(top = 8.dp)
                .offset(x = (-12).dp),
        ) {
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close player", modifier = Modifier.size(32.dp))
        }

        Spacer(Modifier.weight(1f))

        Artwork(
            now.artworkUri,
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f),
            corner = 12.dp,
            iconSize = 72.dp,
        )

        Spacer(Modifier.height(32.dp))

        Text(
            now.title.ifEmpty { "Nothing playing" },
            style = MaterialTheme.typography.displaySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (now.artist.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                now.artist,
                style = MaterialTheme.typography.titleMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            VersionPicker(vm, now)
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = { vm.push(Screen.Queue) },
                shape = TermShape,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text("[ queue ]", style = MaterialTheme.typography.labelMedium, color = Mix.Tape)
            }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = { vm.push(Screen.Lyrics) },
                shape = TermShape,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            ) {
                Text("[ lyrics ]", style = MaterialTheme.typography.labelMedium, color = Mix.Tape)
            }
        }
        Spacer(Modifier.height(12.dp))

        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.player.seekTo((it * duration).toLong()) }
                dragging = null
            },
            colors = SliderDefaults.colors(
                thumbColor = Mix.Tape,
                activeTrackColor = Mix.Tape,
                inactiveTrackColor = Mix.Gap,
            ),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shownPosition), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
            Text(formatTime(now.durationMs), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
        }

        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = vm.player::toggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = if (now.shuffle) "Shuffle on" else "Shuffle off",
                    tint = if (now.shuffle) Mix.Tape else Mix.Fog,
                )
            }
            IconButton(onClick = vm.player::previous, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous song", modifier = Modifier.size(36.dp))
            }
            FilledIconButton(
                shape = TermShape,
                onClick = vm.player::toggle,
                modifier = Modifier.size(76.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) {
                Icon(
                    if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (now.isPlaying) "Pause" else "Play",
                    modifier = Modifier.size(40.dp),
                )
            }
            IconButton(onClick = vm.player::next, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next song", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = vm.player::cycleRepeat) {
                Icon(
                    if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = when (now.repeatMode) {
                        Player.REPEAT_MODE_ONE -> "Repeat this song"
                        Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    tint = if (now.repeatMode == Player.REPEAT_MODE_OFF) Mix.Fog else Mix.Tape,
                )
            }
        }

        Spacer(Modifier.weight(1f))
    }
}

/** Shows the playing file's quality; switch to another downloaded version or download a new one. */
@Composable
private fun VersionPicker(vm: MainViewModel, now: NowPlaying) {
    val current = vm.trackById(now.mediaId) ?: return
    val versions = remember(vm.library, current.id) { vm.versionsOf(current) }
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(
            onClick = { open = true },
            shape = TermShape,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        ) {
            Text(
                "[ ${Quality.describe(current.fileName, current.bitrateKbps)}" +
                    (if (versions.size > 1) " · ${versions.size} versions" else "") + " ▾ ]",
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Tape,
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            versions.forEach { v ->
                val playing = v.id == current.id
                DropdownMenuItem(
                    text = {
                        Text(
                            (if (playing) "> " else "  ") + Quality.describe(v.fileName, v.bitrateKbps),
                            color = if (playing) Mix.Tape else Mix.Paper,
                        )
                    },
                    onClick = {
                        open = false
                        if (!playing) vm.playVersion(v)
                    },
                )
            }
            HorizontalDivider(color = Mix.Gap)
            if (current.album.isNotBlank()) {
                DropdownMenuItem(
                    text = { Text("  get the whole album", color = Mix.Tape) },
                    onClick = {
                        open = false
                        vm.downloadAlbumOf(current)
                    },
                )
            }
            Quality.entries.forEach { q ->
                DropdownMenuItem(
                    text = { Text("  get ${q.label}", color = Mix.Fog) },
                    onClick = {
                        open = false
                        vm.downloadVersion(current, q)
                    },
                )
            }
        }
    }
}
