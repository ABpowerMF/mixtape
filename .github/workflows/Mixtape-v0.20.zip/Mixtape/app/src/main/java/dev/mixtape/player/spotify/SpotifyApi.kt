package dev.mixtape.player.spotify

import dev.mixtape.player.data.LIKED_ID
import dev.mixtape.player.data.SpotifyPlaylistSummary
import dev.mixtape.player.data.SpotifyTrack
import dev.mixtape.player.data.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Read-only calls to the Spotify Web API (2026 version: playlist contents live under /items).
 * Only song names, artists, albums and lengths are read. No audio.
 */
class SpotifyApi(private val auth: SpotifyAuth) {

    /** Liked Songs first, then your playlists. */
    suspend fun libraryPlaylists(): List<SpotifyPlaylistSummary> {
        val me = get("$BASE/me")
        val myId = me.str("id")
        val out = mutableListOf<SpotifyPlaylistSummary>()

        val likedTotal = get("$BASE/me/tracks?limit=1").optInt("total")
        out += SpotifyPlaylistSummary(
            id = LIKED_ID,
            name = "Liked Songs",
            imageUrl = null,
            trackCount = likedTotal,
            ownerName = me.str("display_name").orEmpty(),
            canImport = true,
        )

        var url: String? = "$BASE/me/playlists?limit=50"
        while (url != null) {
            val page = get(url)
            val items = page.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val p = items.optJSONObject(i) ?: continue
                val id = p.str("id") ?: continue
                val owner = p.optJSONObject("owner")
                // "items" is the 2026 name; "tracks" is the old one.
                val counts = p.optJSONObject("items") ?: p.optJSONObject("tracks")
                out += SpotifyPlaylistSummary(
                    id = id,
                    name = p.str("name") ?: "Untitled playlist",
                    imageUrl = p.optJSONArray("images")?.optJSONObject(0)?.str("url"),
                    trackCount = counts?.optInt("total") ?: 0,
                    ownerName = owner?.str("display_name") ?: owner?.str("id").orEmpty(),
                    canImport = owner?.str("id") == myId || p.optBoolean("collaborative"),
                )
            }
            url = page.str("next")
        }
        return out
    }

    suspend fun playlistTracks(playlistId: String): List<SpotifyTrack> =
        if (playlistId == LIKED_ID) {
            pagedTracks("$BASE/me/tracks?limit=50") { it.optJSONObject("track") ?: it.optJSONObject("item") }
        } else {
            pagedTracks("$BASE/playlists/$playlistId/items?limit=50") {
                it.optJSONObject("item") ?: it.optJSONObject("track")
            }
        }

    private suspend fun pagedTracks(firstUrl: String, pick: (JSONObject) -> JSONObject?): List<SpotifyTrack> {
        val out = mutableListOf<SpotifyTrack>()
        var url: String? = firstUrl
        while (url != null) {
            val page = get(url)
            val items = page.optJSONArray("items") ?: JSONArray()
            for (i in 0 until items.length()) {
                val wrapper = items.optJSONObject(i) ?: continue
                val track = pick(wrapper) ?: continue
                parseTrack(track)?.let { out += it }
            }
            url = page.str("next")
        }
        return out
    }

    private fun parseTrack(t: JSONObject): SpotifyTrack? {
        if ((t.str("type") ?: "track") != "track") return null // skip podcast episodes
        val title = t.str("name") ?: return null
        val artistsJson = t.optJSONArray("artists") ?: JSONArray()
        val artists = (0 until artistsJson.length()).mapNotNull { artistsJson.optJSONObject(it)?.str("name") }
        // Spotify "local files" have no id; build a stable one from the name.
        val id = t.str("id") ?: "local:$title|${artists.joinToString(",")}"
        return SpotifyTrack(
            id = id,
            title = title,
            artists = artists,
            album = t.optJSONObject("album")?.str("name").orEmpty(),
            durationMs = t.optLong("duration_ms"),
        )
    }

    private suspend fun get(url: String): JSONObject {
        repeat(4) { attempt ->
            val token = auth.accessToken()
            val res = withContext(Dispatchers.IO) { Http.get(url, token) }
            when {
                res.code in 200..299 -> return JSONObject(res.body)
                res.code == 429 -> delay((res.retryAfterSec ?: 2L).coerceIn(1L, 30L) * 1000L)
                res.code == 401 && attempt == 0 -> auth.invalidateAccessToken()
                else -> throw SpotifyException(res.code, res.body)
            }
        }
        throw SpotifyException(429, "Rate limited")
    }

    private companion object {
        const val BASE = "https://api.spotify.com/v1"
    }
}
