package dev.mixtape.player.library

import dev.mixtape.player.data.SpotifyTrack
import kotlin.math.abs

/**
 * Finds the file on this phone that best fits a Spotify song, using the title and artist tags
 * (or "Artist - Title" filenames) and the song length as a tie-breaker.
 */
class Matcher(tracks: List<LocalTrack>) {

    private class Entry(
        val track: LocalTrack,
        val title: String,
        val artist: String,
        val haystack: String,
    )

    private val entries: List<Entry> = tracks.map { t ->
        val title = Text.normalizeTitle(t.title)
        val artist = Text.normalize(t.artist)
        Entry(t, title, artist, "$title $artist ${Text.normalize(t.album)}")
    }

    private val byTitle: Map<String, List<Entry>> = entries.groupBy { it.title }

    private val byWord: Map<String, List<Entry>> = HashMap<String, MutableList<Entry>>().also { map ->
        entries.forEach { e -> Text.tokens(e.title).forEach { w -> map.getOrPut(w) { mutableListOf() }.add(e) } }
    }

    fun match(song: SpotifyTrack): LocalTrack? {
        val title = Text.normalizeTitle(song.title)
        if (title.isEmpty()) return null
        val artists = song.artists.map(Text::normalize).filter { it.isNotEmpty() }

        val candidates = LinkedHashSet<Entry>()
        byTitle[title]?.let(candidates::addAll)
        // Look up by the three rarest words of the title to keep the candidate list short.
        Text.tokens(title)
            .mapNotNull { byWord[it] }
            .sortedBy { it.size }
            .take(3)
            .forEach(candidates::addAll)

        var best: Entry? = null
        var bestScore = 0.0
        for (e in candidates) {
            val s = score(title, artists, song.durationMs, e)
            if (s > bestScore) {
                bestScore = s
                best = e
            }
        }
        return if (bestScore >= THRESHOLD) best?.track else null
    }

    /** Songs whose title, artist or album contain every word of [query]. */
    fun search(query: String, limit: Int = 200): List<LocalTrack> {
        val words = Text.tokens(Text.normalizeTitle(query))
        if (words.isEmpty()) return entries.take(limit).map { it.track }
        return entries.asSequence()
            .filter { e -> words.all { w -> e.haystack.contains(w) } }
            .take(limit)
            .map { it.track }
            .toList()
    }

    private fun score(title: String, artists: List<String>, durationMs: Long, e: Entry): Double {
        val titleScore = Text.similarity(title, e.title)
        if (titleScore < 0.75) return 0.0

        val artistScore = when {
            e.artist.isEmpty() || artists.isEmpty() -> 0.5 // unknown: don't reward or punish
            artists.any { Text.containsWords(e.artist, it) || Text.containsWords(it, e.artist) } -> 1.0
            else -> artists.maxOf { Text.similarity(it, e.artist) }
        }

        var s = 0.65 * titleScore + 0.35 * artistScore
        val local = e.track.durationMs
        if (durationMs > 0 && local > 0) {
            val diff = abs(durationMs - local)
            if (diff <= 3_000 && artistScore >= 0.5) s += 0.1
            else if (diff > 20_000) s -= 0.15
        }
        return s
    }

    private companion object {
        const val THRESHOLD = 0.8
    }
}
