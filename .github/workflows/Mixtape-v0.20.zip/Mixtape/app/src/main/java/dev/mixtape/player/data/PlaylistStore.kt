package dev.mixtape.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saves imported playlists and your manual matches to a JSON file in app storage. */
class PlaylistStore(context: Context) {

    data class Data(
        val playlists: List<SavedPlaylist>,
        /** Spotify track id -> MediaStore id of the file you picked. */
        val overrides: Map<String, Long>,
    )

    private val file = File(context.filesDir, "playlists.json")

    fun load(): Data {
        if (!file.exists()) return Data(emptyList(), emptyMap())
        return try {
            val root = JSONObject(file.readText())
            val lists = root.optJSONArray("playlists") ?: JSONArray()
            val playlists = (0 until lists.length()).mapNotNull { i ->
                lists.optJSONObject(i)?.let(::readPlaylist)
            }
            val ov = root.optJSONObject("overrides")
            val overrides = HashMap<String, Long>()
            if (ov != null) {
                val keys = ov.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    overrides[key] = ov.getLong(key)
                }
            }
            Data(playlists, overrides)
        } catch (e: Exception) {
            Data(emptyList(), emptyMap())
        }
    }

    fun save(data: Data) {
        val root = JSONObject()
        root.put("playlists", JSONArray().apply { data.playlists.forEach { put(writePlaylist(it)) } })
        root.put("overrides", JSONObject().apply { data.overrides.forEach { (k, v) -> put(k, v) } })
        val tmp = File(file.parentFile, "playlists.json.tmp")
        tmp.writeText(root.toString())
        if (!tmp.renameTo(file)) {
            file.writeText(root.toString())
            tmp.delete()
        }
    }

    private fun readPlaylist(o: JSONObject): SavedPlaylist? {
        val id = o.str("id") ?: return null
        val arr = o.optJSONArray("tracks") ?: JSONArray()
        val tracks = (0 until arr.length()).mapNotNull { i ->
            val t = arr.optJSONObject(i) ?: return@mapNotNull null
            val artistsArr = t.optJSONArray("artists") ?: JSONArray()
            SpotifyTrack(
                id = t.str("id") ?: return@mapNotNull null,
                title = t.optString("title"),
                artists = (0 until artistsArr.length()).map { artistsArr.optString(it) },
                album = t.optString("album"),
                durationMs = t.optLong("durationMs"),
            )
        }
        return SavedPlaylist(
            id = id,
            name = o.optString("name"),
            imageUrl = o.str("imageUrl"),
            tracks = tracks,
            importedAt = o.optLong("importedAt"),
        )
    }

    private fun writePlaylist(p: SavedPlaylist): JSONObject = JSONObject().apply {
        put("id", p.id)
        put("name", p.name)
        p.imageUrl?.let { put("imageUrl", it) }
        put("importedAt", p.importedAt)
        put("tracks", JSONArray().apply {
            p.tracks.forEach { t ->
                put(JSONObject().apply {
                    put("id", t.id)
                    put("title", t.title)
                    put("artists", JSONArray(t.artists))
                    put("album", t.album)
                    put("durationMs", t.durationMs)
                })
            }
        })
    }
}
