package dev.mixtape.player.ui

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import dev.mixtape.player.download.YouTubeCookies

/** Shows YouTube's normal sign-in page; once signed in, keeps the cookies for downloads and closes. */
class YouTubeLoginActivity : ComponentActivity() {

    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // Google refuses sign-in from pages that say they're an in-app browser.
            settings.userAgentString = settings.userAgentString
                .replace("; wv", "")
                .replace(Regex("Version/[\\d.]+ "), "")
            cookies.setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    checkSignedIn(url)
                }
            }
        }
        setContentView(web)
        web.loadUrl(
            "https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true" +
                "&continue=https%3A%2F%2Fm.youtube.com%2F",
        )
        onBackPressedDispatcher.addCallback(this) {
            if (web.canGoBack()) web.goBack() else finish()
        }
    }

    private fun checkSignedIn(url: String) {
        if (!url.contains("youtube.com")) return
        val header = CookieManager.getInstance().getCookie("https://www.youtube.com") ?: return
        if (YouTubeCookies.save(this, header)) {
            CookieManager.getInstance().flush()
            Toast.makeText(this, "Signed in to YouTube", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }
    }

    override fun onDestroy() {
        web.destroy()
        super.onDestroy()
    }
}
