package dev.mixtape.player.download

import android.content.Context
import android.webkit.CookieManager
import java.io.File

/**
 * Optional YouTube sign-in. YouTube sometimes answers "Sign in to confirm you're not a bot" (common on
 * mobile data, where many people share one address) or asks for age confirmation. With the cookies of
 * a signed-in account, yt-dlp gets past both. Stored only in the app's private storage.
 */
object YouTubeCookies {

    fun file(context: Context): File = File(context.applicationContext.filesDir, "youtube-cookies.txt")

    fun isSignedIn(context: Context): Boolean = file(context).let { it.exists() && it.length() > 0 }

    /** Saves the WebView's YouTube cookies in the format yt-dlp reads. False if not signed in yet. */
    fun save(context: Context, cookieHeader: String): Boolean {
        val pairs = cookieHeader.split(";").map { it.trim() }.filter { it.contains('=') }
        val signedIn = pairs.any {
            it.startsWith("SAPISID=") || it.startsWith("__Secure-3PAPISID=") || it.startsWith("LOGIN_INFO=")
        }
        if (!signedIn) return false
        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val text = buildString {
            append("# Netscape HTTP Cookie File\n")
            pairs.forEach { p ->
                append(".youtube.com\tTRUE\t/\tTRUE\t$expiry\t${p.substringBefore('=')}\t${p.substringAfter('=')}\n")
            }
        }
        file(context).writeText(text)
        return true
    }

    fun signOut(context: Context) {
        file(context).delete()
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
    }
}
