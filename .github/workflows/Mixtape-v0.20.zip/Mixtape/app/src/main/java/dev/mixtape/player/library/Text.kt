package dev.mixtape.player.library

import java.text.Normalizer
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/** Text clean-up and fuzzy comparison used for matching song names. */
internal object Text {
    private val MARKS = Regex("\\p{Mn}+")
    private val APOSTROPHES = Regex("['’`´]")
    private val NON_ALNUM = Regex("[^\\p{L}\\p{N}]+")
    private val BRACKETS = Regex("[(\\[]([^)\\]]*)[)\\]]")
    private val FEAT_TAIL = Regex("\\s(feat\\.?|ft\\.?|featuring)\\s.*$")

    /**
     * Words that mark a bracket or " - " suffix as packaging rather than a different recording.
     * "Live", "Acoustic", "Remix" and "Instrumental" are deliberately NOT here: those are different songs.
     */
    private val NOISE = Regex(
        "\\b(feat|ft|featuring|with|remaster|remastered|radio edit|single version|album version|" +
            "original version|mono|stereo|deluxe|bonus track|explicit|clean|official|lyrics?|audio|video|hq|hd)\\b"
    )

    /** Lowercase, strip accents and punctuation, collapse spaces. */
    fun normalize(s: String): String {
        val lower = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(MARKS, "")
        return lower
            .replace("&", " and ")
            .replace(APOSTROPHES, "")
            .replace(NON_ALNUM, " ")
            .trim()
    }

    /** Like [normalize], but also drops "(feat. X)", "- Remastered 2011", "[Official Video]" and similar. */
    fun normalizeTitle(raw: String): String {
        var s = raw.lowercase(Locale.ROOT)
        s = BRACKETS.replace(s) { m ->
            val inner = m.groupValues[1]
            if (NOISE.containsMatchIn(inner)) " " else " $inner "
        }
        val dash = s.indexOf(" - ")
        if (dash > 0 && NOISE.containsMatchIn(s.substring(dash + 3))) s = s.substring(0, dash)
        s = s.replace(FEAT_TAIL, "")
        return normalize(s)
    }

    fun tokens(s: String): Set<String> = s.split(' ').filter { it.isNotEmpty() }.toSet()

    /** True if [needle] appears in [haystack] as whole words. */
    fun containsWords(haystack: String, needle: String): Boolean =
        needle.isNotEmpty() && " $haystack ".contains(" $needle ")

    /** 0.0 to 1.0: edit-distance ratio, or 0.9 when every word of the shorter text is in the longer one. */
    fun similarity(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isEmpty() || b.isEmpty()) return 0.0
        val x = a.take(120)
        val y = b.take(120)
        val lev = 1.0 - levenshtein(x, y).toDouble() / max(x.length, y.length)
        val ta = tokens(a)
        val tb = tokens(b)
        val small = if (ta.size <= tb.size) ta else tb
        val big = if (ta.size <= tb.size) tb else ta
        val contained = if (small.isNotEmpty() && big.containsAll(small)) 0.9 else 0.0
        return max(lev, contained)
    }

    private fun levenshtein(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }
}
