package dev.mixtape.player.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.Size
import android.view.View
import android.widget.RemoteViews
import androidx.media3.common.Player
import dev.mixtape.player.MainActivity
import dev.mixtape.player.R
import dev.mixtape.player.library.LocalLibrary
import dev.mixtape.player.playback.PlaybackService
import java.util.concurrent.Executors

/** Home-screen widgets: now playing, album cover, and cover + clock. */
object Widgets {

    const val ACTION_TOGGLE = "dev.mixtape.player.widget.TOGGLE"
    const val ACTION_NEXT = "dev.mixtape.player.widget.NEXT"

    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var coverFor: String? = null
    private var cover: Bitmap? = null

    private fun prefs(context: Context) = context.getSharedPreferences("widgets", Context.MODE_PRIVATE)

    /** Called by the player whenever the song or play state changes. */
    fun onPlayerChanged(context: Context, player: Player) {
        val item = player.currentMediaItem
        prefs(context).edit()
            .putString("id", item?.mediaId)
            .putString("title", item?.mediaMetadata?.title?.toString())
            .putString("artist", item?.mediaMetadata?.artist?.toString())
            .putBoolean("playing", player.isPlaying)
            .apply()
        updateAll(context)
    }

    /** Redraws every Mixtape widget from the last known song. */
    fun updateAll(context: Context) {
        val app = context.applicationContext
        val p = prefs(app)
        val id = p.getString("id", null)
        val title = p.getString("title", null)
        val artist = p.getString("artist", null)
        val playing = p.getBoolean("playing", false)
        worker.execute {
            val art = loadCover(app, id)
            main.post { draw(app, id, title, artist, playing, art) }
        }
    }

    private fun loadCover(context: Context, id: String?): Bitmap? {
        if (id == null) return null
        if (id == coverFor) return cover
        val audioId = id.toLongOrNull() ?: return null
        val bitmap = runCatching {
            context.contentResolver.loadThumbnail(LocalLibrary.contentUri(audioId), Size(300, 300), null)
        }.getOrNull() ?: runCatching {
            context.contentResolver.openInputStream(LocalLibrary.contentUri(audioId))?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
        coverFor = id
        cover = bitmap
        return bitmap
    }

    private fun draw(context: Context, id: String?, title: String?, artist: String?, playing: Boolean, art: Bitmap?) {
        val manager = AppWidgetManager.getInstance(context)
        val hasSong = id != null && !title.isNullOrEmpty()
        val openApp = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        fun setCover(views: RemoteViews) {
            if (art != null) views.setImageViewBitmap(R.id.w_cover, art)
            else views.setImageViewResource(R.id.w_cover, R.drawable.ic_launcher_foreground)
        }

        // Now playing
        run {
            val views = RemoteViews(context.packageName, R.layout.widget_now_playing)
            setCover(views)
            views.setTextViewText(R.id.w_title, if (hasSong) title else context.getString(R.string.widget_nothing))
            views.setTextViewText(R.id.w_artist, if (hasSong) artist.orEmpty() else context.getString(R.string.widget_open))
            views.setImageViewResource(R.id.w_toggle, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            val buttons = if (hasSong) View.VISIBLE else View.GONE
            views.setViewVisibility(R.id.w_toggle, buttons)
            views.setViewVisibility(R.id.w_next, buttons)
            views.setOnClickPendingIntent(android.R.id.background, openApp)
            views.setOnClickPendingIntent(R.id.w_toggle, control(context, ACTION_TOGGLE, 1))
            views.setOnClickPendingIntent(R.id.w_next, control(context, ACTION_NEXT, 2))
            manager.updateAppWidget(ComponentName(context, NowPlayingWidget::class.java), views)
        }
        // Album cover
        run {
            val views = RemoteViews(context.packageName, R.layout.widget_cover)
            setCover(views)
            views.setOnClickPendingIntent(android.R.id.background, openApp)
            manager.updateAppWidget(ComponentName(context, CoverWidget::class.java), views)
        }
        // Cover + clock
        run {
            val views = RemoteViews(context.packageName, R.layout.widget_cover_clock)
            setCover(views)
            views.setTextViewText(R.id.w_title, if (hasSong) listOfNotNull(title, artist).joinToString(" · ") else "")
            views.setOnClickPendingIntent(android.R.id.background, openApp)
            manager.updateAppWidget(ComponentName(context, CoverClockWidget::class.java), views)
        }
    }

    private fun control(context: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getService(
            context, code, Intent(context, PlaybackService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
}

/** Keeps the widgets in step with the player. Runs inside the playback service. */
class WidgetUpdater(private val context: Context) : Player.Listener {
    override fun onEvents(player: Player, events: Player.Events) {
        if (events.containsAny(
                Player.EVENT_MEDIA_ITEM_TRANSITION,
                Player.EVENT_IS_PLAYING_CHANGED,
                Player.EVENT_MEDIA_METADATA_CHANGED,
            )
        ) {
            Widgets.onPlayerChanged(context, player)
        }
    }
}

class NowPlayingWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateAll(context)
}

class CoverWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateAll(context)
}

class CoverClockWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = Widgets.updateAll(context)
}
