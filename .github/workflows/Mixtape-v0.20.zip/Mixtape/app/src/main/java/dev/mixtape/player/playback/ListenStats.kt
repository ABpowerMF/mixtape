package dev.mixtape.player.playback

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Listening time and play counts per song, saved in the app's private storage. */
object ListenStats {

    data class Entry(
        val id: String,
        val title: String,
        val artist: String,
        val listenedMs: Long,
        val plays: Int,
    )

    /** A song counts as played after this much listening. */
    const val PLAY_AFTER_MS = 30_000L

    private val entries = HashMap<String, Entry>()
    private var file: File? = null
    private var since: Long = 0L

    @Synchronized
    fun init(context: Context) {
        if (file != null) return
        val f = File(context.applicationContext.filesDir, "stats.json")
        file = f
        runCatching {
            if (!f.exists()) return@runCatching
            val json = JSONObject(f.readText())
            since = json.optLong("since")
            val arr = json.optJSONArray("songs") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val e = Entry(o.optString("id"), o.optString("title"), o.optString("artist"), o.optLong("ms"), o.optInt("plays"))
                if (e.id.isNotEmpty()) entries[e.id] = e
            }
        }
        if (since == 0L) since = System.currentTimeMillis()
    }

    @Synchronized
    fun add(id: String, title: String, artist: String, ms: Long, countPlay: Boolean) {
        if (ms <= 0 && !countPlay) return
        val old = entries[id]
        entries[id] = Entry(
            id = id,
            title = title.ifEmpty { old?.title.orEmpty() },
            artist = artist.ifEmpty { old?.artist.orEmpty() },
            listenedMs = (old?.listenedMs ?: 0L) + ms.coerceAtLeast(0L),
            plays = (old?.plays ?: 0) + if (countPlay) 1 else 0,
        )
        save()
    }

    @Synchronized
    fun snapshot(): List<Entry> = entries.values.toList()

    @Synchronized
    fun trackingSince(): Long = since

    @Synchronized
    fun reset() {
        entries.clear()
        since = System.currentTimeMillis()
        save()
    }

    private fun save() {
        val f = file ?: return
        val arr = JSONArray()
        entries.values.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("title", e.title).put("artist", e.artist).put("ms", e.listenedMs).put("plays", e.plays))
        }
        runCatching { f.writeText(JSONObject().put("since", since).put("songs", arr).toString()) }
    }
}
