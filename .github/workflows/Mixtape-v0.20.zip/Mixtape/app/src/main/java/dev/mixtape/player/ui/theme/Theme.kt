package dev.mixtape.player.ui.theme

import android.app.Activity
import android.content.Context
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import dev.mixtape.player.R

/** The app's colours. Background, panels, highlights, lines, text, dim text, accent, errors. */
data class Palette(
    val ink: Color,
    val deep: Color,
    val raised: Color,
    val gap: Color,
    val paper: Color,
    val fog: Color,
    val tape: Color,
    val alert: Color = Color(0xFFFF5F56),
) {
    val isLight: Boolean get() = ink.luminance() > 0.5f

    companion object {
        /** Builds a full palette from the three colours people pick. */
        fun from(background: Color, text: Color, accent: Color) = Palette(
            ink = background,
            deep = lerp(background, text, 0.05f),
            raised = lerp(background, text, 0.10f),
            gap = lerp(background, text, 0.20f),
            paper = text,
            fog = lerp(background, text, 0.55f),
            tape = accent,
        )
    }
}

enum class ThemePreset(val label: String, val palette: Palette?) {
    TERMINAL("Terminal", Palette.from(Color(0xFF050805), Color(0xFFCFF5CF), Color(0xFF39FF6A))),
    MONO("Black & white", Palette.from(Color(0xFF000000), Color(0xFFF2F2F2), Color(0xFFFFFFFF))),
    PAPER("White & black", Palette.from(Color(0xFFFFFFFF), Color(0xFF111111), Color(0xFF000000))),
    GREEN_WHITE("Green & white", Palette.from(Color(0xFFFFFFFF), Color(0xFF102010), Color(0xFF16A34A))),
    AMBER("Amber", Palette.from(Color(0xFF0A0700), Color(0xFFFFE2A8), Color(0xFFFFB000))),
    NIGHT("Night drive", Palette.from(Color(0xFF16202E), Color(0xFFEAF0F7), Color(0xFFF2C14E))),
    CUSTOM("Custom", null),
}

/** Colours people can pick for a custom theme. */
val Swatches = listOf(
    0xFF000000, 0xFF050805, 0xFF0B1220, 0xFF16202E, 0xFF1E1E1E, 0xFF3A3A3A,
    0xFFFFFFFF, 0xFFF2F2F2, 0xFFFFF7E6, 0xFFCFF5CF, 0xFFEAF0F7,
    0xFF39FF6A, 0xFF16A34A, 0xFF00E5FF, 0xFF3B82F6, 0xFF8B5CF6, 0xFFFF4FD8,
    0xFFFF5F56, 0xFFFF8A00, 0xFFFFB000, 0xFFF2C14E, 0xFFFFEB3B,
).map { Color(it) }

/** Current look. Reading these from a composable redraws it when the theme changes. */
object Mix {
    var palette by mutableStateOf(ThemePreset.TERMINAL.palette!!)
    var mono by mutableStateOf(true)

    val Ink: Color get() = palette.ink         // background
    val Deep: Color get() = palette.deep       // sheets, player bar
    val Raised: Color get() = palette.raised   // artwork placeholders, chips, selection
    val Gap: Color get() = palette.gap         // lines, missing songs in the match strip
    val Paper: Color get() = palette.paper     // main text
    val Fog: Color get() = palette.fog         // secondary text
    val Tape: Color get() = palette.tape       // accent: songs found, play
    val Alert: Color get() = palette.alert
}

/** Saves and restores the look. */
object Appearance {
    private fun prefs(context: Context) = context.getSharedPreferences("mixtape", Context.MODE_PRIVATE)

    var preset by mutableStateOf(ThemePreset.TERMINAL)
        private set
    var custom by mutableStateOf(ThemePreset.TERMINAL.palette!!)
        private set

    fun load(context: Context) {
        val p = prefs(context)
        preset = ThemePreset.entries.firstOrNull { it.name == p.getString("theme", null) } ?: ThemePreset.TERMINAL
        custom = Palette.from(
            Color(p.getInt("customBackground", Color(0xFF050805).toArgb())),
            Color(p.getInt("customText", Color(0xFFCFF5CF).toArgb())),
            Color(p.getInt("customAccent", Color(0xFF39FF6A).toArgb())),
        )
        Mix.mono = p.getBoolean("monoFont", true)
        apply()
    }

    fun choose(context: Context, preset: ThemePreset) {
        this.preset = preset
        prefs(context).edit().putString("theme", preset.name).apply()
        apply()
    }

    /** Changes one of the custom colours and switches to the custom theme. */
    fun setCustom(context: Context, background: Color? = null, text: Color? = null, accent: Color? = null) {
        val c = custom
        custom = Palette.from(background ?: c.ink, text ?: c.paper, accent ?: c.tape)
        prefs(context).edit()
            .putInt("customBackground", custom.ink.toArgb())
            .putInt("customText", custom.paper.toArgb())
            .putInt("customAccent", custom.tape.toArgb())
            .apply()
        choose(context, ThemePreset.CUSTOM)
    }

    fun setMonoFont(context: Context, mono: Boolean) {
        Mix.mono = mono
        prefs(context).edit().putBoolean("monoFont", mono).apply()
    }

    private fun apply() {
        Mix.palette = preset.palette ?: custom
    }
}

/** Square corners, like a terminal window. */
val TermShape = RoundedCornerShape(2.dp)

val Mono = FontFamily.Monospace

val Barlow = FontFamily(
    Font(R.font.barlow_regular, FontWeight.Normal),
    Font(R.font.barlow_medium, FontWeight.Medium),
    Font(R.font.barlow_semibold, FontWeight.SemiBold),
    Font(R.font.barlow_bold, FontWeight.Bold),
)

private fun schemeFor(p: Palette) = if (p.isLight) {
    lightColorScheme(
        primary = p.tape, onPrimary = p.ink, primaryContainer = p.raised, onPrimaryContainer = p.paper,
        secondary = p.fog, onSecondary = p.ink, secondaryContainer = p.raised, onSecondaryContainer = p.paper,
        background = p.ink, onBackground = p.paper, surface = p.ink, onSurface = p.paper,
        surfaceVariant = p.raised, onSurfaceVariant = p.fog,
        surfaceContainerLowest = p.ink, surfaceContainerLow = p.deep, surfaceContainer = p.deep,
        surfaceContainerHigh = p.raised, surfaceContainerHighest = p.raised,
        inverseSurface = p.paper, inverseOnSurface = p.ink, outline = p.gap, outlineVariant = p.gap,
        error = p.alert, onError = p.ink,
    )
} else {
    darkColorScheme(
        primary = p.tape, onPrimary = p.ink, primaryContainer = p.raised, onPrimaryContainer = p.paper,
        secondary = p.fog, onSecondary = p.ink, secondaryContainer = p.raised, onSecondaryContainer = p.paper,
        background = p.ink, onBackground = p.paper, surface = p.ink, onSurface = p.paper,
        surfaceVariant = p.raised, onSurfaceVariant = p.fog,
        surfaceContainerLowest = p.ink, surfaceContainerLow = p.deep, surfaceContainer = p.deep,
        surfaceContainerHigh = p.raised, surfaceContainerHighest = p.raised,
        inverseSurface = p.paper, inverseOnSurface = p.ink, outline = p.gap, outlineVariant = p.gap,
        error = p.alert, onError = p.ink,
    )
}

private fun typeFor(mono: Boolean): Typography {
    val base = Typography()
    val family = if (mono) Mono else Barlow
    val scale = if (mono) 1f else 1.1f
    fun TextStyle.set(size: Int? = null, weight: FontWeight? = null, line: Int? = null) = copy(
        fontFamily = family,
        letterSpacing = 0.sp,
        fontSize = size?.let { (it * scale).sp } ?: fontSize,
        fontWeight = weight ?: fontWeight,
        lineHeight = line?.let { (it * scale).sp } ?: lineHeight,
    )
    return Typography(
        displayLarge = base.displayLarge.set(),
        displayMedium = base.displayMedium.set(),
        displaySmall = base.displaySmall.set(size = 24, weight = FontWeight.Bold, line = 30),
        headlineLarge = base.headlineLarge.set(weight = FontWeight.SemiBold),
        headlineMedium = base.headlineMedium.set(weight = FontWeight.SemiBold),
        headlineSmall = base.headlineSmall.set(weight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.set(size = 20, weight = FontWeight.Bold, line = 26),
        titleMedium = base.titleMedium.set(size = 15, weight = FontWeight.Medium, line = 20),
        titleSmall = base.titleSmall.set(weight = FontWeight.Medium),
        bodyLarge = base.bodyLarge.set(size = 15, line = 22),
        bodyMedium = base.bodyMedium.set(size = 13, line = 18),
        bodySmall = base.bodySmall.set(size = 12, line = 16),
        labelLarge = base.labelLarge.set(size = 14, weight = FontWeight.Bold),
        labelMedium = base.labelMedium.set(size = 13, weight = FontWeight.Medium),
        labelSmall = base.labelSmall.set(),
    )
}

private val termShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(2.dp),
    medium = RoundedCornerShape(2.dp),
    large = RoundedCornerShape(2.dp),
    extraLarge = RoundedCornerShape(2.dp),
)

@Composable
fun MixtapeTheme(content: @Composable () -> Unit) {
    val palette = Mix.palette
    val mono = Mix.mono
    val scheme = remember(palette) { schemeFor(palette) }
    val type = remember(mono) { typeFor(mono) }

    // Dark status/navigation bar icons on light themes, light icons on dark ones.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = palette.isLight
                isAppearanceLightNavigationBars = palette.isLight
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = type, shapes = termShapes, content = content)
}
