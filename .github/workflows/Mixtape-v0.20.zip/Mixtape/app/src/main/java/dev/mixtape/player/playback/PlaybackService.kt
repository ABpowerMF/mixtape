package dev.mixtape.player.playback

import androidx.media3.common.Player
import dev.mixtape.player.widget.WidgetUpdater
import dev.mixtape.player.widget.Widgets
import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import dev.mixtape.player.MainActivity
import dev.mixtape.player.library.LocalLibrary

/** Keeps music playing in the background and provides notification + lock-screen controls. */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private var stats: StatsTracker? = null

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .build()

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        ListenStats.init(this)
        stats = StatsTracker(player).also { player.addListener(it) }
        player.addListener(WidgetUpdater(this))

        session = MediaSession.Builder(this, player)
            .setSessionActivity(openApp)
            .setCallback(Callback())
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Play/pause and next buttons on the home-screen widget. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val player = session?.player
        if (player != null) {
            when (intent?.action) {
                Widgets.ACTION_TOGGLE -> if (player.isPlaying) {
                    player.pause()
                } else {
                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                    player.play()
                }
                Widgets.ACTION_NEXT -> player.seekToNextMediaItem()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        stats?.flush()
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    /** Rebuilds the file Uri from the media id if it was stripped on the way to the service. */
    private class Callback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                val id = item.mediaId.toLongOrNull()
                if (item.localConfiguration != null || id == null) item
                else item.buildUpon().setUri(LocalLibrary.contentUri(id)).build()
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }
    }
}
