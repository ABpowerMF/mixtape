Mixtape v0.49

- Safer sharing: the signing key and the Last.fm key are no longer in the code.
- Listen together: phones only show up to each other on the Listen together screen, and only the phone you joined can play your songs.
