package dev.mixtape.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import dev.mixtape.player.download.YouTubeCookies
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.download.MediaSaver
import dev.mixtape.player.ui.theme.Appearance
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Palette
import dev.mixtape.player.ui.theme.Swatches
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.ThemePreset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val version = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName
    }.getOrNull().orEmpty()

    LaunchedEffect(Unit) { vm.refreshStats() }
    var youTubeSignedIn by remember { mutableStateOf(YouTubeCookies.isSignedIn(context)) }
    val youTubeLogin = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        youTubeSignedIn = YouTubeCookies.isSignedIn(context)
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("~/settings", style = MaterialTheme.typography.titleLarge) },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            // ---------- Stats ----------
            item { Section("stats") }
            item {
                Column {
                    SettingRow(
                        "Listening time: ${formatListened(vm.stats.sumOf { it.listenedMs })}",
                        vm.stats.filter { it.listenedMs > 0 }.maxByOrNull { it.listenedMs }
                            ?.let { "Most listened: ${it.title.ifEmpty { "Unknown song" }}" }
                            ?: "Your most listened songs and artists",
                    ) {
                        OutlinedButton(
                            onClick = { vm.push(Screen.Stats) },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text("[ open ]", color = Mix.Tape) }
                    }
                }
            }

            // ---------- Look ----------
            item { Section("theme") }
            item {
                Column {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(ThemePreset.entries) { preset ->
                            ThemeTile(
                                label = preset.label,
                                palette = preset.palette ?: Appearance.custom,
                                selected = Appearance.preset == preset,
                                onClick = { Appearance.choose(context, preset) },
                            )
                        }
                    }
                }
            }
            item { Section("custom colours") }
            item {
                Column {
                    SwatchRow("accent", Appearance.custom.tape) { Appearance.setCustom(context, accent = it) }
                    SwatchRow("background", Appearance.custom.ink) { Appearance.setCustom(context, background = it) }
                    SwatchRow("text", Appearance.custom.paper) { Appearance.setCustom(context, text = it) }
                    Text(
                        "Picking a colour switches to the Custom theme.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    )
                }
            }
            item { Section("font") }
            item {
                Column {
                    Choice("Monospace (terminal)", selected = Mix.mono) { Appearance.setMonoFont(context, true) }
                    Choice("Clean (Barlow)", selected = !Mix.mono) { Appearance.setMonoFont(context, false) }
                }
            }

            // ---------- Downloads ----------
            item { Section("downloads") }
            item {
                Column {
                    SettingRow("Default quality", "Used for new downloads and Download missing") {}
                    QualityPicker(
                        vm.quality,
                        vm::chooseQuality,
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    SettingRow("Songs at the same time", "More is faster but uses more battery and data") {}
                    Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (1..4).forEach { n ->
                            val on = vm.parallelDownloads == n
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .background(if (on) Mix.Tape else Mix.Raised, TermShape)
                                    .clickable { vm.chooseParallelDownloads(n) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("$n", color = if (on) Mix.Ink else Mix.Paper, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    SettingRow("Downloader", "Updates itself once a day. Update now if downloads start failing.") {}
                    OutlinedButton(
                        onClick = DownloadQueue::updateNow,
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                        modifier = Modifier.padding(horizontal = 20.dp),
                    ) { Text("[ update now ]", color = Mix.Tape) }
                    SettingRow(
                        "YouTube account",
                        if (youTubeSignedIn) "Signed in. Fixes \"not a bot\" and age errors."
                        else "Optional. Fixes \"Sign in to confirm\" errors. A spare account is safest.",
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (youTubeSignedIn) {
                                    YouTubeCookies.signOut(context)
                                    youTubeSignedIn = false
                                } else {
                                    youTubeLogin.launch(Intent(context, YouTubeLoginActivity::class.java))
                                }
                            },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(if (youTubeSignedIn) "[ sign out ]" else "[ sign in ]", color = Mix.Tape) }
                    }
                    Text(
                        "Songs are saved to ${MediaSaver.FOLDER}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    )
                }
            }

            // ---------- Player & library ----------
            item { Section("player") }
            item {
                Column {
                    SettingRow("Swipe to change songs", "On the mini player: left = next, right = previous") {
                        Switch(
                            checked = vm.swipeToSkip,
                            onCheckedChange = vm::chooseSwipeToSkip,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Mix.Ink,
                                checkedTrackColor = Mix.Tape,
                                uncheckedThumbColor = Mix.Fog,
                                uncheckedTrackColor = Mix.Raised,
                                uncheckedBorderColor = Mix.Gap,
                            ),
                        )
                    }
                    SettingRow("Rescan music", "Find songs you copied to the phone") {
                        OutlinedButton(
                            onClick = vm::rescanMusic,
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text("[ scan ]", color = Mix.Tape) }
                    }
                }
            }

            item { Section("about") }
            item {
                Column {
                    Text(
                        "mixtape v$version",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        "> $title",
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp),
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        (if (selected) "(•) " else "( ) ") + label,
        style = MaterialTheme.typography.bodyLarge,
        color = if (selected) Mix.Tape else Mix.Paper,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
    )
}

/** A small preview of a theme: its background, text and accent. */
@Composable
private fun ThemeTile(label: String, palette: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(104.dp)
            .clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(72.dp)
                .background(palette.ink, TermShape)
                .border(if (selected) 2.dp else 1.dp, if (selected) Mix.Tape else Mix.Gap, TermShape)
                .padding(8.dp),
        ) {
            Column {
                Text("> play", color = palette.paper, style = MaterialTheme.typography.bodySmall)
                Text("  track", color = palette.fog, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .width(48.dp)
                        .height(6.dp)
                        .background(palette.tape),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = if (selected) Mix.Tape else Mix.Fog,
            maxLines = 1,
        )
    }
}

@Composable
private fun SwatchRow(label: String, current: Color, onPick: (Color) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Paper,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(Modifier.height(6.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(Swatches) { color ->
                val on = color == current
                Box(
                    Modifier
                        .size(34.dp)
                        .background(color, TermShape)
                        .border(if (on) 3.dp else 1.dp, if (on) Mix.Tape else Mix.Gap, TermShape)
                        .clickable { onPick(color) },
                )
            }
        }
    }
}
