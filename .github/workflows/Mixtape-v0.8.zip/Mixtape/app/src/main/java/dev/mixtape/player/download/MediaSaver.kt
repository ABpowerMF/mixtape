package dev.mixtape.player.download

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.io.IOException

/** Puts finished downloads in Music/Mixtape, where every music app (and Mixtape) finds them. */
object MediaSaver {

    const val FOLDER = "Music/Mixtape"

    private val collection: Uri
        get() = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)

    fun mimeType(ext: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "opus" -> "audio/ogg"
            "flac" -> "audio/flac"
            else -> "audio/*"
        }

    /** True if Music/Mixtape already has "[baseName].[ext]". */
    fun exists(context: Context, baseName: String, ext: String): Boolean {
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ? AND ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
        val args = arrayOf("$baseName.$ext", "$FOLDER%")
        return try {
            context.contentResolver.query(collection, arrayOf(MediaStore.MediaColumns._ID), selection, args, null)
                ?.use { it.count > 0 } ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun save(context: Context, file: File): Uri {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType(file.extension.lowercase()))
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$FOLDER/")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(collection, values) ?: throw IOException("Couldn't create the music file.")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Couldn't write the music file.")
            out.use { stream -> file.inputStream().use { it.copyTo(stream) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }
}
