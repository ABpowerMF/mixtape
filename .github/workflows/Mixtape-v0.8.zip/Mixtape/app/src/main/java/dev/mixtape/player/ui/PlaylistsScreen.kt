package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.TermShape
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.data.LIKED_ID
import dev.mixtape.player.data.PlaylistRow
import dev.mixtape.player.data.SavedPlaylist
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistsScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("~/playlists", style = MaterialTheme.typography.titleLarge) },
            actions = {
                IconButton(onClick = vm::openImport) {
                    Icon(Icons.Filled.Add, contentDescription = "Import from Spotify")
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        if (vm.playlists.isEmpty()) {
            EmptyState(
                title = "No playlists yet",
                body = "Import a Spotify playlist or album (just paste its link) and Mixtape fills it with the matching " +
                    "songs on this phone, in the same order. Missing songs can be downloaded in one tap.",
            ) {
                Button(shape = TermShape, onClick = vm::openImport) { Text("Import from Spotify") }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(vm.playlists, key = { it.id }) { p ->
                    PlaylistCard(p, vm.rows[p.id]) { vm.push(Screen.Playlist(p.id)) }
                }
            }
        }
    }
}

@Composable
private fun PlaylistCard(p: SavedPlaylist, rows: List<PlaylistRow>?, onClick: () -> Unit) {
    val found = rows?.count { it.local != null } ?: 0
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(
            p.imageUrl,
            Modifier.size(64.dp),
            fallback = if (p.id == LIKED_ID) Icons.Filled.Favorite else Icons.Filled.MusicNote,
        )
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (rows == null) "Matching…" else foundLabel(found, p.tracks.size),
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 1,
            )
            Spacer(Modifier.height(8.dp))
            MatchStrip(rows?.map { it.local != null } ?: List(p.tracks.size) { false })
        }
    }
}
