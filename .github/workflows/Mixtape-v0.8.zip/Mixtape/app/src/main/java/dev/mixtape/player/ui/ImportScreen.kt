package dev.mixtape.player.ui

import dev.mixtape.player.spotify.SpotifyPublic
import dev.mixtape.player.Config
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import android.net.Uri
import android.content.Intent
import dev.mixtape.player.ui.theme.TermShape
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.data.LIKED_ID
import dev.mixtape.player.data.SpotifyPlaylistSummary
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportScreen(vm: MainViewModel) {
    var selected by remember { mutableStateOf(setOf<String>()) }
    var menuOpen by remember { mutableStateOf(false) }
    val remote = vm.remote

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("~/import", style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            actions = {
                if (vm.loggedIn) {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Reload playlists") },
                            onClick = {
                                menuOpen = false
                                vm.loadRemotePlaylists()
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Log out of Spotify") },
                            onClick = {
                                menuOpen = false
                                selected = emptySet()
                                vm.logout()
                            },
                        )
                    }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )

        LinkImport(vm)

        when {
            !vm.loggedIn -> ConnectPanel(vm)

            remote == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (vm.busy == null) {
                    TextButton(onClick = vm::loadRemotePlaylists) { Text("Load my playlists", color = Mix.Tape) }
                }
            }

            else -> {
                val imported = vm.playlists.map { it.id }.toSet()
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(remote, key = { it.id }) { p ->
                        RemoteRow(
                            p = p,
                            checked = p.id in selected,
                            imported = p.id in imported,
                            onToggle = { selected = if (p.id in selected) selected - p.id else selected + p.id },
                        )
                    }
                }
                Surface(color = Mix.Deep) {
                    Button(shape = TermShape, 
                        onClick = { vm.importSelected(selected) },
                        enabled = selected.isNotEmpty() && vm.busy == null,
                        colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 12.dp),
                    ) {
                        Text(
                            when (selected.size) {
                                0 -> "Choose playlists to import"
                                1 -> "Import 1 playlist"
                                else -> "Import ${selected.size} playlists"
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectPanel(vm: MainViewModel) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var open by remember { mutableStateOf(vm.spotifyClientId.isNotBlank()) }
    var clientId by remember { mutableStateOf(vm.spotifyClientId) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Text(
            (if (open) "▾ " else "▸ ") + "connect your Spotify account (optional)",
            style = MaterialTheme.typography.titleMedium,
            color = Mix.Paper,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { open = !open }
                .padding(vertical = 8.dp),
        )
        Text(
            "Only for private playlists and Liked Songs. Public playlists and albums just need their link.",
            style = MaterialTheme.typography.bodySmall,
            color = Mix.Fog,
        )
        if (open) {

        Spacer(Modifier.height(16.dp))
        Step("1", "Open the Spotify dashboard and log in (needs Spotify Premium).") {
            SmallButton("open") {
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://developer.spotify.com/dashboard"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            }
        }
        Step("2", "Create app → any name → Redirect URI: ${Config.REDIRECT_URI} → tick Web API → Save.") {
            SmallButton("copy URI") { clipboard.setText(AnnotatedString(Config.REDIRECT_URI)) }
        }
        Step("3", "Open the app's settings, copy the Client ID and paste it here.") {}
        OutlinedTextField(
            value = clientId,
            onValueChange = {
                clientId = it.trim()
                vm.chooseClientId(clientId)
            },
            singleLine = true,
            placeholder = { Text("Client ID") },
            trailingIcon = {
                IconButton(onClick = {
                    clipboard.getText()?.text?.trim()?.let {
                        clientId = it
                        vm.chooseClientId(it)
                    }
                }) { Icon(Icons.Filled.ContentPaste, contentDescription = "Paste") }
            },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 28.dp),
        )
        Spacer(Modifier.height(12.dp))
        Step("4", "Connect and allow access. Mixtape only reads your playlists.") {}
        Spacer(Modifier.height(4.dp))
        if (vm.waitingForLogin) {
            Row(Modifier.padding(start = 28.dp), verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(20.dp), color = Mix.Tape, strokeWidth = 2.dp)
                Spacer(Modifier.width(12.dp))
                Text("Log in to Spotify in your browser, then come back.", style = MaterialTheme.typography.bodyMedium)
            }
            TextButton(onClick = vm::connectSpotify, modifier = Modifier.padding(start = 16.dp)) {
                Text("Open the login page again", color = Mix.Tape)
            }
        } else {
            Button(
                shape = TermShape,
                onClick = vm::connectSpotify,
                enabled = clientId.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                modifier = Modifier.padding(start = 28.dp),
            ) {
                Text("Connect Spotify")
            }
        }
        }
    }
}

@Composable
private fun Step(number: String, text: String, action: @Composable () -> Unit) {
    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("$number.", style = MaterialTheme.typography.bodyMedium, color = Mix.Tape, modifier = Modifier.width(28.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, modifier = Modifier.weight(1f))
        action()
    }
}

@Composable
private fun SmallButton(label: String, onClick: () -> Unit) {
    TextButton(onClick = onClick) { Text("[ $label ]", color = Mix.Tape) }
}

@Composable
private fun RemoteRow(p: SpotifyPlaylistSummary, checked: Boolean, imported: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (p.canImport) Modifier.clickable(onClick = onToggle) else Modifier)
            .padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp)
            .alpha(if (p.canImport) 1f else 0.45f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(
            p.imageUrl,
            Modifier.size(52.dp),
            corner = 4.dp,
            fallback = if (p.id == LIKED_ID) Icons.Filled.Favorite else Icons.Filled.MusicNote,
            iconSize = 22.dp,
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                when {
                    !p.canImport -> "Made by ${p.ownerName}. Spotify only shares songs from playlists you made or collaborate on."
                    imported -> "${p.trackCount} songs, already imported. Select to update it."
                    else -> "${p.trackCount} songs"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (p.canImport) {
            Checkbox(
                checked = checked,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = Mix.Tape, checkmarkColor = Mix.Ink),
            )
        }
    }
}

/** Paste a public Spotify playlist or album link; no login needed. */
@Composable
private fun LinkImport(vm: MainViewModel) {
    var link by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            }.getOrNull()
            vm.importFromFile(uri, name)
        }
    }
    LaunchedEffect(Unit) {
        val copied = clipboard.getText()?.text?.trim().orEmpty()
        if (link.isEmpty() && SpotifyPublic.isSpotifyLink(copied)) link = copied
    }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text("Paste a playlist or album link", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = link,
            onValueChange = { link = it },
            singleLine = true,
            placeholder = { Text("https://open.spotify.com/playlist/…") },
            trailingIcon = {
                IconButton(onClick = { clipboard.getText()?.text?.let { link = it.trim() } }) {
                    Icon(Icons.Filled.ContentPaste, contentDescription = "Paste")
                }
            },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(shape = TermShape, 
                onClick = { vm.importFromLink(link.trim()) },
                enabled = link.isNotBlank() && vm.busy == null,
                colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) {
                Text("Import")
            }
            Spacer(Modifier.width(8.dp))
            TextButton(
                onClick = { pickFile.launch(arrayOf("text/*", "application/csv", "application/octet-stream")) },
                enabled = vm.busy == null,
            ) {
                Text("From a file (CSV / text)", color = Mix.Tape)
            }
        }
    }
}
