package dev.mixtape.player.ui

import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix

/** Cover art with a quiet placeholder icon underneath (shown when there's no art). */
@Composable
fun Artwork(
    model: Any?,
    modifier: Modifier,
    corner: Dp = 6.dp,
    fallback: ImageVector = Icons.Filled.MusicNote,
    iconSize: Dp = 24.dp,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Mix.Raised),
        contentAlignment = Alignment.Center,
    ) {
        Icon(fallback, contentDescription = null, tint = Mix.Fog, modifier = Modifier.size(iconSize))
        if (model != null) {
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/**
 * One tick per song in playlist order: yellow if the song is on this phone, dark if missing.
 * Shows at a glance where the gaps are.
 */
@Composable
fun MatchStrip(found: List<Boolean>, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(height / 2)),
    ) {
        val n = found.size
        if (n == 0) {
            drawRect(Mix.Gap)
            return@Canvas
        }
        val gap = if (n <= 60) 2.dp.toPx() else 0f
        val w = ((size.width - gap * (n - 1)) / n).coerceAtLeast(1f)
        found.forEachIndexed { i, ok ->
            drawRect(
                color = if (ok) Mix.Tape else Mix.Gap,
                topLeft = Offset(i * (w + gap), 0f),
                size = Size(w, size.height),
            )
        }
    }
}

fun foundLabel(found: Int, total: Int): String = when {
    total == 0 -> "Empty playlist"
    found == total -> "All $total songs on this phone"
    found == 0 -> "None of the $total songs are on this phone yet"
    else -> "$found of $total songs on this phone"
}

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSec / 60, totalSec % 60)
}

/** A song file on the phone, used in the Songs tab and the match picker. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LocalTrackRow(
    track: LocalTrack,
    highlighted: Boolean,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Mix.Raised else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selected) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Mix.Tape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Check, contentDescription = "Selected", tint = Mix.Ink, modifier = Modifier.size(24.dp))
            }
        } else {
            Artwork(track.artUri, Modifier.size(44.dp), corner = 4.dp, iconSize = 20.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (highlighted) Mix.Tape else Mix.Paper,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOf(track.artist, track.album).filter { it.isNotEmpty() }.joinToString(", ").ifEmpty { "Unknown artist" },
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(formatTime(track.durationMs), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
    }
}

@Composable
fun MiniPlayer(
    now: NowPlaying,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit = {},
    swipeEnabled: Boolean = true,
) {
    // Swipe left for the next song, right for the one before. The row follows the finger a little.
    val scope = rememberCoroutineScope()
    val drag = remember { Animatable(0f) }
    val next by rememberUpdatedState(onNext)
    val previous by rememberUpdatedState(onPrevious)
    val swipe = Modifier.pointerInput(Unit) {
        val threshold = 72.dp.toPx()
        var total = 0f
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = {
                when {
                    total < -threshold -> next()
                    total > threshold -> previous()
                }
                total = 0f
                scope.launch { drag.animateTo(0f) }
            },
            onDragCancel = {
                total = 0f
                scope.launch { drag.animateTo(0f) }
            },
            onHorizontalDrag = { change, amount ->
                change.consume()
                total += amount
                scope.launch { drag.snapTo(total * 0.35f) }
            },
        )
    }
    Surface(color = Mix.Deep) {
        Column {
            val progress = if (now.durationMs > 0) now.positionMs.toFloat() / now.durationMs else 0f
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(Mix.Gap),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(Mix.Tape),
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .then(if (swipeEnabled) swipe else Modifier)
                    .clickable(onClick = onOpen)
                    .offset { IntOffset(drag.value.roundToInt(), 0) }
                    .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(now.artworkUri, Modifier.size(44.dp), corner = 4.dp, iconSize = 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(now.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (now.artist.isNotEmpty()) {
                        Text(
                            now.artist,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Mix.Fog,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                IconButton(onClick = onToggle) {
                    Icon(
                        if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next song")
                }
            }
        }
    }
}

@Composable
fun BusyBar(text: String) {
    Column(Modifier.fillMaxWidth()) {
        LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mix.Tape, trackColor = Mix.Gap)
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Fog,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
    }
}

/** Centered message with one action, for empty screens. */
@Composable
fun EmptyState(title: String, body: String, action: (@Composable () -> Unit)? = null) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(body, style = MaterialTheme.typography.bodyLarge, color = Mix.Fog)
        if (action != null) {
            Spacer(Modifier.height(24.dp))
            action()
        }
    }
}
