package dev.mixtape.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Share
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.launch

private data class TutorialPage(val icon: ImageVector, val title: String, val lines: List<String>)

private val PAGES = listOf(
    TutorialPage(
        Icons.Filled.LibraryMusic,
        "Bring your playlists",
        listOf(
            "Playlists → + : paste a Spotify playlist or album link, or pick a file.",
            "Mixtape lines the songs up with the music on your phone, in the same order.",
            "Spotify playlists update themselves once a day (Settings → spotify sync).",
            "Or make your own with the folder-plus icon.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Download,
        "Fill the gaps",
        listOf(
            "In a playlist, Download missing gets the songs you don't have yet.",
            "Or paste any link in the Download tab, or share it to Mixtape from another app.",
            "Pick the quality there: MP3, M4A, MX original or FLAC.",
        ),
    ),
    TutorialPage(
        Icons.Filled.PlayCircle,
        "The player",
        listOf(
            "Swipe up on the player for the artist, your stats and their albums.",
            "[ quality ▾ ] switches between versions of a song, or gets another one.",
            "The pencil edits the title, artist and cover inside the file.",
            "On the mini player, swipe left for the next song, right for the one before.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Mic,
        "Lyrics and karaoke",
        listOf(
            "[ lyrics ] on the player. Tap a line to jump there.",
            "文A translates every line, on the phone.",
            "The microphone turns on karaoke: the line fills in as it's sung.",
            "The vocals slider turns the voice down, all the way to instrumental.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Equalizer,
        "Make it sound right",
        listOf(
            "The sliders icon on the player: presets, 5 bands, bass, surround and boost.",
            "Slowed or sped up, reverb, bitcrush, fade and crossfade.",
            "Tape stop (Settings → player): pause slows down like a tape deck.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Share,
        "Share a tape",
        listOf(
            "The share icon on a playlist turns it into a cassette with a QR code.",
            "Your friend scans it: Playlists → + → Scan a tape.",
            "They see what they already have, and can download the rest.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Groups,
        "Listen together",
        listOf(
            "Both phones on the same Wi-Fi, Mixtape open on both.",
            "The people icon on the player → pick the phone → invite.",
            "Play on both phones at the same second, or use one as the speaker and the other as the remote.",
            "A song only one of you has streams over the Wi-Fi.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Lock,
        "The vault",
        listOf(
            "Hold an album or playlist → Move to vault, or Delete album.",
            "The vault opens from Settings → vault, with your PIN or fingerprint.",
            "Hold something inside the vault to take it back out.",
            "Settings → library cleanup finds duplicates, missing covers and messy names.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Insights,
        "Your music, your numbers",
        listOf(
            "Smart playlists: most played, recently added, forgotten favourites, never played.",
            "Settings → stats: listening time, top songs and artists, and your Wrapped.",
            "Concerts: upcoming shows of the artists you play, near you first.",
        ),
    ),
    TutorialPage(
        Icons.Filled.GraphicEq,
        "Last.fm",
        listOf(
            "Saves every song you play to your Last.fm profile (\"scrobbling\").",
            "No account? Make a free one at last.fm/join.",
            "Settings → last.fm → [ connect ], then your Last.fm name and password. Only once.",
            "Songs played offline are kept and sent when you're back online.",
        ),
    ),
    TutorialPage(
        Icons.Filled.ScreenRotation,
        "Clock mode and widgets",
        listOf(
            "Turn it on in Settings → player, then turn the phone sideways (auto-rotate on).",
            "Big clock, date, what's playing and your notifications. The screen stays on.",
            "Home screen widgets: now playing, cover, cover + clock, and continue.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Palette,
        "Make it yours",
        listOf(
            "Settings: themes, your own colours, 11 fonts or your own, rounded or terminal style.",
            "A background picture or video, and the ASCII visualiser above the mini player.",
            "Settings → backup saves playlists, stats, lyrics and settings in one file.",
        ),
    ),
)

/** Bump when there are new pages: people who saw an older tutorial see it once more. */
const val TUTORIAL_VERSION = 3

/** A few quick pages on the first launch (and after big updates); replay any time from Settings → about. */
@Composable
fun TutorialScreen(onDone: () -> Unit) {
    val pager = rememberPagerState { PAGES.size }
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .background(Mix.Ink)
            .systemBarsPadding()
            .padding(28.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDone) { Text("Skip", color = Mix.Fog) }
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val p = PAGES[page]
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center,
            ) {
                Icon(p.icon, contentDescription = null, tint = Mix.Tape, modifier = Modifier.size(72.dp))
                Spacer(Modifier.height(28.dp))
                Text(Ui.head(p.title.lowercase()), style = MaterialTheme.typography.displaySmall, color = Mix.Paper)
                Spacer(Modifier.height(20.dp))
                p.lines.forEach { line ->
                    Text("· $line", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            repeat(PAGES.size) { i ->
                Box(
                    Modifier
                        .padding(end = 5.dp)
                        .size(if (i == pager.currentPage) 16.dp else 6.dp, 6.dp)
                        .background(if (i == pager.currentPage) Mix.Tape else Mix.Gap, TermShape),
                )
            }
            Spacer(Modifier.weight(1f))
            val last = pager.currentPage == PAGES.lastIndex
            Button(
                shape = TermShape,
                onClick = { if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
                colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) { Text(if (last) "Start" else "Next") }
        }
        Spacer(Modifier.width(1.dp))
    }
}
