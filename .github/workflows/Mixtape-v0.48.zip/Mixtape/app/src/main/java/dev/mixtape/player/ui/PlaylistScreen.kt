package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.VerticalAlignTop
import androidx.compose.material.icons.filled.SwapVert
import dev.mixtape.player.ui.theme.TermShape
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.data.LIKED_ID
import dev.mixtape.player.data.PlaylistRow
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaylistScreen(vm: MainViewModel, id: String) {
    val playlist = vm.playlists.find { it.id == id }
    if (playlist == null) {
        LaunchedEffect(id) { vm.pop() }
        return
    }
    val rows = vm.sortedRows(id)
    // Search inside the playlist: song title, artists, album, or the matched file's names.
    var query by rememberSaveable(id) { mutableStateOf("") }
    val shown = remember(rows, query) {
        val q = query.trim()
        rows.withIndex().filter { (_, r) ->
            q.isEmpty() ||
                r.track.title.contains(q, true) ||
                r.track.artists.any { it.contains(q, true) } ||
                r.track.album.contains(q, true) ||
                (r.local?.title?.contains(q, true) == true) ||
                (r.local?.artist?.contains(q, true) == true)
        }
    }
    val sort = vm.sortModeOf(id)
    val now by vm.player.state.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var picking by remember { mutableStateOf<PlaylistRow?>(null) }
    var deletingAlbum by remember { mutableStateOf(false) }

    val found = rows.count { it.local != null }
    val total = playlist.tracks.size
    // Albums imported from Spotify look like the albums on the phone (cover per song, length).
    val isAlbum = id.startsWith("album:")
    val albumArtist = remember(playlist) {
        playlist.tracks.flatMap { it.artists.take(1) }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key.orEmpty()
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { if (isAlbum) Text(Ui.path("albums"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                if (editing) {
                    TextButton(onClick = { editing = false }) { Text(Ui.btn("done"), color = Mix.Tape) }
                }
                // Share as a tape (QR code a friend scans).
                IconButton(onClick = { vm.push(Screen.ShareTape(id)) }) {
                    Icon(Icons.Filled.Share, contentDescription = "Share as a tape")
                }
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "More options")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    Text(
                        "sort by",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                    )
                    SortMode.entries.forEach { mode ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    (if (mode == sort) "(•) " else "( ) ") + mode.label,
                                    color = if (mode == sort) Mix.Tape else Mix.Paper,
                                )
                            },
                            onClick = {
                                menuOpen = false
                                vm.chooseSort(id, mode)
                                if (mode != SortMode.PLAYLIST) editing = false
                            },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (id.startsWith("mine:")) "Edit songs" else "Edit order") },
                        leadingIcon = { Icon(Icons.Filled.SwapVert, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            vm.chooseSort(id, SortMode.PLAYLIST)
                            editing = true
                        },
                    )
                    HorizontalDivider(color = Mix.Gap)
                    DropdownMenuItem(
                        text = { Text("Update from Spotify") },
                        leadingIcon = { Icon(Icons.Filled.Sync, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            vm.resync(id)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text(if (vm.isHidden("pl:$id")) "Take out of the vault" else "Move to vault") },
                        leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                        onClick = {
                            menuOpen = false
                            if (vm.isHidden("pl:$id")) vm.takeOutOfVault("pl:$id") else vm.moveToVault("pl:$id")
                        },
                    )
                    if (isAlbum) {
                        DropdownMenuItem(
                            text = { Text("Delete album…", color = Mix.Alert) },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = Mix.Alert) },
                            onClick = {
                                menuOpen = false
                                deletingAlbum = true
                            },
                        )
                    } else {
                        DropdownMenuItem(
                            text = { Text("Remove playlist") },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                vm.removePlaylist(id)
                            },
                        )
                    }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )

        val listState = rememberLazyListState()
        Box(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
                        item(key = "header") {
                            Column(Modifier.padding(horizontal = 20.dp, vertical = if (isAlbum) 8.dp else 0.dp)) {
                                Row(verticalAlignment = if (isAlbum) Alignment.CenterVertically else Alignment.Bottom) {
                                    Artwork(
                                        playlist.imageUrl,
                                        Modifier.size(if (isAlbum) 140.dp else 112.dp),
                                        corner = if (isAlbum) 6.dp else 8.dp,
                                        fallback = if (id == LIKED_ID) Icons.Filled.Favorite else Icons.Filled.MusicNote,
                                        iconSize = 40.dp,
                                    )
                                    Spacer(Modifier.width(16.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            playlist.name,
                                            style = MaterialTheme.typography.titleLarge,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis,
                                        )
                                        if (isAlbum) {
                                            if (albumArtist.isNotEmpty()) {
                                                Text(albumArtist, style = MaterialTheme.typography.bodyLarge, color = Mix.Fog, maxLines = 1)
                                            }
                                            Text(
                                                "$total songs · ${formatListened(playlist.tracks.sumOf { it.durationMs })}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Mix.Fog,
                                            )
                                            if (found < total) {
                                                Text("${total - found} not on this phone", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                                            }
                                        } else {
                                            Spacer(Modifier.height(4.dp))
                                            Text(foundLabel(found, total), style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
                                        }
                                    }
                                }
                                if (isAlbum) {
                                    Spacer(Modifier.height(16.dp))
                                } else {
                                    Spacer(Modifier.height(18.dp))
                                    MatchStrip(rows.map { it.local != null }, height = 8.dp)
                                    Spacer(Modifier.height(18.dp))
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Button(shape = TermShape, 
                                        onClick = { vm.playPlaylist(id, shuffle = false) },
                                        enabled = found > 0,
                                        colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                                    ) {
                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Play")
                                    }
                                    OutlinedButton(shape = TermShape, onClick = { vm.playPlaylist(id, shuffle = true) }, enabled = found > 0) {
                                        Icon(Icons.Filled.Shuffle, contentDescription = null, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Shuffle")
                                    }
                                }
                                if (found < total) {
                                    Spacer(Modifier.height(12.dp))
                                    OutlinedButton(shape = TermShape, onClick = { vm.downloadMissing(id) }) {
                                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Download ${total - found} missing (${vm.quality.label})")
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Text(
                                        "Missing songs fill in by themselves when their files land on this phone. " +
                                            "Tap a missing song, or hold any song, to choose its file yourself.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Mix.Fog,
                                    )
                                }
                                Spacer(Modifier.height(12.dp))
                            }
                        }
                        if (!isAlbum) item(key = "song-search") {
                            Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
                                CompactSearchField(
                                    value = query,
                                    onValueChange = { query = it },
                                    placeholder = "Search songs or artists",
                                    enabled = !editing,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                if (query.isNotBlank()) {
                                    Text(
                                        "${shown.size} of ${rows.size} songs",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Mix.Fog,
                                        modifier = Modifier.padding(top = 4.dp),
                                    )
                                }
                            }
                        }
                        // While editing the order, every song is listed (moving needs the full list).
                        items(if (editing) rows.withIndex().toList() else shown, key = { (i, r) -> "$i:${r.track.id}" }) { (i, row) ->
                            Box(if (Mix.animations) Modifier.animateItem() else Modifier) {
                            if (editing) {
                                EditRow(
                                    position = i + 1,
                                    row = row,
                                    canUp = i > 0,
                                    canDown = i < rows.lastIndex,
                                    onUp = { vm.moveTrack(id, i, i - 1) },
                                    onDown = { vm.moveTrack(id, i, i + 1) },
                                    onTop = { vm.moveTrack(id, i, 0) },
                                    onRemove = if (id.startsWith("mine:")) ({ vm.removeFromPlaylist(id, i) }) else null,
                                )
                            } else {
                                SwipeToQueue(
                                    enabled = row.local != null,
                                    edge = 56.dp,
                                    onQueue = {
                                        row.local?.let {
                                            vm.player.addToQueue(listOf(it))
                                            vm.showMessage("Added to queue: ${it.title}")
                                        }
                                    },
                                ) {
                                    if (isAlbum) {
                                        AlbumTrackRow(
                                            row = row,
                                            albumName = playlist.name,
                                            cover = playlist.imageUrl,
                                            playing = row.local != null && now.mediaId == row.local.id.toString(),
                                            onClick = { if (row.local != null) vm.playPlaylist(id, fromRow = i) else picking = row },
                                            onLongClick = { picking = row },
                                        )
                                    } else {
                                        TrackRow(
                                            position = i + 1,
                                            row = row,
                                            playing = row.local != null && now.mediaId == row.local.id.toString(),
                                            onClick = { if (row.local != null) vm.playPlaylist(id, fromRow = i) else picking = row },
                                            onLongClick = { picking = row },
                                        )
                                    }
                                }
                            }
                            }
                        }
                    }
            FastScrollbar(listState, Modifier.align(Alignment.CenterEnd))
        }
    }

    picking?.let { row ->
        MatchPicker(vm, row, onDismiss = { picking = null })
    }
    if (deletingAlbum) AlbumDeleteDialog(vm, playlistId = id, folder = null) { deletingAlbum = false }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TrackRow(
    position: Int,
    row: PlaylistRow,
    playing: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val onPhone = row.local != null
    Row(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "$position",
            style = MaterialTheme.typography.labelMedium,
            color = if (playing) Mix.Tape else Mix.Fog,
            modifier = Modifier.width(36.dp),
        )
        Column(
            Modifier
                .weight(1f)
                .alpha(if (onPhone) 1f else 0.45f),
        ) {
            Text(
                row.track.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (playing) Mix.Tape else Mix.Paper,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                row.track.artists.joinToString(", "),
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(12.dp))
        when {
            !onPhone -> Text("Missing", style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
            row.manual -> Icon(
                Icons.Filled.Link,
                contentDescription = "File chosen by you",
                tint = Mix.Fog,
                modifier = Modifier.size(18.dp),
            )
            else -> Text(formatTime(row.track.durationMs), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
        }
    }
}

/** A song of an imported album, laid out like the albums on the phone: cover, title, "Artist, Album", length. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AlbumTrackRow(
    row: PlaylistRow,
    albumName: String,
    cover: String?,
    playing: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val onPhone = row.local != null
    Row(
        Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .alpha(if (onPhone) 1f else 0.45f),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(row.local?.artUri ?: cover, Modifier.size(44.dp), corner = 4.dp, iconSize = 20.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                row.track.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (playing) Mix.Tape else Mix.Paper,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOf(row.track.artists.joinToString(", "), row.track.album.ifEmpty { albumName })
                    .filter { it.isNotEmpty() }
                    .joinToString(", "),
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(
            if (onPhone) formatTime(row.local?.durationMs?.takeIf { it > 0 } ?: row.track.durationMs) else "Missing",
            style = MaterialTheme.typography.labelMedium,
            color = Mix.Fog,
        )
    }
}

/** Lets you choose which file on the phone plays for one Spotify song. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MatchPicker(vm: MainViewModel, row: PlaylistRow, onDismiss: () -> Unit) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var query by remember(row.track.id) { mutableStateOf(row.track.title) }
    val results = remember(query, vm.library) { vm.searchLibrary(query, limit = 100) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = Mix.Deep) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Text("Choose the file for", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
            Text(row.track.title, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(row.track.artists.joinToString(", "), style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                placeholder = { Text("Search songs on this phone") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Mix.Tape,
                    cursorColor = Mix.Tape,
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 4.dp),
            )
            if (row.manual) {
                TextButton(onClick = {
                    vm.setManualMatch(row.track.id, null)
                    onDismiss()
                }) {
                    Text("Use automatic matching again", color = Mix.Tape)
                }
            }
        }
        LazyColumn(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 460.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
        ) {
            items(results, key = { it.id }) { t ->
                LocalTrackRow(t, highlighted = t.id == row.local?.id) {
                    vm.setManualMatch(row.track.id, t.id)
                    onDismiss()
                }
            }
            if (results.isEmpty()) {
                item {
                    Text(
                        "No songs on this phone match that search. Try fewer words.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

/** A song row in Edit order mode: move it up, down, or to the top. */
@Composable
private fun EditRow(
    position: Int,
    row: PlaylistRow,
    canUp: Boolean,
    canDown: Boolean,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onTop: () -> Unit,
    onRemove: (() -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "$position",
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Fog,
            modifier = Modifier.width(32.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(row.track.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                row.track.artists.joinToString(", "),
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        IconButton(onClick = onTop, enabled = canUp) {
            Icon(Icons.Filled.VerticalAlignTop, contentDescription = "Move to top")
        }
        IconButton(onClick = onUp, enabled = canUp) {
            Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up")
        }
        IconButton(onClick = onDown, enabled = canDown) {
            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down")
        }
        if (onRemove != null) {
            IconButton(onClick = onRemove) {
                Icon(Icons.Filled.Close, contentDescription = "Remove from playlist", tint = Mix.Alert)
            }
        }
    }
}
