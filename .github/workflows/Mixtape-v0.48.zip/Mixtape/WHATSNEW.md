Mixtape v0.48

- Vault: [ open ] now asks for your fingerprint (or PIN) in a pop-up.
- Settings → updates: the app update and the downloader update are together now.
- New versions are announced once: a phone notification (even with the app closed) or a pop-up in the app.
