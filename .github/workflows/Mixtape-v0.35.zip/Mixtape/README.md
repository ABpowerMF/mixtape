# Mixtape

A music player for the songs on your phone that rebuilds your Spotify playlists from them,
and can download the songs you're missing.

- **Import** a Spotify playlist or album by pasting its link (no login needed). Mixtape lines the
  songs up with the files on your phone, in the same order.
- **Download missing** fetches only the songs of a playlist you don't have yet.
- **Download tab**: paste (or share to Mixtape) any YouTube or Spotify link: a song, album or
  playlist. Pick the quality: MP3 128/192/320, M4A original, MX original (Opus), or FLAC.
  Files go to `Music/Mixtape`. Songs are matched on YouTube Music, closest in length to the
  Spotify version, so you get the album cut (no video intros) with the square album cover.
- **Settings tab**: themes (Terminal, Black & white, White & black, Green & white, Amber,
  Night drive) or your own colours, terminal or clean font, default quality, songs downloaded at
  once, swipe on/off, update the downloader, rescan music.
- **Stats** (Settings → stats): total listening time, most listened songs and top artists.
- **Playlist order**: ⋮ menu on a playlist → sort by playlist order, title, artist or length,
  or *Edit order* to move songs up, down or to the top.
- **Albums**: paste an album link (Spotify or YouTube Music), or type an album name in the
  Download tab and tap Search. On the player, the quality menu has *get the whole album*.
  Albums go in their own folder (Music/Mixtape/Artist - Album) with album name and track numbers,
  and show up in the collapsible *albums* section below your playlists.
- **Import from a file (offline)**: Spotify's "Download your data" zip (liked songs + every playlist,
  private ones too), CSV/TXT from TuneMyMusic or Soundiiz (any service), or "Artist - Title" lines.
  Import → *how do I get a file?* explains each.
- **Queue**: on the player tap *[ queue ]*; in Songs, hold songs → *play next* / *add to queue*.
- **Music folders** (Settings): all music, only the Music folder, or only Mixtape's folder.
  Voice notes, recordings and ringtones are skipped.
- **Playlist search**, and a colour picker (the + after the colour swatches) for any custom colour.
- **Lyrics**: on the player tap *[ lyrics ]*. Synced lyrics light up line by line (tap a line to jump
  there); otherwise plain text. Found once on LRCLIB, then kept on the phone for offline use. You can
  also paste your own (plain or LRC). Online lookup can be turned off in Settings.
  The translate button (文A) shows a translation under each line, done on the phone with Google ML Kit:
  each language downloads once (~30 MB), then works offline.
- **Equaliser**: the sliders icon on the player (or Settings → player). 13 presets, 5 bands,
  bass/depth, surround/width and a volume boost. Uses Android's built-in audio effects.
- **Sideways clock mode** (Settings → player): turn the phone sideways for a smart-display style
  screen with a big clock, the date, the cover, the song and controls. Full screen, stays on.
  The screen also stays on while you read lyrics.
- **Look** (Settings): style *Terminal* (square, [ brackets ]) or *Rounded* (soft corners, plain labels);
  11 fonts (monospace, JetBrains Mono, VT323, 8-bit, Inter, Nunito, Barlow, Space Grotesk, Playfair…)
  or import your own .ttf/.otf; new themes Soft light, Soft dark and Rose.
- **Your own playlists**: Playlists → folder-plus icon, or add songs from the Songs tab (hold → add to
  playlist) and from the player (+ icon). Edit songs to reorder or remove.
- **Player**: swipe up for artist info (Wikipedia, with photos), your stats and their albums. Video covers: the
  song's music video plays silently instead of the cover (Settings → player; Wi-Fi only by default).
- **Fade in & out** between songs (Equaliser → fade).
- **Clock mode** follows the phone's auto-rotate switch; options for seconds, date, cover, colour, size,
  brightness (normal / dim / night) and a notification bell (needs notification access).
- **Mixtape Wrapped** (Stats → wrapped): recap for this month, last month, this year or all time,
  shareable as a story image.
- **Smart playlists**: Most played, Recently added, Forgotten favourites, Never played.
- **Crossfade** (Equaliser → fade): the next song starts while the current one fades out.
- **Edit song**: title, artist, album and cover, saved into the file (player quality menu, or hold a song).
- **Backup & restore** (Settings → backup): playlists, stats, lyrics and settings in one file.
- **Home screen shortcuts**: long-press the icon for Clock mode and your last playlist.
- **Android Auto**: playlists, albums, smart playlists and all songs in the car. For an app not from the
  Play Store, turn on Android Auto → developer settings → Unknown sources.
- **Tutorial** on first install; replay it from Settings → about.
- **Background picture or video** (Settings → background picture), with a darken slider.
- **Battery**: the app only updates the screen while it's visible; fades/crossfade sleep between songs;
  video covers and background videos pause when the app is in the background.
- **Concerts** (Playlists tab, under smart playlists): upcoming shows of your top 30 artists from
  Spotify, the ones near you first (set your area: location or a city; 50/150/500 km), and every
  tour date by date or by artist. Tap a show for tickets. Checked once a day.
- **Widgets**: long-press the home screen → Widgets → Mixtape: *now playing* (cover, song,
  play/pause, next), *cover*, or *cover + clock*.
- **Scroll bar**: drag the right edge of any long list to jump through it.
- **Covers**: songs from Spotify get Spotify's own album cover.
- **Mini player**: swipe left for the next song, right for the one before.
- **Versions**: on the player, tap the `[ quality ▾ ]` button to switch between downloaded
  versions of a song, or get it in another quality.
- **Full playlists**: link import reads every song, not just the first 100. If Spotify blocks that,
  the app says where it failed; importing a CSV or "Artist - Title" text file always works.
- **Delete songs**: in the Songs tab, hold a song to start selecting, tap *Select all* to pick
  everything shown (use search to narrow it), then the bin icon.

About quality: the audio comes from YouTube, whose best stream is about 160 kbps Opus.
"MX original" keeps exactly that. MP3 320 and FLAC make bigger files but can't sound better.

---

## Building without a computer (GitHub)

1. Create a **private** GitHub repository.
2. Upload `Mixtape.zip` to it (*Add file → Upload files*).
3. Create `.github/workflows/build.yml` (*Add file → Create new file*) with the workflow from the chat.
4. Open the **Actions** tab and wait for the green tick (about 10 minutes).
5. Open **Releases** (on the repo's main page), download the newest `Mixtape-N.apk` and install it.

Every time you upload a new `Mixtape.zip`, a new APK is built. It installs over the old one and
keeps your playlists, because every build is signed with the same key (`mixtape.keystore`).

## Optional: logging in to Spotify

Only needed for private playlists and Liked Songs. In the app: Playlists → + → *connect your
Spotify account* and follow the 4 steps on screen (open the dashboard, create an app with the
redirect address shown, paste the Client ID, connect). No rebuilding needed. Spotify requires
Premium on the account that creates the developer app.

The easiest way to add a public playlist: in Spotify tap Share → Mixtape → *Import playlist*.

## How matching works

Mixtape compares the Spotify song title and artists with each file's title and artist tags.
If a file has no tags, it reads names like `Artist - Title.mp3` (track numbers like `01 - ` are ignored).
It ignores accents, capitals, punctuation, "feat. …", and extras like "Remastered 2011", "Radio Edit"
or "Official Video". It keeps words like **Live**, **Acoustic** and **Remix**, since those are different recordings.
Song length breaks ties.

For the best results, make sure your files have correct title and artist tags.

---

## Limits

- Link import works for public playlists and albums. Very long playlists may stop at 100 songs
  if Spotify doesn't allow reading the rest.
- When logged in, Spotify only shares the songs of playlists **you created or collaborate on**,
  plus your **Liked Songs**.
- If the app owner's Premium lapses, Spotify stops the connection until it's renewed.
  Playlists you already imported keep working.
- Spotify logins expire after a while. When that happens, Mixtape asks you to connect again.

## Troubleshooting

| What you see | Fix |
|---|---|
| Browser shows **INVALID_CLIENT: Invalid redirect URI** | In the Spotify dashboard, the Redirect URI must be exactly `http://127.0.0.1:43821/callback` (no `localhost`, no trailing slash). Click **Save** after editing. |
| Browser shows **INVALID_CLIENT: Invalid client** | The Client ID in `Config.kt` has a typo or extra spaces. |
| "Spotify refused access" (403) | The app owner needs Premium, and any other account must be added in **User Management**. |
| "Add your Spotify Client ID in Config.kt first" | See *Optional: logging in to Spotify*. |
| Browser can't open `127.0.0.1` | Go back to Mixtape and tap **Connect Spotify** again. Mixtape must stay open in the background while you log in. |
| A song shows Missing but the file is on the phone | Hold the song and pick the file. Fixing the file's title/artist tags also helps. |
| A download fails with a YouTube error | Mixtape updates its downloader once a day. Wait a bit, then tap the failed song to retry. |
| The APK won't install over the old one | Uninstall the old Mixtape first (only needed once, if it was built on a different computer). |
| A file doesn't appear in **Songs** at all | Android only indexes files in normal folders (Music, Download). Files in hidden folders or with a `.nomedia` file nearby are skipped. |

---

## Project layout

```
app/src/main/java/dev/mixtape/player/
  Config.kt               Spotify Client ID and redirect address
  MainActivity.kt
  spotify/                Login (PKCE), Web API calls, public link reader
  download/               Download queue (yt-dlp), quality options, saving to Music/Mixtape
  library/                Scans the phone's music, fuzzy matching
  data/                   Playlist storage (JSON in app storage)
  playback/               Background playback service (Media3/ExoPlayer)
  ui/                     Compose screens
```

Font: Barlow, SIL Open Font License (see `FONT_LICENSE_OFL.txt`).

Downloader: youtubedl-android (yt-dlp, Python, ffmpeg, QuickJS), GPL-3.0.
