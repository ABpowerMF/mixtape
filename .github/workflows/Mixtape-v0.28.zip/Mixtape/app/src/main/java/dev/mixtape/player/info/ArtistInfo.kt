package dev.mixtape.player.info

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** A short artist profile from Wikipedia. */
data class ArtistInfo(
    val name: String,
    val description: String,
    val extract: String,
    val imageUrl: String?,
    val pageUrl: String?,
    /** A large photo for the header. */
    val heroUrl: String? = null,
    /** More photos from the Wikipedia article. */
    val photos: List<String> = emptyList(),
)

/**
 * Looks an artist up on Wikipedia once and keeps the result on the phone (offline afterwards).
 * Checks the page is really about a musician, trying "(musician)", "(band)"… when the name is ambiguous.
 * Blocking: use Dispatchers.IO.
 */
object ArtistRepo {

    private const val UA = "Mixtape music player (Android; artist info)"
    private val MUSIC_WORDS = listOf(
        "musician", "singer", "rapper", "band", "producer", "dj", "composer", "songwriter", "group",
        "duo", "vocalist", "guitarist", "pianist", "record", "hip hop", "rock", "pop", "jazz", "music",
    )

    private fun file(context: Context, name: String) =
        File(File(context.filesDir, "artists").apply { mkdirs() }, name.lowercase().filter { it.isLetterOrDigit() }.take(80) + ".json")

    fun cached(context: Context, name: String): ArtistInfo? = runCatching {
        val f = file(context, name)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        if (o.optBoolean("none")) return null
        // Saved by an older version without photos: look it up again.
        if (!o.has("hero")) return null
        val photos = o.optJSONArray("photos")
        ArtistInfo(
            o.optString("name"), o.optString("description"), o.optString("extract"),
            o.optString("image").ifEmpty { null }, o.optString("url").ifEmpty { null },
            o.optString("hero").ifEmpty { null },
            (0 until (photos?.length() ?: 0)).mapNotNull { photos?.optString(it)?.ifEmpty { null } },
        )
    }.getOrNull()

    /** True when an earlier lookup found nothing (so we don't ask again every time). */
    fun knownMissing(context: Context, name: String): Boolean =
        runCatching { JSONObject(file(context, name).readText()).optBoolean("none") }.getOrDefault(false)

    fun fetch(context: Context, name: String): ArtistInfo? {
        val candidates = listOf(name, "$name (musician)", "$name (band)", "$name (rapper)", "$name (singer)")
        for (title in candidates) {
            val o = summary(title) ?: continue
            if (o.optString("type") == "disambiguation") continue
            val description = o.optString("description")
            val extract = o.optString("extract")
            val text = (description + " " + extract.take(300)).lowercase()
            if (MUSIC_WORDS.none { text.contains(it) }) continue
            val pageTitle = o.optString("title").ifEmpty { title }
            val info = ArtistInfo(
                name = pageTitle,
                description = description,
                extract = extract,
                imageUrl = o.optJSONObject("thumbnail")?.optString("source")?.ifEmpty { null },
                pageUrl = o.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page")?.ifEmpty { null },
                heroUrl = o.optJSONObject("originalimage")?.optString("source")?.ifEmpty { null },
                photos = runCatching { photos(pageTitle) }.getOrDefault(emptyList()),
            )
            file(context, name).writeText(
                JSONObject().put("name", info.name).put("description", info.description).put("extract", info.extract)
                    .put("image", info.imageUrl.orEmpty()).put("url", info.pageUrl.orEmpty())
                    .put("hero", info.heroUrl.orEmpty()).put("photos", org.json.JSONArray(info.photos)).toString(),
            )
            return info
        }
        file(context, name).writeText(JSONObject().put("none", true).toString())
        return null
    }

    /** Photos in the article (no logos, icons or signatures), up to 8. */
    private fun photos(title: String): List<String> {
        val path = URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20")
        val json = get("https://en.wikipedia.org/api/rest_v1/page/media-list/$path") ?: return emptyList()
        val items = JSONObject(json).optJSONArray("items") ?: return emptyList()
        val skip = listOf("logo", "icon", "signature", "flag", "symbol", "map", "wordmark", "question_book")
        return (0 until items.length()).mapNotNull { i ->
            val it = items.optJSONObject(i) ?: return@mapNotNull null
            if (it.optString("type") != "image") return@mapNotNull null
            val name = it.optString("title").lowercase()
            if (name.endsWith(".svg") || skip.any { s -> name.contains(s) }) return@mapNotNull null
            val src = it.optJSONArray("srcset")?.let { set ->
                (0 until set.length()).mapNotNull { set.optJSONObject(it) }.maxByOrNull { o -> o.optString("scale").removeSuffix("x").toFloatOrNull() ?: 1f }
            }?.optString("src") ?: return@mapNotNull null
            if (src.startsWith("//")) "https:$src" else src
        }.distinct().take(8)
    }

    private fun get(url: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", UA)
        }
        try {
            return if (conn.responseCode == 200) conn.inputStream.bufferedReader().use { it.readText() } else null
        } finally {
            conn.disconnect()
        }
    }

    private fun summary(title: String): JSONObject? {
        val path = URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20")
        val conn = (URL("https://en.wikipedia.org/api/rest_v1/page/summary/$path?redirect=true").openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", UA)
        }
        try {
            return when (val code = conn.responseCode) {
                200 -> JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                404 -> null
                else -> throw IOException("Wikipedia answered $code")
            }
        } finally {
            conn.disconnect()
        }
    }
}
