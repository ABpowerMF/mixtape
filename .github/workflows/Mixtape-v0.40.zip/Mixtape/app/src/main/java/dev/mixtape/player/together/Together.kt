package dev.mixtape.player.together

import android.content.Context
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.download.SongRequest
import dev.mixtape.player.library.LocalLibrary
import dev.mixtape.player.playback.PlayerConnection
import dev.mixtape.player.ui.MainViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.FileInputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

/** Where the music plays while listening together. */
enum class TogetherMode { BOTH, SPEAKER }

/** What happens with a song only one of the two phones has. */
enum class MissingRule(val label: String) {
    STREAM("Stream it from the phone that has it"),
    DOWNLOAD("Download it for them"),
    SKIP("Skip it"),
}

/** Another phone with Mixtape open on the same Wi-Fi. */
data class Peer(val id: String, val name: String, val platform: String, val host: InetAddress, val port: Int, val service: String)

/** A song in the shared session. [owner] is "host" or "guest": the phone the file is on. */
data class SharedSong(
    val key: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val owner: String,
    val addedBy: String? = null,
)

data class Invite(val from: String, val mode: TogetherMode)

/**
 * Listen together on the same Wi-Fi. Phones find each other on the network (no account, no server).
 * The phone that invites ("host") decides what plays; the other ("guest") either plays the same
 * song at the same second, or is a remote for the host. A song only one phone has is streamed
 * to the other over the Wi-Fi (or downloaded for it, or skipped).
 */
class Together(private val vm: MainViewModel) {

    private val context: Context get() = vm.getApplication<android.app.Application>()
    /** Messages go out one at a time, in order. */
    private val outbox = java.util.concurrent.Executors.newSingleThreadExecutor()
    private val player: PlayerConnection get() = vm.player
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val myId = UUID.randomUUID().toString().take(12)

    // ---------- What the screens show ----------

    var peers by mutableStateOf<List<Peer>>(emptyList()); private set
    var invite by mutableStateOf<Invite?>(null); private set
    var active by mutableStateOf(false); private set
    var isHost by mutableStateOf(false); private set
    var mode by mutableStateOf(TogetherMode.BOTH); private set
    var peerName by mutableStateOf(""); private set
    var status by mutableStateOf<String?>(null); private set
    var rule by mutableStateOf(MissingRule.STREAM); private set

    /** The song playing now (on the host), whether it's playing, and where it was at [hostAt]. */
    var current by mutableStateOf<SharedSong?>(null); private set
    var playing by mutableStateOf(false); private set
    var positionMs by mutableStateOf(0L); private set
    var upNext by mutableStateOf<List<SharedSong>>(emptyList()); private set
    /** Keys of the songs the guest has (host's view) / that this phone has (guest's view). */
    var guestHas by mutableStateOf<Set<String>>(emptySet()); private set

    // ---------- Network ----------

    private var control: ServerSocket? = null
    private var http: ServerSocket? = null
    private var conn: Socket? = null
    private var writer: BufferedWriter? = null
    private var pendingInvite: Socket? = null
    private var peerAddress: InetAddress? = null
    private var peerHttp = 0
    private var sessionJob: Job? = null

    private val nsd: NsdManager? get() = context.getSystemService(NsdManager::class.java)
    private var registered: NsdManager.RegistrationListener? = null
    private var discovery: NsdManager.DiscoveryListener? = null
    private var multicast: WifiManager.MulticastLock? = null
    private val resolveQueue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    /** Host: stream url → the guest's song id, for songs the guest added. */
    private val guestSongs = HashMap<String, SharedSong>()

    // ---------- Visibility: be findable while the app is open (or in a session) ----------

    fun appVisible(visible: Boolean) {
        if (visible) {
            startServers()
            advertise(true)
        } else if (!active) {
            advertise(false)
        }
    }

    private fun startServers() {
        if (control == null) {
            val s = runCatching { ServerSocket(0) }.getOrNull() ?: return
            control = s
            scope.launch { acceptLoop(s) }
        }
        if (http == null) {
            val s = runCatching { ServerSocket(0) }.getOrNull() ?: return
            http = s
            scope.launch { httpLoop(s) }
        }
    }

    private fun advertise(on: Boolean) {
        val manager = nsd ?: return
        if (on && registered == null) {
            val controlPort = control?.localPort ?: return
            val info = NsdServiceInfo().apply {
                serviceName = "Mixtape-$myId"
                serviceType = SERVICE
                setPort(controlPort)
                setAttribute("n", vm.shareName.take(40))
                setAttribute("p", "Android")
                setAttribute("id", myId)
            }
            val listener = object : NsdManager.RegistrationListener {
                override fun onServiceRegistered(info: NsdServiceInfo) = Unit
                override fun onRegistrationFailed(info: NsdServiceInfo, error: Int) {
                    registered = null
                }
                override fun onServiceUnregistered(info: NsdServiceInfo) = Unit
                override fun onUnregistrationFailed(info: NsdServiceInfo, error: Int) = Unit
            }
            registered = listener
            runCatching { manager.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) }.onFailure { registered = null }
        } else if (!on) {
            registered?.let { l -> runCatching { manager.unregisterService(l) } }
            registered = null
        }
    }

    // ---------- Finding other phones (while the Listen together screen is open) ----------

    fun startDiscovery() {
        startServers()
        advertise(true)
        val manager = nsd ?: return
        if (discovery != null) return
        multicast = runCatching {
            context.applicationContext.getSystemService(WifiManager::class.java)
                ?.createMulticastLock("mixtape-together")?.apply { setReferenceCounted(false); acquire() }
        }.getOrNull()
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) = Unit
            override fun onDiscoveryStopped(serviceType: String) = Unit
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                discovery = null
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) = Unit
            override fun onServiceFound(info: NsdServiceInfo) {
                if (info.serviceName == "Mixtape-$myId") return
                synchronized(resolveQueue) { resolveQueue.addLast(info) }
                resolveNext()
            }
            override fun onServiceLost(info: NsdServiceInfo) {
                ui { peers = peers.filterNot { it.service == info.serviceName } }
            }
        }
        discovery = listener
        runCatching { manager.discoverServices(SERVICE, NsdManager.PROTOCOL_DNS_SD, listener) }.onFailure { discovery = null }
    }

    fun stopDiscovery() {
        discovery?.let { l -> runCatching { nsd?.stopServiceDiscovery(l) } }
        discovery = null
        runCatching { multicast?.release() }
        multicast = null
    }

    /** Android resolves one phone at a time. */
    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val manager = nsd ?: return
        val next = synchronized(resolveQueue) {
            if (resolving || resolveQueue.isEmpty()) return
            resolving = true
            resolveQueue.removeFirst()
        }
        val done = {
            synchronized(resolveQueue) { resolving = false }
            resolveNext()
        }
        runCatching {
            manager.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = done()
                override fun onServiceResolved(info: NsdServiceInfo) {
                    val attrs = info.attributes
                    fun attr(k: String) = attrs[k]?.let { String(it) }.orEmpty()
                    val id = attr("id")
                    val host = info.host
                    if (id.isNotEmpty() && id != myId && host != null) {
                        val peer = Peer(id, attr("n").ifEmpty { "Mixtape" }, attr("p").ifEmpty { "Android" }, host, info.port, info.serviceName)
                        ui { peers = peers.filterNot { it.id == id } + peer }
                    }
                    done()
                }
            })
        }.onFailure { done() }
    }

    // ---------- Starting a session ----------

    /** Asks [peer] to listen together. */
    fun invite(peer: Peer, how: TogetherMode) {
        if (active) return
        status = "waiting for ${peer.name}…"
        scope.launch {
            try {
                val s = Socket()
                s.connect(InetSocketAddress(peer.host, peer.port), 5_000)
                s.soTimeout = 90_000
                val w = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
                val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                w.write(JSONObject().put("t", "invite").put("name", vm.shareName).put("mode", how.name).put("http", http?.localPort ?: 0).toString())
                w.newLine()
                w.flush()
                val reply = JSONObject(r.readLine() ?: throw java.io.IOException("no answer"))
                if (reply.optString("t") != "accept") {
                    s.close()
                    ui {
                        status = null
                        vm.showMessage("${peer.name} said no.")
                    }
                    return@launch
                }
                s.soTimeout = 0
                ui {
                    begin(s, w, host = true, how = how, name = peer.name, peerHttpPort = reply.optInt("http"))
                }
                readLoop(r)
            } catch (e: Exception) {
                ui {
                    if (!active) {
                        status = null
                        vm.showMessage("Couldn't reach ${peer.name}. Both phones need Mixtape open on the same Wi-Fi.")
                    }
                }
            }
        }
    }

    fun accept() {
        val s = pendingInvite ?: return
        val inv = invite ?: return
        invite = null
        pendingInvite = null
        scope.launch {
            try {
                val w = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
                val r = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8))
                w.write(JSONObject().put("t", "accept").put("http", http?.localPort ?: 0).toString())
                w.newLine()
                w.flush()
                s.soTimeout = 0
                ui { begin(s, w, host = false, how = inv.mode, name = inv.from, peerHttpPort = invitedHttp) }
                readLoop(r)
            } catch (e: Exception) {
                ui { end("Lost the connection.") }
            }
        }
    }

    fun decline() {
        val s = pendingInvite
        invite = null
        pendingInvite = null
        scope.launch {
            runCatching {
                s?.getOutputStream()?.write((JSONObject().put("t", "decline").toString() + "\n").toByteArray())
                s?.close()
            }
        }
    }

    private var invitedHttp = 0

    private suspend fun acceptLoop(server: ServerSocket) {
        while (scope.isActive) {
            val s = runCatching { server.accept() }.getOrNull() ?: break
            scope.launch {
                runCatching {
                    s.soTimeout = 10_000
                    val line = BufferedReader(InputStreamReader(s.getInputStream(), Charsets.UTF_8)).readLine()
                    val o = JSONObject(line ?: "{}")
                    if (o.optString("t") != "invite" || active || pendingInvite != null) {
                        s.close()
                        return@runCatching
                    }
                    s.soTimeout = 0
                    invitedHttp = o.optInt("http")
                    pendingInvite = s
                    val inv = Invite(o.optString("name", "A friend"), runCatching { TogetherMode.valueOf(o.optString("mode")) }.getOrDefault(TogetherMode.BOTH))
                    ui { invite = inv }
                }.onFailure { runCatching { s.close() } }
            }
        }
    }

    private fun begin(s: Socket, w: BufferedWriter, host: Boolean, how: TogetherMode, name: String, peerHttpPort: Int) {
        conn = s
        writer = w
        peerAddress = s.inetAddress
        peerHttp = peerHttpPort
        isHost = host
        mode = how
        peerName = name
        active = true
        status = "in sync"
        guestHas = emptySet()
        current = null
        upNext = emptyList()
        lastApplied = null
        guestSongs.clear()
        stopDiscovery()
        sessionJob?.cancel()
        sessionJob = if (host) {
            scope.launch { hostLoop() }
        } else {
            if (how == TogetherMode.BOTH) player.remote = remoteToHost
            scope.launch { clockLoop() }
        }
    }

    /** Leave the session (or the other phone left). */
    fun leave() {
        send(JSONObject().put("t", "bye"))
        end(null)
    }

    /** Closes the connection after anything still waiting to be sent. */
    private fun closeLater(s: Socket?) {
        outbox.execute { runCatching { s?.close() } }
    }

    private fun end(message: String?) {
        if (!active && conn == null) return
        sessionJob?.cancel()
        sessionJob = null
        player.remote = null
        closeLater(conn)
        conn = null
        writer = null
        active = false
        status = null
        current = null
        upNext = emptyList()
        if (message != null) vm.showMessage(message)
    }

    private fun send(o: JSONObject) {
        val w = writer ?: return
        outbox.execute {
            runCatching {
                w.write(o.toString())
                w.newLine()
                w.flush()
            }
        }
    }

    private suspend fun readLoop(r: BufferedReader) {
        try {
            while (true) {
                val line = r.readLine() ?: break
                val o = runCatching { JSONObject(line) }.getOrNull() ?: continue
                if (o.optString("t") == "ping") {
                    // Answer the clock check straight away, off the main thread.
                    send(JSONObject().put("t", "pong").put("c", o.optLong("c")).put("h", SystemClock.elapsedRealtime()))
                    continue
                }
                withContext(Dispatchers.Main) { handle(o) }
            }
        } catch (e: Exception) {
            // Connection closed.
        }
        ui { if (active) end("$peerName left.") }
    }

    private fun handle(o: JSONObject) {
        when (o.optString("t")) {
            "bye" -> end("$peerName left.")
            "rule" -> rule = runCatching { MissingRule.valueOf(o.optString("rule")) }.getOrDefault(rule)
            // Host side
            "have" -> {
                val arr = o.optJSONArray("keys") ?: JSONArray()
                guestHas = (0 until arr.length()).map { arr.optString(it) }.toSet()
                maybeSkipMissing()
            }
            "cmd" -> when (o.optString("c")) {
                "toggle" -> player.playDirect(!player.isPlayingNow())
                "next" -> player.nextDirect()
                "prev" -> player.previousDirect()
                "seek" -> player.seekDirect(o.optLong("pos"))
            }
            "add" -> {
                val song = readSong(o.optJSONObject("song") ?: return) ?: return
                val gid = song.key.removePrefix("g:")
                val url = "http://${urlHost() ?: return}:$peerHttp/f/$gid"
                guestSongs[url] = song.copy(owner = "guest", addedBy = peerName)
                player.addStream(url, song.title, song.artist)
                vm.showMessage("$peerName added ${song.title}.")
            }
            "pong" -> {
                val now = SystemClock.elapsedRealtime()
                val sent = o.optLong("c")
                val rtt = now - sent
                if (rtt in 0..bestRtt) {
                    bestRtt = rtt
                    clockOffset = o.optLong("h") - (sent + rtt / 2)
                }
            }
            // Guest side
            "state" -> applyState(o)
        }
    }

    // ---------- Host: tell the guest what's playing ----------

    private suspend fun hostLoop() {
        var lastKey: String? = null
        var lastPlaying = false
        var lastSent = 0L
        var lastPos = 0L
        while (scope.isActive && active) {
            withContext(Dispatchers.Main) {
                val now = SystemClock.elapsedRealtime()
                val pos = player.positionNow() ?: 0L
                val isPlaying = player.isPlayingNow()
                val song = songFor(player.currentId(), player.state.value.title, player.state.value.artist)
                val expected = lastPos + if (lastPlaying) now - lastSent else 0L
                val jumped = kotlin.math.abs(pos - expected) > 1_500
                if (song?.key != lastKey || isPlaying != lastPlaying || jumped || now - lastSent > 2_000) {
                    current = song
                    playing = isPlaying
                    positionMs = pos
                    upNext = player.queue.value.drop(1).take(6).mapNotNull { songFor(it.mediaId, it.title, it.artist) }
                    val msg = JSONObject()
                        .put("t", "state")
                        .put("pos", pos)
                        .put("at", now)
                        .put("playing", isPlaying)
                        .put("rule", rule.name)
                        .put("http", http?.localPort ?: 0)
                    song?.let { msg.put("song", writeSong(it)) }
                    msg.put("next", JSONArray().apply { upNext.forEach { put(writeSong(it)) } })
                    send(msg)
                    if (song?.key != lastKey) skippedFor = null
                    lastKey = song?.key
                    lastPlaying = isPlaying
                    lastSent = now
                    lastPos = pos
                }
            }
            delay(250)
        }
    }

    private fun songFor(mediaId: String?, title: String, artist: String): SharedSong? {
        if (mediaId == null) return null
        if (mediaId.startsWith("net:")) {
            val url = mediaId.removePrefix("net:")
            return guestSongs[url] ?: SharedSong("x:$url", title, artist, 0L, "guest")
        }
        val t = vm.trackById(mediaId)
        return SharedSong("h:$mediaId", t?.title ?: title, t?.artist ?: artist, t?.durationMs ?: 0L, "host")
    }

    private var skippedFor: String? = null

    /** "Skip it": the guest doesn't have this song, so both move on. */
    private fun maybeSkipMissing() {
        val song = current ?: return
        if (!isHost || mode != TogetherMode.BOTH || rule != MissingRule.SKIP) return
        if (song.owner != "host" || song.key in guestHas || skippedFor == song.key) return
        skippedFor = song.key
        player.nextDirect()
    }

    fun chooseRule(r: MissingRule) {
        rule = r
        send(JSONObject().put("t", "rule").put("rule", r.name))
        maybeSkipMissing()
    }

    // ---------- Guest: play along ----------

    private var clockOffset = 0L
    private var bestRtt = Long.MAX_VALUE
    private var lastApplied: String? = null
    private var lastHave: Set<String> = emptySet()
    private var downloadAsked = HashSet<String>()

    /** Works out the difference between the two phones' clocks, now and then. */
    private suspend fun clockLoop() {
        while (scope.isActive && active) {
            bestRtt = Long.MAX_VALUE
            repeat(6) {
                send(JSONObject().put("t", "ping").put("c", SystemClock.elapsedRealtime()))
                delay(150)
            }
            delay(30_000)
        }
    }

    private val remoteToHost = object : PlayerConnection.Remote {
        override fun toggle() = send(JSONObject().put("t", "cmd").put("c", "toggle"))
        override fun next() = send(JSONObject().put("t", "cmd").put("c", "next"))
        override fun previous() = send(JSONObject().put("t", "cmd").put("c", "prev"))
        override fun seekTo(ms: Long) = send(JSONObject().put("t", "cmd").put("c", "seek").put("pos", ms))
    }

    /** Buttons on the Listen together screen (guest). */
    fun control(c: String, pos: Long = 0L) = when (c) {
        "toggle" -> remoteToHost.toggle()
        "next" -> remoteToHost.next()
        "prev" -> remoteToHost.previous()
        else -> remoteToHost.seekTo(pos)
    }

    /** Guest: put one of your songs in the shared queue. */
    fun addSong(track: dev.mixtape.player.library.LocalTrack) {
        val song = SharedSong("g:${track.id}", track.title, track.artist, track.durationMs, "guest")
        send(JSONObject().put("t", "add").put("song", writeSong(song)))
        vm.showMessage("Added ${track.title}.")
    }

    private fun applyState(o: JSONObject) {
        if (o.has("http")) peerHttp = o.optInt("http", peerHttp)
        rule = runCatching { MissingRule.valueOf(o.optString("rule")) }.getOrDefault(rule)
        val song = o.optJSONObject("song")?.let(::readSong)
        val isPlaying = o.optBoolean("playing")
        val at = o.optLong("at")
        val pos = o.optLong("pos")
        val nextArr = o.optJSONArray("next") ?: JSONArray()
        current = song
        playing = isPlaying
        positionMs = pos
        upNext = (0 until nextArr.length()).mapNotNull { nextArr.optJSONObject(it)?.let(::readSong) }

        // Which of these songs are on this phone.
        val have = (listOfNotNull(song) + upNext).filter { localFor(it) != null }.map { it.key }.toSet()
        guestHas = have
        if (have != lastHave) {
            lastHave = have
            send(JSONObject().put("t", "have").put("keys", JSONArray(have.toList())))
        }

        if (mode != TogetherMode.BOTH) return
        if (song == null) {
            if (player.isPlayingNow()) player.playDirect(false)
            return
        }
        val target = if (isPlaying) pos + (SystemClock.elapsedRealtime() + clockOffset - at) else pos
        if (song.key != lastApplied) {
            lastApplied = song.key
            val local = localFor(song)
            when {
                local != null -> player.playSingle(local.id.toString(), local.uri, song.title, song.artist, target + SEEK_LEAD, isPlaying)
                rule == MissingRule.SKIP -> player.playDirect(false)
                else -> {
                    if (rule == MissingRule.DOWNLOAD && downloadAsked.add(song.key)) {
                        DownloadQueue.addSongs(listOf(SongRequest(song.title, song.artist, song.durationMs)), vm.quality)
                    }
                    val url = streamUrl(song) ?: return
                    player.playSingle("net:$url", Uri.parse(url), song.title, song.artist, target + STREAM_LEAD, isPlaying)
                }
            }
            return
        }
        // Same song: keep in step.
        if (player.isPlayingNow() != isPlaying) player.playDirect(isPlaying)
        if (isPlaying) {
            val mine = player.positionNow() ?: return
            if (kotlin.math.abs(mine - target) > 150) player.seekDirect(target + SEEK_LEAD)
        }
    }

    /** The file on this phone for a shared song, if any. */
    private fun localFor(song: SharedSong): dev.mixtape.player.library.LocalTrack? {
        if (isHost) return null
        return when {
            song.owner == "guest" && song.key.startsWith("g:") -> vm.trackById(song.key.removePrefix("g:"))
            song.owner == "host" -> vm.matchLocal(song.title, song.artist, song.durationMs)
            else -> null
        }
    }

    private fun streamUrl(song: SharedSong): String? {
        val addr = urlHost() ?: return null
        if (!song.key.startsWith("h:")) return null
        return "http://$addr:$peerHttp/f/${song.key.removePrefix("h:")}"
    }

    // ---------- Labels for the screen ----------

    /** "✓ both", "streams to Kenji", "streams to you"… */
    fun labelFor(song: SharedSong): String {
        if (mode == TogetherMode.SPEAKER) {
            return if (song.owner == "guest") (if (isHost) "streams to you" else "from your phone") else ""
        }
        return if (isHost) {
            when {
                song.owner == "guest" -> "streams to you"
                song.key in guestHas -> "✓ both"
                rule == MissingRule.SKIP -> "skipped"
                rule == MissingRule.DOWNLOAD -> "downloading for $peerName"
                else -> "streams to $peerName"
            }
        } else {
            when {
                song.owner == "guest" -> "streams to $peerName"
                song.key in guestHas -> "✓ both"
                rule == MissingRule.SKIP -> "skipped"
                else -> "streams to you"
            }
        }
    }

    // ---------- Sending files to the other phone ----------

    private suspend fun httpLoop(server: ServerSocket) {
        while (scope.isActive) {
            val s = runCatching { server.accept() }.getOrNull() ?: break
            scope.launch { runCatching { serve(s) }; runCatching { s.close() } }
        }
    }

    /** Tiny web server: GET /f/<song id>, with byte ranges so the other phone can seek. Only for the phone you're with. */
    private fun serve(s: Socket) {
        s.soTimeout = 15_000
        val input = s.getInputStream()
        val head = StringBuilder()
        while (!head.endsWith("\r\n\r\n") && head.length < 8_192) {
            val b = input.read()
            if (b < 0) return
            head.append(b.toChar())
        }
        val lines = head.lines()
        val path = lines.firstOrNull()?.split(' ')?.getOrNull(1).orEmpty()
        val out = s.getOutputStream()
        val allowed = active && s.inetAddress == peerAddress
        val id = path.removePrefix("/f/").toLongOrNull()
        val track = id?.let { vm.trackById(it.toString()) }
        if (!allowed || track == null) {
            out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
            return
        }
        val fd = context.contentResolver.openFileDescriptor(LocalLibrary.contentUri(track.id), "r") ?: return
        fd.use {
            val total = it.statSize
            FileInputStream(it.fileDescriptor).use { file ->
                val range = lines.firstOrNull { l -> l.startsWith("range:", ignoreCase = true) }
                    ?.substringAfter('=')?.trim()
                var start = 0L
                var end = total - 1
                if (range != null) {
                    start = range.substringBefore('-').toLongOrNull() ?: 0L
                    end = range.substringAfter('-').toLongOrNull()?.coerceAtMost(total - 1) ?: (total - 1)
                }
                if (start >= total || start > end) {
                    out.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$total\r\nConnection: close\r\n\r\n".toByteArray())
                    return
                }
                val length = end - start + 1
                val type = when (track.fileName.substringAfterLast('.', "").lowercase()) {
                    "mp3" -> "audio/mpeg"
                    "m4a", "mp4", "aac" -> "audio/mp4"
                    "flac" -> "audio/flac"
                    "opus", "ogg" -> "audio/ogg"
                    "wav" -> "audio/wav"
                    else -> "application/octet-stream"
                }
                val status = if (range != null) "206 Partial Content" else "200 OK"
                val header = buildString {
                    append("HTTP/1.1 $status\r\n")
                    append("Content-Type: $type\r\n")
                    append("Content-Length: $length\r\n")
                    append("Accept-Ranges: bytes\r\n")
                    if (range != null) append("Content-Range: bytes $start-$end/$total\r\n")
                    append("Connection: close\r\n\r\n")
                }
                out.write(header.toByteArray())
                file.channel.position(start)
                val buf = ByteArray(64 * 1024)
                var left = length
                while (left > 0) {
                    val n = file.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n <= 0) break
                    out.write(buf, 0, n)
                    left -= n
                }
                out.flush()
            }
        }
    }

    // ---------- Helpers ----------

    private fun writeSong(s: SharedSong) = JSONObject()
        .put("key", s.key)
        .put("title", s.title)
        .put("artist", s.artist)
        .put("dur", s.durationMs)
        .put("owner", s.owner)
        .put("by", s.addedBy ?: "")

    /** The other phone's address as it goes in a link (IPv6 needs brackets). */
    private fun urlHost(): String? {
        val a = peerAddress ?: return null
        val text = a.hostAddress ?: return null
        return if (a is java.net.Inet6Address) "[" + text.replace("%", "%25") + "]" else text
    }

    private fun readSong(o: JSONObject): SharedSong? {
        val key = o.optString("key")
        if (key.isEmpty()) return null
        return SharedSong(
            key = key,
            title = o.optString("title"),
            artist = o.optString("artist"),
            durationMs = o.optLong("dur"),
            owner = o.optString("owner", "host"),
            addedBy = o.optString("by").ifEmpty { null },
        )
    }

    private fun ui(block: () -> Unit) {
        android.os.Handler(android.os.Looper.getMainLooper()).post(block)
    }

    private companion object {
        const val SERVICE = "_mixtape._tcp"
        /** Starting a little ahead makes up for the time a jump takes. */
        const val SEEK_LEAD = 80L
        const val STREAM_LEAD = 400L
    }
}
