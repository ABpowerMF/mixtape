package dev.mixtape.player

object Config {
    /**
     * Paste the Client ID from your app at https://developer.spotify.com/dashboard
     * (see README.md, step 1).
     */
    const val SPOTIFY_CLIENT_ID = "PASTE_YOUR_CLIENT_ID_HERE"

    /** The Client ID in use: pasted in the app (Import → connect your account), else the one above. */
    @Volatile var clientId: String = ""

    /**
     * Add this exact address as the Redirect URI in your Spotify app settings.
     * Mixtape listens on this port on the phone itself while you log in.
     */
    const val REDIRECT_PORT = 43821
    const val REDIRECT_URI = "http://127.0.0.1:43821/callback"

    /** Read-only access: your playlists and your Liked Songs. */
    const val SCOPES = "playlist-read-private playlist-read-collaborative user-library-read"

    /**
     * Last.fm scrobbling. Get a free key at https://www.last.fm/api/account/create and paste the
     * "API key" and "Shared secret" here. While these are empty, the Last.fm setting stays hidden.
     */
    const val LASTFM_API_KEY = ""
    const val LASTFM_SECRET = ""
}
