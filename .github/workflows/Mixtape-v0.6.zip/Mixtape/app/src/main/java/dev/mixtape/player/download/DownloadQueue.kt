package dev.mixtape.player.download

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import dev.mixtape.player.spotify.SpotifyPublic
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.cancellation.CancellationException

enum class JobStatus { Queued, Running, Done, Skipped, Failed, Canceled }

/** A song known by name, e.g. from a Spotify playlist. */
data class SongRequest(
    val title: String,
    val artist: String,
    val durationMs: Long = 0L,
    /** Spotify track id, used for the Spotify album cover. */
    val spotifyId: String? = null,
)

data class DownloadJob(
    val id: String,
    /** What the list shows, e.g. "Artist - Title" or a video title. */
    val label: String,
    /** A URL, or "ytsearch1:..." to take the best YouTube match. */
    val source: String,
    /** Tags to write instead of YouTube's (songs from Spotify). */
    val title: String?,
    val artist: String?,
    /** File name without extension, or null to use the video title. */
    val fileBase: String?,
    val quality: Quality,
    /** Spotify length, used to pick the right version (no video intros). 0 = unknown. */
    val durationMs: Long = 0L,
    /** A direct video link (not a song found by name). */
    val direct: Boolean = false,
    val spotifyId: String? = null,
    val status: JobStatus = JobStatus.Queued,
    val progress: Float = 0f,
    val message: String? = null,
) {
    val finished: Boolean get() = status != JobStatus.Queued && status != JobStatus.Running
}

/**
 * Lives as long as the app process. DownloadService keeps the process alive while work is pending.
 */
object DownloadQueue {

    private const val PARALLEL = 3
    private const val CROP_COVER =
        "ThumbnailsConvertor+ffmpeg_o:-c:v mjpeg -qmin 1 -qscale:v 1 " +
            "-vf crop=\"'if(gt(ih,iw),iw,ih)':'if(gt(iw,ih),ih,iw)'\""
    private const val UPDATE_EVERY_MS = 24L * 60 * 60 * 1000

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var slots = Semaphore(PARALLEL)
    private val initLock = Mutex()
    private val running = ConcurrentHashMap<String, Job>()
    @Volatile private var initialized = false
    private lateinit var app: Context

    private val _jobs = MutableStateFlow<List<DownloadJob>>(emptyList())
    val jobs: StateFlow<List<DownloadJob>> = _jobs

    /** Links being read right now (before their songs are added to the list). */
    private val _reading = MutableStateFlow(0)
    val reading: StateFlow<Int> = _reading

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages

    fun init(context: Context) {
        app = context.applicationContext
        val saved = app.getSharedPreferences("mixtape", Context.MODE_PRIVATE).getInt("parallel", PARALLEL)
        slots = Semaphore(saved.coerceIn(1, 4))
    }

    /** How many songs download at the same time (1 to 4). Applies to songs added from now on. */
    fun setParallel(count: Int) {
        slots = Semaphore(count.coerceIn(1, 4))
    }

    /** Checks for a newer yt-dlp right away (normally done once a day). */
    fun updateNow() {
        scope.launch {
            try {
                ensureReady()
                val status = YoutubeDL.getInstance().updateYoutubeDL(app)
                app.getSharedPreferences("downloader", Context.MODE_PRIVATE)
                    .edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
                val version = YoutubeDL.getInstance().versionName(app) ?: YoutubeDL.getInstance().version(app) ?: ""
                _messages.tryEmit(
                    if (status == YoutubeDL.UpdateStatus.ALREADY_UP_TO_DATE) "Downloader is up to date $version"
                    else "Downloader updated $version",
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Couldn't update the downloader: ${shortError(e)}")
            }
        }
    }

    val isWorking: Boolean
        get() = _reading.value > 0 || _jobs.value.any { !it.finished }

    // ---------- Adding work ----------

    /** A YouTube link (video or playlist), a Spotify link (track, album or playlist), or any yt-dlp site. */
    fun addLink(link: String, quality: Quality) {
        _reading.update { it + 1 }
        startService()
        scope.launch {
            try {
                ensureReady()
                val jobs = if (SpotifyPublic.isSpotifyLink(link)) {
                    val result = SpotifyPublic.fetch(link)
                    result.note?.let { _messages.tryEmit(it) }
                    result.tracks.map { t -> songJob(SongRequest(t.title, t.artists.joinToString(", "), t.durationMs, t.id), quality) }
                } else {
                    listLink(link, quality)
                }
                if (jobs.isEmpty()) _messages.tryEmit("Nothing to download at that link.")
                enqueue(jobs)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Couldn't read that link: ${shortError(e)}")
            } finally {
                _reading.update { it - 1 }
            }
        }
    }

    /** Songs known by name (e.g. missing songs of an imported playlist). Each is matched on YouTube. */
    fun addSongs(songs: List<SongRequest>, quality: Quality, fileSuffix: String = "") {
        if (songs.isEmpty()) return
        _reading.update { it + 1 }
        startService()
        scope.launch {
            try {
                ensureReady()
                enqueue(songs.map { songJob(it, quality, fileSuffix) })
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _messages.tryEmit("Couldn't start the downloader: ${shortError(e)}")
            } finally {
                _reading.update { it - 1 }
            }
        }
    }

    fun retry(id: String) {
        val job = _jobs.value.find { it.id == id } ?: return
        if (job.status != JobStatus.Failed && job.status != JobStatus.Canceled) return
        setJob(id) { it.copy(status = JobStatus.Queued, progress = 0f, message = null) }
        startService()
        start(job.id)
    }

    fun cancelAll() {
        _jobs.value.filter { !it.finished }.forEach { job ->
            setJob(job.id) { it.copy(status = JobStatus.Canceled) }
            runCatching { YoutubeDL.getInstance().destroyProcessById(job.id) }
            running.remove(job.id)?.cancel()
        }
    }

    fun clearFinished() {
        _jobs.update { list -> list.filterNot { it.finished } }
    }

    // ---------- Internals ----------

    private fun songJob(song: SongRequest, quality: Quality, fileSuffix: String = ""): DownloadJob {
        val label = if (song.artist.isBlank()) song.title else "${song.artist} - ${song.title}"
        return DownloadJob(
            id = UUID.randomUUID().toString(),
            label = label,
            source = "ytsearch1:$label audio",
            title = song.title,
            artist = song.artist.ifBlank { null },
            fileBase = safeName(label + fileSuffix),
            quality = quality,
            durationMs = song.durationMs,
            spotifyId = song.spotifyId,
        )
    }

    /**
     * Candidate videos for a song, best first: YouTube Music songs (album versions with square covers),
     * then regular YouTube results. Ones far from the Spotify length are dropped when closer ones exist.
     * Several are returned so an age-restricted or blocked video can be skipped for the next one.
     */
    private fun findCandidates(query: String, durationMs: Long): List<String> {
        fun search(url: String, musicLinks: Boolean): List<Pair<String, Long>> = try {
            val request = YoutubeDLRequest(url).apply {
                addOption("--flat-playlist")
                addOption("--dump-single-json")
                addOption("--playlist-items", "1-5")
                addOption("--no-warnings")
            }
            val out = YoutubeDL.getInstance().execute(request, null, null).out
            val entries = JSONObject(out.substring(out.indexOf('{'))).optJSONArray("entries")
            (0 until (entries?.length() ?: 0)).mapNotNull { i ->
                val e = entries?.optJSONObject(i) ?: return@mapNotNull null
                val id = e.optString("id")
                val link = if (id.isNotEmpty()) {
                    if (musicLinks) "https://music.youtube.com/watch?v=$id" else "https://www.youtube.com/watch?v=$id"
                } else {
                    e.optString("url")
                }
                if (link.isEmpty()) null else link to (e.optDouble("duration", 0.0) * 1000).toLong()
            }
        } catch (e: Exception) {
            emptyList()
        }

        fun rank(list: List<Pair<String, Long>>): List<String> {
            if (durationMs <= 0) return list.map { it.first }
            val close = list.filter { it.second > 0 && kotlin.math.abs(it.second - durationMs) <= 20_000 }
                .sortedBy { kotlin.math.abs(it.second - durationMs) }
            val rest = list.filterNot { it in close }
            return (close + rest).map { it.first }
        }

        val q = java.net.URLEncoder.encode(query, "UTF-8")
        val music = rank(search("https://music.youtube.com/search?q=$q#songs", musicLinks = true))
        val videos = rank(search("ytsearch5:$query audio", musicLinks = false))
        val seen = HashSet<String>()
        return (music + videos).filter { seen.add(it.substringAfter("v=").substringBefore('&')) }
    }

    /** Full details of one video (title, and "track"/"artist" when YouTube knows it's a song). */
    private fun videoInfo(url: String): JSONObject? = try {
        val request = YoutubeDLRequest(url).apply {
            addOption("--dump-json")
            addOption("--skip-download")
            addOption("--no-playlist")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(request, null, null).out
        JSONObject(out.substring(out.indexOf('{')))
    } catch (e: Exception) {
        null
    }

    /** Lists the videos behind a link without downloading anything (fast, one request). */
    private fun listLink(link: String, quality: Quality): List<DownloadJob> {
        val request = YoutubeDLRequest(link).apply {
            addOption("--flat-playlist")
            // A video opened from inside a playlist means just that video.
            addOption("--no-playlist")
            addOption("--dump-single-json")
            addOption("--no-warnings")
        }
        val out = YoutubeDL.getInstance().execute(request, null, null).out
        val json = JSONObject(out.substring(out.indexOf('{')))
        val entries = json.optJSONArray("entries")
        if (entries == null) {
            return listOf(videoJob(json.optString("title"), json.optString("webpage_url").ifEmpty { link }, quality))
        }
        val jobs = ArrayList<DownloadJob>()
        for (i in 0 until entries.length()) {
            val e = entries.optJSONObject(i) ?: continue
            val url = e.optString("url").ifEmpty { e.optString("webpage_url") }
            if (url.isEmpty()) continue
            jobs += videoJob(e.optString("title"), url, quality)
        }
        return jobs
    }

    private fun videoJob(title: String, url: String, quality: Quality) = DownloadJob(
        id = UUID.randomUUID().toString(),
        label = title.ifEmpty { url },
        source = url,
        title = null,
        artist = null,
        fileBase = null,
        quality = quality,
        direct = true,
    )

    private fun enqueue(jobs: List<DownloadJob>) {
        if (jobs.isEmpty()) return
        _jobs.update { it + jobs }
        jobs.forEach { start(it.id) }
    }

    private fun start(id: String) {
        val handle = scope.launch {
            slots.withPermit {
                val job = _jobs.value.find { it.id == id }
                if (job == null || job.status != JobStatus.Queued) return@withPermit
                setJob(id) { it.copy(status = JobStatus.Running, progress = 0f) }
                try {
                    val result = download(job)
                    setJob(id) { it.copy(status = result, progress = 100f) }
                } catch (e: CancellationException) {
                    setJob(id) { it.copy(status = JobStatus.Canceled) }
                    throw e
                } catch (e: YoutubeDL.CanceledException) {
                    setJob(id) { it.copy(status = JobStatus.Canceled) }
                } catch (e: Exception) {
                    val current = _jobs.value.find { it.id == id }
                    if (current?.status != JobStatus.Canceled) {
                        setJob(id) { it.copy(status = JobStatus.Failed, message = shortError(e)) }
                    }
                }
            }
        }
        running[id] = handle
        handle.invokeOnCompletion { running.remove(id) }
    }

    private fun download(job: DownloadJob): JobStatus {
        val q = job.quality
        var title = job.title
        var artist = job.artist
        var fileBase = job.fileBase
        var withCover = true

        val candidates: List<String> = when {
            job.direct -> {
                // A video link: if YouTube knows which song it is, get the album version instead
                // (proper cover, no video intro). Otherwise keep the video's audio without its video frame as cover.
                val info = videoInfo(job.source)
                val track = info?.optString("track")?.trim().orEmpty()
                val who = info?.let { i ->
                    i.optJSONArray("artists")?.optString(0)?.ifEmpty { null }
                        ?: i.optString("artist").substringBefore(",").ifEmpty { null }
                        ?: i.optString("creator").ifEmpty { null }
                }?.trim().orEmpty()
                if (track.isNotEmpty() && who.isNotEmpty()) {
                    title = track
                    artist = who
                    fileBase = safeName("$who - $track")
                    val seconds = info?.optDouble("duration", 0.0) ?: 0.0
                    findCandidates("$who - $track", (seconds * 1000).toLong()) + job.source
                } else {
                    withCover = false
                    listOf(job.source)
                }
            }
            job.title != null -> findCandidates(job.label, job.durationMs) + job.source
            else -> listOf(job.source)
        }

        if (fileBase != null && MediaSaver.exists(app, fileBase, q.ext)) return JobStatus.Skipped

        // Try each version until one works (some are age-restricted or blocked in some countries).
        var lastError: Exception? = null
        var restricted = 0
        for (source in candidates.distinct().take(8)) {
            if (_jobs.value.find { it.id == job.id }?.status == JobStatus.Canceled) throw YoutubeDL.CanceledException()
            try {
                attempt(job, source, title, artist, fileBase, withCover)
                return JobStatus.Done
            } catch (e: YoutubeDL.CanceledException) {
                throw e
            } catch (e: Exception) {
                lastError = e
                val msg = e.message.orEmpty()
                if (msg.contains("confirm your age", true) || msg.contains("age-restricted", true) ||
                    msg.contains("inappropriate for some users", true)
                ) {
                    restricted++
                }
            }
        }
        if (restricted > 0 && restricted == candidates.distinct().take(8).size) {
            throw IllegalStateException("Every version found is age-restricted on YouTube.")
        }
        throw lastError ?: IllegalStateException("No version of this song could be downloaded.")
    }

    private fun attempt(
        job: DownloadJob,
        source: String,
        title: String?,
        artist: String?,
        fileBase: String?,
        withCover: Boolean,
    ) {
        val q = job.quality
        val dir = File(app.cacheDir, "downloads/${job.id}")
        dir.deleteRecursively()
        dir.mkdirs()
        try {
            val name = (fileBase ?: "%(title).150B") + ".%(ext)s"

            // Songs from Spotify get Spotify's own album cover: fetch the video's details, swap in
            // the cover, and let yt-dlp download from those details.
            val cover = if (withCover) job.spotifyId?.let { SpotifyPublic.coverUrl(it) } else null
            val infoFile = cover?.let {
                videoInfo(source)?.let { info ->
                    info.put("thumbnails", JSONArray().put(JSONObject().put("url", cover).put("id", "spotify")))
                    info.put("thumbnail", cover)
                    File(dir, "info.json").apply { writeText(info.toString()) }
                }
            }
            val base = if (infoFile != null) {
                YoutubeDLRequest(emptyList<String>()).apply { addOption("--load-info-json", infoFile.absolutePath) }
            } else {
                YoutubeDLRequest(source)
            }
            val request = base.apply {
                addOption("-f", q.format)
                addOption("-x")
                addOption("--audio-format", q.codec)
                q.bitrate?.let { addOption("--audio-quality", it) }
                addOption("--embed-metadata")
                if (withCover) {
                    addOption("--embed-thumbnail")
                    addOption("--convert-thumbnails", "jpg")
                    // Crop YouTube's 16:9 thumbnail to the square album cover in the middle.
                    addOption("--ppa", CROP_COVER)
                }
                addOption("--no-playlist")
                addOption("--no-mtime")
                addOption("--no-warnings")
                addOption("--retries", 5)
                addOption("-o", File(dir, name).absolutePath)
                // Write the Spotify title/artist into the file instead of the video's.
                val commands = ArrayList<String>()
                title?.let {
                    commands += listOf("--parse-metadata", ":(?P<meta_title>)")
                    commands += listOf("--replace-in-metadata", "meta_title", "^$", escapeReplacement(it))
                }
                artist?.let {
                    commands += listOf("--parse-metadata", ":(?P<meta_artist>)")
                    commands += listOf("--replace-in-metadata", "meta_artist", "^$", escapeReplacement(it))
                }
                if (commands.isNotEmpty()) addCommands(commands)
            }

            var lastShown = -1
            val onProgress: (Float, Long, String) -> Unit = { progress, _, _ ->
                val whole = progress.toInt()
                if (whole != lastShown && progress >= 0f) {
                    lastShown = whole
                    setJob(job.id) { it.copy(progress = progress) }
                }
            }
            YoutubeDL.getInstance().execute(request, job.id, onProgress)

            val file = dir.listFiles()
                ?.filter { it.isFile && it.extension.equals(q.ext, ignoreCase = true) }
                ?.maxByOrNull { it.length() }
                ?: throw IllegalStateException("No ${q.ext} file came out of the download.")
            MediaSaver.save(app, file)
        } finally {
            dir.deleteRecursively()
        }
    }

    private suspend fun ensureReady() {
        initLock.withLock {
            if (initialized) return@withLock
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
            initialized = true
            updateIfStale()
        }
    }

    /** YouTube changes often; keep yt-dlp current (at most one check a day). */
    private fun updateIfStale() {
        val prefs = app.getSharedPreferences("downloader", Context.MODE_PRIVATE)
        val last = prefs.getLong("lastUpdate", 0L)
        val now = System.currentTimeMillis()
        if (now - last < UPDATE_EVERY_MS) return
        try {
            YoutubeDL.getInstance().updateYoutubeDL(app)
            prefs.edit().putLong("lastUpdate", now).apply()
        } catch (e: Exception) {
            // Offline or GitHub unreachable: keep the current version and try again next time.
        }
    }

    private fun setJob(id: String, change: (DownloadJob) -> DownloadJob) {
        _jobs.update { list -> list.map { if (it.id == id) change(it) else it } }
    }

    private fun startService() {
        runCatching {
            ContextCompat.startForegroundService(app, Intent(app, DownloadService::class.java))
        }
    }

    /** Python's re.sub treats backslashes in the replacement specially. */
    private fun escapeReplacement(text: String): String = text.replace("\\", "\\\\")

    fun safeName(text: String): String =
        text.replace(Regex("""[\\/:*?"<>|]+"""), "").trim().take(150).ifEmpty { "track" }

    private fun shortError(e: Throwable): String {
        val lines = (e.message ?: e.javaClass.simpleName).lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.lastOrNull { it.startsWith("ERROR:") } ?: lines.firstOrNull() ?: "Unknown error"
        return line.removePrefix("ERROR:").trim().take(160)
    }
}
