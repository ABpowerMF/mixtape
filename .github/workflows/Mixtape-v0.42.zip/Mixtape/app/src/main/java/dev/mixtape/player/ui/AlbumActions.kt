package dev.mixtape.player.ui

import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui

/**
 * "Delete album?": keep the songs on the phone or delete them too, and (if some are in your
 * playlists) whether to take them out of those as well.
 * [playlistId] for an album imported from Spotify, [folder] for an album on the phone.
 */
@Composable
fun AlbumDeleteDialog(vm: MainViewModel, playlistId: String?, folder: String?, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val info = remember(playlistId, folder, vm.rows, vm.library) { vm.albumDeleteInfo(playlistId, folder) }
    if (info == null) {
        androidx.compose.runtime.LaunchedEffect(Unit) { onDismiss() }
        return
    }
    var deleteFiles by remember { mutableStateOf(false) }
    var takeOut by remember { mutableStateOf(false) }
    val n = info.songs.size

    val askDelete = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            vm.deleteAlbum(playlistId, folder, info, deleteFiles = true, takeOutOfPlaylists = takeOut)
            vm.rescanMusic()
            vm.showMessage("Deleted ${info.name} and its $n songs.")
        }
        onDismiss()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Ui.head("delete album?")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    info.name + if (n > 0) " · $n songs on this phone" else " · none of its songs are on this phone",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mix.Fog,
                )
                if (n > 0) {
                    Option(
                        on = !deleteFiles,
                        title = "Keep the songs",
                        body = "Only the album goes. The songs stay in Songs and in your playlists.",
                    ) { deleteFiles = false }
                    Option(
                        on = deleteFiles,
                        title = "Delete the songs too",
                        body = "Removes the $n files from this phone.",
                    ) { deleteFiles = true }
                }
                if (info.inPlaylists > 0) {
                    val names = (info.ownPlaylists + info.otherPlaylists).distinct()
                    Text(
                        "${info.inPlaylists} of these songs are in your playlists: ${names.take(4).joinToString(", ")}" +
                            (if (names.size > 4) " and ${names.size - 4} more" else "") + ".",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Paper,
                    )
                    if (info.ownPlaylists.isNotEmpty()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { takeOut = !takeOut },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = takeOut,
                                onCheckedChange = { takeOut = it },
                                colors = CheckboxDefaults.colors(checkedColor = Mix.Tape, checkmarkColor = Mix.Ink, uncheckedColor = Mix.Fog),
                            )
                            Text("Also take them out of my playlists", style = MaterialTheme.typography.bodyMedium, color = Mix.Paper)
                        }
                    }
                    if (deleteFiles && info.otherPlaylists.isNotEmpty()) {
                        Text(
                            "In imported playlists they'll show as missing (you can download them again).",
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (deleteFiles && n > 0) {
                    val uris = info.songs.map { it.uri }
                    if (Build.VERSION.SDK_INT >= 30) {
                        val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
                        askDelete.launch(IntentSenderRequest.Builder(request.intentSender).build())
                    } else {
                        vm.deleteDirect(uris)
                        vm.deleteAlbum(playlistId, folder, info, deleteFiles = true, takeOutOfPlaylists = takeOut)
                        onDismiss()
                    }
                } else {
                    vm.deleteAlbum(playlistId, folder, info, deleteFiles = false, takeOutOfPlaylists = takeOut)
                    onDismiss()
                }
            }) { Text("Delete", color = Mix.Alert) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

@Composable
private fun Option(on: Boolean, title: String, body: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            if (on) "(•)" else "( )",
            style = MaterialTheme.typography.bodyLarge,
            color = Mix.Paper,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier.width(36.dp),
        )
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = if (on) Mix.Paper else Mix.Fog, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        }
    }
}

/**
 * Hold an album or playlist in the Playlists tab: hide it (it then lives in Settings → hidden),
 * delete the album, or remove the playlist.
 */
@Composable
fun HoldMenu(
    vm: MainViewModel,
    open: Boolean,
    onClose: () -> Unit,
    hideKey: String,
    playlistId: String?,
    folder: String?,
) {
    var deleting by remember { mutableStateOf(false) }
    val isAlbum = folder != null || playlistId?.startsWith("album:") == true
    Box {
        DropdownMenu(expanded = open, onDismissRequest = onClose) {
            val hidden = vm.isHidden(hideKey)
            DropdownMenuItem(
                text = { Text(if (hidden) "Show again" else if (isAlbum) "Hide album" else "Hide playlist") },
                onClick = {
                    onClose()
                    vm.setHidden(hideKey, !hidden)
                    if (!hidden) vm.showMessage("Hidden. Find it in Settings → hidden.")
                },
            )
            if (isAlbum) {
                DropdownMenuItem(
                    text = { Text("Delete album…", color = Mix.Alert) },
                    onClick = {
                        onClose()
                        deleting = true
                    },
                )
            } else if (playlistId != null) {
                DropdownMenuItem(
                    text = { Text("Remove playlist", color = Mix.Alert) },
                    onClick = {
                        onClose()
                        vm.removePlaylist(playlistId)
                    },
                )
            }
        }
    }
    if (deleting) AlbumDeleteDialog(vm, playlistId, folder) { deleting = false }
}
