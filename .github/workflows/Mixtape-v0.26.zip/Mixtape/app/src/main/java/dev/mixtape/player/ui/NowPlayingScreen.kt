package dev.mixtape.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.BoxWithConstraints
import dev.mixtape.player.ui.theme.Ui
import dev.mixtape.player.playback.AudioFx
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.foundation.layout.width
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.download.Quality
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix

@Composable
fun NowPlayingScreen(vm: MainViewModel, now: NowPlaying) {
    // While dragging the slider, show the drag position instead of the live one.
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = now.durationMs.coerceAtLeast(1L)
    val fraction = dragging ?: (now.positionMs.toFloat() / duration).coerceIn(0f, 1f)
    val shownPosition = if (dragging != null) (fraction * duration).toLong() else now.positionMs

    var addingToPlaylist by remember { mutableStateOf(false) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
    val pageHeight = maxHeight
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
    Column(
        Modifier
            .height(pageHeight)
            .systemBarsPadding()
            .padding(horizontal = 28.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::pop, modifier = Modifier.offset(x = (-12).dp)) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close player", modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.weight(1f))
            if (vm.trackById(now.mediaId) != null) {
                IconButton(onClick = { addingToPlaylist = true }) {
                    Icon(Icons.Filled.LibraryAdd, contentDescription = "Add to a playlist")
                }
            }
            IconButton(onClick = { vm.push(Screen.Equalizer) }, modifier = Modifier.offset(x = 12.dp)) {
                Icon(
                    Icons.Filled.Equalizer,
                    contentDescription = "Equaliser",
                    tint = if (AudioFx.settings.enabled) Mix.Tape else Mix.Paper,
                )
            }
        }

        Spacer(Modifier.weight(1f))

        PlayerCover(now.artworkUri, moving = vm.movingCover && now.isPlaying && Mix.animations)

        Spacer(Modifier.height(32.dp))

        Text(
            now.title.ifEmpty { "Nothing playing" },
            style = MaterialTheme.typography.displaySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (now.artist.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                now.artist,
                style = MaterialTheme.typography.titleMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VersionPicker(vm, now, Modifier.weight(1.3f))
            OutlinedButton(
                onClick = { vm.push(Screen.Queue) },
                shape = TermShape,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier.weight(1f),
            ) {
                Text(Ui.btn("queue"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape, maxLines = 1, softWrap = false)
            }
            OutlinedButton(
                onClick = { vm.push(Screen.Lyrics) },
                shape = TermShape,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier.weight(1f),
            ) {
                Text(Ui.btn("lyrics"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape, maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.height(12.dp))

        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.player.seekTo((it * duration).toLong()) }
                dragging = null
            },
            colors = SliderDefaults.colors(
                thumbColor = Mix.Tape,
                activeTrackColor = Mix.Tape,
                inactiveTrackColor = Mix.Gap,
            ),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shownPosition), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
            Text(formatTime(now.durationMs), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
        }

        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = vm.player::toggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = if (now.shuffle) "Shuffle on" else "Shuffle off",
                    tint = if (now.shuffle) Mix.Tape else Mix.Fog,
                )
            }
            IconButton(onClick = vm.player::previous, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous song", modifier = Modifier.size(36.dp))
            }
            FilledIconButton(
                shape = TermShape,
                onClick = vm.player::toggle,
                modifier = Modifier.size(76.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) {
                Icon(
                    if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (now.isPlaying) "Pause" else "Play",
                    modifier = Modifier.size(40.dp),
                )
            }
            IconButton(onClick = vm.player::next, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next song", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = vm.player::cycleRepeat) {
                Icon(
                    if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = when (now.repeatMode) {
                        Player.REPEAT_MODE_ONE -> "Repeat this song"
                        Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    tint = if (now.repeatMode == Player.REPEAT_MODE_OFF) Mix.Fog else Mix.Tape,
                )
            }
        }

        Spacer(Modifier.weight(1f))
        if (now.artist.isNotBlank()) {
            Text(
                "▾ " + (if (Mix.rounded) "About the artist" else "about the artist"),
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Fog,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 6.dp),
            )
        }
    }
    ArtistSection(vm, now)
    }
    }

    if (addingToPlaylist) {
        vm.trackById(now.mediaId)?.let { track ->
            AddToPlaylistDialog(vm, listOf(track)) { addingToPlaylist = false }
        } ?: run { addingToPlaylist = false }
    }
}

/** The cover; optionally drifts and zooms slowly while playing (Settings → player → moving cover). */
@Composable
private fun PlayerCover(model: Any?, moving: Boolean) {
    val motion = rememberInfiniteTransition(label = "cover")
    val t by motion.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift",
    )
    val scale = if (moving) 1f + 0.12f * t else 1f
    val dx = if (moving) (t - 0.5f) * 24f else 0f
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp)),
    ) {
        Artwork(
            model,
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = dx * density
                },
            corner = 0.dp,
            iconSize = 72.dp,
        )
    }
}

/** Below the player: a short Wikipedia profile, your stats for this artist, and their albums on the phone. */
@Composable
private fun ArtistSection(vm: MainViewModel, now: NowPlaying) {
    val name = now.artist.substringBefore(",").substringBefore(" & ").substringBefore(" feat").trim()
    if (name.isEmpty()) return
    LaunchedEffect(name) {
        vm.loadArtist(name)
        vm.refreshStats()
    }
    val info = vm.artistInfo.takeIf { vm.artistInfoFor == name }
    val mine = remember(vm.stats, name) { vm.stats.filter { it.artist.contains(name, ignoreCase = true) } }
    val onPhone = remember(vm.library, name) { vm.library.count { it.artist.contains(name, ignoreCase = true) } }
    val albums = remember(vm.library, name) { vm.localAlbums().filter { it.artist.contains(name, ignoreCase = true) } }

    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 28.dp, vertical = 16.dp),
    ) {
        Text(Ui.head("about the artist"), style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Artwork(info?.imageUrl, Modifier.size(72.dp), corner = if (Mix.rounded) 36.dp else 2.dp, fallback = Icons.Filled.Person, iconSize = 32.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(info?.name ?: name, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                info?.description?.takeIf { it.isNotBlank() }?.let {
                    Text(it.replaceFirstChar { c -> c.uppercase() }, style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        val plays = mine.sumOf { it.plays }
        val time = mine.sumOf { it.listenedMs }
        Text(
            buildString {
                append("$onPhone songs on this phone")
                if (plays > 0) append(" · $plays plays · ${formatListened(time)} listened")
            },
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Paper,
        )
        if (info != null && info.extract.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(info.extract, style = MaterialTheme.typography.bodyMedium, color = Mix.Paper)
            Text("From Wikipedia", style = MaterialTheme.typography.bodySmall, color = Mix.Fog, modifier = Modifier.padding(top = 4.dp))
        } else if (!vm.artistInfoOnline) {
            Text(
                "Artist info from Wikipedia is off (Settings → player).",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
        if (albums.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(Ui.head("albums"), style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(albums, key = { it.folder }) { a ->
                    Column(
                        Modifier
                            .width(110.dp)
                            .clickable {
                                vm.pop()
                                vm.push(Screen.Album(a.folder))
                            },
                    ) {
                        Artwork(a.tracks.first().artUri, Modifier.size(110.dp), corner = if (Mix.rounded) 12.dp else 2.dp, fallback = Icons.Filled.Album)
                        Text(a.name, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** Shows the playing file's quality; switch to another downloaded version or download a new one. */
@Composable
private fun VersionPicker(vm: MainViewModel, now: NowPlaying, modifier: Modifier = Modifier) {
    val current = vm.trackById(now.mediaId) ?: return
    val versions = remember(vm.library, current.id) { vm.versionsOf(current) }
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            shape = TermShape,
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
Ui.btn(Quality.describe(current.fileName, current.bitrateKbps) + " ▾"),
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Tape,
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            versions.forEach { v ->
                val playing = v.id == current.id
                DropdownMenuItem(
                    text = {
                        Text(
                            (if (playing) "> " else "  ") + Quality.describe(v.fileName, v.bitrateKbps),
                            color = if (playing) Mix.Tape else Mix.Paper,
                        )
                    },
                    onClick = {
                        open = false
                        if (!playing) vm.playVersion(v)
                    },
                )
            }
            HorizontalDivider(color = Mix.Gap)
            if (current.album.isNotBlank()) {
                DropdownMenuItem(
                    text = { Text("  get the whole album", color = Mix.Tape) },
                    onClick = {
                        open = false
                        vm.downloadAlbumOf(current)
                    },
                )
            }
            Quality.entries.forEach { q ->
                DropdownMenuItem(
                    text = { Text("  get ${q.label}", color = Mix.Fog) },
                    onClick = {
                        open = false
                        vm.downloadVersion(current, q)
                    },
                )
            }
        }
    }
}
