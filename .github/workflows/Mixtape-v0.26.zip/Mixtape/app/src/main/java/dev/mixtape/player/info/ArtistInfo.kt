package dev.mixtape.player.info

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** A short artist profile from Wikipedia. */
data class ArtistInfo(
    val name: String,
    val description: String,
    val extract: String,
    val imageUrl: String?,
    val pageUrl: String?,
)

/**
 * Looks an artist up on Wikipedia once and keeps the result on the phone (offline afterwards).
 * Checks the page is really about a musician, trying "(musician)", "(band)"… when the name is ambiguous.
 * Blocking: use Dispatchers.IO.
 */
object ArtistRepo {

    private const val UA = "Mixtape music player (Android; artist info)"
    private val MUSIC_WORDS = listOf(
        "musician", "singer", "rapper", "band", "producer", "dj", "composer", "songwriter", "group",
        "duo", "vocalist", "guitarist", "pianist", "record", "hip hop", "rock", "pop", "jazz", "music",
    )

    private fun file(context: Context, name: String) =
        File(File(context.filesDir, "artists").apply { mkdirs() }, name.lowercase().filter { it.isLetterOrDigit() }.take(80) + ".json")

    fun cached(context: Context, name: String): ArtistInfo? = runCatching {
        val f = file(context, name)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        if (o.optBoolean("none")) return null
        ArtistInfo(o.optString("name"), o.optString("description"), o.optString("extract"), o.optString("image").ifEmpty { null }, o.optString("url").ifEmpty { null })
    }.getOrNull()

    /** True when an earlier lookup found nothing (so we don't ask again every time). */
    fun knownMissing(context: Context, name: String): Boolean =
        runCatching { JSONObject(file(context, name).readText()).optBoolean("none") }.getOrDefault(false)

    fun fetch(context: Context, name: String): ArtistInfo? {
        val candidates = listOf(name, "$name (musician)", "$name (band)", "$name (rapper)", "$name (singer)")
        for (title in candidates) {
            val o = summary(title) ?: continue
            if (o.optString("type") == "disambiguation") continue
            val description = o.optString("description")
            val extract = o.optString("extract")
            val text = (description + " " + extract.take(300)).lowercase()
            if (MUSIC_WORDS.none { text.contains(it) }) continue
            val info = ArtistInfo(
                name = o.optString("title").ifEmpty { name },
                description = description,
                extract = extract,
                imageUrl = o.optJSONObject("thumbnail")?.optString("source")?.ifEmpty { null },
                pageUrl = o.optJSONObject("content_urls")?.optJSONObject("mobile")?.optString("page")?.ifEmpty { null },
            )
            file(context, name).writeText(
                JSONObject().put("name", info.name).put("description", info.description).put("extract", info.extract)
                    .put("image", info.imageUrl.orEmpty()).put("url", info.pageUrl.orEmpty()).toString(),
            )
            return info
        }
        file(context, name).writeText(JSONObject().put("none", true).toString())
        return null
    }

    private fun summary(title: String): JSONObject? {
        val path = URLEncoder.encode(title.replace(' ', '_'), "UTF-8").replace("+", "%20")
        val conn = (URL("https://en.wikipedia.org/api/rest_v1/page/summary/$path?redirect=true").openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", UA)
        }
        try {
            return when (val code = conn.responseCode) {
                200 -> JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                404 -> null
                else -> throw IOException("Wikipedia answered $code")
            }
        } finally {
            conn.disconnect()
        }
    }
}
