Mixtape v0.54

- Uses less battery, with every feature still there:
  - Cocoon style: the cursor pulses twice when it lands, then holds still. Before, every tile kept the screen redrawing non-stop.
  - The visualiser runs at about 24 frames a second and rests in between, and stops completely in the background or with the screen off.
  - Karaoke lyrics glide at 30 updates a second, and only while you're looking at them.
  - The cassette reels turn in small steps, and only while they're meant to spin.
  - RG Rotate: the closed-screen check only runs while the screen is on, and only every few seconds when nothing plays. On phones it barely runs at all.
  - Closed screen: the song position updates twice a second only with lyrics on (once a second is enough otherwise).

Mixtape v0.53

- Fixed: updating from inside the app stopped with "The coroutine scope left the composition".

- Square screens (RG Rotate): the player screen now fits. The cover sits on the left with the song beside it, and the seek bar and buttons are below, all on one screen. Scroll down for the artist.
- Closed screen: the lyrics always fit next to the cover. The line being sung stays in the middle and only whole lines show around it, never half a line.
- Cocoon style: playlist and album tiles are just the covers (the name only shows on tiles without a cover). No mini player at the bottom: use the "now playing" tile, tap the song name in the bottom bar, or press Y.
