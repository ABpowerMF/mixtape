package dev.mixtape.player.ui

import android.app.Activity
import android.content.Context
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import dev.mixtape.player.lyrics.Lrc
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.rotate.Rotate
import dev.mixtape.player.ui.theme.Mix
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RG Rotate, screen closed: the player takes the place of the console's clock.
 * Laid out on a 360 × 360 grid and scaled to fit the square screen.
 */
@Composable
fun ClosedScreen(vm: MainViewModel, now: NowPlaying) {
    val context = LocalContext.current
    ClosedFullScreen()
    var lastTouch by remember { mutableLongStateOf(System.currentTimeMillis()) }
    ClosedKeepScreenOn(now.isPlaying, lastTouch)
    var lyricsOn by remember { mutableStateOf(false) }
    // Twice-a-second updates only while the lyrics need them; once a second is enough otherwise.
    DisposableEffect(lyricsOn) {
        vm.player.fastProgress = lyricsOn
        onDispose { vm.player.fastProgress = false }
    }
    LaunchedEffect(lyricsOn, now.mediaId) {
        if (lyricsOn && now.mediaId != null) vm.loadLyrics(now.mediaId)
    }

    // Clock + battery for the top strip (this screen replaces the console's clock).
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            time = System.currentTimeMillis()
            delay(60_000L - time % 60_000L)
        }
    }
    val clock = SimpleDateFormat(if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(time))
    val battery = remember(time) { batteryPercent(context) }

    val font = MaterialTheme.typography.bodyMedium.fontFamily
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Mix.Ink)
            .pointerInput(Unit) {
                // Any touch keeps the screen awake a little longer.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    lastTouch = System.currentTimeMillis()
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        val scale = minOf(maxWidth, maxHeight) / 360.dp
        Box(
            Modifier
                .requiredSize(360.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
        ) {
            val base = TextStyle(fontFamily = font, color = Mix.Paper)
            // ---------- top strip ----------
            Row(
                Modifier
                    .padding(start = 16.dp, end = 16.dp, top = 10.dp)
                    .fillMaxWidth()
                    .height(24.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val path = when {
                    now.mediaId == null -> if (Mix.rounded) "Mixtape" else "~/mixtape"
                    lyricsOn -> (if (Mix.rounded) "Lyrics · " else "~/lyrics · ") + now.title
                    else -> if (Mix.rounded) "Now playing" else "~/now-playing"
                }
                Text(path, style = base.copy(fontSize = 10.sp, color = Mix.Fog), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(12.dp))
                Text(clock, style = base.copy(fontSize = 10.sp, color = Mix.Fog))
                if (battery != null) {
                    Spacer(Modifier.width(8.dp))
                    Text("$battery%", style = base.copy(fontSize = 10.sp, color = Mix.Fog))
                }
            }

            if (now.mediaId == null) {
                IdleView(vm, clock, base)
            } else {
                PlayerView(vm, now, lyricsOn, { lyricsOn = !lyricsOn }, base)
            }
        }
    }
}

@Composable
private fun PlayerView(vm: MainViewModel, now: NowPlaying, lyricsOn: Boolean, toggleLyrics: () -> Unit, base: TextStyle) {
    val track = vm.trackById(now.mediaId)
    val queue by vm.player.queue.collectAsStateWithLifecycle()
    val playingFrom by vm.player.context.collectAsStateWithLifecycle()
    val next = queue.firstOrNull { !it.current }

    // ---------- cover ----------
    Artwork(
        track?.artUri ?: now.artworkUri,
        Modifier
            .offset(x = 16.dp, y = 44.dp)
            .size(156.dp),
        corner = if (Mix.rounded) 14.dp else 4.dp,
        fallback = Icons.Filled.Album,
        iconSize = 48.dp,
    )

    // ---------- song info, or the lyrics in its place ----------
    val mode = when {
        !lyricsOn -> 0
        else -> 1
    }
    Box(
        Modifier
            .offset(x = 186.dp, y = 44.dp)
            .size(158.dp, 156.dp),
    ) {
        AnimatedContent(
            targetState = mode,
            transitionSpec = {
                if (!Mix.animations) {
                    fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                } else {
                    (fadeIn(tween(320, delayMillis = 80)) + slideInVertically(tween(420)) { it / 8 }) togetherWith
                        (fadeOut(tween(300)) + slideOutVertically(tween(420)) { -it / 12 } + scaleOut(tween(420), targetScale = 0.97f))
                }
            },
            label = "closed-info",
        ) { m ->
            if (m == 0) {
                Column(Modifier.fillMaxSize()) {
                    Text(
                        (if (now.isPlaying) "> from " else "> paused · ") + playingFrom.ifBlank { "your songs" },
                        style = base.copy(fontSize = 10.sp, color = Mix.Fog),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(now.title, style = base.copy(fontSize = 20.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(4.dp))
                    Text(now.artist, style = base.copy(fontSize = 13.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val album = track?.album.orEmpty()
                    if (album.isNotBlank()) {
                        Spacer(Modifier.height(3.dp))
                        Text(album, style = base.copy(fontSize = 11.sp, color = Mix.Fog), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Spacer(Modifier.weight(1f))
                    if (next != null) {
                        Box(Modifier.fillMaxWidth().height(1.dp).background(Mix.Gap))
                        Spacer(Modifier.height(6.dp))
                        Text("next >", style = base.copy(fontSize = 9.sp, color = Mix.Fog))
                        Text(
                            next.title + if (next.artist.isNotBlank()) " · " + next.artist else "",
                            style = base.copy(fontSize = 11.sp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            } else {
                LyricsColumn(vm, now.positionMs, base)
            }
        }
    }

    // ---------- seek bar ----------
    SeekBar(
        positionMs = now.positionMs,
        durationMs = now.durationMs,
        onSeek = vm.player::seekTo,
        base = base,
        modifier = Modifier
            .offset(x = 16.dp, y = 206.dp)
            .size(328.dp, 32.dp),
        timesModifier = Modifier.offset(x = 16.dp, y = 238.dp).size(328.dp, 32.dp),
        lyricsButton = {
            val on = lyricsOn
            val bg by animateColorAsState(if (on) Mix.Tape else Color.Transparent, tween(260), label = "lyr-bg")
            val fg by animateColorAsState(if (on) Mix.Ink else Mix.Paper, tween(260), label = "lyr-fg")
            val border by animateColorAsState(if (on) Mix.Tape else Mix.Gap, tween(260), label = "lyr-border")
            Box(
                Modifier
                    .height(26.dp)
                    .background(bg, RoundedCornerShape(13.dp))
                    .border(1.dp, border, RoundedCornerShape(13.dp))
                    .clickable(onClick = toggleLyrics)
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("lyrics", style = base.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = fg))
            }
        },
    )

    // ---------- controls ----------
    Row(
        Modifier
            .offset(x = 16.dp, y = 278.dp)
            .size(328.dp, 64.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        SmallToggle(
            icon = Icons.Filled.Shuffle,
            label = "Shuffle",
            on = now.shuffle,
            onClick = vm.player::toggleShuffle,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            IconButton(onClick = vm.player::previous, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous song", tint = Mix.Paper, modifier = Modifier.size(30.dp))
            }
            IconButton(onClick = vm.player::toggle, modifier = Modifier.size(64.dp)) {
                Icon(
                    if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (now.isPlaying) "Pause" else "Play",
                    tint = Mix.Tape,
                    modifier = Modifier.size(46.dp),
                )
            }
            IconButton(onClick = vm.player::next, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next song", tint = Mix.Paper, modifier = Modifier.size(30.dp))
            }
        }
        SmallToggle(
            icon = if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
            label = when (now.repeatMode) {
                Player.REPEAT_MODE_ONE -> "Repeat: one"
                Player.REPEAT_MODE_ALL -> "Repeat: all"
                else -> "Repeat: off"
            },
            on = now.repeatMode != Player.REPEAT_MODE_OFF,
            onClick = vm.player::cycleRepeat,
        )
    }
}

/** Shuffle / repeat: small icon, lit with a dot when on. */
@Composable
private fun SmallToggle(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, on: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .size(44.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(icon, contentDescription = label, tint = if (on) Mix.Tape else Mix.Fog, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(3.dp))
        Box(Modifier.size(3.dp).background(if (on) Mix.Tape else Color.Transparent, CircleShape))
    }
}

/**
 * Tap or drag anywhere on the bar. While dragging it gets thicker and the time shows above
 * your finger; the song jumps when you let go.
 */
@Composable
private fun SeekBar(
    positionMs: Long,
    durationMs: Long,
    onSeek: (Long) -> Unit,
    base: TextStyle,
    modifier: Modifier,
    timesModifier: Modifier,
    lyricsButton: @Composable () -> Unit,
) {
    var scrubbing by remember { mutableStateOf(false) }
    var scrubFrac by remember { mutableFloatStateOf(0f) }
    val playFrac = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val frac = if (scrubbing) scrubFrac else playFrac
    val barH by animateDpAsState(if (scrubbing) 6.dp else 4.dp, tween(160), label = "bar-h")
    val thumb by animateDpAsState(if (scrubbing) 18.dp else 12.dp, tween(160), label = "thumb")
    val shownMs = if (scrubbing) (scrubFrac * durationMs).toLong() else positionMs

    BoxWithConstraints(
        modifier.pointerInput(durationMs) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val w = size.width.toFloat().coerceAtLeast(1f)
                scrubbing = true
                scrubFrac = (down.position.x / w).coerceIn(0f, 1f)
                down.consume()
                drag(down.id) { change ->
                    scrubFrac = (change.position.x / w).coerceIn(0f, 1f)
                    change.consume()
                }
                if (durationMs > 0) onSeek((scrubFrac * durationMs).toLong())
                scrubbing = false
            }
        },
    ) {
        val width = maxWidth
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth()
                .height(barH)
                .background(Mix.Gap, RoundedCornerShape(3.dp)),
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(frac)
                    .background(Mix.Tape, RoundedCornerShape(3.dp)),
            )
        }
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .offset(x = width * frac - thumb / 2)
                .size(thumb)
                .border(3.dp, Mix.Ink, CircleShape)
                .background(Mix.Paper, CircleShape),
        )
        if (scrubbing) {
            Text(
                formatTime(shownMs),
                style = base.copy(fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Mix.Ink),
                modifier = Modifier
                    .offset(x = (width * frac - 24.dp).coerceIn(0.dp, width - 48.dp), y = (-26).dp)
                    .width(48.dp)
                    .background(Mix.Tape, RoundedCornerShape(3.dp))
                    .padding(vertical = 3.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
    }
    Row(timesModifier, verticalAlignment = Alignment.CenterVertically) {
        Text(formatTime(shownMs), style = base.copy(fontSize = 11.sp, color = Mix.Fog), modifier = Modifier.width(64.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { lyricsButton() }
        Text(
            formatTime(durationMs),
            style = base.copy(fontSize = 11.sp, color = Mix.Fog),
            modifier = Modifier.width(64.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End,
        )
    }
}

/** The lyrics where the song name was: the line being sung, the one before and two after. */
@Composable
private fun LyricsColumn(vm: MainViewModel, positionMs: Long, base: TextStyle) {
    when (val state = vm.lyricsState) {
        is MainViewModel.LyricsState.Found -> {
            val lyrics = state.lyrics
            if (lyrics.synced.isNotEmpty()) {
                val lines = lyrics.synced
                val cur = Lrc.currentIndex(lines, positionMs)
                AnimatedContent(
                    targetState = cur,
                    transitionSpec = {
                        if (!Mix.animations) {
                            fadeIn(tween(0)) togetherWith fadeOut(tween(0))
                        } else {
                            (fadeIn(tween(260)) + slideInVertically(tween(320)) { it / 5 }) togetherWith
                                (fadeOut(tween(200)) + slideOutVertically(tween(320)) { -it / 5 })
                        }
                    },
                    label = "lyric-line",
                ) { c ->
                    FitLyrics(lines.map { it.text }, c, base)
                }
            } else if (lyrics.instrumental) {
                Message("instrumental", "no words in this one", base)
            } else {
                Text(
                    lyrics.plain.orEmpty(),
                    style = base.copy(fontSize = 12.sp, lineHeight = 16.sp),
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                )
            }
        }
        MainViewModel.LyricsState.Loading, MainViewModel.LyricsState.Idle -> Message("looking for lyrics…", "", base)
        MainViewModel.LyricsState.NotFound -> Message(
            "no lyrics saved",
            "open the song in Mixtape to find them, or paste your own there",
            base,
        )
    }
}

/**
 * Fits the lyrics in the space next to the cover: the line being sung sits a little above the
 * middle, then as many lines before and after as fit whole. A line that doesn't fit isn't shown,
 * so nothing gets cut in half.
 */
@Composable
private fun FitLyrics(lines: List<String>, cur: Int, base: TextStyle) {
    val anchor = cur.coerceAtLeast(0)
    val from = maxOf(0, anchor - 3)
    val to = minOf(lines.lastIndex, anchor + 5)
    val window = (from..to).toList()
    Layout(
        content = {
            window.forEach { k ->
                val isCur = k == cur
                Text(
                    lines[k].ifBlank { "· · ·" },
                    style = base.copy(
                        fontSize = if (isCur) 14.sp else 12.sp,
                        lineHeight = if (isCur) 18.sp else 15.sp,
                        fontWeight = if (isCur) FontWeight.Bold else FontWeight.Normal,
                        color = when {
                            isCur -> Mix.Tape
                            k < cur -> Mix.Fog.copy(alpha = 0.7f)
                            k == cur + 1 -> Mix.Paper
                            else -> Mix.Fog
                        },
                    ),
                )
            }
        },
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds(),
    ) { measurables, constraints ->
        val gap = 6.dp.roundToPx()
        val loose = constraints.copy(minWidth = 0, minHeight = 0, maxHeight = Constraints.Infinity)
        val placeables = measurables.map { it.measure(loose) }
        val h = constraints.maxHeight
        val ci = window.indexOf(anchor).coerceAtLeast(0)
        val tops = arrayOfNulls<Int>(placeables.size)
        if (placeables.isNotEmpty()) {
            val current = placeables[ci]
            val top = if (current.height >= h) 0 else ((h - current.height) * 0.42f).toInt()
            tops[ci] = top
            var y = top
            for (i in ci - 1 downTo 0) {
                val next = y - gap - placeables[i].height
                if (next < 0) break
                tops[i] = next
                y = next
            }
            y = top + current.height
            for (i in ci + 1 until placeables.size) {
                val next = y + gap
                if (next + placeables[i].height > h) break
                tops[i] = next
                y = next + placeables[i].height
            }
        }
        layout(constraints.maxWidth, h) {
            placeables.forEachIndexed { i, p -> tops[i]?.let { p.placeRelative(0, it) } }
        }
    }
}

@Composable
private fun Message(title: String, body: String, base: TextStyle) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Text(title, style = base.copy(fontSize = 14.sp, fontWeight = FontWeight.Bold))
        if (body.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(body, style = base.copy(fontSize = 11.sp, lineHeight = 15.sp, color = Mix.Fog))
        }
    }
}

/** Nothing playing: a big clock like the console's, plus a card to start music again. */
@Composable
private fun IdleView(vm: MainViewModel, clock: String, base: TextStyle) {
    val context = LocalContext.current
    val day = remember(clock) { SimpleDateFormat("EEE · d MMM", Locale.getDefault()).format(Date()).lowercase() }
    val lastId = remember { context.getSharedPreferences("mixtape", Context.MODE_PRIVATE).getString("lastPlaylist", null) }
    val last = vm.playlists.firstOrNull { it.id == lastId }

    Column(
        Modifier
            .offset(y = 72.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(clock, style = base.copy(fontSize = 72.sp, lineHeight = 80.sp, fontWeight = FontWeight.Bold, letterSpacing = (-3).sp))
        Spacer(Modifier.height(6.dp))
        Text(day, style = base.copy(fontSize = 13.sp, color = Mix.Fog))
    }
    Row(
        Modifier
            .offset(x = 16.dp, y = 214.dp)
            .width(328.dp),
    ) {
        Text("> nothing playing", style = base.copy(fontSize = 10.sp, color = Mix.Fog), modifier = Modifier.weight(1f))
        Text("tap to play", style = base.copy(fontSize = 10.sp, color = Mix.Fog))
    }
    Row(
        Modifier
            .offset(x = 16.dp, y = 236.dp)
            .size(328.dp, 80.dp)
            .background(Mix.Raised, RoundedCornerShape(6.dp))
            .border(1.dp, Mix.Gap, RoundedCornerShape(6.dp))
            .clickable { vm.playFromWidget(last?.id) }
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(last?.imageUrl, Modifier.size(56.dp), corner = 3.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(if (last != null) "resume" else "shuffle", style = base.copy(fontSize = 10.sp, color = Mix.Fog))
            Text(
                last?.name ?: "all your songs",
                style = base.copy(fontSize = 15.sp, fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Mix.Tape, modifier = Modifier.size(30.dp))
    }
}

private fun batteryPercent(context: Context): Int? = runCatching {
    context.getSystemService(BatteryManager::class.java)?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}.getOrNull()?.takeIf { it in 0..100 }

/** Keeps the screen on while playing (or for a while after the last touch, as set in Settings → rotate). */
@Composable
private fun ClosedKeepScreenOn(playing: Boolean, lastTouch: Long) {
    val view = LocalView.current
    val seconds = Rotate.screenOnSeconds
    LaunchedEffect(playing, lastTouch, seconds) {
        if (seconds == 0) {
            view.keepScreenOn = playing
            return@LaunchedEffect
        }
        view.keepScreenOn = true
        delay(seconds * 1000L)
        view.keepScreenOn = false
    }
    DisposableEffect(view) { onDispose { view.keepScreenOn = false } }
}

/** Hides the status and navigation bars while the closed screen shows. */
@Composable
private fun ClosedFullScreen() {
    val view = LocalView.current
    DisposableEffect(view) {
        val window = (view.context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
}
