package dev.mixtape.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameMillis
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import dev.mixtape.player.playback.Extras
import dev.mixtape.player.playback.LevelTap
import dev.mixtape.player.playback.VisualiserStyle
import dev.mixtape.player.ui.theme.Mix

/** How tall the visualiser strip is: two rows of small characters. */
val VisualiserHeight = 22.dp

/**
 * The ASCII visualiser: a low strip of characters that move with the music, drawn on top of
 * whatever is behind it (it doesn't take any room). Flat while paused.
 */
@Composable
fun AsciiVisualiser(playing: Boolean, modifier: Modifier = Modifier) {
    val style = Extras.visualiser
    if (style == VisualiserStyle.OFF) return
    val tap = Extras.levels

    // Only listen while this is on screen (not while the app is in the background).
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val lifeState by lifecycle.currentStateAsState()
    val onScreen = lifeState.isAtLeast(Lifecycle.State.STARTED)
    DisposableEffect(tap, onScreen) {
        tap?.active = onScreen
        onDispose { tap?.active = false }
    }

    val glyphs = when (style) {
        VisualiserStyle.BARS -> listOf(" ", "▁", "▂", "▃", "▄", "▅", "▆", "▇", "█")
        VisualiserStyle.DOTS -> listOf(" ", "·", "·", "∙", "∙", "•", "•", "●", "●")
        else -> listOf(" ", "_", "_", ".", "-", "-", "~", "'", "˙")
    }
    val measurer = rememberTextMeasurer(cacheSize = 24)
    val color = Mix.Paper
    val textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp, color = color)
    val layouts: List<TextLayoutResult> = remember(style, color) { glyphs.map { measurer.measure(it, textStyle) } }

    val raw = remember { FloatArray(LevelTap.BANDS) }
    val shown = remember { FloatArray(LevelTap.BANDS) }
    var frame by remember { mutableIntStateOf(0) }
    val gain = remember { floatArrayOf(0.6f) }

    LaunchedEffect(playing, tap, onScreen) {
        // Nothing to draw with the app in the background or the screen off.
        if (!onScreen) return@LaunchedEffect
        while (true) {
            // About 24 frames a second, and the app sleeps in between (waking up for every
            // screen frame just to skip it kept the phone busy).
            withFrameMillis { it }
            val fresh = playing && tap?.read(raw) == true
            var peak = 0f
            var still = true
            for (i in shown.indices) {
                val target = if (fresh) raw[i] else 0f
                // Rises fast, falls slowly.
                shown[i] = if (target > shown[i]) shown[i] + (target - shown[i]) * 0.6f else shown[i] * 0.86f + target * 0.14f
                if (shown[i] > 0.01f) still = false
                if (raw[i] > peak) peak = raw[i]
            }
            // Auto level: quiet songs still move, loud ones don't sit at the top.
            if (fresh) gain[0] = (gain[0] * 0.97f + peak * 0.03f).coerceIn(0.25f, 1f)
            frame++
            if (!playing && still) break
            kotlinx.coroutines.delay(40)
        }
    }

    val cellW = remember(color) { measurer.measure("█", textStyle).size.width.toFloat().coerceAtLeast(4f) }
    val rows = 2
    Canvas(modifier.fillMaxWidth().height(VisualiserHeight)) {
            if (frame < 0) return@Canvas // reading the frame counter redraws every frame
            // A soft shade behind the characters, so they read over covers.
            drawRect(
                Brush.verticalGradient(listOf(Color.Transparent, Mix.Ink.copy(alpha = 0.55f))),
            )
            val cols = (size.width / cellW).toInt().coerceAtLeast(1)
            val rowH = size.height / rows
            val levels = glyphs.size - 1
            val g = gain[0]
            for (c in 0 until cols) {
                // Spread the bands over the columns (lows on the left).
                val pos = c.toFloat() / cols * (LevelTap.BANDS - 1)
                val i = pos.toInt()
                val frac = pos - i
                val a = shown[i]
                val b = shown[(i + 1).coerceAtMost(LevelTap.BANDS - 1)]
                val v = ((a + (b - a) * frac) / g).coerceIn(0f, 1f)
                val steps = (v * levels * rows).toInt()
                val x = c * cellW + (size.width - cols * cellW) / 2f
                if (style == VisualiserStyle.WAVE) {
                    // One mark per column at its height.
                    val idx = steps.coerceIn(1, levels * rows)
                    val row = if (idx > levels) 0 else 1
                    val glyph = if (row == 0) idx - levels else idx
                    val lay = layouts[glyph.coerceIn(1, levels)]
                    drawText(lay, topLeft = Offset(x, row * rowH + (rowH - lay.size.height) / 2f))
                } else {
                    for (r in 0 until rows) {
                        // Bottom row fills first.
                        val fromBottom = rows - 1 - r
                        val fill = (steps - fromBottom * levels).coerceIn(0, levels)
                        if (fill == 0) continue
                        val lay = layouts[fill]
                        drawText(lay, topLeft = Offset(x, r * rowH + (rowH - lay.size.height) / 2f))
                    }
                }
            }
    }
}
