package dev.mixtape.player.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import dev.mixtape.player.tape.Tape
import dev.mixtape.player.tape.TapeCodec
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Shell = Color(0xFFEDEDED)
private val LabelInk = Color(0xFF111111)
private val LabelGrey = Color(0xFF555555)
private val Reel = Color(0xFF3A3A3A)

/** "24h 10m" / "48m" for the tape label. */
private fun tapeLength(ms: Long): String {
    val minutes = ms / 60_000
    return if (minutes >= 60) "${minutes / 60}h ${minutes % 60}m" else "${minutes}m"
}

/** The cassette: label with the playlist name (in the app's own font), and the reels turning. */
@Composable
fun TapeGraphic(name: String, subtitle: String, spinning: Boolean, modifier: Modifier = Modifier) {
    // The reels turn in small steps a dozen times a second (one turn every 4 s), and only
    // while they're meant to spin: a smooth endless animation redraws the screen non-stop.
    var angle by remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
    androidx.compose.runtime.LaunchedEffect(spinning) {
        if (!spinning) return@LaunchedEffect
        while (true) {
            delay(80)
            angle = (angle + 7.2f) % 360f
        }
    }
    Column(
        modifier
            .fillMaxWidth()
            .background(Shell, RoundedCornerShape(14.dp))
            .padding(start = 16.dp, end = 16.dp, top = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White, RoundedCornerShape(6.dp))
                .drawWithContent {
                    drawContent()
                    drawRect(LabelInk, size = Size(size.width, 6.dp.toPx()))
                }
                .padding(start = 12.dp, end = 12.dp, top = 14.dp, bottom = 10.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("A", style = MaterialTheme.typography.labelSmall, color = LabelGrey)
                Text("C-90 · mixtape", style = MaterialTheme.typography.labelSmall, color = LabelGrey)
            }
            Text(
                name,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = LabelInk,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = LabelGrey, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        // The window with the two reels.
        Row(
            Modifier
                .align(Alignment.CenterHorizontally)
                .width(230.dp)
                .height(62.dp)
                .background(LabelInk, RoundedCornerShape(31.dp))
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ReelIcon(18.dp, if (spinning) angle else 0f)
            Box(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp)
                    .height(18.dp)
                    .background(Color(0xFF2A2A2A), RoundedCornerShape(3.dp)),
            )
            ReelIcon(12.dp, if (spinning) angle else 0f)
        }
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .width(200.dp)
                .height(18.dp)
                .background(Color(0xFFD6D6D6), RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)),
        )
    }
}

@Composable
private fun ReelIcon(radius: Dp, angle: Float) {
    Canvas(
        Modifier
            .size(40.dp)
            .rotate(angle),
    ) {
        val c = center
        drawCircle(Reel, radius.toPx(), c)
        drawCircle(Shell, 9.dp.toPx(), c)
        val a = 9.dp.toPx()
        val b = 5.dp.toPx()
        val w = 2.dp.toPx()
        drawLine(LabelInk, Offset(c.x, c.y - a), Offset(c.x, c.y - b), w, StrokeCap.Butt)
        drawLine(LabelInk, Offset(c.x, c.y + b), Offset(c.x, c.y + a), w, StrokeCap.Butt)
        drawLine(LabelInk, Offset(c.x - a, c.y), Offset(c.x - b, c.y), w, StrokeCap.Butt)
        drawLine(LabelInk, Offset(c.x + b, c.y), Offset(c.x + a, c.y), w, StrokeCap.Butt)
    }
}

/** A QR code, drawn square by square so it stays sharp at any size. */
@Composable
fun QrCode(text: String, modifier: Modifier = Modifier) {
    val matrix: BitMatrix? = remember(text) {
        runCatching {
            QRCodeWriter().encode(
                text,
                BarcodeFormat.QR_CODE,
                0,
                0,
                mapOf(EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L, EncodeHintType.MARGIN to 0),
            )
        }.getOrNull()
    }
    Canvas(
        modifier
            .aspectRatio(1f)
            .background(Color.White, RoundedCornerShape(8.dp))
            .padding(10.dp),
    ) {
        val m = matrix ?: return@Canvas
        val cell = size.minDimension / m.width
        for (y in 0 until m.height) {
            for (x in 0 until m.width) {
                if (m.get(x, y)) {
                    drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.5f, cell + 0.5f))
                }
            }
        }
    }
}

/** Share a playlist as a tape: the cassette, a QR code a friend scans, and the first songs. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareTapeScreen(vm: MainViewModel, id: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tape = remember(id, vm.playlists, vm.shareName) { vm.tapeOf(id) }
    if (tape == null) {
        LaunchedEffect(id) { vm.pop() }
        return
    }
    val codes = remember(tape) { TapeCodec.encode(tape) }
    var part by remember { mutableIntStateOf(0) }
    // Long tapes don't fit one code: show the parts one after another.
    LaunchedEffect(codes) {
        if (codes.size < 2) return@LaunchedEffect
        while (true) {
            delay(450)
            part = (part + 1) % codes.size
        }
    }
    val subtitle = "from ${tape.from} · ${tape.count} songs · ${tapeLength(vm.lengthOf(id))}"
    val card = rememberGraphicsLayer()
    var bigQr by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("share-tape"), style = MaterialTheme.typography.titleLarge, color = Mix.Fog) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            // This part is what "Share tape" / "Save image" turn into a picture.
            Column(
                Modifier
                    .drawWithContent {
                        card.record { this@drawWithContent.drawContent() }
                        drawLayer(card)
                    }
                    .background(Mix.Ink)
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                TapeGraphic(tape.name, subtitle, spinning = true)
                if (bigQr) {
                    QrCode(codes[part % codes.size], Modifier.fillMaxWidth().clickable { bigQr = false })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!bigQr) {
                        QrCode(codes[part % codes.size], Modifier.size(150.dp).clickable { bigQr = true })
                        Spacer(Modifier.width(16.dp))
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(Ui.head("scan to get it"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
                        Text(
                            "In Mixtape: Playlists › + › Scan a tape." +
                                if (codes.size > 1) " This tape is ${codes.size} codes in a row: hold the camera on it until it's read." else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                        )
                    }
                }
            }
            val rows = vm.sortedRows(id)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("side A", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                rows.take(3).forEachIndexed { i, r ->
                    Text(
                        "%02d %s · %s".format(i + 1, r.track.title, r.track.artists.joinToString(", ")),
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Paper,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (rows.size > 3) {
                    Text("… ${rows.size - 3} more", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
                }
            }
            Spacer(Modifier.height(4.dp))
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Button(
                onClick = {
                    scope.launch {
                        val bitmap = runCatching { card.toImageBitmap().asAndroidBitmap() }.getOrNull()
                        shareTape(context, tape, bitmap, many = codes.size > 1)
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(3.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Mix.Paper, contentColor = Mix.Ink),
            ) { Text("Share tape", fontWeight = FontWeight.Bold) }
            if (codes.size == 1) {
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            val bitmap = runCatching { card.toImageBitmap().asAndroidBitmap() }.getOrNull()
                            val ok = bitmap != null && withContext(Dispatchers.IO) { saveImage(context, bitmap, tape.name) }
                            vm.showMessage(if (ok) "Saved to Pictures/Mixtape." else "Couldn't save the picture.")
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    shape = RoundedCornerShape(3.dp),
                    border = BorderStroke(1.dp, Mix.Gap),
                ) { Text("Save image", color = Mix.Paper) }
            }
        }
    }
}

private fun safe(name: String) = name.replace(Regex("[^\\p{L}\\p{N} ._-]"), "").trim().ifEmpty { "tape" }.take(40)

/**
 * Opens the share sheet with a picture of the tape. A long tape (several codes) also gets a text
 * list of its songs, which Mixtape can import (Playlists › + › import from a file).
 */
private suspend fun shareTape(context: Context, tape: Tape, bitmap: Bitmap?, many: Boolean) {
    val dir = File(context.cacheDir, "share").apply { mkdirs() }
    val uris = ArrayList<android.net.Uri>()
    withContext(Dispatchers.IO) {
        if (bitmap != null) {
            val img = File(dir, "${safe(tape.name)}-tape.png")
            img.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            uris += FileProvider.getUriForFile(context, context.packageName + ".files", img)
        }
        if (many || bitmap == null) {
            val txt = File(dir, "${safe(tape.name)}.txt")
            txt.writeText(tape.tracks.joinToString("\n") { t -> "${t.artists.joinToString(", ")} - ${t.title}" })
            uris += FileProvider.getUriForFile(context, context.packageName + ".files", txt)
        }
    }
    val text = tape.spotify?.let { sp ->
        "${tape.name} · open.spotify.com/${sp.substringBefore(':')}/${sp.substringAfter(':')}"
    } ?: tape.name
    val send = if (uris.size == 1) {
        Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uris[0])
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*").putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
    }
    send.putExtra(Intent.EXTRA_TEXT, text).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    context.startActivity(Intent.createChooser(send, "Share tape").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

/** Saves the tape picture to Pictures/Mixtape. */
private fun saveImage(context: Context, bitmap: Bitmap, name: String): Boolean = runCatching {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "${safe(name)}-tape.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Mixtape")
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
    resolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) } ?: return false
    true
}.getOrDefault(false)

/** Small cassette for the "tape found" card. */
@Composable
fun MiniTape(name: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .size(width = 88.dp, height = 56.dp)
            .background(Shell, RoundedCornerShape(5.dp))
            .padding(5.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(20.dp)
                .background(Color.White, RoundedCornerShape(2.dp))
                .padding(horizontal = 4.dp),
            contentAlignment = Alignment.CenterStart,
        ) {
            Text(name, color = LabelInk, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(18.dp)
                .background(LabelInk, RoundedCornerShape(9.dp)),
        )
    }
}
