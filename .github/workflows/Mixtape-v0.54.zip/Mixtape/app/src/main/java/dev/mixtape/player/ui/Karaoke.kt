package dev.mixtape.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.mixtape.player.lyrics.Lrc
import dev.mixtape.player.lyrics.LyricLine
import dev.mixtape.player.playback.AudioFx
import dev.mixtape.player.playback.Extras
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix

/**
 * The song position, moving smoothly between the player's updates (which come twice a second),
 * so the karaoke fill glides instead of jumping.
 */
@Composable
fun rememberSmoothPosition(now: NowPlaying): Long {
    var shown by remember { mutableLongStateOf(now.positionMs) }
    // Only glide while the app is on screen: in the background or with the screen off it rests.
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    val lifeState by lifecycle.currentStateFlow.collectAsState()
    val onScreen = lifeState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)
    LaunchedEffect(now.positionMs, now.isPlaying, now.mediaId, onScreen) {
        val base = now.positionMs
        shown = base
        if (!now.isPlaying || !onScreen) return@LaunchedEffect
        val speed = AudioFx.settings.speed.coerceIn(0.5f, 1.5f)
        val start = withFrameMillis { it }
        while (true) {
            val t = withFrameMillis { it }
            // Never run more than a second ahead of the last real update.
            shown = base + ((t - start) * speed).toLong().coerceAtMost(1_000L)
            // 30 updates a second still glides, at half the work of every screen frame.
            kotlinx.coroutines.delay(30)
        }
    }
    return shown
}

/** "vocals ───●─── 20%" under the lyrics top bar while karaoke is on. */
@Composable
fun VocalsSlider() {
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text("vocals", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        Spacer(Modifier.width(12.dp))
        Slider(
            value = Extras.vocals,
            onValueChange = { Extras.chooseVocals(context, it) },
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Mix.Paper,
                activeTrackColor = Mix.Paper,
                inactiveTrackColor = Mix.Gap,
            ),
        )
        Spacer(Modifier.width(12.dp))
        Text(
            "${(Extras.vocals * 100).toInt()}%",
            style = MaterialTheme.typography.bodySmall,
            color = Mix.Paper,
            modifier = Modifier.widthIn(min = 36.dp),
        )
    }
}

/** How long a line is sung for: until the next line, but not through a long instrumental gap. */
private fun singTime(lines: List<LyricLine>, i: Int): Long {
    val line = lines[i]
    val next = lines.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 6_000)
    val estimate = 600L + line.text.length * 110L
    return (next - line.timeMs).coerceAtMost(estimate).coerceAtLeast(400L)
}

/** The line, filled with white from the left as it's sung ([fraction] 0–1). */
private fun filled(text: String, fraction: Float, sung: Color, unsung: Color): AnnotatedString {
    if (text.isEmpty()) return AnnotatedString("♪")
    val exact = fraction.coerceIn(0f, 1f) * text.length
    val whole = exact.toInt().coerceAtMost(text.length)
    val part = exact - whole
    return buildAnnotatedString {
        withStyle(SpanStyle(color = sung)) { append(text.substring(0, whole)) }
        if (whole < text.length) {
            // The letter being sung fades in, so the fill moves smoothly.
            withStyle(SpanStyle(color = lerp(unsung, sung, part))) { append(text[whole]) }
            withStyle(SpanStyle(color = unsung)) { append(text.substring(whole + 1)) }
        }
    }
}

/**
 * Karaoke lyrics: the line being sung is big and fills with white as it goes, the ones before
 * are dim, the next ones grey. Scrolls by itself; tap a line to jump there.
 */
@Composable
fun KaraokeLyrics(
    lines: List<LyricLine>,
    positionMs: Long,
    onSeek: (Long) -> Unit,
) {
    val listState = rememberLazyListState()
    val current = Lrc.currentIndex(lines, positionMs + 150)
    LaunchedEffect(current) {
        // Keeps a couple of sung lines above the current one.
        if (current >= 0 && !listState.isScrollInProgress) {
            listState.animateScrollToItem((current - 2).coerceAtLeast(0))
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(top = 24.dp, bottom = 320.dp),
    ) {
        itemsIndexed(lines) { i, line ->
            val active = i == current
            Column(
                Modifier
                    .fillMaxWidth()
                    .clickable { onSeek(line.timeMs) }
                    .padding(horizontal = 20.dp, vertical = if (active) 12.dp else 7.dp),
            ) {
                if (active) {
                    val fraction = (positionMs + 150 - line.timeMs).toFloat() / singTime(lines, i)
                    Text(
                        filled(line.text, fraction, Mix.Paper, Mix.Fog),
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            lineHeight = 34.sp,
                        ),
                    )
                } else {
                    Text(
                        line.text.ifEmpty { "♪" },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Normal),
                        color = if (i < current) Mix.Fog.copy(alpha = 0.45f) else Mix.Fog,
                    )
                }
            }
        }
    }
}
