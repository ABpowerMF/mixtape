package dev.mixtape.player.ui

import android.content.Context
import android.os.BatteryManager
import android.text.format.DateFormat
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FiberNew
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.data.LIKED_ID
import dev.mixtape.player.data.SavedPlaylist
import dev.mixtape.player.ui.theme.Mix
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * Cocoon style (Settings → style): the look of the Cocoon console frontend. Soft rounded tiles,
 * see-through "glass" panels, a wave background, the tabs on top (L / R switch them) and a bar
 * at the bottom that says what the console buttons do.
 */

/** Tab order in the Cocoon top bar (L / R walk through it). */
val cocoonTabs = listOf(HomeTab.Songs, HomeTab.Playlists, HomeTab.Download, HomeTab.Settings)

/** What the console's X button does on the current screen (null = play / pause). */
object ConsoleKeys {
    var onX by mutableStateOf<(() -> Unit)?>(null)
    var xLabel by mutableStateOf("shuffle")
}

/** Lets a screen take over the X button while it's showing. */
@Composable
fun ConsoleX(label: String, action: () -> Unit) {
    val current by rememberUpdatedState(action)
    DisposableEffect(label) {
        val handler: () -> Unit = { current() }
        ConsoleKeys.onX = handler
        ConsoleKeys.xLabel = label
        onDispose { if (ConsoleKeys.onX === handler) ConsoleKeys.onX = null }
    }
}

val GlassFill: Color get() = Mix.Paper.copy(alpha = 0.06f)
val GlassLine: Color get() = Mix.Paper.copy(alpha = 0.12f)

/** A see-through rounded panel. */
fun Modifier.glass(shape: Shape = RoundedCornerShape(16.dp)): Modifier = composed {
    this
        .clip(shape)
        .background(GlassFill, shape)
        .border(1.dp, GlassLine, shape)
}

/**
 * The Cocoon cursor: a ring in the accent colour, and a little lift, on whatever has focus.
 * It pulses twice when it lands and then holds still, so the screen isn't redrawn non-stop
 * (a ring that pulses forever keeps the screen redrawing 60 times a second, which drains battery).
 */
fun Modifier.cocoonFocus(shape: Shape = RoundedCornerShape(16.dp)): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val lift by animateFloatAsState(if (focused) 1.05f else 1f, tween(180), label = "lift")
    val pulse = remember { Animatable(1f) }
    LaunchedEffect(focused) {
        pulse.snapTo(1f)
        if (!focused || !Mix.animations) return@LaunchedEffect
        repeat(2) {
            pulse.animateTo(0.45f, tween(450))
            pulse.animateTo(1f, tween(450))
        }
    }
    val alpha = pulse.value
    this
        .onFocusChanged { focused = it.isFocused || it.hasFocus }
        .graphicsLayer {
            scaleX = lift
            scaleY = lift
        }
        .border(
            width = if (focused) 2.5.dp else 0.dp,
            color = if (focused) Mix.Tape.copy(alpha = alpha) else Color.Transparent,
            shape = shape,
        )
}

/** Soft waves along the bottom of the screen, behind everything. */
@Composable
fun WaveBackground(modifier: Modifier = Modifier) {
    val fill = Mix.Paper.copy(alpha = 0.035f)
    val line = Mix.Paper.copy(alpha = 0.09f)
    val faint = Mix.Paper.copy(alpha = 0.05f)
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val top = h * 0.62f
        val band = h - top
        fun y(f: Float) = top + band * f
        val area = Path().apply {
            moveTo(0f, y(0.5f))
            cubicTo(w * 0.17f, y(0.26f), w * 0.33f, y(0.74f), w * 0.5f, y(0.5f))
            cubicTo(w * 0.67f, y(0.26f), w * 0.83f, y(0.26f), w, y(0.5f))
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(area, fill)
        val crest = Path().apply {
            moveTo(0f, y(0.66f))
            cubicTo(w * 0.19f, y(0.46f), w * 0.36f, y(0.84f), w * 0.56f, y(0.66f))
            cubicTo(w * 0.75f, y(0.5f), w * 0.9f, y(0.52f), w, y(0.67f))
        }
        drawPath(crest, line, style = Stroke(width = 1.dp.toPx()))
        val high = Path().apply {
            moveTo(0f, y(0.34f))
            cubicTo(w * 0.22f, y(0.16f), w * 0.42f, y(0.53f), w * 0.64f, y(0.33f))
            cubicTo(w * 0.8f, y(0.2f), w * 0.92f, y(0.24f), w, y(0.29f))
        }
        drawPath(high, faint, style = Stroke(width = 1.dp.toPx()))
    }
}

/** A console button as a little round badge: "A", "B", "X", "Y". */
@Composable
fun Glyph(letter: String, inverted: Boolean = false) {
    Box(
        Modifier
            .size(16.dp)
            .background(if (inverted) Mix.Ink else Mix.Paper, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            letter,
            fontSize = 9.sp,
            lineHeight = 9.sp,
            fontWeight = FontWeight.Bold,
            color = if (inverted) Mix.Tape else Mix.Ink,
        )
    }
}

/** "L" / "R" shoulder badges either side of the tabs. */
@Composable
private fun Shoulder(letter: String) {
    Box(
        Modifier
            .size(24.dp, 18.dp)
            .background(Mix.Paper.copy(alpha = 0.12f), RoundedCornerShape(5.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Text(letter, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Mix.Paper)
    }
}

/** Logo, clock and battery, then the tabs. Only on the main screen. */
@Composable
fun CocoonTopBar(vm: MainViewModel) {
    val context = LocalContext.current
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            time = System.currentTimeMillis()
            delay(60_000L - time % 60_000L)
        }
    }
    val clock = SimpleDateFormat(if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(time))
    val battery = remember(time) { batteryLevel(context) }

    Column(
        Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Row(Modifier.fillMaxWidth().height(32.dp), verticalAlignment = Alignment.CenterVertically) {
            CassetteMark()
            Spacer(Modifier.width(8.dp))
            Text("Mixtape", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Mix.Paper, modifier = Modifier.weight(1f))
            Row(
                Modifier
                    .height(26.dp)
                    .glass(RoundedCornerShape(13.dp))
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (battery != null) {
                    Text("$battery%", fontSize = 11.sp, color = Mix.Fog)
                    Spacer(Modifier.width(8.dp))
                }
                Text(clock, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Mix.Paper)
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Shoulder("L")
            Row(
                Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
            ) {
                cocoonTabs.forEach { tab ->
                    val on = vm.tab == tab
                    val shape = RoundedCornerShape(15.dp)
                    Box(
                        Modifier
                            .cocoonFocus(shape)
                            .height(30.dp)
                            .clip(shape)
                            .background(if (on) Mix.Tape else GlassFill, shape)
                            .border(1.dp, if (on) Mix.Tape else GlassLine, shape)
                            .clickable { vm.tab = tab }
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            tabLabel(tab),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (on) Mix.Ink else Mix.Paper.copy(alpha = 0.8f),
                            maxLines = 1,
                        )
                    }
                }
            }
            Shoulder("R")
        }
    }
}

private fun tabLabel(tab: HomeTab) = when (tab) {
    HomeTab.Songs -> "songs"
    HomeTab.Playlists -> "playlists"
    HomeTab.Download -> "downloads"
    HomeTab.Settings -> "settings"
}

/** The Mixtape cassette, drawn small. */
@Composable
private fun CassetteMark() {
    val c = Mix.Paper
    Canvas(Modifier.size(22.dp, 15.dp)) {
        val s = 1.dp.toPx()
        drawRoundRect(c, size = Size(size.width, size.height), cornerRadius = CornerRadius(3 * s), style = Stroke(width = s))
        drawCircle(c, radius = 2.2f * s, center = Offset(size.width * 0.3f, size.height * 0.42f))
        drawCircle(c, radius = 2.2f * s, center = Offset(size.width * 0.7f, size.height * 0.42f))
        val p = Path().apply {
            moveTo(size.width * 0.2f, size.height)
            lineTo(size.width * 0.3f, size.height * 0.75f)
            lineTo(size.width * 0.7f, size.height * 0.75f)
            lineTo(size.width * 0.8f, size.height)
        }
        drawPath(p, c, style = Stroke(width = s))
    }
}

/** What the console buttons do here, at the bottom of the screen. */
@Composable
fun CocoonHintBar(vm: MainViewModel, screen: Screen) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .height(30.dp)
            .glass(RoundedCornerShape(15.dp))
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (now.mediaId != null) now.title else "Mixtape",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = Mix.Paper,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(1f)
                .clickable(enabled = now.mediaId != null) { vm.push(Screen.NowPlaying) },
        )
        Spacer(Modifier.width(8.dp))
        Hint("A", "open")
        if (screen != Screen.Home) Hint("B", "back")
        Hint("X", if (ConsoleKeys.onX != null) ConsoleKeys.xLabel else if (now.isPlaying) "pause" else "play")
        if (now.mediaId != null) Hint("Y", "player")
    }
}

@Composable
private fun Hint(letter: String, label: String) {
    Row(Modifier.padding(start = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Glyph(letter)
        Spacer(Modifier.width(3.dp))
        Text(label, fontSize = 10.sp, color = Mix.Paper.copy(alpha = 0.8f), maxLines = 1)
    }
}

private fun batteryLevel(context: Context): Int? = runCatching {
    context.getSystemService(BatteryManager::class.java)?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}.getOrNull()?.takeIf { it in 0..100 }

// ---------------------------------------------------------------- home: the tile grid

/**
 * Playlists tab in Cocoon style: what's playing as a wide tile, then your playlists, albums and
 * smart playlists as square tiles, like games on a console home screen.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CocoonHome(
    vm: MainViewModel,
    playlists: List<SavedPlaylist>,
    spotifyAlbums: List<SavedPlaylist>,
    albums: List<LocalAlbum>,
    query: String,
    onQuery: (String) -> Unit,
    onNewPlaylist: () -> Unit,
) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cols = maxOf(4, (maxWidth / 100.dp).toInt())
        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (now.mediaId != null && query.isBlank()) {
                item(key = "now", span = { GridItemSpan(maxLineSpan) }) { NowTile(vm) }
            }
            item(key = "search", span = { GridItemSpan(maxLineSpan) }) {
                CompactSearchField(
                    value = query,
                    onValueChange = onQuery,
                    placeholder = "Search playlists and albums",
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            items(playlists, key = { it.id }) { p ->
                val rows = vm.rows[p.id]
                val missing = rows?.let { r -> p.tracks.size - r.count { it.local != null } } ?: 0
                HoldWrap(vm, "pl:" + p.id, p.id, null) { hold ->
                    CocoonTile(
                        title = p.name,
                        model = p.imageUrl,
                        fallback = if (p.id == LIKED_ID) Icons.Filled.Favorite else Icons.Filled.MusicNote,
                        badge = missing.takeIf { it > 0 },
                        onHold = hold,
                    ) { vm.push(Screen.Playlist(p.id)) }
                }
            }
            if (query.isBlank()) {
                item(key = "import", span = { GridItemSpan(2) }) {
                    ActionTile(Icons.Filled.Add, "Import from Spotify", "paste a playlist link", vm::openImport)
                }
                item(key = "new", span = { GridItemSpan(2) }) {
                    ActionTile(Icons.Filled.CreateNewFolder, "New playlist", "pick songs yourself", onNewPlaylist)
                }
            }
            if (spotifyAlbums.isNotEmpty() || albums.isNotEmpty()) {
                item(key = "albums-title", span = { GridItemSpan(maxLineSpan) }) { TileHeader("albums") }
                items(spotifyAlbums, key = { "s:" + it.id }) { p ->
                    HoldWrap(vm, "pl:" + p.id, p.id, null) { hold ->
                        CocoonTile(p.name, p.imageUrl, Icons.Filled.Album, null, hold) { vm.push(Screen.Playlist(p.id)) }
                    }
                }
                items(albums, key = { "l:" + it.folder }) { a ->
                    HoldWrap(vm, "al:" + a.folder, null, a.folder) { hold ->
                        CocoonTile(a.name, a.tracks.first().artUri, Icons.Filled.Album, null, hold) { vm.push(Screen.Album(a.folder)) }
                    }
                }
            }
            if (query.isBlank()) {
                item(key = "smart-title", span = { GridItemSpan(maxLineSpan) }) { TileHeader("smart playlists") }
                items(SmartKind.entries, key = { "smart:" + it.name }) { kind ->
                    SmartTile(kind) { vm.push(Screen.Smart(kind)) }
                }
            }
        }
    }
}

@Composable
private fun TileHeader(text: String) {
    Text(
        text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Mix.Fog,
        modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 2.dp),
    )
}

/** What's playing, as a wide tile at the top. Opens the player. */
@Composable
private fun NowTile(vm: MainViewModel) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    val track = vm.trackById(now.mediaId)
    val shape = RoundedCornerShape(18.dp)
    Row(
        Modifier
            .cocoonFocus(shape)
            .fillMaxWidth()
            .height(96.dp)
            .glass(shape)
            .clickable { vm.push(Screen.NowPlaying) }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(track?.artUri ?: now.artworkUri, Modifier.size(76.dp), corner = 12.dp, iconSize = 28.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).background(Mix.Tape, CircleShape))
                Spacer(Modifier.width(5.dp))
                Text("now playing", fontSize = 10.sp, color = Mix.Fog)
            }
            Text(now.title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                now.artist + " · " + formatTime(now.positionMs) + " / " + formatTime(now.durationMs),
                fontSize = 11.sp,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(6.dp))
            val frac = if (now.durationMs > 0) (now.positionMs.toFloat() / now.durationMs).coerceIn(0f, 1f) else 0f
            Box(Modifier.fillMaxWidth().height(3.dp).background(Mix.Paper.copy(alpha = 0.2f), RoundedCornerShape(2.dp))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Mix.Tape, RoundedCornerShape(2.dp)))
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Mix.Tape, CircleShape)
                .clickable(onClick = vm.player::toggle),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (now.isPlaying) "Pause" else "Play",
                tint = Mix.Ink,
            )
        }
    }
}

/** A square tile: cover, name on a glass strip, and a red count of songs not downloaded yet. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CocoonTile(
    title: String,
    model: Any?,
    fallback: ImageVector,
    badge: Int?,
    onHold: (() -> Unit)?,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        Modifier
            .cocoonFocus(shape)
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(shape)
            .semantics { contentDescription = title }
            .combinedClickable(onClick = onClick, onLongClick = onHold),
    ) {
        Artwork(model, Modifier.fillMaxSize(), corner = 0.dp, fallback = fallback, iconSize = 28.dp)
        if (badge != null) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .heightIn(min = 18.dp)
                    .background(Mix.Alert, RoundedCornerShape(9.dp))
                    .padding(horizontal = 5.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("$badge", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
        // Just the cover, like a game on a console home screen. Without a cover, the name instead.
        if (model == null) {
            Text(
                title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Mix.Paper,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 8.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun SmartTile(kind: SmartKind, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .cocoonFocus(shape)
            .fillMaxWidth()
            .aspectRatio(1f)
            .glass(shape)
            .clickable(onClick = onClick)
            .padding(8.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Icon(
            when (kind) {
                SmartKind.MOST_PLAYED -> Icons.Filled.Whatshot
                SmartKind.RECENTLY_ADDED -> Icons.Filled.NewReleases
                SmartKind.FORGOTTEN -> Icons.Filled.History
                SmartKind.NEVER_PLAYED -> Icons.Filled.FiberNew
            },
            contentDescription = null,
            tint = Mix.Tape,
            modifier = Modifier.size(22.dp),
        )
        Text(kind.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Mix.Paper, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ActionTile(icon: ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .cocoonFocus(shape)
            .fillMaxWidth()
            .height(64.dp)
            .glass(shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(32.dp)
                .background(Mix.Paper.copy(alpha = 0.10f), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = null, tint = Mix.Paper, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, fontSize = 10.sp, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// ---------------------------------------------------------------- album / playlist header

/** Big cover, title and the Play (A) / Shuffle (X) buttons, for albums and playlists. */
@Composable
fun CocoonHero(
    model: Any?,
    fallback: ImageVector,
    chip: String,
    title: String,
    subtitle: String,
    info: String,
    enabled: Boolean,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
    onMore: (() -> Unit)? = null,
    modifier: Modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
) {
    if (enabled) ConsoleX("shuffle", onShuffle)
    Row(
        modifier
            .fillMaxWidth()
            .height(124.dp),
    ) {
        Artwork(model, Modifier.size(124.dp), corner = 18.dp, fallback = fallback, iconSize = 44.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Text(
                chip.uppercase(),
                fontSize = 9.sp,
                letterSpacing = 1.sp,
                color = Mix.Paper,
                modifier = Modifier
                    .glass(RoundedCornerShape(8.dp))
                    .padding(horizontal = 7.dp, vertical = 2.dp),
            )
            Spacer(Modifier.height(4.dp))
            Text(title, fontSize = 22.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, color = Mix.Paper, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (subtitle.isNotBlank()) {
                Text(subtitle, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(info, fontSize = 10.sp, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                PillButton("A", "Play", primary = true, enabled = enabled, onClick = onPlay)
                PillButton("X", "Shuffle", primary = false, enabled = enabled, onClick = onShuffle)
                if (onMore != null) {
                    val shape = CircleShape
                    Box(
                        Modifier
                            .cocoonFocus(shape)
                            .size(32.dp)
                            .glass(shape)
                            .clickable(onClick = onMore),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Filled.MoreHoriz, contentDescription = "More options", tint = Mix.Paper, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PillButton(letter: String, label: String, primary: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .cocoonFocus(shape)
            .height(32.dp)
            .clip(shape)
            .background(if (primary) Mix.Tape else GlassFill, shape)
            .border(1.dp, if (primary) Mix.Tape else GlassLine, shape)
            .graphicsLayer { alpha = if (enabled) 1f else 0.4f }
            .clickable(enabled = enabled, onClick = onClick)
            .padding(start = 7.dp, end = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Glyph(letter, inverted = primary)
        Spacer(Modifier.width(6.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = if (primary) Mix.Ink else Mix.Paper)
    }
}

// ---------------------------------------------------------------- settings: sections on the left

/** Settings sections down the left side (Cocoon style). */
@Composable
fun CocoonRail(sections: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    Column(
        Modifier
            .width(112.dp)
            .padding(start = 12.dp, top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        sections.forEach { (key, label) ->
            val on = key == selected
            val shape = RoundedCornerShape(15.dp)
            Box(
                Modifier
                    .cocoonFocus(shape)
                    .fillMaxWidth()
                    .height(30.dp)
                    .clip(shape)
                    .background(if (on) Mix.Paper.copy(alpha = 0.16f) else Color.Transparent, shape)
                    .border(1.dp, if (on) Mix.Paper.copy(alpha = 0.22f) else Color.Transparent, shape)
                    .clickable { onSelect(key) }
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (on) Mix.Paper else Mix.Paper.copy(alpha = 0.75f),
                    maxLines = 1,
                )
            }
        }
    }
}
