package dev.mixtape.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mixtape.player.update.Updater
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope

/** Downloads and installs [r]; first asks Android for permission to install if needed. */
private fun startUpdate(vm: MainViewModel, context: android.content.Context, scope: kotlinx.coroutines.CoroutineScope, r: Updater.Release, askPermission: () -> Unit) {
    if (!Updater.canInstall(context)) {
        askPermission()
        return
    }
    // Runs in the app's own scope, not the screen's: leaving or redrawing Settings mid-download
    // used to cancel it ("The coroutine scope left the composition").
    val app = context.applicationContext
    vm.viewModelScope.launch {
        Updater.downloadAndInstall(app, r)?.let { vm.showMessage(it) }
    }
}

/** "Allow Mixtape to install updates": explains, then opens Android's switch for it. */
@Composable
private fun InstallPermissionDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Ui.head("allow updates")) },
        text = {
            Text(
                "Android needs your OK once before Mixtape can install its own updates. " +
                    "Turn on \"Allow from this source\" for Mixtape, come back, and tap update again.",
            )
        },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                Updater.openInstallPermission(context)
            }) { Text("Open settings", color = Mix.Tape) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

/**
 * Checks once a day when the app opens. A new version is shown once (here or as a phone
 * notification, whichever comes first); after that it's only in Settings → updates.
 */
@Composable
fun UpdatePopup(vm: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { Updater.check(context) }
    var showing by remember { mutableStateOf<String?>(null) }
    var askPermission by remember { mutableStateOf(false) }
    val r = Updater.latest
    LaunchedEffect(r?.version) {
        if (r != null && Updater.hasUpdate(context) && !Updater.alreadyTold(context, r.version)) {
            showing = r.version
            Updater.markTold(context, r.version)
        }
    }
    if (askPermission) InstallPermissionDialog { askPermission = false }
    if (r == null || showing != r.version) return
    AlertDialog(
        onDismissRequest = { showing = null },
        title = { Text(Ui.head("mixtape v${r.version} is out")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("You have v${Updater.currentVersion(context)}. Your playlists and settings stay.", color = Mix.Fog)
                if (r.notes.isNotBlank()) {
                    Text(
                        r.notes,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .heightIn(max = 220.dp)
                            .verticalScroll(rememberScrollState()),
                    )
                }
                Updater.progress?.let { p ->
                    LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth(), color = Mix.Tape, trackColor = Mix.Gap)
                }
                Text("Later? It's always in Settings → updates.", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
            }
        },
        confirmButton = {
            TextButton(
                enabled = Updater.progress == null,
                onClick = { startUpdate(vm, context, scope, r) { askPermission = true } },
            ) { Text(if (Updater.progress != null) "Downloading…" else "Update", color = Mix.Tape) }
        },
        dismissButton = {
            TextButton(onClick = { showing = null }) { Text("Later", color = Mix.Paper) }
        },
        containerColor = Mix.Deep,
    )
}

/** Settings → updates. */
@Composable
fun UpdateSettings(vm: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var askPermission by remember { mutableStateOf(false) }
    if (askPermission) InstallPermissionDialog { askPermission = false }
    val r = Updater.latest
    val newer = r != null && Updater.hasUpdate(context)
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (newer) "v${r?.version} is out" else "Mixtape v${Updater.currentVersion(context)}",
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (newer) Mix.Tape else Mix.Paper,
                )
                Text(
                    when {
                        Updater.checking -> "checking…"
                        newer -> "You have v${Updater.currentVersion(context)}. Playlists and settings stay."
                        else -> Updater.status ?: "Checks GitHub once a day"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                )
            }
            Spacer(Modifier.width(12.dp))
            OutlinedButton(
                enabled = !Updater.checking && Updater.progress == null,
                onClick = {
                    if (newer && r != null) {
                        startUpdate(vm, context, scope, r) { askPermission = true }
                    } else {
                        scope.launch { Updater.check(context, force = true) }
                    }
                },
                shape = TermShape,
                border = BorderStroke(1.dp, Mix.Gap),
            ) { Text(Ui.btn(if (newer) "update" else "check"), color = Mix.Tape) }
        }
        Updater.progress?.let { p ->
            LinearProgressIndicator(
                progress = { p },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                color = Mix.Tape,
                trackColor = Mix.Gap,
            )
        }
        if (newer && r != null && r.notes.isNotBlank()) {
            Text(
                r.notes,
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                maxLines = 8,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
        }
    }
}
