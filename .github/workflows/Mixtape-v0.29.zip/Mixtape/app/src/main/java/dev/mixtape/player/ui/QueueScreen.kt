package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueScreen(vm: MainViewModel) {
    val queue by vm.player.queue.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("queue"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            actions = {
                if (queue.size > 1) {
                    TextButton(onClick = vm.player::clearQueue) { Text(Ui.btn("clear"), color = Mix.Alert) }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        if (queue.isEmpty()) {
            EmptyState(title = "Nothing in the queue", body = "Play a song, or hold songs in the Songs tab to add them.")
        } else {
            Text(
                "${queue.size - 1} up next · tap a song to jump to it",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
            val listState = rememberLazyListState()
            Box(Modifier.fillMaxSize()) {
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                    itemsIndexed(queue, key = { _, e -> e.index.toString() + ":" + e.mediaId }) { i, e ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(if (e.current) Mix.Raised else Mix.Ink)
                                .clickable { vm.player.jumpTo(e.index) }
                                .padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (e.current) ">" else "$i",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (e.current) Mix.Tape else Mix.Fog,
                                modifier = Modifier.width(36.dp),
                            )
                            Column(Modifier.weight(1f)) {
                                Text(
                                    e.title.ifEmpty { "Unknown song" },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (e.current) Mix.Tape else Mix.Paper,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(e.artist, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
                            }
                            if (!e.current) {
                                IconButton(onClick = { vm.player.removeFromQueue(e.index) }) {
                                    Icon(Icons.Filled.Close, contentDescription = "Remove from queue", tint = Mix.Fog)
                                }
                            }
                        }
                    }
                }
                FastScrollbar(listState, Modifier.align(Alignment.CenterEnd))
            }
        }
    }
}
