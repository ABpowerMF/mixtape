package dev.mixtape.player.playback

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ln

/** Equaliser settings. Band gains are in dB for [AudioFx.FREQS]. */
data class FxSettings(
    val enabled: Boolean = false,
    val preset: String = "Flat",
    val bands: List<Float> = List(AudioFx.FREQS.size) { 0f },
    /** Bass / depth, 0–1000. */
    val bass: Int = 0,
    /** Surround / width, 0–1000. */
    val surround: Int = 0,
    /** Volume boost in dB, 0–10. */
    val boost: Float = 0f,
)

/**
 * The equaliser, bass, surround and volume boost, using Android's built-in audio effects on the
 * player's audio. Settings are kept even when nothing is playing and applied when playback starts.
 */
object AudioFx {

    /** Five bands, like most Android equalisers: 60 Hz, 230 Hz, 910 Hz, 3.6 kHz, 14 kHz. */
    val FREQS = intArrayOf(60, 230, 910, 3_600, 14_000)
    const val MAX_DB = 12f

    val PRESETS: List<Pair<String, List<Float>>> = listOf(
        "Flat" to listOf(0f, 0f, 0f, 0f, 0f),
        "Bass boost" to listOf(6f, 4f, 0f, 0f, 0f),
        "Bass cut" to listOf(-6f, -3f, 0f, 0f, 0f),
        "Treble boost" to listOf(0f, 0f, 0f, 3f, 6f),
        "Vocal" to listOf(-2f, 0f, 3f, 3f, 1f),
        "Pop" to listOf(-1f, 2f, 4f, 2f, -1f),
        "Rock" to listOf(5f, 3f, -1f, 2f, 4f),
        "Hip-hop" to listOf(5f, 4f, 0f, 1f, 2f),
        "Electronic" to listOf(5f, 2f, 0f, 2f, 5f),
        "Jazz" to listOf(3f, 1f, -1f, 2f, 3f),
        "Classical" to listOf(4f, 2f, -1f, 2f, 4f),
        "Acoustic" to listOf(3f, 1f, 1f, 2f, 2f),
        "Loudness" to listOf(5f, 1f, -1f, 1f, 4f),
    )

    var settings by mutableStateOf(FxSettings())
        private set

    private var sessionId = 0
    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null
    private var loaded = false

    private fun prefs(context: Context) = context.getSharedPreferences("audiofx", Context.MODE_PRIVATE)

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val raw = prefs(context).getString("settings", null) ?: return
        runCatching {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("bands") ?: JSONArray()
            settings = FxSettings(
                enabled = o.optBoolean("enabled"),
                preset = o.optString("preset", "Flat"),
                bands = List(FREQS.size) { i -> arr.optDouble(i, 0.0).toFloat() },
                bass = o.optInt("bass"),
                surround = o.optInt("surround"),
                boost = o.optDouble("boost", 0.0).toFloat(),
            )
        }
    }

    fun update(context: Context, new: FxSettings) {
        settings = new
        val o = JSONObject()
            .put("enabled", new.enabled)
            .put("preset", new.preset)
            .put("bands", JSONArray(new.bands.map { it.toDouble() }))
            .put("bass", new.bass)
            .put("surround", new.surround)
            .put("boost", new.boost.toDouble())
        prefs(context).edit().putString("settings", o.toString()).apply()
        apply()
    }

    /** Called by the playback service with the player's audio session. */
    @Synchronized
    fun attach(audioSessionId: Int) {
        if (audioSessionId == sessionId && eq != null) return
        release()
        if (audioSessionId <= 0) return
        sessionId = audioSessionId
        eq = runCatching { Equalizer(0, audioSessionId) }.getOrNull()
        bassBoost = runCatching { BassBoost(0, audioSessionId) }.getOrNull()
        virtualizer = runCatching { Virtualizer(0, audioSessionId) }.getOrNull()
        loudness = runCatching { LoudnessEnhancer(audioSessionId) }.getOrNull()
        apply()
    }

    @Synchronized
    fun release() {
        listOfNotNull(eq, bassBoost, virtualizer, loudness).forEach { runCatching { it.release() } }
        eq = null
        bassBoost = null
        virtualizer = null
        loudness = null
        sessionId = 0
    }

    @Synchronized
    private fun apply() {
        val s = settings
        eq?.let { e ->
            runCatching {
                val range = e.bandLevelRange // millibels, e.g. -1500..1500
                for (b in 0 until e.numberOfBands) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    val db = if (s.enabled) gainAt(s.bands, hz) else 0f
                    val mb = (db * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
                e.enabled = s.enabled
            }
        }
        bassBoost?.let { b ->
            runCatching {
                if (b.strengthSupported) b.setStrength(s.bass.coerceIn(0, 1000).toShort())
                b.enabled = s.enabled && s.bass > 0
            }
        }
        virtualizer?.let { v ->
            runCatching {
                if (v.strengthSupported) v.setStrength(s.surround.coerceIn(0, 1000).toShort())
                v.enabled = s.enabled && s.surround > 0
            }
        }
        loudness?.let { l ->
            runCatching {
                l.setTargetGain((s.boost.coerceIn(0f, 10f) * 100).toInt())
                l.enabled = s.enabled && s.boost > 0f
            }
        }
    }

    /** Gain at [hz], interpolated between our bands on a log-frequency scale. */
    fun gainAt(bands: List<Float>, hz: Float): Float {
        if (hz <= FREQS.first()) return bands.first()
        if (hz >= FREQS.last()) return bands.last()
        for (i in 0 until FREQS.lastIndex) {
            val lo = FREQS[i].toFloat()
            val hi = FREQS[i + 1].toFloat()
            if (hz in lo..hi) {
                val t = ((ln(hz) - ln(lo)) / (ln(hi) - ln(lo)))
                return bands[i] + (bands[i + 1] - bands[i]) * t
            }
        }
        return 0f
    }
}
