package dev.mixtape.player.ui

import androidx.compose.ui.graphics.toArgb
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import dev.mixtape.player.download.YouTubeCookies
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.download.MediaSaver
import dev.mixtape.player.ui.theme.Appearance
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Palette
import dev.mixtape.player.ui.theme.Swatches
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.ThemePreset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val version = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName
    }.getOrNull().orEmpty()

    LaunchedEffect(Unit) { vm.refreshStats() }
    var youTubeSignedIn by remember { mutableStateOf(YouTubeCookies.isSignedIn(context)) }
    val youTubeLogin = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        youTubeSignedIn = YouTubeCookies.isSignedIn(context)
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("~/settings", style = MaterialTheme.typography.titleLarge) },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            // ---------- Stats ----------
            item { Section("stats") }
            item {
                Column {
                    SettingRow(
                        "Listening time: ${formatListened(vm.stats.sumOf { it.listenedMs })}",
                        vm.stats.filter { it.listenedMs > 0 }.maxByOrNull { it.listenedMs }
                            ?.let { "Most listened: ${it.title.ifEmpty { "Unknown song" }}" }
                            ?: "Your most listened songs and artists",
                    ) {
                        OutlinedButton(
                            onClick = { vm.push(Screen.Stats) },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text("[ open ]", color = Mix.Tape) }
                    }
                }
            }

            // ---------- Look ----------
            item { Section("theme") }
            item {
                Column {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(ThemePreset.entries) { preset ->
                            ThemeTile(
                                label = preset.label,
                                palette = preset.palette ?: Appearance.custom,
                                selected = Appearance.preset == preset,
                                onClick = { Appearance.choose(context, preset) },
                            )
                        }
                    }
                }
            }
            item { Section("custom colours") }
            item {
                Column {
                    SwatchRow("accent", Appearance.custom.tape) { Appearance.setCustom(context, accent = it) }
                    SwatchRow("background", Appearance.custom.ink) { Appearance.setCustom(context, background = it) }
                    SwatchRow("text", Appearance.custom.paper) { Appearance.setCustom(context, text = it) }
                    Text(
                        "Picking a colour switches to the Custom theme.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    )
                }
            }
            item { Section("font") }
            item {
                Column {
                    Choice("Monospace (terminal)", selected = Mix.mono) { Appearance.setMonoFont(context, true) }
                    Choice("Clean (Barlow)", selected = !Mix.mono) { Appearance.setMonoFont(context, false) }
                }
            }

            // ---------- Downloads ----------
            item { Section("downloads") }
            item {
                Column {
                    SettingRow("Default quality", "Used for new downloads and Download missing") {}
                    QualityPicker(
                        vm.quality,
                        vm::chooseQuality,
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    SettingRow("Songs at the same time", "More is faster but uses more battery and data") {}
                    Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (1..4).forEach { n ->
                            val on = vm.parallelDownloads == n
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .background(if (on) Mix.Tape else Mix.Raised, TermShape)
                                    .clickable { vm.chooseParallelDownloads(n) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("$n", color = if (on) Mix.Ink else Mix.Paper, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    SettingRow("Downloader", "Updates itself once a day. Update now if downloads start failing.") {}
                    OutlinedButton(
                        onClick = DownloadQueue::updateNow,
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                        modifier = Modifier.padding(horizontal = 20.dp),
                    ) { Text("[ update now ]", color = Mix.Tape) }
                    SettingRow(
                        "YouTube account",
                        if (youTubeSignedIn) "Signed in. Fixes \"not a bot\" and age errors."
                        else "Optional. Fixes \"Sign in to confirm\" errors. A spare account is safest.",
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (youTubeSignedIn) {
                                    YouTubeCookies.signOut(context)
                                    youTubeSignedIn = false
                                } else {
                                    youTubeLogin.launch(Intent(context, YouTubeLoginActivity::class.java))
                                }
                            },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(if (youTubeSignedIn) "[ sign out ]" else "[ sign in ]", color = Mix.Tape) }
                    }
                    Text(
                        "Songs are saved to ${MediaSaver.FOLDER}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    )
                }
            }

            // ---------- Library ----------
            item { Section("music folders") }
            item {
                Column {
                    LibraryScope.entries.forEach { scope ->
                        Choice(scope.label + " · " + scope.note, selected = vm.libraryScope == scope) {
                            vm.chooseLibraryScope(scope)
                        }
                    }
                }
            }

            // ---------- Player & library ----------
            item { Section("player") }
            item {
                Column {
                    SettingRow("Swipe to change songs", "On the mini player: left = next, right = previous") {
                        Switch(
                            checked = vm.swipeToSkip,
                            onCheckedChange = vm::chooseSwipeToSkip,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Mix.Ink,
                                checkedTrackColor = Mix.Tape,
                                uncheckedThumbColor = Mix.Fog,
                                uncheckedTrackColor = Mix.Raised,
                                uncheckedBorderColor = Mix.Gap,
                            ),
                        )
                    }
                    SettingRow("Sideways clock mode", "Turn the phone sideways: big clock, date and what's playing. Screen stays on.") {
                    Switch(
                        checked = vm.dockMode,
                        onCheckedChange = vm::chooseDockMode,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Mix.Ink,
                            checkedTrackColor = Mix.Tape,
                            uncheckedThumbColor = Mix.Fog,
                            uncheckedTrackColor = Mix.Raised,
                            uncheckedBorderColor = Mix.Gap,
                        ),
                    )
                }
                SettingRow("Equaliser", "Presets, 5 bands, bass, surround and volume boost") {
                    OutlinedButton(
                        onClick = { vm.push(Screen.Equalizer) },
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                    ) { Text("[ open ]", color = Mix.Tape) }
                }
                SettingRow("Find lyrics online", "Looks each song up once on LRCLIB, then keeps them offline") {
                    Switch(
                        checked = vm.lyricsOnline,
                        onCheckedChange = vm::chooseLyricsOnline,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Mix.Ink,
                            checkedTrackColor = Mix.Tape,
                            uncheckedThumbColor = Mix.Fog,
                            uncheckedTrackColor = Mix.Raised,
                            uncheckedBorderColor = Mix.Gap,
                        ),
                    )
                }
                SettingRow("Rescan music", "Find songs you copied to the phone") {
                        OutlinedButton(
                            onClick = vm::rescanMusic,
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text("[ scan ]", color = Mix.Tape) }
                    }
                }
            }

            item { Section("about") }
            item {
                Column {
                    Text(
                        "mixtape v$version",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        "> $title",
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp),
    )
}

@Composable
private fun SettingRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        (if (selected) "(•) " else "( ) ") + label,
        style = MaterialTheme.typography.bodyLarge,
        color = if (selected) Mix.Tape else Mix.Paper,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
    )
}

/** A small preview of a theme: its background, text and accent. */
@Composable
private fun ThemeTile(label: String, palette: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(104.dp)
            .clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(72.dp)
                .background(palette.ink, TermShape)
                .border(if (selected) 2.dp else 1.dp, if (selected) Mix.Tape else Mix.Gap, TermShape)
                .padding(8.dp),
        ) {
            Column {
                Text("> play", color = palette.paper, style = MaterialTheme.typography.bodySmall)
                Text("  track", color = palette.fog, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .width(48.dp)
                        .height(6.dp)
                        .background(palette.tape),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = if (selected) Mix.Tape else Mix.Fog,
            maxLines = 1,
        )
    }
}

@Composable
private fun SwatchRow(label: String, current: Color, onPick: (Color) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Paper,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(Modifier.height(6.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(Swatches) { color ->
                val on = color == current
                Box(
                    Modifier
                        .size(34.dp)
                        .background(color, TermShape)
                        .border(if (on) 3.dp else 1.dp, if (on) Mix.Tape else Mix.Gap, TermShape)
                        .clickable { onPick(color) },
                )
            }
            // Any colour: opens the colour picker.
            item {
                var picking by remember { mutableStateOf(false) }
                Box(
                    Modifier
                        .size(34.dp)
                        .background(Mix.Raised, TermShape)
                        .border(1.dp, Mix.Gap, TermShape)
                        .clickable { picking = true },
                    contentAlignment = Alignment.Center,
                ) { Text("+", color = Mix.Tape, style = MaterialTheme.typography.titleMedium) }
                if (picking) {
                    ColorPickerDialog(
                        initial = current,
                        onDismiss = { picking = false },
                        onPick = {
                            picking = false
                            onPick(it)
                        },
                    )
                }
            }
        }
    }
}

/** Pick any colour: hue, saturation and brightness sliders, or type a hex code. */
@Composable
private fun ColorPickerDialog(initial: Color, onDismiss: () -> Unit, onPick: (Color) -> Unit) {
    val start = remember {
        FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toArgb(), it) }
    }
    var hue by remember { mutableStateOf(start[0]) }
    var sat by remember { mutableStateOf(start[1]) }
    var value by remember { mutableStateOf(start[2]) }
    val color = Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
    var hex by remember { mutableStateOf(String.format("%06X", initial.toArgb() and 0xFFFFFF)) }

    fun setFromHex(text: String) {
        hex = text.uppercase().filter { it.isLetterOrDigit() }.take(6)
        if (hex.length == 6) {
            val argb = hex.toLongOrNull(16)?.toInt() ?: return
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(argb or 0xFF000000.toInt(), hsv)
            hue = hsv[0]; sat = hsv[1]; value = hsv[2]
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("> pick a colour") },
        text = {
            Column {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .background(color, TermShape)
                        .border(1.dp, Mix.Gap, TermShape),
                )
                Spacer(Modifier.height(12.dp))
                Text("hue", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                Slider(
                    value = hue,
                    onValueChange = { hue = it; hex = String.format("%06X", Color.hsv(it, sat, value).toArgb() and 0xFFFFFF) },
                    valueRange = 0f..360f,
                    colors = SliderDefaults.colors(thumbColor = Color.hsv(hue, 1f, 1f), activeTrackColor = Color.hsv(hue, 1f, 1f)),
                )
                Text("saturation", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                Slider(
                    value = sat,
                    onValueChange = { sat = it; hex = String.format("%06X", Color.hsv(hue, it, value).toArgb() and 0xFFFFFF) },
                    colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
                )
                Text("brightness", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                Slider(
                    value = value,
                    onValueChange = { value = it; hex = String.format("%06X", Color.hsv(hue, sat, it).toArgb() and 0xFFFFFF) },
                    colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
                )
                OutlinedTextField(
                    value = hex,
                    onValueChange = ::setFromHex,
                    singleLine = true,
                    prefix = { Text("#") },
                    label = { Text("hex") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(color) }) { Text("Use", color = Mix.Tape) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}
