package dev.mixtape.player.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.mixtape.player.Config
import dev.mixtape.player.data.PlaylistRow
import dev.mixtape.player.data.PlaylistStore
import dev.mixtape.player.data.SavedPlaylist
import dev.mixtape.player.data.SpotifyPlaylistSummary
import dev.mixtape.player.data.SpotifyTrack
import dev.mixtape.player.download.AlbumHit
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.playback.ListenStats
import dev.mixtape.player.download.Quality
import dev.mixtape.player.download.SongRequest
import dev.mixtape.player.library.LocalLibrary
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.library.Matcher
import dev.mixtape.player.playback.PlayerConnection
import dev.mixtape.player.spotify.LoopbackReceiver
import dev.mixtape.player.spotify.NotLoggedInException
import dev.mixtape.player.spotify.SpotifyApi
import dev.mixtape.player.spotify.SpotifyAuth
import dev.mixtape.player.spotify.SpotifyException
import dev.mixtape.player.spotify.SpotifyPublic
import dev.mixtape.player.spotify.SpotifyWeb
import dev.mixtape.player.spotify.WebParsing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.BindException
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.coroutines.cancellation.CancellationException

sealed interface Screen {
    data object Home : Screen
    data class Playlist(val id: String) : Screen
    data object Import : Screen
    data object NowPlaying : Screen
    data object Stats : Screen
}

enum class HomeTab { Playlists, Songs, Download, Settings }

/** How a playlist's songs are listed and played. */
enum class SortMode(val label: String) {
    PLAYLIST("Playlist order"),
    TITLE("Title A–Z"),
    ARTIST("Artist A–Z"),
    SHORTEST("Shortest first"),
    LONGEST("Longest first"),
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val context: Application get() = getApplication()
    private val auth = SpotifyAuth(app)
    private val api = SpotifyApi(auth)
    private val store = PlaylistStore(app)
    private val receiver = LoopbackReceiver(Config.REDIRECT_PORT)
    val player = PlayerConnection(app, viewModelScope)

    // Navigation
    val stack = mutableStateListOf<Screen>(Screen.Home)
    var tab by mutableStateOf(HomeTab.Playlists)

    // Music on this phone
    var hasPermission by mutableStateOf(false); private set
    var library by mutableStateOf<List<LocalTrack>>(emptyList()); private set
    var libraryLoaded by mutableStateOf(false); private set
    private var libraryById: Map<Long, LocalTrack> = emptyMap()
    private var matcher = Matcher(emptyList())

    // Imported playlists and how they map onto the files above
    var playlists by mutableStateOf<List<SavedPlaylist>>(emptyList()); private set
    var rows by mutableStateOf<Map<String, List<PlaylistRow>>>(emptyMap()); private set
    private var overrides: Map<String, Long> = emptyMap()

    // Downloads
    private val prefs = app.getSharedPreferences("mixtape", Context.MODE_PRIVATE)
    var quality by mutableStateOf(Quality.fromName(prefs.getString("quality", null))); private set
    /** Text in the link box on the Download tab. */
    var linkDraft by mutableStateOf("")

    // Sorting
    var sortModes by mutableStateOf<Map<String, SortMode>>(emptyMap()); private set

    fun sortModeOf(id: String): SortMode =
        sortModes[id] ?: SortMode.entries.firstOrNull { it.name == prefs.getString("sort:$id", null) } ?: SortMode.PLAYLIST

    fun chooseSort(id: String, mode: SortMode) {
        sortModes = sortModes + (id to mode)
        prefs.edit().putString("sort:$id", mode.name).apply()
    }

    /** The playlist's rows in the chosen order (what the screen shows and what plays). */
    fun sortedRows(id: String): List<PlaylistRow> {
        val list = rows[id].orEmpty()
        fun length(r: PlaylistRow) = r.local?.durationMs?.takeIf { it > 0 } ?: r.track.durationMs
        return when (sortModeOf(id)) {
            SortMode.PLAYLIST -> list
            SortMode.TITLE -> list.sortedBy { it.track.title.lowercase() }
            SortMode.ARTIST -> list.sortedWith(compareBy({ it.track.artists.firstOrNull().orEmpty().lowercase() }, { it.track.title.lowercase() }))
            SortMode.SHORTEST -> list.sortedBy { length(it) }
            SortMode.LONGEST -> list.sortedByDescending { length(it) }
        }
    }

    /** Moves a song within the playlist's own order (Edit order). */
    fun moveTrack(id: String, from: Int, to: Int) {
        val p = playlists.find { it.id == id } ?: return
        if (from !in p.tracks.indices || to !in p.tracks.indices || from == to) return
        val tracks = p.tracks.toMutableList().apply { add(to, removeAt(from)) }
        upsert(p.copy(tracks = tracks))
        rows[id]?.let { r ->
            if (from in r.indices && to in r.indices) {
                rows = rows + (id to r.toMutableList().apply { add(to, removeAt(from)) })
            }
        }
        viewModelScope.launch { persist() }
    }

    // Stats
    var stats by mutableStateOf<List<ListenStats.Entry>>(emptyList()); private set
    var statsSince by mutableStateOf(0L); private set

    fun refreshStats() {
        ListenStats.init(context)
        stats = ListenStats.snapshot()
        statsSince = ListenStats.trackingSince()
    }

    fun resetStats() {
        ListenStats.reset()
        refreshStats()
    }

    // Spotify account (optional)
    var spotifyClientId by mutableStateOf(
        prefs.getString("spotifyClientId", null)
            ?: Config.SPOTIFY_CLIENT_ID.takeUnless { it.startsWith("PASTE") }.orEmpty(),
    ); private set

    fun chooseClientId(id: String) {
        spotifyClientId = id.trim()
        Config.clientId = spotifyClientId
        prefs.edit().putString("spotifyClientId", spotifyClientId).apply()
    }

    /** A Spotify playlist/album shared to Mixtape: the app asks whether to import or download it. */
    var sharedSpotify by mutableStateOf<String?>(null)

    fun importShared() {
        val link = sharedSpotify ?: return
        sharedSpotify = null
        tab = HomeTab.Playlists
        importFromLink(link)
    }

    fun downloadShared() {
        val link = sharedSpotify ?: return
        sharedSpotify = null
        tab = HomeTab.Download
        DownloadQueue.addLink(link, quality)
    }

    // Settings
    var swipeToSkip by mutableStateOf(prefs.getBoolean("swipeToSkip", true)); private set
    var parallelDownloads by mutableStateOf(prefs.getInt("parallel", 3).coerceIn(1, 4)); private set

    fun chooseSwipeToSkip(on: Boolean) {
        swipeToSkip = on
        prefs.edit().putBoolean("swipeToSkip", on).apply()
    }

    fun chooseParallelDownloads(count: Int) {
        parallelDownloads = count.coerceIn(1, 4)
        prefs.edit().putInt("parallel", parallelDownloads).apply()
        DownloadQueue.setParallel(parallelDownloads)
    }

    /** Looks for music files again (e.g. after copying songs to the phone). */
    fun rescanMusic() {
        scanLibrary()
        errorText = "Looking for music files…"
    }

    // Spotify
    var loggedIn by mutableStateOf(auth.isLoggedIn); private set
    var waitingForLogin by mutableStateOf(false); private set
    var remote by mutableStateOf<List<SpotifyPlaylistSummary>?>(null); private set

    /** Progress text while something is loading, or null. */
    var busy by mutableStateOf<String?>(null); private set
    /** Message for the snackbar, or null. */
    var errorText by mutableStateOf<String?>(null)

    private var scanJob: Job? = null
    private var rescanJob: Job? = null
    private var rematchJob: Job? = null
    private var loginJob: Job? = null
    private var loginServer: ServerSocket? = null

    /** Rescans when music files are added or removed while the app is open. */
    private val mediaObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            if (!hasPermission) return
            rescanJob?.cancel()
            rescanJob = viewModelScope.launch {
                delay(1500)
                scanLibrary()
            }
        }
    }

    init {
        DownloadQueue.init(app)
        Config.clientId = spotifyClientId
        SpotifyWeb.init(app)
        viewModelScope.launch { DownloadQueue.messages.collect { errorText = it } }
        context.contentResolver.registerContentObserver(LocalLibrary.watchUri, true, mediaObserver)
        viewModelScope.launch {
            val data = withContext(Dispatchers.IO) { store.load() }
            playlists = data.playlists
            overrides = data.overrides
            rematch()
        }
    }

    // ---------- Navigation ----------

    fun push(screen: Screen) {
        stack.add(screen)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun openImport() {
        push(Screen.Import)
        if (loggedIn && remote == null && busy == null) loadRemotePlaylists()
    }

    // ---------- Local library ----------

    fun onPermission(granted: Boolean) {
        hasPermission = granted
        if (granted) scanLibrary()
    }

    private fun scanLibrary() {
        if (scanJob?.isActive == true) return
        scanJob = viewModelScope.launch {
            val tracks = withContext(Dispatchers.IO) { LocalLibrary.scan(context) }
            val changed = tracks != library || !libraryLoaded
            libraryLoaded = true
            if (!changed) return@launch
            val newMatcher = withContext(Dispatchers.Default) { Matcher(tracks) }
            library = tracks
            libraryById = tracks.associateBy { it.id }
            matcher = newMatcher
            rematch()
        }
    }

    fun searchLibrary(query: String, limit: Int = 200): List<LocalTrack> = matcher.search(query, limit)

    /** Recomputes which file fills each playlist position. Runs off the main thread. */
    private fun rematch() {
        val lists = playlists
        val manual = overrides
        val m = matcher
        val byId = libraryById
        rematchJob?.cancel()
        rematchJob = viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                lists.associate { p ->
                    p.id to p.tracks.map { t ->
                        val picked = manual[t.id]?.let { byId[it] }
                        PlaylistRow(t, picked ?: m.match(t), manual = picked != null)
                    }
                }
            }
            rows = result
        }
    }

    // ---------- Spotify ----------

    fun connectSpotify() {
        errorText = null
        if (Config.clientId.isBlank()) {
            errorText = "Paste your Client ID first (step 3)."
            return
        }
        // Stop any earlier attempt so its listener frees the port.
        loginJob?.cancel()
        runCatching { loginServer?.close() }
        val request = auth.newRequest()
        waitingForLogin = true
        loginJob = viewModelScope.launch {
            val thisJob = coroutineContext[Job]
            var server: ServerSocket? = null
            try {
                val listener = withContext(Dispatchers.IO) { receiver.open() }
                server = listener
                loginServer = listener
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                val params = receiver.awaitCallback(listener)
                val error = params["error"]
                when {
                    error == "access_denied" -> errorText = "Spotify login was cancelled."
                    error != null -> errorText = "Spotify login failed ($error)."
                    params["state"] != request.state -> errorText = "That login didn't come from this app. Try again."
                    else -> {
                        auth.exchangeCode(params.getValue("code"), request.verifier)
                        loggedIn = true
                        loadRemotePlaylists()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (isActive) handle(e)
            } finally {
                runCatching { server?.close() }
                if (loginJob === thisJob) waitingForLogin = false
            }
        }
    }

    fun logout() {
        auth.logout()
        loggedIn = false
        remote = null
    }

    fun loadRemotePlaylists() = task("Loading your Spotify playlists…") {
        remote = api.libraryPlaylists()
    }

    fun importSelected(ids: Set<String>) {
        val summaries = remote.orEmpty().filter { it.id in ids && it.canImport }
        if (summaries.isEmpty()) return
        task("Importing…") {
            for (s in summaries) {
                busy = "Importing ${s.name}…"
                val tracks = api.playlistTracks(s.id)
                upsert(SavedPlaylist(s.id, s.name, s.imageUrl, tracks, System.currentTimeMillis()))
            }
            persist()
            rematch()
            if (stack.lastOrNull() == Screen.Import) pop()
        }
    }

    /** Pulls the latest song list for one playlist from Spotify. */
    fun resync(id: String) {
        val existing = playlists.find { it.id == id } ?: return
        if (id.startsWith(FILE_PREFIX)) {
            errorText = "This playlist came from a file. Import the file again to update it."
            return
        }
        val public = id.startsWith(ALBUM_PREFIX) || (!loggedIn && id != dev.mixtape.player.data.LIKED_ID)
        if (!public && !loggedIn) {
            errorText = "Connect Spotify first: tap + on the Playlists tab."
            return
        }
        task("Syncing ${existing.name}…") {
            val tracks = if (public) {
                val kind = if (id.startsWith(ALBUM_PREFIX)) "album" else "playlist"
                val r = withContext(Dispatchers.IO) { SpotifyPublic.fetch(kind, id.removePrefix(ALBUM_PREFIX)) }
                r.note?.let { errorText = it }
                r.tracks
            } else {
                api.playlistTracks(id)
            }
            upsert(existing.copy(tracks = tracks, importedAt = System.currentTimeMillis()))
            persist()
            rematch()
        }
    }

    /** Imports a public playlist or album from its Spotify link. No login needed. */
    fun importFromLink(link: String) {
        val parsed = SpotifyPublic.parseLink(link)
        if (parsed == null || parsed.first == "track") {
            errorText = "Paste a Spotify playlist or album link."
            return
        }
        task("Reading playlist…") {
            val r = withContext(Dispatchers.IO) { SpotifyPublic.fetch(parsed.first, parsed.second) }
            val id = if (r.kind == "album") ALBUM_PREFIX + r.id else r.id
            upsert(SavedPlaylist(id, r.name, r.imageUrl, r.tracks, System.currentTimeMillis()))
            persist()
            rematch()
            if (stack.lastOrNull() == Screen.Import) pop()
            push(Screen.Playlist(id))
            r.note?.let { errorText = it }
        }
    }

    /** Imports a playlist export (CSV) or a text file with one "Artist - Title" per line. */
    fun importFromFile(uri: Uri, fileName: String?) {
        task("Reading file…") {
            val text = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() }
            } ?: throw java.io.IOException("Couldn't open that file.")
            val songs = WebParsing.songsFromText(text)
            if (songs.isEmpty()) throw java.io.IOException("No songs found in that file.")
            val name = fileName?.substringBeforeLast('.')?.ifBlank { null } ?: "Imported playlist"
            val id = FILE_PREFIX + System.currentTimeMillis()
            val tracks = songs.mapIndexed { i, (title, artists) ->
                SpotifyTrack("$id:$i", title, artists, "", 0L)
            }
            upsert(SavedPlaylist(id, name, null, tracks, System.currentTimeMillis()))
            persist()
            rematch()
            if (stack.lastOrNull() == Screen.Import) pop()
            push(Screen.Playlist(id))
        }
    }

    // ---------- Downloads ----------

    fun chooseQuality(q: Quality) {
        quality = q
        prefs.edit().putString("quality", q.name).apply()
    }

    /** Album search results on the Download tab. */
    var albumResults by mutableStateOf<List<AlbumHit>>(emptyList()); private set
    var searchingAlbums by mutableStateOf(false); private set

    /** A link downloads; anything else searches albums. */
    fun startDownload() {
        val link = extractLink(linkDraft)
        if (link != null) {
            DownloadQueue.addLink(link, quality)
            linkDraft = ""
            albumResults = emptyList()
            return
        }
        val query = linkDraft.trim()
        if (query.isEmpty()) return
        searchingAlbums = true
        viewModelScope.launch {
            try {
                albumResults = DownloadQueue.searchAlbums(query)
                if (albumResults.isEmpty()) errorText = "No albums found for \"$query\"."
            } catch (e: Exception) {
                errorText = "Album search failed: ${e.message?.lines()?.firstOrNull().orEmpty()}"
            } finally {
                searchingAlbums = false
            }
        }
    }

    fun downloadAlbum(hit: AlbumHit) {
        DownloadQueue.addLink(hit.url, quality)
        albumResults = emptyList()
        linkDraft = ""
    }

    /** Downloads the whole album of a song on the phone (from the player). */
    fun downloadAlbumOf(track: LocalTrack) {
        if (track.album.isBlank()) return
        errorText = "Looking for ${track.album}…"
        viewModelScope.launch {
            try {
                val hit = DownloadQueue.searchAlbums("${track.artist} ${track.album}").firstOrNull()
                if (hit == null) {
                    errorText = "Couldn't find the album ${track.album}."
                } else {
                    DownloadQueue.addLink(hit.url, quality)
                    errorText = "Downloading the album ${hit.title}. Progress is in the Download tab."
                }
            } catch (e: Exception) {
                errorText = "Album search failed: ${e.message?.lines()?.firstOrNull().orEmpty()}"
            }
        }
    }

    /** Finds each song of the playlist that isn't on the phone yet and downloads it. */
    fun downloadMissing(id: String) {
        val missing = rows[id].orEmpty().filter { it.local == null }.map { it.track }
        if (missing.isEmpty()) return
        DownloadQueue.addSongs(missing.map { SongRequest(it.title, it.artists.joinToString(", "), it.durationMs, it.id) }, quality)
        errorText = "Downloading ${missing.size} songs. They fill in here as they finish."
    }

    fun trackById(mediaId: String?): LocalTrack? = mediaId?.toLongOrNull()?.let { libraryById[it] }

    /** Other files of the same song on the phone (e.g. MP3 and FLAC), current one included. */
    fun versionsOf(track: LocalTrack): List<LocalTrack> {
        fun key(t: LocalTrack) = (t.title + "|" + t.artist).lowercase().filter { it.isLetterOrDigit() || it == '|' }
        val k = key(track)
        return library.filter { key(it) == k }.sortedBy { it.fileName.lowercase() }
    }

    fun playVersion(track: LocalTrack) = player.replaceCurrent(track)

    /** Downloads the playing song again in another quality, next to the existing file. */
    fun downloadVersion(track: LocalTrack, q: Quality) {
        val sameType = versionsOf(track).any { it.fileName.endsWith(".${q.ext}", ignoreCase = true) }
        val suffix = if (sameType) " [${q.label}]" else ""
        DownloadQueue.addSongs(listOf(SongRequest(track.title, track.artist, track.durationMs)), q, suffix)
        errorText = "Getting ${q.label}. Pick it here when it's done (see the Download tab)."
    }

    /** Called when a link is shared to Mixtape from another app. */
    fun receiveShared(text: String?) {
        val link = extractLink(text.orEmpty()) ?: return
        while (stack.size > 1) stack.removeAt(stack.lastIndex)
        val kind = SpotifyPublic.parseLink(link)?.first
        if (kind == "playlist" || kind == "album") {
            // Spotify playlist or album: ask "import" or "download".
            sharedSpotify = link
        } else {
            linkDraft = link
            tab = HomeTab.Download
        }
    }

    /** Deletes files directly (Android 10, which has no system delete dialog). */
    fun deleteDirect(uris: List<Uri>) {
        viewModelScope.launch {
            var failed = 0
            withContext(Dispatchers.IO) {
                uris.forEach { uri ->
                    try {
                        context.contentResolver.delete(uri, null, null)
                    } catch (e: Exception) {
                        failed++
                    }
                }
            }
            if (failed > 0) errorText = "Android didn't allow deleting $failed of those songs."
        }
    }

    private fun extractLink(text: String): String? =
        Regex("""https?://\S+""").find(text)?.value?.trimEnd('.', ',', ')', '"', '\'')

    fun removePlaylist(id: String) {
        playlists = playlists.filterNot { it.id == id }
        if (stack.lastOrNull() == Screen.Playlist(id)) pop()
        viewModelScope.launch {
            persist()
            rematch()
        }
    }

    /** Use [localId] for this Spotify song everywhere, or null to go back to automatic matching. */
    fun setManualMatch(spotifyTrackId: String, localId: Long?) {
        overrides = if (localId == null) overrides - spotifyTrackId else overrides + (spotifyTrackId to localId)
        viewModelScope.launch {
            persist()
            rematch()
        }
    }

    // ---------- Playback ----------

    /** Plays the songs of a playlist that are on this phone, in Spotify order. */
    fun playPlaylist(id: String, fromRow: Int? = null, shuffle: Boolean? = null) {
        val list = sortedRows(id)
        val queue = ArrayList<LocalTrack>()
        var start = 0
        list.forEachIndexed { i, row ->
            val local = row.local ?: return@forEachIndexed
            if (i == fromRow) start = queue.size
            queue += local
        }
        if (queue.isEmpty()) return
        if (shuffle == true) start = queue.indices.random()
        player.play(queue, start, shuffle)
    }

    fun playSongs(tracks: List<LocalTrack>, index: Int) {
        if (tracks.isNotEmpty()) player.play(tracks, index, shuffle = null)
    }

    // ---------- Helpers ----------

    private fun upsert(p: SavedPlaylist) {
        val i = playlists.indexOfFirst { it.id == p.id }
        playlists = if (i >= 0) playlists.toMutableList().also { it[i] = p } else playlists + p
    }

    private suspend fun persist() {
        val data = PlaylistStore.Data(playlists, overrides)
        withContext(Dispatchers.IO) { store.save(data) }
    }

    private fun task(label: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = label
            errorText = null
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handle(e)
            } finally {
                busy = null
            }
        }
    }

    private fun handle(e: Throwable) {
        if (e is NotLoggedInException) {
            loggedIn = false
            remote = null
        }
        errorText = when (e) {
            is NotLoggedInException -> "Your Spotify login expired. Tap Connect Spotify to log in again."
            is SpotifyException -> when (e.code) {
                400 -> "Spotify didn't accept the login. Check the Client ID and Redirect URI (README, step 1)."
                401 -> "Spotify rejected the login. Connect again."
                403 -> "Spotify refused access. The app owner needs Spotify Premium, and other accounts must be added under User Management."
                404 -> "Spotify couldn't find that playlist. It may have been deleted."
                429 -> "Spotify is limiting requests right now. Wait a minute and try again."
                else -> "Spotify returned error ${e.code}. Try again."
            }
            is UnknownHostException -> "No internet connection."
            is SocketTimeoutException -> if (waitingForLogin) "Spotify login timed out. Tap Connect Spotify to try again." else "Spotify took too long to answer. Try again."
            is BindException -> "Couldn't start the login listener on port ${Config.REDIRECT_PORT}. Restart the app and try again."
            else -> e.message ?: "Something went wrong."
        }
    }

    private companion object {
        const val ALBUM_PREFIX = "album:"
        const val FILE_PREFIX = "file:"
    }

    override fun onCleared() {
        context.contentResolver.unregisterContentObserver(mediaObserver)
        runCatching { loginServer?.close() }
        player.release()
    }
}
