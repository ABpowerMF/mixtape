package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mixtape.player.playback.AudioFx
import dev.mixtape.player.playback.FxSettings
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val s = AudioFx.settings
    fun set(new: FxSettings) = AudioFx.update(context, new)
    val on = s.enabled

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("equaliser"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            actions = {
                Switch(
                    checked = on,
                    onCheckedChange = { set(s.copy(enabled = it)) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Mix.Ink,
                        checkedTrackColor = Mix.Tape,
                        uncheckedThumbColor = Mix.Fog,
                        uncheckedTrackColor = Mix.Raised,
                        uncheckedBorderColor = Mix.Gap,
                    ),
                    modifier = Modifier.padding(end = 12.dp),
                )
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Text(
                    if (on) "On. Changes apply straight away." else "Off. Turn it on with the switch above.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                    modifier = Modifier.padding(horizontal = 20.dp),
                )
            }

            // ---------- Presets ----------
            item { EqHeading("presets") }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(AudioFx.PRESETS) { (name, gains) ->
                        val selected = s.preset == name
                        Text(
                            name,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (selected) Mix.Ink else Mix.Paper,
                            modifier = Modifier
                                .background(if (selected) Mix.Tape else Mix.Raised, TermShape)
                                .border(1.dp, if (selected) Mix.Tape else Mix.Gap, TermShape)
                                .clickable { set(s.copy(enabled = true, preset = name, bands = gains)) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                        )
                    }
                }
                if (s.preset == "Custom") {
                    Text(
                        "Custom: your own settings.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    )
                }
            }

            // ---------- Bands ----------
            item { EqHeading("bands") }
            items(AudioFx.FREQS.indices.toList()) { i ->
                val hz = AudioFx.FREQS[i]
                val label = if (hz >= 1000) "${hz / 1000f}".removeSuffix(".0") + " kHz" else "$hz Hz"
                val db = s.bands[i]
                FxSlider(
                    label = label,
                    value = db,
                    valueText = (if (db > 0) "+" else "") + "%.1f dB".format(db),
                    range = -AudioFx.MAX_DB..AudioFx.MAX_DB,
                    enabled = on,
                    onChange = { v ->
                        val snapped = (v * 2).roundToInt() / 2f
                        set(s.copy(preset = "Custom", bands = s.bands.toMutableList().also { it[i] = snapped }))
                    },
                )
            }

            // ---------- Extras ----------
            item { EqHeading("extras") }
            item {
                FxSlider(
                    label = "Bass / depth",
                    value = s.bass / 10f,
                    valueText = "${s.bass / 10}%",
                    range = 0f..100f,
                    enabled = on,
                    onChange = { set(s.copy(bass = (it * 10).roundToInt())) },
                )
                FxSlider(
                    label = "Surround / width",
                    value = s.surround / 10f,
                    valueText = "${s.surround / 10}%",
                    range = 0f..100f,
                    enabled = on,
                    onChange = { set(s.copy(surround = (it * 10).roundToInt())) },
                )
                FxSlider(
                    label = "Volume boost",
                    value = s.boost,
                    valueText = "+%.1f dB".format(s.boost),
                    range = 0f..10f,
                    enabled = on,
                    onChange = { set(s.copy(boost = (it * 2).roundToInt() / 2f)) },
                )
                Text(
                    "Volume boost can distort loud songs and tire your ears: go easy. Surround and bass " +
                        "work best on headphones; some phones only apply them there.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                )
            }
            item {
                OutlinedButton(
                    onClick = { set(FxSettings(enabled = s.enabled)) },
                    shape = TermShape,
                    border = BorderStroke(1.dp, Mix.Gap),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                ) { Text(Ui.btn("reset all"), color = Mix.Tape) }
            }
        }
    }
}

@Composable
private fun EqHeading(text: String) {
    Text(
        Ui.head(text),
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp),
    )
}

@Composable
private fun FxSlider(
    label: String,
    value: Float,
    valueText: String,
    range: ClosedFloatingPointRange<Float>,
    enabled: Boolean,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = if (enabled) Mix.Paper else Mix.Fog, modifier = Modifier.weight(1f))
            Text(valueText, style = MaterialTheme.typography.bodySmall, color = if (enabled) Mix.Tape else Mix.Fog)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            enabled = enabled,
            colors = SliderDefaults.colors(
                thumbColor = Mix.Tape,
                activeTrackColor = Mix.Tape,
                inactiveTrackColor = Mix.Gap,
                disabledThumbColor = Mix.Fog,
                disabledActiveTrackColor = Mix.Gap,
                disabledInactiveTrackColor = Mix.Raised,
            ),
            modifier = Modifier.height(32.dp),
        )
    }
}
