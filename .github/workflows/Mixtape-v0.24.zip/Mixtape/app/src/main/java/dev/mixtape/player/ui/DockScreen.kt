package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import android.app.Activity
import android.text.format.DateFormat
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Sideways clock mode, like a smart display: big clock and date, the cover and the song, simple
 * controls. Full screen, the screen stays on, and everything shifts a few pixels every minute so a
 * static image doesn't burn into the display.
 */
@Composable
fun DockScreen(vm: MainViewModel, now: NowPlaying) {
    KeepScreenOn()
    FullScreen()

    val context = LocalContext.current
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            time = System.currentTimeMillis()
            delay(1000 - time % 1000)
        }
    }
    val locale = Locale.getDefault()
    val clock = SimpleDateFormat(if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm", locale).format(Date(time))
    val day = SimpleDateFormat("EEEE, d MMMM", locale).format(Date(time))
    val minute = time / 60_000
    val shiftX = remember(minute) { Random.nextInt(-8, 9) }
    val shiftY = remember(minute) { Random.nextInt(-6, 7) }
    val track = vm.trackById(now.mediaId)
    val playing = now.mediaId != null

    Box(
        Modifier
            .fillMaxSize()
            .background(Mix.Ink),
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .offset(x = shiftX.dp, y = shiftY.dp)
                .padding(horizontal = 40.dp, vertical = 28.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (playing) {
                Artwork(
                    track?.artUri ?: now.artworkUri,
                    Modifier
                        .fillMaxHeight()
                        .aspectRatio(1f),
                    corner = 4.dp,
                    iconSize = 72.dp,
                )
                Spacer(Modifier.width(40.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    clock,
                    fontSize = if (playing) 88.sp else 120.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = MaterialTheme.typography.displayLarge.fontFamily,
                    color = Mix.Paper,
                    maxLines = 1,
                )
                Text(day.replaceFirstChar { it.titlecase(locale) }, style = MaterialTheme.typography.titleLarge, color = Mix.Fog)
                if (playing) {
                    Spacer(Modifier.height(20.dp))
                    Text(
                        now.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = Mix.Tape,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        now.artist,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Mix.Fog,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Spacer(Modifier.height(12.dp))
                    LinearProgressIndicator(
                        progress = { if (now.durationMs > 0) (now.positionMs.toFloat() / now.durationMs).coerceIn(0f, 1f) else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp),
                        color = Mix.Tape,
                        trackColor = Mix.Gap,
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = vm.player::previousSong, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = Mix.Paper, modifier = Modifier.size(32.dp))
                        }
                        IconButton(onClick = vm.player::toggle, modifier = Modifier.size(64.dp)) {
                            Icon(
                                if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (now.isPlaying) "Pause" else "Play",
                                tint = Mix.Tape,
                                modifier = Modifier.size(44.dp),
                            )
                        }
                        IconButton(onClick = vm.player::next, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = Mix.Paper, modifier = Modifier.size(32.dp))
                        }
                    }
                } else {
                    Spacer(Modifier.height(16.dp))
                    Text(Ui.head("nothing playing"), style = MaterialTheme.typography.bodyLarge, color = Mix.Fog)
                }
            }
        }
    }
}

/** Hides the status and navigation bars (swipe from the edge to see them). */
@Composable
private fun FullScreen() {
    val view = LocalView.current
    DisposableEffect(view) {
        val window = (view.context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
}
