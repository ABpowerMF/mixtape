package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.QueuePlayNext
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.lazy.rememberLazyListState
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.library.LocalLibrary
import dev.mixtape.player.ui.theme.Mix

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongsScreen(vm: MainViewModel) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var query by rememberSaveable { mutableStateOf("") }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var confirmDelete by remember { mutableStateOf(false) }
    val songs = remember(query, vm.library) {
        if (query.isBlank()) vm.library else vm.searchLibrary(query, limit = Int.MAX_VALUE)
    }
    val selecting = selected.isNotEmpty()

    // Android shows its own "Allow Mixtape to delete these?" dialog; the list refreshes by itself.
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        selected = emptySet()
    }

    fun deleteSelected() {
        val uris = selected.map { LocalLibrary.contentUri(it) }
        if (uris.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        } else {
            vm.deleteDirect(uris)
            selected = emptySet()
        }
    }

    BackHandler(enabled = selecting) { selected = emptySet() }

    Column(Modifier.fillMaxSize()) {
        if (selecting) {
            TopAppBar(
                title = { Text("${selected.size} selected", style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = { selected = emptySet() }) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel selection")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        vm.player.playNext(songs.filter { it.id in selected })
                        selected = emptySet()
                    }) {
                        Icon(Icons.Filled.QueuePlayNext, contentDescription = "Play next")
                    }
                    IconButton(onClick = {
                        vm.player.addToQueue(songs.filter { it.id in selected })
                        selected = emptySet()
                    }) {
                        Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = "Add to queue")
                    }
                    IconButton(onClick = { selected = selected + songs.map { it.id } }) {
                        Icon(Icons.Filled.SelectAll, contentDescription = "Select all shown")
                    }
                    IconButton(onClick = {
                        if (Build.VERSION.SDK_INT >= 30) deleteSelected() else confirmDelete = true
                    }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Mix.Alert)
                    }
                },
                windowInsets = WindowInsets(0, 0, 0, 0),
            )
        } else {
            TopAppBar(
                title = { Text(Ui.path("songs"), style = MaterialTheme.typography.titleLarge) },
                windowInsets = WindowInsets(0, 0, 0, 0),
            )
        }
        if (vm.libraryLoaded && vm.library.isEmpty()) {
            EmptyState(
                title = "No music files found",
                body = "Download songs in the Download tab, or copy audio files into the Music or Download folder. " +
                    "They show up here and in your playlists automatically.",
            )
        } else {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear search")
                        }
                    }
                },
                placeholder = { Text("Search ${vm.library.size} songs") },
                supportingText = if (!selecting && vm.library.isNotEmpty()) {
                    { Text("Hold a song to select it: queue it, or delete it.", color = Mix.Fog) }
                } else {
                    null
                },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
            )
            val listState = rememberLazyListState()
            Box(Modifier.fillMaxSize()) {
                LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 8.dp)) {
                                itemsIndexed(songs, key = { _, t -> t.id }) { i, t ->
                                    val isSelected = t.id in selected
                                    LocalTrackRow(
                                        track = t,
                                        highlighted = now.mediaId == t.id.toString(),
                                        selected = isSelected,
                                        onLongClick = { selected = if (isSelected) selected - t.id else selected + t.id },
                                    ) {
                                        if (selecting) {
                                            selected = if (isSelected) selected - t.id else selected + t.id
                                        } else {
                                            vm.playSongs(songs, i)
                                        }
                                    }
                                }
                            }
                FastScrollbar(listState, Modifier.align(Alignment.CenterEnd))
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete ${selected.size} songs?") },
            text = { Text("The files are removed from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    deleteSelected()
                }) { Text("Delete", color = Mix.Alert) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = Mix.Paper) }
            },
            containerColor = Mix.Deep,
        )
    }
}
