package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui

import androidx.compose.foundation.layout.Row

import androidx.compose.foundation.clickable

import dev.mixtape.player.playback.NowPlaying
import androidx.compose.foundation.background
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.fadeOut
import androidx.compose.animation.fadeIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.ui.platform.LocalConfiguration
import android.content.res.Configuration
import android.content.pm.ActivityInfo
import android.app.Activity
import androidx.compose.material3.AlertDialog
import dev.mixtape.player.ui.theme.TermShape
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.MainActivity
import dev.mixtape.player.ui.theme.Mix

@Composable
fun MixtapeApp(vm: MainViewModel) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val screen = vm.stack.last()
    LaunchedEffect(screen) {
        vm.player.fastProgress = screen == Screen.NowPlaying || screen == Screen.Lyrics
    }

    // RG Rotate with the screen closed: only the closed-screen player (it sits over the lock screen).
    if (vm.closedScreen) {
        ClosedScreen(vm, now)
        return
    }

    // Sideways clock mode follows the phone's own auto-rotate switch: with auto-rotate off, the
    // phone stays upright and the clock never appears by accident.
    val activity = LocalContext.current as? Activity
    // The Clock mode shortcut turns the screen sideways by itself until you go back.
    LaunchedEffect(vm.forcedClock) {
        activity?.requestedOrientation = if (vm.forcedClock) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
    if (vm.forcedClock || (vm.dockMode && LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE)) {
        BackHandler(enabled = vm.forcedClock) { vm.forcedClock = false }
        DockScreen(vm, now)
        return
    }
    if (vm.showTutorial) {
        TutorialScreen(onDone = vm::finishTutorial)
        return
    }

    BackHandler(enabled = vm.stack.size > 1) { vm.pop() }

    vm.sharedSpotify?.let {
        AlertDialog(
            onDismissRequest = { vm.sharedSpotify = null },
            title = { Text("Spotify link") },
            text = { Text("Import it as a playlist (matched with your songs), or download all its songs?") },
            confirmButton = { TextButton(onClick = vm::importShared) { Text("Import playlist", color = Mix.Tape) } },
            dismissButton = { TextButton(onClick = vm::downloadShared) { Text("Download songs", color = Mix.Paper) } },
            containerColor = Mix.Deep,
        )
    }

    // A new version on GitHub: offered once (Settings → updates any time).
    if (vm.hasPermission) UpdatePopup(vm)

    // Making the vault PIN (from Settings, or the first time something goes in the vault).
    if (vm.vaultSetupFor != null) VaultSetupDialog(vm) { vm.vaultSetupFor = null }

    // Listen together: someone on the same Wi-Fi invites you.
    vm.together.invite?.let { inv ->
        AlertDialog(
            onDismissRequest = vm.together::decline,
            title = { Text(Ui.head("listen together")) },
            text = {
                Text(
                    if (inv.mode == dev.mixtape.player.together.TogetherMode.BOTH) {
                        "${inv.from} wants to listen together: the same song plays on both phones."
                    } else {
                        "${inv.from} wants to listen together on their phone. Yours becomes the remote: skip, pause, add songs."
                    },
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.together.accept()
                    vm.push(Screen.Together)
                }) { Text("Join", color = Mix.Tape) }
            },
            dismissButton = { TextButton(onClick = vm.together::decline) { Text("Decline", color = Mix.Paper) } },
            containerColor = Mix.Deep,
        )
    }

    LaunchedEffect(vm.errorText) {
        val text = vm.errorText ?: return@LaunchedEffect
        snackbar.showSnackbar(text, withDismissAction = true, duration = SnackbarDuration.Long)
        vm.errorText = null
    }

    Box(Modifier.fillMaxSize()) {
    AppBackground()
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when {
            !vm.hasPermission -> PermissionScreen(onResult = vm::onPermission)
            Mix.animations -> Box(Modifier.fillMaxSize()) {
                MainScaffold(vm, now, if (screen == Screen.NowPlaying) vm.stack.getOrNull(vm.stack.lastIndex - 1) ?: Screen.Home else screen, snackbar)
                AnimatedVisibility(
                    visible = screen == Screen.NowPlaying,
                    enter = slideInVertically(tween(280)) { it } + fadeIn(tween(200)),
                    exit = slideOutVertically(tween(240)) { it } + fadeOut(tween(200)),
                ) {
                    Box(Modifier.fillMaxSize()) {
                        AppBackground()
                        NowPlayingScreen(vm, now)
                    }
                }
            }
            screen == Screen.NowPlaying && !Mix.animations -> NowPlayingScreen(vm, now)
            else -> MainScaffold(vm, now, screen, snackbar)
        }
    }
    }
}

/** The app's main frame: current screen, mini player and bottom tabs. */
@Composable
private fun MainScaffold(vm: MainViewModel, now: NowPlaying, screen: Screen, snackbar: SnackbarHostState) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = { if (Mix.cocoon && screen == Screen.Home) CocoonTopBar(vm) },
        bottomBar = {
            Column(if (screen == Screen.Home && !Mix.cocoon) Modifier else Modifier.navigationBarsPadding()) {
                if (vm.together.active && screen != Screen.Together) {
                    // "● with Kenji": tap for the Listen together screen.
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(Mix.Deep)
                            .clickable { vm.push(Screen.Together) }
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text("● with ${vm.together.peerName}", style = MaterialTheme.typography.bodySmall, color = Mix.Tape)
                        Text(" · listening together", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                    }
                }
                if (now.mediaId != null) {
                    // ASCII visualiser: sits on top of the page just above the mini player (takes no room).
                    Box(Modifier.fillMaxWidth().height(0.dp)) {
                        AsciiVisualiser(
                            playing = now.isPlaying,
                            modifier = Modifier.wrapContentHeight(Alignment.Bottom, unbounded = true),
                        )
                    }
                    MiniPlayer(
                        now = now,
                        onOpen = { vm.push(Screen.NowPlaying) },
                        onToggle = vm.player::toggle,
                        onNext = vm.player::next,
                        onPrevious = vm.player::previousSong,
                        swipeEnabled = vm.swipeToSkip,
                    )
                }
                if (Mix.cocoon) CocoonHintBar(vm, screen) else if (screen == Screen.Home) HomeNav(vm)
            }
        },
    ) { padding ->
        Column(Modifier.padding(padding)) {
            vm.busy?.let { BusyBar(it) }
            Box(Modifier.weight(1f)) {
                if (Mix.animations) {
                    AnimatedContent(
                        targetState = screen to vm.tab,
                        contentKey = { (s, t) -> if (s == Screen.Home) "tab:" + t.name else s.toString() },
                        transitionSpec = {
                            (fadeIn(tween(220)) + slideInVertically(tween(220)) { it / 20 }) togetherWith fadeOut(tween(120))
                        },
                        label = "screens",
                    ) { (s, t) -> ScreenContent(vm, s, t) }
                } else {
                    ScreenContent(vm, screen, vm.tab)
                }
            }
        }
    }
}

@Composable
private fun HomeNav(vm: MainViewModel) {
    val colors = NavigationBarItemDefaults.colors(
        selectedIconColor = Mix.Ink,
        selectedTextColor = Mix.Paper,
        indicatorColor = Mix.Tape,
        unselectedIconColor = Mix.Fog,
        unselectedTextColor = Mix.Fog,
    )
    NavigationBar(containerColor = Mix.Deep) {
        NavigationBarItem(
            selected = vm.tab == HomeTab.Playlists,
            onClick = { vm.tab = HomeTab.Playlists },
            icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
            label = { Text("Playlists") },
            colors = colors,
        )
        NavigationBarItem(
            selected = vm.tab == HomeTab.Songs,
            onClick = { vm.tab = HomeTab.Songs },
            icon = { Icon(Icons.Filled.MusicNote, contentDescription = null) },
            label = { Text("Songs") },
            colors = colors,
        )
        NavigationBarItem(
            selected = vm.tab == HomeTab.Download,
            onClick = { vm.tab = HomeTab.Download },
            icon = { Icon(Icons.Filled.Download, contentDescription = null) },
            label = { Text("Download") },
            colors = colors,
        )
        NavigationBarItem(
            selected = vm.tab == HomeTab.Settings,
            onClick = { vm.tab = HomeTab.Settings },
            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
            label = { Text("Settings") },
            colors = colors,
        )
    }
}

@Composable
private fun PermissionScreen(onResult: (Boolean) -> Unit) {
    val context = LocalContext.current
    var askedOnce by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        askedOnce = true
        onResult(granted)
    }
    Box(Modifier.systemBarsPadding()) {
        EmptyState(
            title = "Your music, your playlists",
            body = "Mixtape plays the music files on this phone and lines them up with your Spotify playlists. " +
                "Allow music access so it can find them.",
        ) {
            Column {
                Button(shape = TermShape, onClick = { launcher.launch(MainActivity.audioPermission) }) {
                    Text("Allow music access")
                }
                if (askedOnce) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "If no prompt appears, turn on Music and audio for Mixtape in Settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                    )
                    TextButton(onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                        )
                    }) {
                        Text("Open Settings")
                    }
                }
            }
        }
    }
}

/** One screen of the app (the part between the top and the mini player). */
@Composable
private fun ScreenContent(vm: MainViewModel, screen: Screen, tab: HomeTab) {
        when (screen) {
            Screen.Home -> when (tab) {
                HomeTab.Playlists -> PlaylistsScreen(vm)
                HomeTab.Songs -> SongsScreen(vm)
                HomeTab.Download -> DownloadScreen(vm)
                HomeTab.Settings -> SettingsScreen(vm)
            }
            is Screen.Playlist -> PlaylistScreen(vm, screen.id)
            Screen.Import -> ImportScreen(vm)
            Screen.Stats -> StatsScreen(vm)
            Screen.Wrapped -> WrappedScreen(vm)
            Screen.Concerts -> ConcertsScreen(vm)
            is Screen.Smart -> SmartScreen(vm, screen.kind)
            Screen.Queue -> QueueScreen(vm)
            Screen.Lyrics -> LyricsScreen(vm)
            Screen.Equalizer -> EqualizerScreen(vm)
            is Screen.Album -> AlbumScreen(vm, screen.folder)
            is Screen.ShareTape -> ShareTapeScreen(vm, screen.id)
            Screen.ScanTape -> ScanTapeScreen(vm)
            Screen.Cleanup -> CleanupScreen(vm)
            Screen.Together -> TogetherScreen(vm)
            is Screen.SendToDs -> SendToDsScreen(vm, screen.id)
            Screen.Vault -> VaultScreen(vm)
            Screen.NowPlaying -> Unit
        }
}
