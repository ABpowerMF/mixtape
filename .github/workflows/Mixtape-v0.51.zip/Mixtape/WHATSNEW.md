Mixtape v0.51

- RG Rotate: close the screen and Mixtape shows its player instead of the clock: cover, song, a seek bar you can tap or drag, previous / play / next, shuffle and repeat, and lyrics that slide in where the song name was. The shoulder buttons skip songs while it's closed; any other button opens the app again. With nothing playing it shows a big clock and a card to start music. Settings → rotate.
- Cocoon style (Settings → style → Cocoon): looks like the Cocoon console frontend. Playlists, albums and smart playlists as tiles, glass panels, waves in the background, tabs on top (L / R switch them) and a bar that says what A, B, X and Y do. Settings get a list of sections on the left.
- Console buttons everywhere: L / R change tab, X play / pause (shuffle on an album or playlist), Y opens the player.
