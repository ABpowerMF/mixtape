package dev.mixtape.player.spotify

import android.content.Context
import android.net.Uri
import android.util.Base64
import dev.mixtape.player.Config
import dev.mixtape.player.data.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom

class NotLoggedInException : Exception("Not connected to Spotify")

class SpotifyException(val code: Int, body: String) : Exception("Spotify error $code: ${body.take(300)}")

/** One login attempt: the page to open, plus the secrets needed to finish it. */
data class AuthRequest(val url: Uri, val verifier: String, val state: String)

/**
 * Spotify login using "Authorization Code with PKCE" (no client secret needed on the phone).
 * Tokens are kept in private app storage and refreshed automatically.
 */
class SpotifyAuth(context: Context) {

    private val prefs = context.getSharedPreferences("spotify_auth", Context.MODE_PRIVATE)
    private val mutex = Mutex()

    val isLoggedIn: Boolean get() = prefs.contains(KEY_REFRESH)

    fun newRequest(): AuthRequest {
        val verifier = randomString(64)
        val state = randomString(16)
        val url = Uri.parse("https://accounts.spotify.com/authorize").buildUpon()
            .appendQueryParameter("client_id", Config.SPOTIFY_CLIENT_ID)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", Config.REDIRECT_URI)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("code_challenge", challengeFor(verifier))
            .appendQueryParameter("state", state)
            .appendQueryParameter("scope", Config.SCOPES)
            .build()
        return AuthRequest(url, verifier, state)
    }

    suspend fun exchangeCode(code: String, verifier: String) {
        val res = withContext(Dispatchers.IO) {
            Http.postForm(
                TOKEN_URL,
                mapOf(
                    "grant_type" to "authorization_code",
                    "code" to code,
                    "redirect_uri" to Config.REDIRECT_URI,
                    "client_id" to Config.SPOTIFY_CLIENT_ID,
                    "code_verifier" to verifier,
                ),
            )
        }
        if (res.code !in 200..299) throw SpotifyException(res.code, res.body)
        save(JSONObject(res.body))
    }

    /** A valid access token, refreshing it first if it's about to expire. */
    suspend fun accessToken(): String = mutex.withLock {
        val cached = prefs.getString(KEY_ACCESS, null)
        val expiresAt = prefs.getLong(KEY_EXPIRES, 0L)
        if (cached != null && System.currentTimeMillis() < expiresAt - 60_000L) cached else refresh()
    }

    /** Forces the next [accessToken] call to refresh. */
    fun invalidateAccessToken() {
        prefs.edit().remove(KEY_EXPIRES).apply()
    }

    fun logout() {
        prefs.edit().clear().apply()
    }

    private suspend fun refresh(): String {
        val refreshToken = prefs.getString(KEY_REFRESH, null) ?: throw NotLoggedInException()
        val res = withContext(Dispatchers.IO) {
            Http.postForm(
                TOKEN_URL,
                mapOf(
                    "grant_type" to "refresh_token",
                    "refresh_token" to refreshToken,
                    "client_id" to Config.SPOTIFY_CLIENT_ID,
                ),
            )
        }
        if (res.code == 400 || res.code == 401) {
            // Refresh token expired or revoked: log in again.
            logout()
            throw NotLoggedInException()
        }
        if (res.code !in 200..299) throw SpotifyException(res.code, res.body)
        return save(JSONObject(res.body))
    }

    private fun save(json: JSONObject): String {
        val access = json.getString("access_token")
        val editor = prefs.edit()
            .putString(KEY_ACCESS, access)
            .putLong(KEY_EXPIRES, System.currentTimeMillis() + json.optLong("expires_in", 3600L) * 1000L)
        // Spotify may send a new refresh token; keep the old one if it doesn't.
        json.str("refresh_token")?.let { editor.putString(KEY_REFRESH, it) }
        editor.apply()
        return access
    }

    private fun randomString(length: Int): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        val rnd = SecureRandom()
        return String(CharArray(length) { chars[rnd.nextInt(chars.length)] })
    }

    private fun challengeFor(verifier: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
        return Base64.encodeToString(digest, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
    }

    private companion object {
        const val TOKEN_URL = "https://accounts.spotify.com/api/token"
        const val KEY_ACCESS = "access_token"
        const val KEY_REFRESH = "refresh_token"
        const val KEY_EXPIRES = "expires_at"
    }
}
