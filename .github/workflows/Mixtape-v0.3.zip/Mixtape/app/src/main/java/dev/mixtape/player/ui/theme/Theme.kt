package dev.mixtape.player.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.mixtape.player.R

/** Terminal palette: black screen, phosphor-green text, bright green for what's on the phone. */
object Mix {
    val Ink = Color(0xFF050805)     // background
    val Deep = Color(0xFF0C130C)    // sheets, player bar
    val Raised = Color(0xFF142014)  // artwork placeholders, chips, selection
    val Gap = Color(0xFF223322)     // lines, missing songs in the match strip
    val Paper = Color(0xFFCFF5CF)   // main text
    val Fog = Color(0xFF6F946F)     // secondary text
    val Tape = Color(0xFF39FF6A)    // accent: songs found, play, cursor
    val Alert = Color(0xFFFF5F56)
}

/** Square corners, like a terminal window. */
val TermShape = RoundedCornerShape(2.dp)

/** The whole app uses the phone's monospace font. */
val Mono = FontFamily.Monospace

val Barlow = FontFamily(
    Font(R.font.barlow_regular, FontWeight.Normal),
    Font(R.font.barlow_medium, FontWeight.Medium),
    Font(R.font.barlow_semibold, FontWeight.SemiBold),
    Font(R.font.barlow_bold, FontWeight.Bold),
)

private val scheme = darkColorScheme(
    primary = Mix.Tape,
    onPrimary = Mix.Ink,
    primaryContainer = Mix.Raised,
    onPrimaryContainer = Mix.Paper,
    secondary = Mix.Fog,
    onSecondary = Mix.Ink,
    secondaryContainer = Mix.Raised,
    onSecondaryContainer = Mix.Paper,
    background = Mix.Ink,
    onBackground = Mix.Paper,
    surface = Mix.Ink,
    onSurface = Mix.Paper,
    surfaceVariant = Mix.Raised,
    onSurfaceVariant = Mix.Fog,
    surfaceContainerLowest = Mix.Ink,
    surfaceContainerLow = Mix.Deep,
    surfaceContainer = Mix.Deep,
    surfaceContainerHigh = Mix.Raised,
    surfaceContainerHighest = Mix.Raised,
    inverseSurface = Mix.Paper,
    inverseOnSurface = Mix.Ink,
    outline = Mix.Gap,
    outlineVariant = Mix.Gap,
    error = Mix.Alert,
    onError = Mix.Ink,
)

private val base = Typography()
private fun TextStyle.barlow(size: Int? = null, weight: FontWeight? = null, line: Int? = null) = copy(
    fontFamily = Mono,
    letterSpacing = 0.sp,
    fontSize = size?.sp ?: fontSize,
    fontWeight = weight ?: fontWeight,
    lineHeight = line?.sp ?: lineHeight,
)

private val type = Typography(
    displayLarge = base.displayLarge.barlow(),
    displayMedium = base.displayMedium.barlow(),
    displaySmall = base.displaySmall.barlow(size = 24, weight = FontWeight.Bold, line = 30),
    headlineLarge = base.headlineLarge.barlow(weight = FontWeight.SemiBold),
    headlineMedium = base.headlineMedium.barlow(weight = FontWeight.SemiBold),
    headlineSmall = base.headlineSmall.barlow(weight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.barlow(size = 20, weight = FontWeight.Bold, line = 26),
    titleMedium = base.titleMedium.barlow(size = 15, weight = FontWeight.Medium, line = 20),
    titleSmall = base.titleSmall.barlow(weight = FontWeight.Medium),
    bodyLarge = base.bodyLarge.barlow(size = 15, line = 22),
    bodyMedium = base.bodyMedium.barlow(size = 13, line = 18),
    bodySmall = base.bodySmall.barlow(size = 12, line = 16),
    labelLarge = base.labelLarge.barlow(size = 14, weight = FontWeight.Bold),
    labelMedium = base.labelMedium.barlow(size = 13, weight = FontWeight.Medium),
    labelSmall = base.labelSmall.barlow(),
)

private val termShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(2.dp),
    medium = RoundedCornerShape(2.dp),
    large = RoundedCornerShape(2.dp),
    extraLarge = RoundedCornerShape(2.dp),
)

@Composable
fun MixtapeTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, shapes = termShapes, content = content)
}
