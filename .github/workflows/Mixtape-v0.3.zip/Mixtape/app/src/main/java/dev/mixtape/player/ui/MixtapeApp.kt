package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.TermShape
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.MainActivity
import dev.mixtape.player.ui.theme.Mix

@Composable
fun MixtapeApp(vm: MainViewModel) {
    val now by vm.player.state.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    val screen = vm.stack.last()

    BackHandler(enabled = vm.stack.size > 1) { vm.pop() }

    LaunchedEffect(vm.errorText) {
        val text = vm.errorText ?: return@LaunchedEffect
        snackbar.showSnackbar(text, withDismissAction = true, duration = SnackbarDuration.Long)
        vm.errorText = null
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when {
            !vm.hasPermission -> PermissionScreen(onResult = vm::onPermission)
            screen == Screen.NowPlaying -> NowPlayingScreen(vm, now)
            else -> Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                snackbarHost = { SnackbarHost(snackbar) },
                bottomBar = {
                    Column(if (screen == Screen.Home) Modifier else Modifier.navigationBarsPadding()) {
                        if (now.mediaId != null) {
                            MiniPlayer(
                                now = now,
                                onOpen = { vm.push(Screen.NowPlaying) },
                                onToggle = vm.player::toggle,
                                onNext = vm.player::next,
                                onPrevious = vm.player::previousSong,
                            )
                        }
                        if (screen == Screen.Home) HomeNav(vm)
                    }
                },
            ) { padding ->
                Column(Modifier.padding(padding)) {
                    vm.busy?.let { BusyBar(it) }
                    Box(Modifier.weight(1f)) {
                        when (screen) {
                            Screen.Home -> when (vm.tab) {
                                HomeTab.Playlists -> PlaylistsScreen(vm)
                                HomeTab.Songs -> SongsScreen(vm)
                                HomeTab.Download -> DownloadScreen(vm)
                            }
                            is Screen.Playlist -> PlaylistScreen(vm, screen.id)
                            Screen.Import -> ImportScreen(vm)
                            Screen.NowPlaying -> Unit
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeNav(vm: MainViewModel) {
    val colors = NavigationBarItemDefaults.colors(
        selectedIconColor = Mix.Ink,
        selectedTextColor = Mix.Paper,
        indicatorColor = Mix.Tape,
        unselectedIconColor = Mix.Fog,
        unselectedTextColor = Mix.Fog,
    )
    NavigationBar(containerColor = Mix.Deep) {
        NavigationBarItem(
            selected = vm.tab == HomeTab.Playlists,
            onClick = { vm.tab = HomeTab.Playlists },
            icon = { Icon(Icons.Filled.LibraryMusic, contentDescription = null) },
            label = { Text("Playlists") },
            colors = colors,
        )
        NavigationBarItem(
            selected = vm.tab == HomeTab.Songs,
            onClick = { vm.tab = HomeTab.Songs },
            icon = { Icon(Icons.Filled.MusicNote, contentDescription = null) },
            label = { Text("Songs") },
            colors = colors,
        )
        NavigationBarItem(
            selected = vm.tab == HomeTab.Download,
            onClick = { vm.tab = HomeTab.Download },
            icon = { Icon(Icons.Filled.Download, contentDescription = null) },
            label = { Text("Download") },
            colors = colors,
        )
    }
}

@Composable
private fun PermissionScreen(onResult: (Boolean) -> Unit) {
    val context = LocalContext.current
    var askedOnce by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        askedOnce = true
        onResult(granted)
    }
    Box(Modifier.systemBarsPadding()) {
        EmptyState(
            title = "Your music, your playlists",
            body = "Mixtape plays the music files on this phone and lines them up with your Spotify playlists. " +
                "Allow music access so it can find them.",
        ) {
            Column {
                Button(shape = TermShape, onClick = { launcher.launch(MainActivity.audioPermission) }) {
                    Text("Allow music access")
                }
                if (askedOnce) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        "If no prompt appears, turn on Music and audio for Mixtape in Settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                    )
                    TextButton(onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                        )
                    }) {
                        Text("Open Settings")
                    }
                }
            }
        }
    }
}
