package dev.mixtape.player.playback

import com.google.common.collect.ImmutableList
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaLibraryService
import androidx.media3.common.Player
import dev.mixtape.player.widget.WidgetUpdater
import dev.mixtape.player.widget.Widgets
import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import dev.mixtape.player.MainActivity
import dev.mixtape.player.library.LocalLibrary

/** Keeps music playing in the background and provides notification + lock-screen controls. */
class PlaybackService : MediaLibraryService() {

    private var session: MediaLibrarySession? = null
    private var stats: StatsTracker? = null

    // Fade in / out and crossfade (Equaliser → fade). A second, short-lived player keeps the old
    // song going while it fades out and the main player starts the next song fading in.
    private val fadeHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var tail: ExoPlayer? = null
    private var tailStart = 0L
    private var tailLength = 1L
    private var fadeInUntil = 0L
    private var fadeInLength = 1L
    private var crossfadedFrom: String? = null

    private val fadeTick = object : Runnable {
        override fun run() {
            val p = session?.player
            val now = android.os.SystemClock.elapsedRealtime()
            val fx = AudioFx.settings
            if (p != null) {
                val fadeMs = (fx.fadeSeconds * 1000).toLong()
                val xMs = (fx.crossfadeSeconds * 1000).toLong()
                val pos = p.currentPosition
                val dur = p.duration

                // Start a crossfade near the end of the song.
                val key = "${p.currentMediaItemIndex}:${p.currentMediaItem?.mediaId}"
                if (xMs > 0 && p.isPlaying && p.hasNextMediaItem() && p.repeatMode != Player.REPEAT_MODE_ONE &&
                    dur > xMs * 2 && dur - pos in 1..xMs && crossfadedFrom != key
                ) {
                    val item = p.currentMediaItem
                    if (item != null) {
                        startTail(item, pos, (dur - pos).coerceAtLeast(500L))
                        p.seekToNextMediaItem()
                        crossfadedFrom = "${p.currentMediaItemIndex}:${p.currentMediaItem?.mediaId}"
                        fadeInLength = xMs
                        fadeInUntil = now + xMs
                    }
                }

                // Main player volume: fade rules and the crossfade fade-in.
                var v = 1f
                if (fadeMs > 0) {
                    if (pos < fadeMs) v = pos.toFloat() / fadeMs
                    if (dur > 0 && dur - pos < fadeMs && tail == null) v = minOf(v, (dur - pos).toFloat() / fadeMs)
                }
                if (fadeInUntil > now) v = minOf(v, 1f - (fadeInUntil - now).toFloat() / fadeInLength)
                val target = v.coerceIn(0f, 1f)
                if (p.volume != target) p.volume = target

                // The old song fades out on the second player.
                tail?.let { t ->
                    val done = (now - tailStart).toFloat() / tailLength
                    // Only stop early if you paused (the next song may still be loading).
                    if (done >= 1f || !p.playWhenReady) stopTail() else t.volume = (1f - done).coerceIn(0f, 1f)
                }
            }
            // Battery: only wake up often right around a fade; otherwise sleep until the next one,
            // and not at all while paused (playing again restarts this).
            val fadeMs = (fx.fadeSeconds * 1000).toLong()
            val xMs = (fx.crossfadeSeconds * 1000).toLong()
            val next: Long? = if (p == null) {
                null
            } else if (tail != null || fadeInUntil > now) {
                80L
            } else if (!p.isPlaying) {
                null
            } else if (fadeMs == 0L && xMs == 0L) {
                null
            } else {
                val pos = p.currentPosition
                val dur = p.duration
                val window = maxOf(fadeMs, xMs) + 1_500
                val untilEnd = if (dur > 0) dur - pos - window else Long.MAX_VALUE
                when {
                    pos < fadeMs + 300 -> 80L
                    untilEnd <= 0 -> 80L
                    else -> untilEnd.coerceIn(200L, 5_000L)
                }
            }
            if (next != null) fadeHandler.postDelayed(this, next)
        }
    }

    /** Restarts the fade timer (after it went to sleep). */
    fun kickFade() {
        fadeHandler.removeCallbacks(fadeTick)
        fadeHandler.post(fadeTick)
    }

    private fun startTail(item: MediaItem, position: Long, length: Long) {
        stopTail()
        val playable = if (item.localConfiguration != null) {
            item
        } else {
            item.buildUpon().setUri(LocalLibrary.contentUri(item.mediaId.toLongOrNull() ?: return)).build()
        }
        val t = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                /* handleAudioFocus = */ false,
            )
            .build()
        t.setMediaItem(playable, position)
        t.volume = 1f
        t.prepare()
        t.play()
        tail = t
        tailStart = android.os.SystemClock.elapsedRealtime()
        tailLength = length
    }

    private fun stopTail() {
        tail?.run {
            stop()
            release()
        }
        tail = null
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true,
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones are unplugged
            .build()

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        ListenStats.init(this)
        AudioFx.load(this)
        AudioFx.onChanged = { kickFade() }
        AudioFx.attach(player.audioSessionId)
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) = AudioFx.attach(audioSessionId)

            // Wake the fade timer up again when music starts or the song changes.
            override fun onIsPlayingChanged(isPlaying: Boolean) = kickFade()
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = kickFade()
        })
        fadeHandler.post(fadeTick)
        stats = StatsTracker(player).also { player.addListener(it) }
        player.addListener(WidgetUpdater(this))

        session = MediaLibrarySession.Builder(this, player, Callback(this))
            .setSessionActivity(openApp)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    /** Play/pause and next buttons on the home-screen widget. */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val player = session?.player
        if (player != null) {
            when (intent?.action) {
                Widgets.ACTION_TOGGLE -> if (player.isPlaying) {
                    player.pause()
                } else {
                    if (player.playbackState == Player.STATE_IDLE) player.prepare()
                    player.play()
                }
                Widgets.ACTION_NEXT -> player.seekToNextMediaItem()
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = session?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        fadeHandler.removeCallbacks(fadeTick)
        AudioFx.onChanged = null
        stopTail()
        AudioFx.release()
        stats?.flush()
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    /**
     * Rebuilds the file Uri from the media id if it was stripped on the way to the service, and
     * answers Android Auto: what to show, and what to play when a song is picked there.
     */
    private class Callback(private val service: PlaybackService) : MediaLibrarySession.Callback {
        private val worker = java.util.concurrent.Executors.newSingleThreadExecutor()

        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val resolved = mediaItems.map { item ->
                val id = item.mediaId.substringAfterLast('|').toLongOrNull()
                if (item.localConfiguration != null && !item.mediaId.contains('|')) item
                else if (id == null) item
                else item.buildUpon().setMediaId(id.toString()).setUri(LocalLibrary.contentUri(id)).build()
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }

        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            // One song picked in the car → play its whole list from there.
            if (mediaItems.size == 1 && mediaItems[0].mediaId.contains('|')) {
                return Futures.submit(
                    java.util.concurrent.Callable {
                        val expanded = AutoLibrary.expand(service, mediaItems[0])
                        if (expanded != null) {
                            MediaSession.MediaItemsWithStartPosition(expanded.first, expanded.second, 0L)
                        } else {
                            val id = mediaItems[0].mediaId.substringAfterLast('|').toLong()
                            MediaSession.MediaItemsWithStartPosition(
                                listOf(mediaItems[0].buildUpon().setMediaId(id.toString()).setUri(LocalLibrary.contentUri(id)).build()),
                                0,
                                0L,
                            )
                        }
                    },
                    worker,
                )
            }
            return super.onSetMediaItems(mediaSession, controller, mediaItems, startIndex, startPositionMs)
        }

        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: MediaLibraryService.LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(AutoLibrary.rootItem(), params))

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: MediaLibraryService.LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> = Futures.submit(
            java.util.concurrent.Callable {
                val all = AutoLibrary.children(service, parentId)
                val from = (page * pageSize).coerceAtMost(all.size)
                val to = (from + pageSize).coerceAtMost(all.size)
                LibraryResult.ofItemList(ImmutableList.copyOf(all.subList(from, to)), params)
            },
            worker,
        )

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> = Futures.submit(
            java.util.concurrent.Callable {
                AutoLibrary.item(service, mediaId)?.let { LibraryResult.ofItem(it, null) }
                    ?: LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
            },
            worker,
        )
    }
}
