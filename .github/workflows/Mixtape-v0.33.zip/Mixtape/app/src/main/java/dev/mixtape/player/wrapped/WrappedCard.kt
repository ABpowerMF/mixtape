package dev.mixtape.player.wrapped

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.Size
import androidx.core.content.FileProvider
import dev.mixtape.player.library.LocalLibrary
import java.io.File

/** Draws a 1080×1920 story card of a recap and shares it. */
object WrappedCard {

    data class Colors(val background: Int, val text: Int, val dim: Int, val accent: Int)

    fun render(context: Context, w: Wrapped, c: Colors): Bitmap {
        val width = 1080
        val height = 1920
        val coverSize = 400
        val cover = w.topSongs.firstOrNull()?.id?.toLongOrNull()?.let { id ->
            runCatching { context.contentResolver.loadThumbnail(LocalLibrary.contentUri(id), Size(coverSize, coverSize), null) }.getOrNull()
        }
        // Measure first, then draw scaled so everything always fits the story without overlapping.
        val needed = draw(Canvas(Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)), w, c, cover, coverSize, width)
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(c.background)
        val scale = minOf(1f, height / needed)
        canvas.save()
        canvas.translate(width * (1 - scale) / 2f, (height - needed * scale) / 2f)
        canvas.scale(scale, scale)
        draw(canvas, w, c, cover, coverSize, width)
        canvas.restore()
        return bmp
    }

    /** Draws the card top to bottom; returns the height used. */
    private fun draw(canvas: Canvas, w: Wrapped, c: Colors, cover: Bitmap?, coverSize: Int, width: Int): Float {
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        fun paint(size: Float, color: Int, bold: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) monoBold else mono
        }
        fun fit(text: String, p: Paint, max: Float): String {
            if (p.measureText(text) <= max) return text
            var t = text
            while (t.isNotEmpty() && p.measureText("$t…") > max) t = t.dropLast(1)
            return "$t…"
        }
        fun plural(n: Int, one: String) = "$n $one" + if (n == 1) "" else "s"
        val left = 80f
        val maxText = width - left * 2 - 60f
        var y = 130f
        canvas.drawText("> MIXTAPE WRAPPED", left, y, paint(50f, c.accent, bold = true))
        y += 62f
        canvas.drawText(w.label, left, y, paint(40f, c.dim))

        // Cover of the top song, big numbers beside it
        y += 50f
        val coverRect = RectF(left, y, left + coverSize, y + coverSize)
        if (cover != null) {
            canvas.drawBitmap(cover, null, coverRect, Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            canvas.drawRect(coverRect, Paint().apply { color = c.dim; alpha = 60 })
        }
        val nx = left + coverSize + 50f
        val hours = w.totalMs / 3_600_000
        val minutes = (w.totalMs / 60_000) % 60
        val total = when {
            hours >= 10 -> "$hours h"
            hours >= 1 -> "${hours}h ${minutes}m"
            else -> "${w.totalMs / 60_000} min"
        }
        canvas.drawText(total, nx, y + 130f, paint(if (total.length > 6) 88f else 110f, c.text, bold = true))
        canvas.drawText("listened", nx, y + 185f, paint(38f, c.dim))
        canvas.drawText(plural(w.plays, "play"), nx, y + 270f, paint(44f, c.text))
        canvas.drawText(plural(w.differentSongs, "song"), nx, y + 330f, paint(44f, c.text))
        canvas.drawText(plural(w.activeDays, "day"), nx, y + 390f, paint(44f, c.text))
        y += coverSize + 100f

        if (w.topSongs.isNotEmpty()) {
            canvas.drawText("> top songs", left, y, paint(46f, c.accent, bold = true))
            y += 16f
            w.topSongs.forEachIndexed { i, s ->
                y += 64f
                canvas.drawText("${i + 1}", left, y, paint(44f, c.dim, bold = true))
                canvas.drawText(fit(s.title, paint(44f, c.text, bold = true), maxText), left + 60f, y, paint(44f, c.text, bold = true))
                canvas.drawText(fit(s.artist, paint(30f, c.dim), maxText), left + 60f, y + 36f, paint(30f, c.dim))
                y += 36f
            }
            y += 80f
        }
        if (w.topArtists.isNotEmpty()) {
            canvas.drawText("> top artists", left, y, paint(46f, c.accent, bold = true))
            y += 10f
            w.topArtists.forEachIndexed { i, a ->
                y += 60f
                canvas.drawText("${i + 1}", left, y, paint(42f, c.dim, bold = true))
                canvas.drawText(fit(a.name, paint(42f, c.text), maxText), left + 60f, y, paint(42f, c.text))
            }
            y += 90f
        }

        // Listening by hour, placed after everything above (never on top of it)
        canvas.drawText("> when you listen", left, y, paint(42f, c.accent, bold = true))
        val chartTop = y + 30f
        val chartBottom = chartTop + 170f
        val max = (w.hours.maxOrNull() ?: 0L).coerceAtLeast(1L)
        val barW = (width - left * 2) / 24f
        val bar = Paint().apply { color = c.accent }
        val empty = Paint().apply { color = c.dim; alpha = 70 }
        for (h in 0 until 24) {
            val hgt = (chartBottom - chartTop) * w.hours[h] / max
            if (w.hours[h] == 0L) {
                canvas.drawRect(left + h * barW + 4f, chartBottom - 4f, left + (h + 1) * barW - 4f, chartBottom, empty)
            } else {
                canvas.drawRect(left + h * barW + 4f, chartBottom - hgt.coerceAtLeast(6f), left + (h + 1) * barW - 4f, chartBottom, bar)
            }
        }
        listOf(0 to "0h", 6 to "6h", 12 to "12h", 18 to "18h").forEach { (h, label) ->
            canvas.drawText(label, left + h * barW, chartBottom + 44f, paint(30f, c.dim))
        }
        y = chartBottom + 44f
        w.topDay?.let { (day, _) ->
            y += 80f
            canvas.drawText("favourite day: $day", left, y, paint(38f, c.text))
        }
        return y + 80f
    }

    /** Saves the card and opens the share sheet (stories, chats…). */
    fun share(context: Context, bitmap: Bitmap) {
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "mixtape-wrapped.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "Share your Mixtape Wrapped").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
