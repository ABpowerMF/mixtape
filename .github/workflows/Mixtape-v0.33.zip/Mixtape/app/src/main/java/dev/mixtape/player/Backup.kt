package dev.mixtape.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * One file with everything personal: playlists (and your song picks), stats and listening history,
 * saved lyrics and artist info, your imported font, and the settings. Spotify/YouTube logins are
 * left out on purpose.
 */
object Backup {

    private val FILES = listOf("playlists.json", "stats.json", "listens.log")
    private val FOLDERS = listOf("lyrics", "artists", "fonts")
    private val PREFS = listOf("mixtape", "audiofx")

    fun export(context: Context, target: Uri) {
        val dir = context.filesDir
        val out = context.contentResolver.openOutputStream(target) ?: throw IllegalStateException("Couldn't write the backup file.")
        ZipOutputStream(out).use { zip ->
            fun add(name: String, bytes: ByteArray) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
            add("mixtape-backup.json", JSONObject().put("version", 1).put("made", System.currentTimeMillis()).toString().toByteArray())
            FILES.map { File(dir, it) }.filter { it.exists() }.forEach { add("files/${it.name}", it.readBytes()) }
            FOLDERS.forEach { folder ->
                File(dir, folder).listFiles()?.filter { it.isFile }?.forEach { add("files/$folder/${it.name}", it.readBytes()) }
            }
            PREFS.forEach { name -> add("prefs/$name.json", prefsToJson(context, name).toString().toByteArray()) }
        }
    }

    /** Replaces the current data with the backup. The app restarts afterwards. */
    fun restore(context: Context, source: Uri) {
        val dir = context.filesDir
        val input = context.contentResolver.openInputStream(source) ?: throw IllegalStateException("Couldn't open that file.")
        var valid = false
        val prefs = HashMap<String, JSONObject>()
        val files = HashMap<String, ByteArray>()
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                val bytes = zip.readBytes()
                when {
                    e.name == "mixtape-backup.json" -> valid = true
                    e.name.startsWith("prefs/") -> prefs[e.name.removePrefix("prefs/").removeSuffix(".json")] = JSONObject(String(bytes))
                    e.name.startsWith("files/") && !e.name.contains("..") -> files[e.name.removePrefix("files/")] = bytes
                }
            }
        }
        if (!valid) throw IllegalStateException("That isn't a Mixtape backup.")
        FOLDERS.forEach { File(dir, it).deleteRecursively() }
        files.forEach { (path, bytes) ->
            val top = path.substringBefore('/')
            if (path in FILES || top in FOLDERS) {
                File(dir, path).apply { parentFile?.mkdirs() }.writeBytes(bytes)
            }
        }
        prefs.filterKeys { it in PREFS }.forEach { (name, json) -> jsonToPrefs(context, name, json) }
    }

    fun restartApp(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        context.startActivity(launch)
        Runtime.getRuntime().exit(0)
    }

    private fun prefsToJson(context: Context, name: String): JSONObject {
        val out = JSONObject()
        context.getSharedPreferences(name, Context.MODE_PRIVATE).all.forEach { (key, value) ->
            val entry = when (value) {
                is Boolean -> JSONObject().put("t", "b").put("v", value)
                is Int -> JSONObject().put("t", "i").put("v", value)
                is Long -> JSONObject().put("t", "l").put("v", value)
                is Float -> JSONObject().put("t", "f").put("v", value.toDouble())
                is String -> JSONObject().put("t", "s").put("v", value)
                is Set<*> -> JSONObject().put("t", "set").put("v", JSONArray(value.map { it.toString() }))
                else -> null
            }
            if (entry != null) out.put(key, entry)
        }
        return out
    }

    private fun jsonToPrefs(context: Context, name: String, json: JSONObject) {
        val edit = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val e = json.optJSONObject(key) ?: continue
            when (e.optString("t")) {
                "b" -> edit.putBoolean(key, e.optBoolean("v"))
                "i" -> edit.putInt(key, e.optInt("v"))
                "l" -> edit.putLong(key, e.optLong("v"))
                "f" -> edit.putFloat(key, e.optDouble("v").toFloat())
                "s" -> edit.putString(key, e.optString("v"))
                "set" -> {
                    val arr = e.optJSONArray("v") ?: JSONArray()
                    edit.putStringSet(key, (0 until arr.length()).map { arr.optString(it) }.toSet())
                }
            }
        }
        edit.commit()
    }
}
