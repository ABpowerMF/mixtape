package dev.mixtape.player.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DragHandle
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.Player
import dev.mixtape.player.playback.QueueEntry
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

/** Keys for the upcoming songs: stable while dragging, even if a song is in the queue twice. */
private fun keysOf(entries: List<QueueEntry>): List<String> {
    val seen = HashMap<String, Int>()
    return entries.map { e ->
        val n = (seen[e.mediaId] ?: 0) + 1
        seen[e.mediaId] = n
        "${e.mediaId}#$n"
    }
}

/**
 * The queue, like Spotify: now playing, "Next in queue" (songs you added), then "Next from" the
 * playlist. Hold the ≡ handle and drag to reorder; swipe a song left to remove it.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueScreen(vm: MainViewModel) {
    val queue by vm.player.queue.collectAsStateWithLifecycle()
    val now by vm.player.state.collectAsStateWithLifecycle()
    val playingFrom by vm.player.context.collectAsStateWithLifecycle()
    val current = queue.firstOrNull { it.current }

    // Local copy so dragging feels instant; it follows the player whenever you're not dragging.
    var upcoming by remember { mutableStateOf(queue.filter { !it.current }) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(queue) { if (!dragging) upcoming = queue.filter { !it.current } }
    val keys = keysOf(upcoming)
    val queuedCount = upcoming.count { it.queued }
    val base = (current?.index ?: -1) + 1

    val listState = rememberLazyListState()
    val reorder = rememberReorderableLazyListState(listState) { from, to ->
        val fromPos = keys.indexOfFirst { it == from.key }
        val toPos = keys.indexOfFirst { it == to.key }
        if (fromPos < 0 || toPos < 0) return@rememberReorderableLazyListState
        upcoming = upcoming.toMutableList().apply { add(toPos, removeAt(fromPos)) }
        vm.player.moveInQueue(base + fromPos, base + toPos)
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Column {
                    Text(Ui.path("queue"), style = MaterialTheme.typography.titleLarge)
                    if (playingFrom.isNotBlank()) {
                        Text("Playing $playingFrom", style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
                    }
                }
            },
            navigationIcon = { IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        if (current == null) {
            EmptyState(title = "Nothing in the queue", body = "Play something, or swipe a song to the right to add it.")
        } else {

        LazyColumn(Modifier.weight(1f), state = listState, contentPadding = PaddingValues(bottom = 12.dp)) {
            item(key = "now") {
                Header("now playing")
                QueueRow(vm, current, highlighted = true) {
                    FilledIconButton(
                        shape = TermShape,
                        onClick = vm.player::toggle,
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                    ) {
                        Icon(if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = if (now.isPlaying) "Pause" else "Play")
                    }
                }
            }
            upcoming.forEachIndexed { pos, e ->
                if (pos == 0 && queuedCount > 0) {
                    item(key = "h-queue") {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.weight(1f)) { Header("next in queue") }
                            TextButton(onClick = vm.player::clearQueue, modifier = Modifier.padding(end = 8.dp)) {
                                Text(Ui.btn("clear queue"), color = Mix.Tape)
                            }
                        }
                    }
                }
                if (pos == queuedCount) {
                    item(key = "h-from") { Header("next from: " + playingFrom.ifBlank { "this list" }) }
                }
                val key = keys[pos]
                item(key = key) {
                    ReorderableItem(reorder, key = key) { isDragging ->
                        val remove by rememberUpdatedState { vm.player.removeFromQueue(base + pos) }
                        val swipe = rememberSwipeToDismissBoxState(
                            confirmValueChange = { v ->
                                if (v == SwipeToDismissBoxValue.EndToStart) remove()
                                false
                            },
                            positionalThreshold = { it * 0.35f },
                        )
                        SwipeToDismissBox(
                            state = swipe,
                            enableDismissFromStartToEnd = false,
                            backgroundContent = {
                                if (swipe.dismissDirection == SwipeToDismissBoxValue.EndToStart) Row(
                                    Modifier
                                        .fillMaxSize()
                                        .background(Mix.Alert.copy(alpha = 0.25f))
                                        .padding(end = 24.dp),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(Ui.btn("remove"), color = Mix.Alert, style = MaterialTheme.typography.labelLarge)
                                    Spacer(Modifier.width(8.dp))
                                    Icon(Icons.Filled.Delete, contentDescription = null, tint = Mix.Alert)
                                }
                            },
                        ) {
                            Box(
                                Modifier
                                    .then(if (isDragging) Modifier.shadow(8.dp, TermShape) else Modifier)
                                    .background(if (isDragging) Mix.Raised else if (Mix.wallpaper != null) Color.Transparent else MaterialTheme.colorScheme.background),
                            ) {
                                QueueRow(vm, e, highlighted = false, onClick = { vm.player.jumpTo(base + pos) }) {
                                    IconButton(
                                        onClick = {},
                                        modifier = Modifier.draggableHandle(
                                            onDragStarted = { dragging = true },
                                            onDragStopped = { dragging = false },
                                        ),
                                    ) {
                                        Icon(Icons.Filled.DragHandle, contentDescription = "Drag to reorder", tint = Mix.Fog)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom: shuffle and repeat, like Spotify's queue.
        Row(
            Modifier
                .fillMaxWidth()
                .background(Mix.Deep)
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BottomButton(
                label = "Shuffle",
                on = now.shuffle,
                icon = { Icon(Icons.Filled.Shuffle, contentDescription = null, tint = if (now.shuffle) Mix.Tape else Mix.Paper) },
                onClick = vm.player::toggleShuffle,
                modifier = Modifier.weight(1f),
            )
            BottomButton(
                label = when (now.repeatMode) {
                    Player.REPEAT_MODE_ONE -> "Repeat one"
                    Player.REPEAT_MODE_ALL -> "Repeat all"
                    else -> "Repeat"
                },
                on = now.repeatMode != Player.REPEAT_MODE_OFF,
                icon = {
                    Icon(
                        if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        contentDescription = null,
                        tint = if (now.repeatMode != Player.REPEAT_MODE_OFF) Mix.Tape else Mix.Paper,
                    )
                },
                onClick = vm.player::cycleRepeat,
                modifier = Modifier.weight(1f),
            )
        }
        }
    }
}

@Composable
private fun Header(text: String) {
    Text(
        Ui.head(text),
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 6.dp),
    )
}

@Composable
private fun QueueRow(
    vm: MainViewModel,
    e: QueueEntry,
    highlighted: Boolean,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit,
) {
    val track = vm.trackById(e.mediaId)
    Row(
        Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Artwork(track?.artUri, Modifier.size(52.dp), corner = if (Mix.rounded) 8.dp else 2.dp, iconSize = 22.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                e.title.ifEmpty { track?.title ?: "Unknown song" },
                style = MaterialTheme.typography.titleMedium,
                color = if (highlighted) Mix.Tape else Mix.Paper,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(e.artist.ifEmpty { track?.artist.orEmpty() }, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
        }
        trailing()
    }
}

@Composable
private fun BottomButton(label: String, on: Boolean, icon: @Composable () -> Unit, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .background(if (on) Mix.Raised else Mix.Ink, TermShape)
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        icon()
        Text(label, style = MaterialTheme.typography.labelMedium, color = if (on) Mix.Tape else Mix.Paper)
    }
}
