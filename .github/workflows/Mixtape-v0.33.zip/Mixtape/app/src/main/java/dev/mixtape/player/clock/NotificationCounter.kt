package dev.mixtape.player.clock

import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Counts your notifications for the clock screen (only if you allow "notification access").
 * Nothing is read or stored apart from how many there are and which apps they're from.
 */
class NotificationCounter : NotificationListenerService() {

    override fun onListenerConnected() = update()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = update()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = update()

    override fun onListenerDisconnected() {
        _count.value = 0
        _apps.value = emptyList()
    }

    private fun update() {
        val list = runCatching { activeNotifications?.toList() }.getOrNull().orEmpty()
            .filter { it.isClearable && !it.isOngoing && it.packageName != packageName }
        _count.value = list.size
        _apps.value = list.map { it.packageName }.distinct().take(5)
    }

    companion object {
        private val _count = MutableStateFlow(0)
        val count: StateFlow<Int> = _count
        private val _apps = MutableStateFlow<List<String>>(emptyList())
        /** Packages with notifications (for their icons), newest first. */
        val apps: StateFlow<List<String>> = _apps

        fun hasAccess(context: Context): Boolean =
            NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)
    }
}
