package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.playback.ListenStats
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import java.text.DateFormat
import java.util.Date

/** "12 h 05 m", "34 m", "45 s". */
fun formatListened(ms: Long): String {
    val minutes = ms / 60_000
    return when {
        minutes >= 60 -> "%d h %02d m".format(minutes / 60, minutes % 60)
        minutes >= 1 -> "$minutes m"
        else -> "${ms / 1000} s"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(vm: MainViewModel) {
    LaunchedEffect(Unit) { vm.refreshStats() }
    var confirmReset by remember { mutableStateOf(false) }

    val entries = vm.stats
    val totalMs = entries.sumOf { it.listenedMs }
    val plays = entries.sumOf { it.plays }
    val topSongs = entries.filter { it.listenedMs > 0 }.sortedByDescending { it.listenedMs }.take(20)
    val topArtists = entries
        .filter { it.artist.isNotBlank() }
        .groupBy { it.artist.substringBefore(",").trim() }
        .map { (artist, list) -> Triple(artist, list.sumOf { it.listenedMs }, list.sumOf { it.plays }) }
        .sortedByDescending { it.second }
        .take(10)
    val maxSong = topSongs.firstOrNull()?.listenedMs ?: 1L
    val maxArtist = topArtists.firstOrNull()?.second ?: 1L

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("stats"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                androidx.compose.material3.TextButton(onClick = { vm.push(Screen.Wrapped) }) {
                    Text(dev.mixtape.player.ui.theme.Ui.btn("wrapped"), color = Mix.Tape)
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Column(Modifier.padding(horizontal = 20.dp)) {
                    Text("total listening", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                    Text(formatListened(totalMs), style = MaterialTheme.typography.displaySmall, color = Mix.Tape)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "$plays plays · ${entries.count { it.plays > 0 }} different songs",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Paper,
                    )
                    if (vm.statsSince > 0) {
                        Text(
                            "since " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(vm.statsSince)),
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                        )
                    }
                }
            }
            if (entries.isEmpty()) {
                item {
                    Text(
                        "Nothing yet. Play some music and your stats show up here.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        modifier = Modifier.padding(20.dp),
                    )
                }
            } else {
                item { StatsHeading("most listened songs") }
                itemsIndexed(topSongs, key = { _, e -> "s" + e.id }) { i, e ->
                    StatBar(
                        rank = i + 1,
                        title = e.title.ifEmpty { "Unknown song" },
                        subtitle = listOf(e.artist, "${e.plays} plays").filter { it.isNotBlank() }.joinToString(" · "),
                        value = formatListened(e.listenedMs),
                        fraction = e.listenedMs.toFloat() / maxSong,
                    )
                }
                if (topArtists.isNotEmpty()) {
                    item { StatsHeading("top artists") }
                    itemsIndexed(topArtists, key = { _, a -> "a" + a.first }) { i, a ->
                        StatBar(
                            rank = i + 1,
                            title = a.first,
                            subtitle = "${a.third} plays",
                            value = formatListened(a.second),
                            fraction = a.second.toFloat() / maxArtist,
                        )
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { confirmReset = true },
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                        modifier = Modifier.padding(20.dp),
                    ) { Text(Ui.btn("reset stats"), color = Mix.Alert) }
                }
            }
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset stats?") },
            text = { Text("All listening time and play counts are cleared.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmReset = false
                    vm.resetStats()
                }) { Text("Reset", color = Mix.Alert) }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel", color = Mix.Paper) } },
            containerColor = Mix.Deep,
        )
    }
}

@Composable
private fun StatsHeading(text: String) {
    Text(
        Ui.head(text),
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 8.dp),
    )
}

/** A ranked row with a bar showing its share of the top entry. */
@Composable
private fun StatBar(rank: Int, title: String, subtitle: String, value: String, fraction: Float) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("%2d".format(rank), style = MaterialTheme.typography.bodyMedium, color = Mix.Fog, modifier = Modifier.width(32.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(value, style = MaterialTheme.typography.bodyMedium, color = Mix.Paper)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .padding(start = 32.dp)
                .fillMaxWidth()
                .height(4.dp)
                .background(Mix.Raised),
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction.coerceIn(0.02f, 1f))
                    .fillMaxHeight()
                    .background(Mix.Tape),
            )
        }
    }
}
