package dev.mixtape.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import dev.mixtape.player.wrapped.WrapPeriod
import dev.mixtape.player.wrapped.WrappedCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Mixtape Wrapped: your listening recap for a month, a year or all time, shareable as an image. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WrappedScreen(vm: MainViewModel) {
    var period by rememberSaveable { mutableStateOf(WrapPeriod.THIS_MONTH) }
    LaunchedEffect(period) { vm.loadWrapped(period) }
    val w = vm.wrapped?.takeIf { it.period == period }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("wrapped"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = { IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            actions = {
                if (w != null && w.totalMs > 0) {
                    IconButton(onClick = {
                        scope.launch {
                            val colors = WrappedCard.Colors(Mix.Ink.toArgb(), Mix.Paper.toArgb(), Mix.Fog.toArgb(), Mix.Tape.toArgb())
                            val card = withContext(Dispatchers.Default) { WrappedCard.render(context, w, colors) }
                            WrappedCard.share(context, card)
                        }
                    }) { Icon(Icons.Filled.Share, contentDescription = "Share as image") }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(WrapPeriod.entries) { p ->
                val on = p == period
                Text(
                    p.label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (on) Mix.Ink else Mix.Paper,
                    modifier = Modifier
                        .background(if (on) Mix.Tape else Mix.Raised, TermShape)
                        .clickable { period = p }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
        }
        when {
            w == null -> Text("…", modifier = Modifier.padding(20.dp), color = Mix.Fog)
            w.totalMs == 0L -> EmptyState(
                title = "No listening yet",
                body = "Wrapped counts from this version on. Play some music and come back.",
            )
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
                item {
                    Text(w.label, style = MaterialTheme.typography.titleMedium, color = Mix.Fog)
                    Text(formatListened(w.totalMs), style = MaterialTheme.typography.displaySmall, color = Mix.Tape)
                    Text(
                        "${w.plays} plays · ${w.differentSongs} songs · ${w.activeDays} days",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Mix.Paper,
                    )
                    w.topDay?.let { (day, ms) ->
                        Text("Favourite day: $day (${formatListened(ms)})", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
                    }
                    Spacer(Modifier.height(20.dp))
                    Text(Ui.head("top songs"), style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
                }
                items(w.topSongs.withIndex().toList()) { (i, s) ->
                    val track = vm.trackById(s.id)
                    Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", style = MaterialTheme.typography.titleMedium, color = Mix.Fog, modifier = Modifier.width(28.dp))
                        Artwork(track?.artUri, Modifier.size(48.dp), corner = if (Mix.rounded) 8.dp else 2.dp, iconSize = 20.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${s.artist} · ${formatListened(s.ms)}", style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(16.dp))
                    Text(Ui.head("top artists"), style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
                }
                items(w.topArtists.withIndex().toList()) { (i, a) ->
                    Row(Modifier.padding(vertical = 6.dp)) {
                        Text("${i + 1}", style = MaterialTheme.typography.titleMedium, color = Mix.Fog, modifier = Modifier.width(28.dp))
                        Text(a.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), maxLines = 1)
                        Text(formatListened(a.ms), style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
                    }
                }
                item {
                    Spacer(Modifier.height(16.dp))
                    Text(Ui.head("when you listen"), style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
                    Spacer(Modifier.height(8.dp))
                    val accent = Mix.Tape
                    val max = (w.hours.maxOrNull() ?: 0L).coerceAtLeast(1L)
                    Canvas(
                        Modifier
                            .fillMaxWidth()
                            .height(120.dp),
                    ) {
                        val barW = size.width / 24f
                        for (h in 0 until 24) {
                            val bh = (size.height * w.hours[h] / max).coerceAtLeast(2f)
                            drawRect(accent, Offset(h * barW + 2f, size.height - bh), Size(barW - 4f, bh))
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        listOf("0h", "6h", "12h", "18h", "24h").forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = Mix.Fog) }
                    }
                    Spacer(Modifier.height(24.dp))
                    Button(
                        shape = TermShape,
                        onClick = {
                            scope.launch {
                                val colors = WrappedCard.Colors(Mix.Ink.toArgb(), Mix.Paper.toArgb(), Mix.Fog.toArgb(), Mix.Tape.toArgb())
                                val card = withContext(Dispatchers.Default) { WrappedCard.render(context, w, colors) }
                                WrappedCard.share(context, card)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Share as a story")
                    }
                }
            }
        }
    }
}
