package dev.mixtape.player.playback

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Listening time and play counts per song, plus a small history of listening sessions
 * (when, what, how long) for Mixtape Wrapped and smart playlists. All on the phone.
 */
object ListenStats {

    data class Entry(
        val id: String,
        val title: String,
        val artist: String,
        val listenedMs: Long,
        val plays: Int,
        /** Last time it counted as played (0 = unknown). */
        val lastPlayed: Long = 0L,
    )

    /** One stretch of listening, for recaps. */
    data class Session(val at: Long, val id: String, val title: String, val artist: String, val ms: Long, val played: Boolean)

    /** A song counts as played after this much listening. */
    const val PLAY_AFTER_MS = 30_000L

    private val entries = HashMap<String, Entry>()
    private var file: File? = null
    private var history: File? = null
    private var since: Long = 0L

    @Synchronized
    fun init(context: Context) {
        if (file != null) return
        val dir = context.applicationContext.filesDir
        val f = File(dir, "stats.json")
        file = f
        history = File(dir, "listens.log")
        runCatching {
            if (!f.exists()) return@runCatching
            val json = JSONObject(f.readText())
            since = json.optLong("since")
            val arr = json.optJSONArray("songs") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val e = Entry(
                    o.optString("id"), o.optString("title"), o.optString("artist"),
                    o.optLong("ms"), o.optInt("plays"), o.optLong("last"),
                )
                if (e.id.isNotEmpty()) entries[e.id] = e
            }
        }
        if (since == 0L) since = System.currentTimeMillis()
    }

    /** Re-reads the files (after restoring a backup). */
    @Synchronized
    fun reload(context: Context) {
        entries.clear()
        file = null
        init(context)
    }

    @Synchronized
    fun add(id: String, title: String, artist: String, ms: Long, countPlay: Boolean) {
        if (ms <= 0 && !countPlay) return
        val now = System.currentTimeMillis()
        val old = entries[id]
        entries[id] = Entry(
            id = id,
            title = title.ifEmpty { old?.title.orEmpty() },
            artist = artist.ifEmpty { old?.artist.orEmpty() },
            listenedMs = (old?.listenedMs ?: 0L) + ms.coerceAtLeast(0L),
            plays = (old?.plays ?: 0) + if (countPlay) 1 else 0,
            lastPlayed = if (countPlay) now else old?.lastPlayed ?: 0L,
        )
        save()
        appendHistory(Session(now, id, title.ifEmpty { old?.title.orEmpty() }, artist.ifEmpty { old?.artist.orEmpty() }, ms, countPlay))
    }

    @Synchronized
    fun snapshot(): List<Entry> = entries.values.toList()

    @Synchronized
    fun trackingSince(): Long = since

    /** Listening sessions between [from] and [to] (milliseconds since 1970). */
    @Synchronized
    fun sessions(from: Long, to: Long): List<Session> {
        val f = history ?: return emptyList()
        if (!f.exists()) return emptyList()
        return f.readLines().mapNotNull { line ->
            val p = line.split('\t')
            if (p.size < 6) return@mapNotNull null
            val at = p[0].toLongOrNull() ?: return@mapNotNull null
            if (at < from || at >= to) return@mapNotNull null
            Session(at, p[1], p[2], p[3], p[4].toLongOrNull() ?: 0L, p[5] == "1")
        }
    }

    @Synchronized
    fun reset() {
        entries.clear()
        since = System.currentTimeMillis()
        save()
        history?.delete()
    }

    private fun appendHistory(s: Session) {
        val f = history ?: return
        val clean = { t: String -> t.replace('\t', ' ').replace('\n', ' ') }
        runCatching {
            f.appendText("${s.at}\t${s.id}\t${clean(s.title)}\t${clean(s.artist)}\t${s.ms}\t${if (s.played) 1 else 0}\n")
        }
    }

    private fun save() {
        val f = file ?: return
        val arr = JSONArray()
        entries.values.forEach { e ->
            arr.put(
                JSONObject().put("id", e.id).put("title", e.title).put("artist", e.artist)
                    .put("ms", e.listenedMs).put("plays", e.plays).put("last", e.lastPlayed),
            )
        }
        runCatching { f.writeText(JSONObject().put("since", since).put("songs", arr).toString()) }
    }
}
