package dev.mixtape.player.library

import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import dev.mixtape.player.download.DownloadQueue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Changes a song's title, artist, album and cover inside the file itself (so every app sees it),
 * using the ffmpeg that comes with the downloader. The audio is copied untouched, not re-encoded.
 */
object TagEditor {

    sealed interface Result {
        data object Done : Result
        /** Android must ask you first (a file another app made). Launch it, then save again. */
        class NeedPermission(val request: IntentSender) : Result
        class Failed(val reason: String) : Result
    }

    suspend fun save(
        context: Context,
        track: LocalTrack,
        title: String,
        artist: String,
        album: String,
        cover: Uri?,
    ): Result = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val uri = LocalLibrary.contentUri(track.id)

        // Can we write it? Files Mixtape made are fine; others need a yes from you once.
        try {
            resolver.openFileDescriptor(uri, "rw")?.close()
        } catch (e: SecurityException) {
            return@withContext if (Build.VERSION.SDK_INT >= 30) {
                Result.NeedPermission(MediaStore.createWriteRequest(resolver, listOf(uri)).intentSender)
            } else {
                Result.Failed("Android doesn't allow changing this file.")
            }
        }

        runCatching { DownloadQueue.prepareTools() }.onFailure { return@withContext Result.Failed("The editor isn't ready: ${it.message}") }

        val ext = track.fileName.substringAfterLast('.', "mp3").lowercase().ifEmpty { "mp3" }
        val dir = File(context.cacheDir, "tag-edit").apply { deleteRecursively(); mkdirs() }
        try {
            val input = File(dir, "in.$ext")
            val output = File(dir, "out.$ext")
            resolver.openInputStream(uri)?.use { i -> input.outputStream().use { i.copyTo(it) } }
                ?: return@withContext Result.Failed("Couldn't read the file.")

            // Ogg/Opus can't take a cover through ffmpeg; the text tags still work.
            val canCover = ext in setOf("mp3", "m4a", "mp4", "aac", "flac")
            val coverFile = if (cover != null && canCover) {
                File(dir, "cover.jpg").also { f ->
                    resolver.openInputStream(cover)?.use { i -> f.outputStream().use { i.copyTo(it) } }
                }
            } else {
                null
            }

            val cmd = ArrayList<String>()
            cmd += File(context.applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath
            cmd += listOf("-y", "-i", input.absolutePath)
            if (coverFile != null) cmd += listOf("-i", coverFile.absolutePath)
            cmd += listOf("-map", "0:a")
            if (coverFile != null) {
                cmd += listOf("-map", "1:0", "-c:v", "mjpeg", "-disposition:v:0", "attached_pic")
            } else if (canCover) {
                cmd += listOf("-map", "0:v?", "-c:v", "copy")
            }
            cmd += listOf("-c:a", "copy", "-map_metadata", "0")
            cmd += listOf("-metadata", "title=$title", "-metadata", "artist=$artist", "-metadata", "album=$album")
            if (ext == "mp3") cmd += listOf("-id3v2_version", "3")
            cmd += output.absolutePath

            val process = ProcessBuilder(cmd).redirectErrorStream(true).apply {
                environment()["LD_LIBRARY_PATH"] =
                    File(context.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib").absolutePath
            }.start()
            val log = process.inputStream.bufferedReader().readText()
            if (!process.waitFor(60, TimeUnit.SECONDS)) {
                process.destroy()
                return@withContext Result.Failed("Took too long.")
            }
            if (process.exitValue() != 0 || !output.exists() || output.length() == 0L) {
                return@withContext Result.Failed(log.lines().lastOrNull { it.isNotBlank() }?.take(120) ?: "ffmpeg failed")
            }
            resolver.openOutputStream(uri, "wt")?.use { out -> output.inputStream().use { it.copyTo(out) } }
                ?: return@withContext Result.Failed("Couldn't write the file.")
            Result.Done
        } catch (e: Exception) {
            Result.Failed(e.message ?: e.javaClass.simpleName)
        } finally {
            dir.deleteRecursively()
        }
    }
}
