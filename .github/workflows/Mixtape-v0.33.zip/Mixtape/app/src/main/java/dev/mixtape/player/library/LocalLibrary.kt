package dev.mixtape.player.library

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore

/** A music file on this phone, as indexed by Android's media store. */
data class LocalTrack(
    val id: Long,
    val title: String,
    /** Empty when the file has no artist tag. */
    val artist: String,
    val album: String,
    val durationMs: Long,
    val albumId: Long,
    val fileName: String = "",
    val bitrateKbps: Int = 0,
    /** Folder on the phone, e.g. "Music/Mixtape/Kanye West - Graduation/". */
    val folder: String = "",
    /** Track number on its album (0 = unknown). */
    val trackNo: Int = 0,
    /** When the file arrived on the phone (milliseconds). */
    val addedAt: Long = 0L,
) {
    val uri: Uri get() = LocalLibrary.contentUri(id)
    val artUri: Uri get() = ContentUris.withAppendedId(ALBUM_ART, albumId)

    private companion object {
        val ALBUM_ART: Uri = Uri.parse("content://media/external/audio/albumart")
    }
}

object LocalLibrary {

    private val collection: Uri =
        if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

    /** Uri to watch for new or removed music files. */
    val watchUri: Uri get() = collection

    fun contentUri(id: Long): Uri = ContentUris.withAppendedId(collection, id)

    // "01 - ", "07. ", "3_", "12) " at the start of a filename, or "04 " with a leading zero
    private val TRACK_NUMBER = Regex("^\\s*(\\d{1,3}\\s*[-._)]\\s*|0\\d\\s+)")

    fun scan(context: Context): List<LocalTrack> {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.RELATIVE_PATH,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.DATE_ADDED,
        ) + if (Build.VERSION.SDK_INT >= 30) arrayOf(MediaStore.Audio.Media.BITRATE) else emptyArray()
        val out = ArrayList<LocalTrack>()
        context.contentResolver.query(
            collection,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC",
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val folderCol = c.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
            val trackCol = c.getColumnIndex(MediaStore.Audio.Media.TRACK)
            val addedCol = c.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
            val bitrateCol = if (Build.VERSION.SDK_INT >= 30) c.getColumnIndex(MediaStore.Audio.Media.BITRATE) else -1

            while (c.moveToNext()) {
                val fileName = c.getString(nameCol).orEmpty()
                val baseName = fileName.substringBeforeLast('.')
                var title = c.getString(titleCol).orEmpty().trim()
                var artist = c.getString(artistCol).orEmpty().trim()
                if (artist == MediaStore.UNKNOWN_STRING) artist = ""

                // No real title tag (Android falls back to the filename): read "Artist - Title" from the name.
                if (title.isEmpty() || title == baseName) {
                    val cleaned = baseName.replace(TRACK_NUMBER, "").trim()
                    val parts = cleaned.split(" - ", limit = 2)
                    if (parts.size == 2) {
                        if (artist.isEmpty()) artist = parts[0].trim()
                        title = parts[1].trim()
                    } else {
                        title = cleaned
                    }
                }

                var album = c.getString(albumCol).orEmpty()
                if (album == MediaStore.UNKNOWN_STRING) album = ""

                out += LocalTrack(
                    id = c.getLong(idCol),
                    title = title.ifEmpty { fileName },
                    artist = artist,
                    album = album,
                    durationMs = c.getLong(durationCol),
                    albumId = c.getLong(albumIdCol),
                    fileName = fileName,
                    bitrateKbps = if (bitrateCol >= 0 && !c.isNull(bitrateCol)) c.getInt(bitrateCol) / 1000 else 0,
                    folder = if (folderCol >= 0) c.getString(folderCol).orEmpty() else "",
                    // MediaStore stores disc 1 track 3 as 1003.
                    trackNo = if (trackCol >= 0 && !c.isNull(trackCol)) c.getInt(trackCol) % 1000 else 0,
                    addedAt = if (addedCol >= 0 && !c.isNull(addedCol)) c.getLong(addedCol) * 1000 else 0L,
                )
            }
        }
        return out
    }
}
