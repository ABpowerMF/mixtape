package dev.mixtape.player.playback

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import dev.mixtape.player.data.PlaylistStore
import dev.mixtape.player.library.LocalLibrary
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.library.Matcher

/**
 * What Android Auto (and other car/watch screens) can browse: your playlists, albums,
 * smart playlists and all songs. Built from the same files the app uses, refreshed each minute.
 */
object AutoLibrary {

    const val ROOT = "root"
    private const val PLAYLISTS = "playlists"
    private const val ALBUMS = "albums"
    private const val SMART = "smart"
    private const val SONGS = "songs"
    /** Playable ids look like "parent|trackId", so choosing a song plays the whole list from it. */
    private const val SEP = "|"

    private var loadedAt = 0L
    private var library: List<LocalTrack> = emptyList()
    private var lists: Map<String, Pair<String, List<LocalTrack>>> = emptyMap()

    @Synchronized
    private fun ensure(context: Context) {
        if (System.currentTimeMillis() - loadedAt < 60_000 && library.isNotEmpty()) return
        val tracks = runCatching { LocalLibrary.scan(context) }.getOrDefault(emptyList())
        val byId = tracks.associateBy { it.id }
        val matcher = Matcher(tracks)
        val data = runCatching { PlaylistStore(context).load() }.getOrNull()
        val out = LinkedHashMap<String, Pair<String, List<LocalTrack>>>()
        data?.playlists?.forEach { p ->
            val songs = p.tracks.mapNotNull { t ->
                data.overrides[t.id]?.let { byId[it] }
                    ?: t.id.removePrefix("local:").takeIf { t.id.startsWith("local:") }?.toLongOrNull()?.let { byId[it] }
                    ?: matcher.match(t)
            }
            out["pl:${p.id}"] = p.name to songs
        }
        // Albums Mixtape downloaded into their own folders.
        tracks.filter { it.folder.startsWith("Music/Mixtape/") && it.folder.trimEnd('/').count { c -> c == '/' } >= 2 }
            .groupBy { it.folder }
            .forEach { (folder, songs) ->
                val sorted = songs.sortedWith(compareBy({ if (it.trackNo > 0) it.trackNo else Int.MAX_VALUE }, { it.title.lowercase() }))
                out["al:$folder"] = (sorted.firstOrNull { it.album.isNotBlank() }?.album ?: folder.trimEnd('/').substringAfterLast('/')) to sorted
            }
        // Smart playlists
        ListenStats.init(context)
        val stats = ListenStats.snapshot().associateBy { it.id }
        fun s(t: LocalTrack) = stats[t.id.toString()]
        val monthAgo = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        out["sm:most"] = "Most played" to tracks.filter { (s(it)?.listenedMs ?: 0L) > 0 }.sortedByDescending { s(it)!!.listenedMs }.take(50)
        out["sm:recent"] = "Recently added" to tracks.sortedByDescending { it.addedAt }.take(50)
        out["sm:forgotten"] = "Forgotten favourites" to tracks.filter { t ->
            val e = s(t) ?: return@filter false
            e.plays >= 3 && (if (e.lastPlayed > 0) e.lastPlayed else ListenStats.trackingSince()) < monthAgo
        }.take(50)
        out["sm:never"] = "Never played" to tracks.filter { (s(it)?.plays ?: 0) == 0 }.sortedBy { it.title.lowercase() }
        out[SONGS] = "All songs" to tracks.sortedBy { it.title.lowercase() }

        library = tracks
        lists = out
        loadedAt = System.currentTimeMillis()
    }

    fun rootItem(): MediaItem = folder(ROOT, "Mixtape", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)

    fun children(context: Context, parent: String): List<MediaItem> {
        ensure(context)
        return when (parent) {
            ROOT -> listOf(
                folder(PLAYLISTS, "Playlists", MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS),
                folder(ALBUMS, "Albums", MediaMetadata.MEDIA_TYPE_FOLDER_ALBUMS),
                folder(SMART, "Smart playlists", MediaMetadata.MEDIA_TYPE_FOLDER_PLAYLISTS),
                folder(SONGS, "All songs", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED),
            )
            PLAYLISTS -> lists.filterKeys { it.startsWith("pl:") }.map { (id, v) -> folder(id, v.first, MediaMetadata.MEDIA_TYPE_PLAYLIST) }
            ALBUMS -> lists.filterKeys { it.startsWith("al:") }.map { (id, v) -> folder(id, v.first, MediaMetadata.MEDIA_TYPE_ALBUM) }
            SMART -> lists.filterKeys { it.startsWith("sm:") }.map { (id, v) -> folder(id, v.first, MediaMetadata.MEDIA_TYPE_PLAYLIST) }
            else -> lists[parent]?.second.orEmpty().take(500).map { song(it, parent) }
        }
    }

    fun item(context: Context, id: String): MediaItem? {
        ensure(context)
        if (id == ROOT) return rootItem()
        val trackId = id.substringAfterLast(SEP).toLongOrNull()
        return trackId?.let { t -> library.firstOrNull { it.id == t } }?.let { song(it, id.substringBefore(SEP)) }
    }

    /** A song picked in the car: the whole list it came from, starting at that song. */
    fun expand(context: Context, picked: MediaItem): Pair<List<MediaItem>, Int>? {
        val id = picked.mediaId
        if (!id.contains(SEP)) return null
        ensure(context)
        val parent = id.substringBefore(SEP)
        val trackId = id.substringAfter(SEP).toLongOrNull() ?: return null
        val songs = lists[parent]?.second ?: return null
        val start = songs.indexOfFirst { it.id == trackId }.coerceAtLeast(0)
        return songs.map { playable(it) } to start
    }

    /** The item the player actually plays (plain id, file Uri). */
    fun playable(t: LocalTrack): MediaItem = MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(LocalLibrary.contentUri(t.id))
        .setMediaMetadata(meta(t).build())
        .build()

    private fun song(t: LocalTrack, parent: String): MediaItem = MediaItem.Builder()
        .setMediaId("$parent$SEP${t.id}")
        .setUri(LocalLibrary.contentUri(t.id))
        .setMediaMetadata(meta(t).build())
        .build()

    private fun meta(t: LocalTrack) = MediaMetadata.Builder()
        .setTitle(t.title)
        .setArtist(t.artist)
        .setAlbumTitle(t.album)
        .setIsBrowsable(false)
        .setIsPlayable(true)
        .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)

    private fun folder(id: String, title: String, type: Int): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(type)
                .build(),
        )
        .build()

    @Suppress("unused")
    private fun uriOf(t: LocalTrack): Uri = LocalLibrary.contentUri(t.id)
}
