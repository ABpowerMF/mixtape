package dev.mixtape.player.ui

import android.app.Activity
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import dev.mixtape.player.clock.NotificationCounter
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Sideways clock mode, like a smart display. Kept light on battery: pure black background,
 * optional dimmed screen, the clock only redraws once a minute (unless seconds are on), no
 * progress bar redraws, and everything shifts a few pixels each minute against burn-in.
 */
@Composable
fun DockScreen(vm: MainViewModel, now: NowPlaying) {
    KeepScreenOn()
    FullScreen()
    ScreenBrightness(
        when (vm.clockDim) {
            1 -> 0.25f
            2 -> 0.04f
            else -> WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        },
    )

    val context = LocalContext.current
    var time by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(vm.clockSeconds) {
        while (true) {
            time = System.currentTimeMillis()
            // Wake up only when the shown time changes.
            val step = if (vm.clockSeconds) 1_000L else 60_000L
            delay(step - time % step)
        }
    }
    val locale = Locale.getDefault()
    val pattern = if (DateFormat.is24HourFormat(context)) "HH:mm" else "h:mm"
    val clock = SimpleDateFormat(if (vm.clockSeconds) "$pattern:ss" else pattern, locale).format(Date(time))
    val day = SimpleDateFormat("EEEE, d MMMM", locale).format(Date(time))
    val minute = time / 60_000
    val shiftX = remember(minute) { Random.nextInt(-8, 9) }
    val shiftY = remember(minute) { Random.nextInt(-6, 7) }
    val track = vm.trackById(now.mediaId)
    val playing = now.mediaId != null
    val night = vm.clockDim == 2
    // At night everything is drawn dimmer as well (less light, less power on OLED screens).
    val main = if (vm.clockAccent) Mix.Tape else Mix.Paper
    val textColor = if (night) main.copy(alpha = 0.55f) else main
    val soft = if (night) Mix.Fog.copy(alpha = 0.5f) else Mix.Fog
    val baseSize = listOf(64, 88, 116)[vm.clockSize]

    val notifications by NotificationCounter.count.collectAsState()
    val notifyApps by NotificationCounter.apps.collectAsState()
    val showNotifications = vm.clockNotifications && NotificationCounter.hasAccess(context)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        Row(
            Modifier
                .fillMaxSize()
                .offset(x = shiftX.dp, y = shiftY.dp)
                .padding(horizontal = 40.dp, vertical = 28.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (playing && vm.clockCover) {
                Artwork(
                    track?.artUri ?: now.artworkUri,
                    Modifier
                        .fillMaxHeight()
                        .aspectRatio(1f),
                    corner = if (dev.mixtape.player.ui.theme.Mix.rounded) 16.dp else 4.dp,
                    iconSize = 72.dp,
                )
                Spacer(Modifier.width(40.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    clock,
                    fontSize = (if (playing && vm.clockCover) baseSize else baseSize + 24).sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = MaterialTheme.typography.displayLarge.fontFamily,
                    color = textColor,
                    maxLines = 1,
                )
                if (vm.clockDate) {
                    Text(day.replaceFirstChar { it.titlecase(locale) }, style = MaterialTheme.typography.titleLarge, color = soft)
                }
                if (playing) {
                    Spacer(Modifier.height(18.dp))
                    Text(now.title, style = MaterialTheme.typography.titleLarge, color = if (night) soft else Mix.Tape, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(now.artist, style = MaterialTheme.typography.bodyLarge, color = soft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = vm.player::previousSong, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous", tint = soft, modifier = Modifier.size(32.dp))
                        }
                        IconButton(onClick = vm.player::toggle, modifier = Modifier.size(64.dp)) {
                            Icon(
                                if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = if (now.isPlaying) "Pause" else "Play",
                                tint = textColor,
                                modifier = Modifier.size(44.dp),
                            )
                        }
                        IconButton(onClick = vm.player::next, modifier = Modifier.size(52.dp)) {
                            Icon(Icons.Filled.SkipNext, contentDescription = "Next", tint = soft, modifier = Modifier.size(32.dp))
                        }
                    }
                } else {
                    Spacer(Modifier.height(16.dp))
                    Text("> nothing playing", style = MaterialTheme.typography.bodyLarge, color = soft)
                }
            }
        }
        // Notifications: top right corner, next to the clock.
        if (showNotifications && notifications > 0) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = shiftX.dp, y = shiftY.dp)
                    .padding(top = 36.dp, end = 44.dp),
            ) {
                NotificationRow(notifications, notifyApps, soft)
            }
        }
    }
}

/** Bell, how many notifications, and the icons of the apps they're from. */
@Composable
private fun NotificationRow(count: Int, apps: List<String>, tint: Color) {
    val context = LocalContext.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.Notifications, contentDescription = null, tint = tint, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(8.dp))
        Text("$count", style = MaterialTheme.typography.headlineSmall, color = tint)
        Spacer(Modifier.width(14.dp))
        apps.forEach { pkg ->
            val icon = remember(pkg) {
                runCatching { context.packageManager.getApplicationIcon(pkg).toBitmap(48, 48).asImageBitmap() }.getOrNull()
            }
            if (icon != null) {
                Image(icon, contentDescription = null, modifier = Modifier.size(28.dp), alpha = 0.8f)
                Spacer(Modifier.width(8.dp))
            }
        }
    }
}

/** Sets the screen brightness while clock mode is showing, and puts it back after. */
@Composable
private fun ScreenBrightness(level: Float) {
    val view = LocalView.current
    DisposableEffect(view, level) {
        val window = (view.context as? Activity)?.window
        window?.let { w -> w.attributes = w.attributes.apply { screenBrightness = level } }
        onDispose {
            window?.let { w ->
                w.attributes = w.attributes.apply { screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE }
            }
        }
    }
}

/** Hides the status and navigation bars (swipe from the edge to see them). */
@Composable
private fun FullScreen() {
    val view = LocalView.current
    DisposableEffect(view) {
        val window = (view.context as? Activity)?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }
}
