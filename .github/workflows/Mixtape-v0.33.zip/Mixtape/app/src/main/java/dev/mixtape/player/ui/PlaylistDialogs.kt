package dev.mixtape.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui

/** Pick one of your own playlists (or make a new one) for [songs]. */
@Composable
fun AddToPlaylistDialog(vm: MainViewModel, songs: List<LocalTrack>, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    val mine = vm.ownPlaylists()
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(Ui.head("add ${songs.size} song${if (songs.size == 1) "" else "s"} to…")) },
        text = {
            Column {
                Column(
                    Modifier
                        .heightIn(max = 260.dp)
                        .verticalScroll(rememberScrollState()),
                ) {
                    if (mine.isEmpty()) {
                        Text("No playlists of your own yet. Make one below.", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                    }
                    mine.forEach { p ->
                        Text(
                            p.name + "  (${p.tracks.size})",
                            style = MaterialTheme.typography.bodyLarge,
                            color = Mix.Paper,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    vm.addToPlaylist(p.id, songs)
                                    onDone()
                                }
                                .padding(vertical = 10.dp),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    placeholder = { Text("New playlist name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    vm.createPlaylist(name, songs, open = false)
                    vm.showMessage("Made \"${name.trim()}\" with ${songs.size} song${if (songs.size == 1) "" else "s"}.")
                    onDone()
                },
            ) { Text("Create", color = if (name.isNotBlank()) Mix.Tape else Mix.Fog) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

/** Name a new, empty playlist of your own. */
@Composable
fun NewPlaylistDialog(vm: MainViewModel, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(Ui.head("new playlist")) },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    placeholder = { Text("Name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Add songs from the Songs tab (hold songs → add to playlist) or from the player (the + icon).",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank(), onClick = {
                vm.createPlaylist(name)
                onDone()
            }) { Text("Create", color = if (name.isNotBlank()) Mix.Tape else Mix.Fog) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}
