package dev.mixtape.player.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape

/** A smart playlist: rebuilt from your library and listening every time you open it. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartScreen(vm: MainViewModel, kind: SmartKind) {
    LaunchedEffect(Unit) { vm.refreshStats() }
    val tracks = remember(vm.library, vm.stats, kind) { vm.smartTracks(kind) }
    val now by vm.player.state.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(kind.title, style = MaterialTheme.typography.titleLarge) },
            navigationIcon = { IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        Text(
            "${kind.note} · ${tracks.size} songs",
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Fog,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        if (tracks.isEmpty()) {
            EmptyState(
                title = "Nothing here yet",
                body = when (kind) {
                    SmartKind.MOST_PLAYED -> "Listen to some music and your favourites show up here."
                    SmartKind.FORGOTTEN -> "Songs you played often but not for a month will appear here."
                    else -> "No songs match yet."
                },
            )
        } else {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            Button(
                shape = TermShape,
                onClick = { vm.playSmart(kind, 0, shuffle = false) },
                colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Play")
            }
            Spacer(Modifier.width(12.dp))
            OutlinedButton(shape = TermShape, onClick = { vm.playSmart(kind, 0, shuffle = true) }) {
                Icon(Icons.Filled.Shuffle, contentDescription = null, tint = Mix.Tape)
                Spacer(Modifier.width(6.dp))
                Text("Shuffle", color = Mix.Tape)
            }
        }
        val listState = rememberLazyListState()
        Box(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 16.dp)) {
                itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
                    SwipeToQueue(onQueue = {
                        vm.player.addToQueue(listOf(t))
                        vm.showMessage("Added to queue: ${t.title}")
                    }) {
                        LocalTrackRow(t, highlighted = now.mediaId == t.id.toString()) { vm.playSmart(kind, i, shuffle = false) }
                    }
                }
            }
            FastScrollbar(listState, Modifier.align(Alignment.CenterEnd))
        }
        }
    }
}
