package dev.mixtape.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.launch

private data class TutorialPage(val icon: ImageVector, val title: String, val lines: List<String>)

private val PAGES = listOf(
    TutorialPage(
        Icons.Filled.LibraryMusic,
        "Bring your playlists",
        listOf(
            "Playlists → + : paste a Spotify playlist or album link, or pick a file.",
            "Mixtape lines the songs up with the music on your phone, in the same order.",
            "Or make your own with the folder-plus icon.",
        ),
    ),
    TutorialPage(
        Icons.Filled.Download,
        "Fill the gaps",
        listOf(
            "In a playlist, Download missing gets the songs you don't have yet.",
            "Or paste any link in the Download tab, or share it to Mixtape from another app.",
            "Pick the quality there: MP3, M4A, MX original or FLAC.",
        ),
    ),
    TutorialPage(
        Icons.Filled.ScreenRotation,
        "Clock mode",
        listOf(
            "Turn it on in Settings → player, then turn the phone sideways (auto-rotate on).",
            "Big clock, date, what's playing and your notifications. The screen stays on.",
            "Or long-press the Mixtape icon → Clock mode.",
        ),
    ),
)

/** Three quick pages on the first launch; replay any time from Settings → about. */
@Composable
fun TutorialScreen(onDone: () -> Unit) {
    val pager = rememberPagerState { PAGES.size }
    val scope = rememberCoroutineScope()
    Column(
        Modifier
            .fillMaxSize()
            .background(Mix.Ink)
            .systemBarsPadding()
            .padding(28.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onDone) { Text("Skip", color = Mix.Fog) }
        }
        HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
            val p = PAGES[page]
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                Icon(p.icon, contentDescription = null, tint = Mix.Tape, modifier = Modifier.size(72.dp))
                Spacer(Modifier.height(28.dp))
                Text(Ui.head(p.title.lowercase()), style = MaterialTheme.typography.displaySmall, color = Mix.Paper)
                Spacer(Modifier.height(20.dp))
                p.lines.forEach { line ->
                    Text(line, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper, modifier = Modifier.padding(vertical = 6.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            repeat(PAGES.size) { i ->
                Box(
                    Modifier
                        .padding(end = 8.dp)
                        .size(if (i == pager.currentPage) 22.dp else 8.dp, 8.dp)
                        .background(if (i == pager.currentPage) Mix.Tape else Mix.Gap, TermShape),
                )
            }
            Spacer(Modifier.weight(1f))
            val last = pager.currentPage == PAGES.lastIndex
            Button(
                shape = TermShape,
                onClick = { if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
                colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) { Text(if (last) "Start" else "Next") }
        }
        Spacer(Modifier.width(1.dp))
    }
}
