package dev.mixtape.player.lyrics

import com.google.android.gms.tasks.Task
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Translates lyrics on the phone with Google's ML Kit. Each language is a one-time download
 * (about 30 MB); after that it works offline and nothing leaves the phone.
 */
object LyricsTranslator {

    /** Languages offered in the lyrics screen: (label, ML Kit code). */
    val LANGUAGES: List<Pair<String, String>> = listOf(
        "English" to TranslateLanguage.ENGLISH,
        "Português" to TranslateLanguage.PORTUGUESE,
        "Español" to TranslateLanguage.SPANISH,
        "Français" to TranslateLanguage.FRENCH,
        "Deutsch" to TranslateLanguage.GERMAN,
        "Italiano" to TranslateLanguage.ITALIAN,
        "Nederlands" to TranslateLanguage.DUTCH,
        "Polski" to TranslateLanguage.POLISH,
        "Türkçe" to TranslateLanguage.TURKISH,
        "Русский" to TranslateLanguage.RUSSIAN,
        "العربية" to TranslateLanguage.ARABIC,
        "हिन्दी" to TranslateLanguage.HINDI,
        "日本語" to TranslateLanguage.JAPANESE,
        "한국어" to TranslateLanguage.KOREAN,
        "中文" to TranslateLanguage.CHINESE,
    )

    fun labelOf(code: String?): String? = LANGUAGES.firstOrNull { it.second == code }?.first

    class Result(val lines: List<String>, val sameLanguage: Boolean)

    /** Translates each line to [target]. [onStatus] reports "downloading…" / "translating…". */
    suspend fun translate(lines: List<String>, target: String, onStatus: (String) -> Unit): Result {
        val sample = lines.filter { it.isNotBlank() }.joinToString("\n").take(3000)
        val detected = runCatching { LanguageIdentification.getClient().identifyLanguage(sample).awaitTask() }.getOrNull()
        val source = detected?.let { TranslateLanguage.fromLanguageTag(it) } ?: TranslateLanguage.ENGLISH
        if (source == target) return Result(lines, sameLanguage = true)

        val translator = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build(),
        )
        try {
            onStatus("getting the language (once, about 30 MB)…")
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).awaitTask()
            onStatus("translating…")
            val out = lines.map { line -> if (line.isBlank()) line else translator.translate(line).awaitTask() }
            return Result(out, sameLanguage = false)
        } finally {
            translator.close()
        }
    }

    private suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { cont ->
        addOnSuccessListener { cont.resume(it) }
        addOnFailureListener { cont.resumeWithException(it) }
        addOnCanceledListener { cont.cancel() }
    }
}
