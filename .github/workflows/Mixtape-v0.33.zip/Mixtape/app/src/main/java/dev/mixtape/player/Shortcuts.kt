package dev.mixtape.player

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

/** Long-press the app icon: Clock mode (always there) and your last playlist. */
object Shortcuts {
    const val ACTION_CLOCK = "dev.mixtape.player.CLOCK"
    const val ACTION_LAST_PLAYLIST = "dev.mixtape.player.LAST_PLAYLIST"

    fun updateLastPlaylist(context: Context, name: String) {
        runCatching {
            val shortcut = ShortcutInfoCompat.Builder(context, "last_playlist")
                .setShortLabel(name.take(24))
                .setLongLabel("Play $name".take(40))
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_shortcut_playlist))
                .setIntent(Intent(context, MainActivity::class.java).setAction(ACTION_LAST_PLAYLIST))
                .build()
            ShortcutManagerCompat.pushDynamicShortcut(context, shortcut)
        }
    }
}
