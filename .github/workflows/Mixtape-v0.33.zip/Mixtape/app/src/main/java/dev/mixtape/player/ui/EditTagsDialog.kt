package dev.mixtape.player.ui

import android.app.Activity
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui

/** Edit a song's title, artist, album and cover; saved into the file itself. */
@Composable
fun EditTagsDialog(vm: MainViewModel, track: LocalTrack, onDone: () -> Unit) {
    var title by remember { mutableStateOf(track.title) }
    var artist by remember { mutableStateOf(track.artist) }
    var album by remember { mutableStateOf(track.album) }
    var cover by remember { mutableStateOf<Uri?>(null) }
    val pickCover = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) cover = uri }
    fun save(permission: (android.content.IntentSender) -> Unit) = vm.saveTags(track, title, artist, album, cover, permission)
    val allow = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        // Android asked "allow Mixtape to change this file?"; on yes, save for real.
        if (result.resultCode == Activity.RESULT_OK) save { vm.showMessage("Android didn't allow changing this file.") }
    }
    val isOpus = track.fileName.substringAfterLast('.').lowercase() in setOf("opus", "ogg")

    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(Ui.head("edit song")) },
        text = {
            Column {
                Field("Title", title) { title = it }
                Field("Artist", artist) { artist = it }
                Field("Album", album) { album = it }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Artwork(cover ?: track.artUri, Modifier.size(56.dp), corner = if (Mix.rounded) 8.dp else 2.dp)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        if (isOpus) "Covers can't be changed in Opus files" else Ui.btn("change cover"),
                        color = if (isOpus) Mix.Fog else Mix.Tape,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .clickable(enabled = !isOpus) { pickCover.launch("image/*") }
                            .padding(vertical = 8.dp),
                    )
                }
                Text(
                    "Saved into the file, so other music apps see it too.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                save { request -> allow.launch(IntentSenderRequest.Builder(request).build()) }
                onDone()
            }) { Text("Save", color = Mix.Tape) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        label = { Text(label) },
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
    )
}
