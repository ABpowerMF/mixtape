Mixtape v0.53

- Fixed: updating from inside the app stopped with "The coroutine scope left the composition".

- Square screens (RG Rotate): the player screen now fits. The cover sits on the left with the song beside it, and the seek bar and buttons are below, all on one screen. Scroll down for the artist.
- Closed screen: the lyrics always fit next to the cover. The line being sung stays in the middle and only whole lines show around it, never half a line.
- Cocoon style: playlist and album tiles are just the covers (the name only shows on tiles without a cover). No mini player at the bottom: use the "now playing" tile, tap the song name in the bottom bar, or press Y.
