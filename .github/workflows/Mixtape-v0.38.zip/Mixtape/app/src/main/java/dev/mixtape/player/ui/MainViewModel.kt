package dev.mixtape.player.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.mixtape.player.Config
import dev.mixtape.player.data.PlaylistRow
import dev.mixtape.player.data.PlaylistStore
import dev.mixtape.player.data.SavedPlaylist
import dev.mixtape.player.data.SpotifyPlaylistSummary
import dev.mixtape.player.data.SpotifyTrack
import dev.mixtape.player.download.AlbumHit
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.lyrics.LyricsRepo
import dev.mixtape.player.playback.ListenStats
import dev.mixtape.player.download.Quality
import dev.mixtape.player.download.SongRequest
import dev.mixtape.player.library.LocalLibrary
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.library.Matcher
import dev.mixtape.player.playback.PlayerConnection
import dev.mixtape.player.spotify.LoopbackReceiver
import dev.mixtape.player.spotify.NotLoggedInException
import dev.mixtape.player.spotify.SpotifyApi
import dev.mixtape.player.spotify.SpotifyAuth
import dev.mixtape.player.spotify.SpotifyException
import dev.mixtape.player.spotify.LibraryImport
import dev.mixtape.player.spotify.SpotifyPublic
import dev.mixtape.player.spotify.SpotifyWeb
import dev.mixtape.player.spotify.WebParsing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.BindException
import java.net.ServerSocket
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import kotlin.coroutines.cancellation.CancellationException

sealed interface Screen {
    data object Home : Screen
    data class Playlist(val id: String) : Screen
    data object Import : Screen
    data object NowPlaying : Screen
    data object Stats : Screen
    data object Queue : Screen
    data object Lyrics : Screen
    data object Equalizer : Screen
    data class Album(val folder: String) : Screen
    data class Smart(val kind: SmartKind) : Screen
    data object Wrapped : Screen
    data object Concerts : Screen
}

enum class HomeTab { Playlists, Songs, Download, Settings }

/** An album downloaded into its own folder. */
data class LocalAlbum(val folder: String, val name: String, val artist: String, val tracks: List<LocalTrack>)

/** Playlists that build themselves from your library and listening. */
enum class SmartKind(val title: String, val note: String) {
    MOST_PLAYED("Most played", "Your 50 most listened songs"),
    RECENTLY_ADDED("Recently added", "The newest songs on this phone"),
    FORGOTTEN("Forgotten favourites", "Songs you played a lot, but not in the last month"),
    NEVER_PLAYED("Never played", "Songs you haven't listened to yet"),
}

/** Which audio files count as music. */
enum class LibraryScope(val label: String, val note: String) {
    ALL("All music", "Everything except voice notes, recordings and ringtones"),
    MUSIC("Music folder", "Only files in the phone's Music folder"),
    MIXTAPE("Mixtape folder", "Only songs Mixtape downloaded (Music/Mixtape)"),
}

/** How a playlist's songs are listed and played. */
enum class SortMode(val label: String) {
    PLAYLIST("Playlist order"),
    TITLE("Title A–Z"),
    ARTIST("Artist A–Z"),
    SHORTEST("Shortest first"),
    LONGEST("Longest first"),
}

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val context: Application get() = getApplication()
    private val auth = SpotifyAuth(app)
    private val api = SpotifyApi(auth)
    private val store = PlaylistStore(app)
    private val receiver = LoopbackReceiver(Config.REDIRECT_PORT)
    val player = PlayerConnection(app, viewModelScope)

    // Navigation
    val stack = mutableStateListOf<Screen>(Screen.Home)
    var tab by mutableStateOf(HomeTab.Playlists)

    // Music on this phone
    var hasPermission by mutableStateOf(false); private set
    var library by mutableStateOf<List<LocalTrack>>(emptyList()); private set
    var libraryLoaded by mutableStateOf(false); private set
    private var libraryById: Map<Long, LocalTrack> = emptyMap()
    private var matcher = Matcher(emptyList())

    // Imported playlists and how they map onto the files above
    var playlists by mutableStateOf<List<SavedPlaylist>>(emptyList()); private set
    var rows by mutableStateOf<Map<String, List<PlaylistRow>>>(emptyMap()); private set
    private var overrides: Map<String, Long> = emptyMap()

    // Downloads
    private val prefs = app.getSharedPreferences("mixtape", Context.MODE_PRIVATE)
    var quality by mutableStateOf(Quality.fromName(prefs.getString("quality", null))); private set
    /** Text in the link box on the Download tab. */
    var linkDraft by mutableStateOf("")

    // Albums (downloaded into their own folders, plus Spotify albums imported by link)
    var albumsOpen by mutableStateOf(prefs.getBoolean("albumsOpen", true)); private set

    /** Albums as a list, or as a gallery of covers with 2, 3 or 4 per row. */
    var albumsGallery by mutableStateOf(prefs.getBoolean("albumsGallery", false)); private set
    var galleryColumns by mutableStateOf(prefs.getInt("galleryColumns", 3).coerceIn(2, 4)); private set

    fun chooseAlbumsGallery(on: Boolean) {
        albumsGallery = on
        prefs.edit().putBoolean("albumsGallery", on).apply()
    }

    fun chooseGalleryColumns(n: Int) {
        galleryColumns = n.coerceIn(2, 4)
        prefs.edit().putInt("galleryColumns", galleryColumns).apply()
    }

    fun toggleAlbums() {
        albumsOpen = !albumsOpen
        prefs.edit().putBoolean("albumsOpen", albumsOpen).apply()
    }

    /** Albums downloaded by Mixtape: songs in Music/Mixtape/<Artist - Album>/. */
    fun localAlbums(): List<LocalAlbum> {
        val root = dev.mixtape.player.download.MediaSaver.FOLDER + "/"
        return library
            .filter { it.folder.startsWith(root) && it.folder.trimEnd('/').length > root.trimEnd('/').length }
            .groupBy { it.folder }
            .map { (folder, tracks) ->
                val sorted = tracks.sortedWith(compareBy({ if (it.trackNo > 0) it.trackNo else Int.MAX_VALUE }, { it.title.lowercase() }))
                val name = sorted.map { it.album }.firstOrNull { it.isNotBlank() && it != "Music" }
                    ?: folder.trimEnd('/').substringAfterLast('/')
                LocalAlbum(folder, name, sorted.first().artist, sorted)
            }
            .sortedBy { it.name.lowercase() }
    }

    fun albumTracks(folder: String): List<LocalTrack> =
        localAlbums().firstOrNull { it.folder == folder }?.tracks.orEmpty()

    fun playAlbum(folder: String, from: Int = 0, shuffle: Boolean? = null) {
        val tracks = albumTracks(folder)
        if (tracks.isNotEmpty()) {
            player.setContext(localAlbums().firstOrNull { it.folder == folder }?.name ?: "Album")
            player.play(tracks, from.coerceIn(0, tracks.lastIndex), shuffle = shuffle)
        }
    }

    // Sorting
    var sortModes by mutableStateOf<Map<String, SortMode>>(emptyMap()); private set

    fun sortModeOf(id: String): SortMode =
        sortModes[id] ?: SortMode.entries.firstOrNull { it.name == prefs.getString("sort:$id", null) } ?: SortMode.PLAYLIST

    fun chooseSort(id: String, mode: SortMode) {
        sortModes = sortModes + (id to mode)
        prefs.edit().putString("sort:$id", mode.name).apply()
    }

    /** The playlist's rows in the chosen order (what the screen shows and what plays). */
    fun sortedRows(id: String): List<PlaylistRow> {
        val list = rows[id].orEmpty()
        fun length(r: PlaylistRow) = r.local?.durationMs?.takeIf { it > 0 } ?: r.track.durationMs
        return when (sortModeOf(id)) {
            SortMode.PLAYLIST -> list
            SortMode.TITLE -> list.sortedBy { it.track.title.lowercase() }
            SortMode.ARTIST -> list.sortedWith(compareBy({ it.track.artists.firstOrNull().orEmpty().lowercase() }, { it.track.title.lowercase() }))
            SortMode.SHORTEST -> list.sortedBy { length(it) }
            SortMode.LONGEST -> list.sortedByDescending { length(it) }
        }
    }

    /** Moves a song within the playlist's own order (Edit order). */
    fun moveTrack(id: String, from: Int, to: Int) {
        val p = playlists.find { it.id == id } ?: return
        if (from !in p.tracks.indices || to !in p.tracks.indices || from == to) return
        val tracks = p.tracks.toMutableList().apply { add(to, removeAt(from)) }
        upsert(p.copy(tracks = tracks))
        rows[id]?.let { r ->
            if (from in r.indices && to in r.indices) {
                rows = rows + (id to r.toMutableList().apply { add(to, removeAt(from)) })
            }
        }
        viewModelScope.launch { persist() }
    }

    // Stats
    var stats by mutableStateOf<List<ListenStats.Entry>>(emptyList()); private set
    var statsSince by mutableStateOf(0L); private set

    fun refreshStats() {
        ListenStats.init(context)
        stats = ListenStats.snapshot()
        statsSince = ListenStats.trackingSince()
    }

    fun resetStats() {
        ListenStats.reset()
        refreshStats()
    }

    // Spotify account (optional)
    var spotifyClientId by mutableStateOf(
        prefs.getString("spotifyClientId", null)
            ?: Config.SPOTIFY_CLIENT_ID.takeUnless { it.startsWith("PASTE") }.orEmpty(),
    ); private set

    fun chooseClientId(id: String) {
        spotifyClientId = id.trim()
        Config.clientId = spotifyClientId
        prefs.edit().putString("spotifyClientId", spotifyClientId).apply()
    }

    /** A Spotify playlist/album shared to Mixtape: the app asks whether to import or download it. */
    var sharedSpotify by mutableStateOf<String?>(null)

    fun importShared() {
        val link = sharedSpotify ?: return
        sharedSpotify = null
        tab = HomeTab.Playlists
        importFromLink(link)
    }

    fun downloadShared() {
        val link = sharedSpotify ?: return
        sharedSpotify = null
        tab = HomeTab.Download
        DownloadQueue.addLink(link, quality)
    }

    // Which files are music
    var libraryScope by mutableStateOf(
        LibraryScope.entries.firstOrNull { it.name == prefs.getString("libraryScope", null) } ?: LibraryScope.ALL,
    ); private set

    fun chooseLibraryScope(scope: LibraryScope) {
        libraryScope = scope
        prefs.edit().putString("libraryScope", scope.name).apply()
        libraryLoaded = false
        scanLibrary()
    }

    private val notMusic = listOf(
        "whatsapp", "telegram", "recordings", "recorder", "voice", "call", "ringtones",
        "notifications", "alarms", "sounds/", "podcasts", "audiobooks", "signal",
    )

    private fun inScope(t: LocalTrack): Boolean {
        val folder = t.folder.lowercase()
        return when (libraryScope) {
            LibraryScope.MIXTAPE -> folder.startsWith("music/mixtape/")
            LibraryScope.MUSIC -> folder.startsWith("music/")
            LibraryScope.ALL -> notMusic.none { folder.contains(it) }
        }
    }

    // Lyrics
    sealed interface LyricsState {
        data object Idle : LyricsState
        data object Loading : LyricsState
        data object NotFound : LyricsState
        data class Found(val lyrics: dev.mixtape.player.lyrics.Lyrics) : LyricsState
    }

    var lyricsFor by mutableStateOf<String?>(null); private set
    var lyricsState by mutableStateOf<LyricsState>(LyricsState.Idle); private set
    var lyricsOnline by mutableStateOf(prefs.getBoolean("lyricsOnline", true)); private set

    fun chooseLyricsOnline(on: Boolean) {
        lyricsOnline = on
        prefs.edit().putBoolean("lyricsOnline", on).apply()
    }

    /** Shows saved lyrics for the playing song, or looks them up once (if allowed). */
    fun loadLyrics(mediaId: String?, force: Boolean = false) {
        val track = trackById(mediaId)
        if (track == null) {
            lyricsFor = null
            lyricsState = LyricsState.NotFound
            return
        }
        if (!force && lyricsFor == mediaId && lyricsState !is LyricsState.Idle) return
        lyricsFor = mediaId
        lyricsState = LyricsState.Loading
        viewModelScope.launch {
            val id = track.id.toString()
            val result = withContext(Dispatchers.IO) {
                (if (force) null else LyricsRepo.cached(context, id)) ?: if (lyricsOnline) {
                    runCatching {
                        LyricsRepo.fetch(context, id, track.title, track.artist, track.album, track.durationMs)
                    }.getOrNull()
                } else {
                    null
                }
            }
            if (lyricsFor == mediaId) {
                lyricsState = if (result != null) LyricsState.Found(result) else LyricsState.NotFound
                translateLyrics()
            }
        }
    }

    // Lyrics translation (on the phone)
    var translateTo by mutableStateOf(prefs.getString("lyricsLang", null)); private set
    var translation by mutableStateOf<List<String>?>(null); private set
    var translationStatus by mutableStateOf<String?>(null); private set
    private val translationCache = HashMap<String, List<String>>()
    private var translateJob: kotlinx.coroutines.Job? = null

    fun chooseTranslation(code: String?) {
        translateTo = code
        prefs.edit().putString("lyricsLang", code).apply()
        translation = null
        translateLyrics()
    }

    /** Lines as shown on screen: synced lines, or the plain text split into lines. */
    fun lyricLines(l: dev.mixtape.player.lyrics.Lyrics): List<String> =
        if (l.synced.isNotEmpty()) l.synced.map { it.text } else l.plain.orEmpty().lines()

    /** Translates the lyrics on screen into [translateTo], if set. */
    fun translateLyrics() {
        translateJob?.cancel()
        val target = translateTo
        val state = lyricsState
        val id = lyricsFor
        if (target == null || state !is LyricsState.Found || id == null) {
            translation = null
            translationStatus = null
            return
        }
        val key = "$id:$target"
        translationCache[key]?.let {
            translation = it
            translationStatus = null
            return
        }
        val lines = lyricLines(state.lyrics)
        translation = null
        translationStatus = "translating…"
        translateJob = viewModelScope.launch {
            try {
                val result = dev.mixtape.player.lyrics.LyricsTranslator.translate(lines, target) { translationStatus = it }
                if (result.sameLanguage) {
                    translation = null
                    translationStatus = "already in ${dev.mixtape.player.lyrics.LyricsTranslator.labelOf(target) ?: "that language"}"
                } else {
                    translationCache[key] = result.lines
                    translation = result.lines
                    translationStatus = null
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                translation = null
                translationStatus = "couldn't translate: ${e.message?.lines()?.firstOrNull() ?: "no internet for the first download?"}"
            }
        }
    }

    fun pasteLyrics(text: String) {
        val id = lyricsFor ?: return
        viewModelScope.launch {
            val saved = withContext(Dispatchers.IO) { LyricsRepo.savePasted(context, id, text) }
            lyricsState = if (saved != null) LyricsState.Found(saved) else LyricsState.NotFound
            translationCache.keys.removeAll { it.startsWith("$id:") }
            translateLyrics()
        }
    }

    fun removeLyrics() {
        val id = lyricsFor ?: return
        viewModelScope.launch {
            withContext(Dispatchers.IO) { LyricsRepo.delete(context, id) }
            lyricsState = LyricsState.NotFound
        }
    }

    /** Sideways clock mode: turning the phone sideways shows a big clock with what's playing. */
    var dockMode by mutableStateOf(prefs.getBoolean("dockMode", false)); private set

    fun chooseDockMode(on: Boolean) {
        dockMode = on
        prefs.edit().putBoolean("dockMode", on).apply()
    }

    // Player extras
    var movingCover by mutableStateOf(prefs.getBoolean("movingCover", false)); private set
    var artistInfoOnline by mutableStateOf(prefs.getBoolean("artistInfo", true)); private set

    // Video covers: the song's music video plays silently instead of the cover (like Spotify's Canvas).
    var videoCovers by mutableStateOf(prefs.getBoolean("videoCovers", true)); private set
    var videoWifiOnly by mutableStateOf(prefs.getBoolean("videoWifiOnly", true)); private set
    var videoCover by mutableStateOf<Pair<String, String>?>(null); private set
    private val videoCache = HashMap<String, Pair<Long, String?>>()
    private var videoJob: kotlinx.coroutines.Job? = null

    fun chooseVideoCovers(on: Boolean) {
        videoCovers = on
        prefs.edit().putBoolean("videoCovers", on).apply()
        if (!on) videoCover = null
    }

    fun chooseVideoWifiOnly(on: Boolean) {
        videoWifiOnly = on
        prefs.edit().putBoolean("videoWifiOnly", on).apply()
    }

    private fun onWifi(): Boolean {
        val cm = context.getSystemService(android.net.ConnectivityManager::class.java) ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /** What the video cover is doing, shown small on the cover ("finding video…", "no video", …). */
    var videoStatus by mutableStateOf<String?>(null); private set

    /** Gets the playing song's video clip (downloaded once, then kept). */
    fun loadVideoCover(mediaId: String?) {
        if (videoCover?.first == mediaId && videoCover != null) return
        videoCover = null
        videoStatus = null
        videoJob?.cancel()
        val track = trackById(mediaId) ?: return
        if (!videoCovers) return
        val id = track.id.toString()
        videoJob = viewModelScope.launch {
            val cached = withContext(Dispatchers.IO) {
                java.io.File(context.cacheDir, "video-covers").listFiles()?.firstOrNull { it.name.startsWith("$id.") && !it.name.endsWith(".none") && it.length() > 0 }
            }
            if (cached == null && batterySaverOn()) {
                videoStatus = "video: off while battery saver is on"
                return@launch
            }
            if (cached == null && videoWifiOnly && !onWifi()) {
                videoStatus = "video: waiting for Wi-Fi"
                return@launch
            }
            videoStatus = if (cached == null) "video: finding…" else null
            val clip = cached ?: runCatching { DownloadQueue.videoClip(id, track.title, track.artist.substringBefore(",").trim()) }.getOrNull()
            if (trackById(player.state.value.mediaId)?.id?.toString() != id) return@launch
            if (clip != null) {
                videoCover = id to clip.absolutePath
                videoStatus = null
            } else {
                videoStatus = "video: " + (DownloadQueue.lastVideoError ?: "none found")
            }
        }
    }

    fun chooseMovingCover(on: Boolean) {
        movingCover = on
        prefs.edit().putBoolean("movingCover", on).apply()
    }

    fun chooseArtistInfo(on: Boolean) {
        artistInfoOnline = on
        prefs.edit().putBoolean("artistInfo", on).apply()
    }

    var artistInfo by mutableStateOf<dev.mixtape.player.info.ArtistInfo?>(null); private set
    /** The artist's photo from Spotify (a file on the phone), if found. */
    var artistPhoto by mutableStateOf<String?>(null); private set
    var artistInfoFor by mutableStateOf<String?>(null); private set

    /** Loads the artist profile shown under the player (saved after the first time). */
    fun loadArtist(name: String) {
        if (name.isBlank() || name == artistInfoFor) return
        artistInfoFor = name
        artistInfo = null
        artistPhoto = null
        // Any Spotify song of this artist in your playlists leads to their Spotify photo.
        val current = trackById(player.state.value.mediaId)
        val spotifyTrack = rows.values.asSequence().flatten()
            .firstOrNull { r -> r.local != null && r.local.id == current?.id && r.track.id.length == 22 }?.track?.id
            ?: rows.values.asSequence().flatten()
                .firstOrNull { r -> r.track.id.length == 22 && r.track.artists.any { it.equals(name, ignoreCase = true) } }?.track?.id
        viewModelScope.launch {
            val photo = withContext(Dispatchers.IO) {
                runCatching { dev.mixtape.player.info.ArtistRepo.spotifyPhoto(context, name, spotifyTrack) }.getOrNull()
            }
            if (artistInfoFor == name) artistPhoto = photo
        }
        viewModelScope.launch {
            val info = withContext(Dispatchers.IO) {
                dev.mixtape.player.info.ArtistRepo.cached(context, name) ?: if (
                    artistInfoOnline && !dev.mixtape.player.info.ArtistRepo.knownMissing(context, name)
                ) {
                    runCatching { dev.mixtape.player.info.ArtistRepo.fetch(context, name) }.getOrNull()
                } else {
                    null
                }
            }
            if (artistInfoFor == name) artistInfo = info
        }
    }

    // Clock mode options
    var clockSeconds by mutableStateOf(prefs.getBoolean("clockSeconds", false)); private set
    var clockDate by mutableStateOf(prefs.getBoolean("clockDate", true)); private set
    var clockCover by mutableStateOf(prefs.getBoolean("clockCover", true)); private set
    var clockAccent by mutableStateOf(prefs.getBoolean("clockAccent", false)); private set
    var clockSize by mutableStateOf(prefs.getInt("clockSize", 1).coerceIn(0, 2)); private set
    var clockDim by mutableStateOf(prefs.getInt("clockDim", 0).coerceIn(0, 2)); private set
    var clockNotifications by mutableStateOf(prefs.getBoolean("clockNotifications", false)); private set

    fun setClock(
        seconds: Boolean = clockSeconds,
        date: Boolean = clockDate,
        cover: Boolean = clockCover,
        accent: Boolean = clockAccent,
        size: Int = clockSize,
        dim: Int = clockDim,
        notifications: Boolean = clockNotifications,
    ) {
        clockSeconds = seconds; clockDate = date; clockCover = cover; clockAccent = accent
        clockSize = size; clockDim = dim; clockNotifications = notifications
        prefs.edit()
            .putBoolean("clockSeconds", seconds).putBoolean("clockDate", date).putBoolean("clockCover", cover)
            .putBoolean("clockAccent", accent).putInt("clockSize", size).putInt("clockDim", dim)
            .putBoolean("clockNotifications", notifications)
            .apply()
    }

    // Your own playlists
    /** Playlists made in the app (not imported). */
    fun ownPlaylists() = playlists.filter { it.id.startsWith(MINE_PREFIX) }

    fun createPlaylist(name: String, songs: List<LocalTrack> = emptyList(), open: Boolean = true): String {
        val id = MINE_PREFIX + System.currentTimeMillis()
        upsert(SavedPlaylist(id, name.trim().ifEmpty { "My playlist" }, null, songs.map { it.asPlaylistTrack() }, System.currentTimeMillis()))
        viewModelScope.launch {
            persist()
            rematch()
        }
        if (open) push(Screen.Playlist(id))
        return id
    }

    fun addToPlaylist(id: String, songs: List<LocalTrack>) {
        val p = playlists.find { it.id == id } ?: return
        val have = p.tracks.map { it.id }.toHashSet()
        val added = songs.map { it.asPlaylistTrack() }.filter { it.id !in have }
        upsert(p.copy(tracks = p.tracks + added))
        viewModelScope.launch {
            persist()
            rematch()
        }
        errorText = if (added.isEmpty()) "Already in ${p.name}." else "Added ${added.size} to ${p.name}."
    }

    fun removeFromPlaylist(id: String, index: Int) {
        val p = playlists.find { it.id == id } ?: return
        if (index !in p.tracks.indices) return
        upsert(p.copy(tracks = p.tracks.toMutableList().apply { removeAt(index) }))
        rows[id]?.let { r -> if (index in r.indices) rows = rows + (id to r.toMutableList().apply { removeAt(index) }) }
        viewModelScope.launch { persist() }
    }

    fun renamePlaylist(id: String, name: String) {
        val p = playlists.find { it.id == id } ?: return
        upsert(p.copy(name = name.trim().ifEmpty { p.name }))
        viewModelScope.launch { persist() }
    }

    private fun LocalTrack.asPlaylistTrack() =
        SpotifyTrack("local:$id", title, artist.split(", ").filter { it.isNotBlank() }, album, durationMs)

    // Smart playlists
    var smartOpen by mutableStateOf(prefs.getBoolean("smartOpen", true)); private set

    fun toggleSmart() {
        smartOpen = !smartOpen
        prefs.edit().putBoolean("smartOpen", smartOpen).apply()
    }

    fun smartTracks(kind: SmartKind): List<LocalTrack> {
        val stats = stats.associateBy { it.id }
        val monthAgo = System.currentTimeMillis() - 30L * 24 * 3600 * 1000
        fun s(t: LocalTrack) = stats[t.id.toString()]
        return when (kind) {
            SmartKind.MOST_PLAYED -> library.filter { (s(it)?.listenedMs ?: 0L) > 0 }.sortedByDescending { s(it)!!.listenedMs }.take(50)
            SmartKind.RECENTLY_ADDED -> library.sortedByDescending { it.addedAt }.take(50)
            SmartKind.FORGOTTEN -> library.filter { t ->
                val e = s(t) ?: return@filter false
                // Songs last played before history started count as "a while ago".
                val last = if (e.lastPlayed > 0) e.lastPlayed else statsSince
                e.plays >= 3 && last < monthAgo
            }.sortedByDescending { s(it)!!.plays }.take(50)
            SmartKind.NEVER_PLAYED -> library.filter { (s(it)?.plays ?: 0) == 0 }.sortedBy { it.title.lowercase() }
        }
    }

    fun playSmart(kind: SmartKind, from: Int = 0, shuffle: Boolean? = null) {
        val tracks = smartTracks(kind)
        if (tracks.isNotEmpty()) {
            player.setContext(kind.title)
            player.play(tracks, from.coerceIn(0, tracks.lastIndex), shuffle)
        }
    }

    // Concerts of the artists in your playlists
    var concertsOpen by mutableStateOf(prefs.getBoolean("concertsOpen", true)); private set
    var concerts by mutableStateOf<List<dev.mixtape.player.concerts.Concert>>(emptyList()); private set
    var concertStatus by mutableStateOf<String?>(null); private set
    var areaName by mutableStateOf(prefs.getString("areaName", null)); private set
    private var areaLat = prefs.getString("areaLat", null)?.toDoubleOrNull()
    private var areaLon = prefs.getString("areaLon", null)?.toDoubleOrNull()
    var radiusKm by mutableStateOf(prefs.getInt("radiusKm", 150)); private set
    /** Distance (km) from your area to each concert city; null = unknown. */
    var cityDistances by mutableStateOf<Map<String, Double?>>(emptyMap()); private set
    private var concertJob: kotlinx.coroutines.Job? = null

    fun toggleConcerts() {
        concertsOpen = !concertsOpen
        prefs.edit().putBoolean("concertsOpen", concertsOpen).apply()
    }

    fun nearConcerts() = concerts.filter { c -> cityDistances[c.city]?.let { it <= radiusKm } == true }

    fun chooseRadius(km: Int) {
        radiusKm = km
        prefs.edit().putInt("radiusKm", km).apply()
    }

    /** The artists to check: most songs in your playlists and most listened, up to 30. */
    private fun concertArtists(): List<Pair<String, String>> {
        val score = HashMap<String, Double>()
        val trackOf = HashMap<String, String>()
        rows.values.asSequence().flatten().forEach { r ->
            if (r.track.id.length != 22) return@forEach
            val name = r.track.artists.firstOrNull()?.trim().orEmpty()
            if (name.isEmpty()) return@forEach
            score[name] = (score[name] ?: 0.0) + 1.0
            trackOf.putIfAbsent(name, r.track.id)
        }
        stats.forEach { e ->
            val name = e.artist.substringBefore(",").trim()
            if (name in trackOf) score[name] = (score[name] ?: 0.0) + e.listenedMs / 60_000.0
        }
        return score.entries.sortedByDescending { it.value }.take(30).mapNotNull { (name, _) -> trackOf[name]?.let { name to it } }
    }

    private fun artistIdOf(name: String, trackId: String): String? {
        val key = "artistId:" + name.lowercase()
        prefs.getString(key, null)?.let { return it.ifEmpty { null } }
        val id = dev.mixtape.player.spotify.SpotifyPublic.artistIdFor(trackId, name)
        if (id != null) prefs.edit().putString(key, id).apply()
        return id
    }

    /** Loads concerts (from what's saved; online only for artists not checked in the last day). */
    fun refreshConcerts(force: Boolean = false) {
        if (concertJob?.isActive == true) return
        if (!force && batterySaverOn() && concerts.isNotEmpty()) return
        concertJob = viewModelScope.launch {
            val artists = concertArtists()
            if (artists.isEmpty()) {
                concertStatus = "Import a Spotify playlist first: concerts come from its artists."
                return@launch
            }
            val all = ArrayList<dev.mixtape.player.concerts.Concert>()
            var failed = 0
            artists.forEachIndexed { i, (name, trackId) ->
                concertStatus = "Checking tour dates… ${i + 1}/${artists.size}"
                val list = withContext(Dispatchers.IO) {
                    val id = runCatching { artistIdOf(name, trackId) }.getOrNull() ?: return@withContext emptyList()
                    (if (!force) dev.mixtape.player.concerts.ConcertRepo.cached(context, id) else null)
                        ?: runCatching { dev.mixtape.player.concerts.ConcertRepo.fetch(context, id, name) }
                            .onFailure { failed++ }
                            .getOrElse { dev.mixtape.player.concerts.ConcertRepo.cached(context, id, Long.MAX_VALUE) ?: emptyList() }
                }
                all += list
            }
            concerts = all.distinctBy { it.id + "|" + it.artist }.sortedBy { it.start }
            concertStatus = if (failed == artists.size) "Couldn't reach Spotify for tour dates. Try again later." else null
            updateDistances()
        }
    }

    private suspend fun updateDistances() {
        val lat = areaLat ?: return
        val lon = areaLon ?: return
        val cities = concerts.map { it.city }.distinct()
        cityDistances = withContext(Dispatchers.IO) {
            cities.associateWith { city ->
                dev.mixtape.player.concerts.ConcertRepo.locate(context, city)?.let {
                    dev.mixtape.player.concerts.ConcertRepo.distanceKm(lat to lon, it)
                }
            }
        }
    }

    private fun setArea(name: String, lat: Double, lon: Double) {
        areaName = name
        areaLat = lat
        areaLon = lon
        prefs.edit().putString("areaName", name).putString("areaLat", lat.toString()).putString("areaLon", lon.toString()).apply()
        viewModelScope.launch { updateDistances() }
    }

    /** "Your area" from a city you type. */
    fun setAreaFromCity(city: String) {
        viewModelScope.launch {
            val place = withContext(Dispatchers.IO) { dev.mixtape.player.concerts.ConcertRepo.locate(context, city.trim()) }
            if (place == null) errorText = "Couldn't find \"$city\"." else setArea(city.trim(), place.first, place.second)
        }
    }

    /** "Your area" from the phone's rough location (needs the location permission). */
    @android.annotation.SuppressLint("MissingPermission")
    fun setAreaFromLocation() {
        viewModelScope.launch {
            val lm = context.getSystemService(android.location.LocationManager::class.java)
            val loc = runCatching {
                listOf(
                    android.location.LocationManager.NETWORK_PROVIDER,
                    android.location.LocationManager.PASSIVE_PROVIDER,
                    android.location.LocationManager.GPS_PROVIDER,
                ).mapNotNull { lm?.getLastKnownLocation(it) }.maxByOrNull { it.time }
            }.getOrNull()
            if (loc == null) {
                errorText = "Couldn't get your location. Type your city instead."
                return@launch
            }
            val name = withContext(Dispatchers.IO) { dev.mixtape.player.concerts.ConcertRepo.cityAt(context, loc.latitude, loc.longitude) }
            setArea(name ?: "your area", loc.latitude, loc.longitude)
        }
    }

    // Mixtape Wrapped
    var wrapped by mutableStateOf<dev.mixtape.player.wrapped.Wrapped?>(null); private set

    fun loadWrapped(period: dev.mixtape.player.wrapped.WrapPeriod) {
        viewModelScope.launch {
            ListenStats.init(context)
            wrapped = withContext(Dispatchers.IO) { dev.mixtape.player.wrapped.WrappedMaker.make(period) }
        }
    }

    // Home-screen shortcuts
    /** Clock mode opened from the shortcut: shown even with the phone upright. */
    var forcedClock by mutableStateOf(false)

    private var pendingLastPlaylist = false

    /** From the home-screen shortcut; waits until the playlists are loaded. */
    fun requestLastPlaylist() {
        if (playlists.isEmpty()) pendingLastPlaylist = true else openLastPlaylist()
    }

    fun openLastPlaylist() {
        val id = prefs.getString("lastPlaylist", null) ?: return
        if (playlists.none { it.id == id }) return
        while (stack.size > 1) stack.removeAt(stack.lastIndex)
        tab = HomeTab.Playlists
        push(Screen.Playlist(id))
        playPlaylist(id)
    }

    private fun rememberLastPlaylist(id: String) {
        prefs.edit().putString("lastPlaylist", id).apply()
        val name = playlists.find { it.id == id }?.name ?: return
        dev.mixtape.player.Shortcuts.updateLastPlaylist(context, name)
    }

    // First-run tutorial
    var showTutorial by mutableStateOf(false)

    fun finishTutorial() {
        showTutorial = false
        prefs.edit().putBoolean("tutorialSeen", true).apply()
    }

    private fun checkFirstRun() {
        if (prefs.getBoolean("tutorialSeen", false)) return
        // Only on a fresh install: an update (or an app that already has data) skips it.
        val info = runCatching { context.packageManager.getPackageInfo(context.packageName, 0) }.getOrNull()
        val freshInstall = info == null || info.firstInstallTime == info.lastUpdateTime
        if (freshInstall && playlists.isEmpty()) showTutorial = true else prefs.edit().putBoolean("tutorialSeen", true).apply()
    }

    // Tag editor
    fun saveTags(
        track: LocalTrack,
        title: String,
        artist: String,
        album: String,
        cover: Uri?,
        onNeedPermission: (android.content.IntentSender) -> Unit,
    ) {
        viewModelScope.launch {
            errorText = "Saving…"
            when (val r = dev.mixtape.player.library.TagEditor.save(context, track, title.trim(), artist.trim(), album.trim(), cover)) {
                is dev.mixtape.player.library.TagEditor.Result.Done -> {
                    errorText = "Saved into the file."
                    kotlinx.coroutines.delay(1500)
                    scanLibrary()
                }
                is dev.mixtape.player.library.TagEditor.Result.NeedPermission -> onNeedPermission(r.request)
                is dev.mixtape.player.library.TagEditor.Result.Failed -> errorText = "Couldn't save: ${r.reason}"
            }
        }
    }

    // Settings
    var swipeToSkip by mutableStateOf(prefs.getBoolean("swipeToSkip", true)); private set
    var parallelDownloads by mutableStateOf(prefs.getInt("parallel", 3).coerceIn(1, 4)); private set

    fun chooseSwipeToSkip(on: Boolean) {
        swipeToSkip = on
        prefs.edit().putBoolean("swipeToSkip", on).apply()
    }

    fun chooseParallelDownloads(count: Int) {
        parallelDownloads = count.coerceIn(1, 4)
        prefs.edit().putInt("parallel", parallelDownloads).apply()
        DownloadQueue.setParallel(parallelDownloads)
    }

    /** Looks for music files again (e.g. after copying songs to the phone). */
    fun rescanMusic() {
        scanLibrary()
        errorText = "Looking for music files…"
    }

    // Spotify
    var loggedIn by mutableStateOf(auth.isLoggedIn); private set
    var waitingForLogin by mutableStateOf(false); private set
    var remote by mutableStateOf<List<SpotifyPlaylistSummary>?>(null); private set

    /** Progress text while something is loading, or null. */
    var busy by mutableStateOf<String?>(null); private set
    /** Message for the snackbar, or null. */
    var errorText by mutableStateOf<String?>(null)

    private var scanJob: Job? = null
    private var rescanJob: Job? = null
    private var rematchJob: Job? = null
    private var loginJob: Job? = null
    private var loginServer: ServerSocket? = null

    /**
     * Rescans when music files are added or removed. Battery: while the app is in the background
     * it only notes that something changed, and rescans once when you come back.
     */
    private var rescanWhenVisible = false
    private val mediaObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
            if (!hasPermission) return
            if (!player.isVisible) {
                rescanWhenVisible = true
                return
            }
            rescanJob?.cancel()
            rescanJob = viewModelScope.launch {
                delay(3000) // a download writes several changes in a row: scan once at the end
                scanLibrary()
            }
        }
    }

    /** True when the phone's battery saver is on: online extras (videos, tour dates) wait. */
    fun batterySaverOn(): Boolean =
        context.getSystemService(android.os.PowerManager::class.java)?.isPowerSaveMode == true

    init {
        DownloadQueue.init(app)
        Config.clientId = spotifyClientId
        SpotifyWeb.init(app)
        dev.mixtape.player.playback.AudioFx.load(app)
        viewModelScope.launch { DownloadQueue.messages.collect { errorText = it } }
        context.contentResolver.registerContentObserver(LocalLibrary.watchUri, true, mediaObserver)
        player.onBecameVisible = {
            if (rescanWhenVisible && hasPermission) {
                rescanWhenVisible = false
                scanLibrary()
            }
        }
        viewModelScope.launch {
            val data = withContext(Dispatchers.IO) { store.load() }
            playlists = data.playlists
            fixMissingCovers()
            checkFirstRun()
            if (pendingLastPlaylist) {
                pendingLastPlaylist = false
                openLastPlaylist()
            }
            overrides = data.overrides
            rematch()
        }
    }

    // ---------- Navigation ----------

    fun push(screen: Screen) {
        stack.add(screen)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun openImport() {
        push(Screen.Import)
        if (loggedIn && remote == null && busy == null) loadRemotePlaylists()
    }

    // ---------- Local library ----------

    private var lastScanAt = 0L

    fun onPermission(granted: Boolean) {
        hasPermission = granted
        // New files are also caught by the media watcher, so a full rescan on every return is not needed.
        if (granted && (!libraryLoaded || System.currentTimeMillis() - lastScanAt > 60_000)) scanLibrary()
    }

    private fun scanLibrary() {
        if (scanJob?.isActive == true) return
        lastScanAt = System.currentTimeMillis()
        scanJob = viewModelScope.launch {
            val tracks = withContext(Dispatchers.IO) { LocalLibrary.scan(context).filter { inScope(it) } }
            val changed = tracks != library || !libraryLoaded
            libraryLoaded = true
            if (!changed) return@launch
            val newMatcher = withContext(Dispatchers.Default) { Matcher(tracks) }
            library = tracks
            libraryById = tracks.associateBy { it.id }
            matcher = newMatcher
            rematch()
        }
    }

    fun searchLibrary(query: String, limit: Int = 200): List<LocalTrack> = matcher.search(query, limit)

    /** Recomputes which file fills each playlist position. Runs off the main thread. */
    private fun rematch() {
        val lists = playlists
        val manual = overrides
        val m = matcher
        val byId = libraryById
        rematchJob?.cancel()
        rematchJob = viewModelScope.launch {
            val result = withContext(Dispatchers.Default) {
                lists.associate { p ->
                    p.id to p.tracks.map { t ->
                        val picked = manual[t.id]?.let { byId[it] }
                        // Songs added in the app point straight at their file.
                        val exact = if (t.id.startsWith("local:")) t.id.removePrefix("local:").toLongOrNull()?.let { byId[it] } else null
                        PlaylistRow(t, picked ?: exact ?: m.match(t), manual = picked != null)
                    }
                }
            }
            rows = result
        }
    }

    // ---------- Spotify ----------

    fun connectSpotify() {
        errorText = null
        if (Config.clientId.isBlank()) {
            errorText = "Paste your Client ID first (step 3)."
            return
        }
        // Stop any earlier attempt so its listener frees the port.
        loginJob?.cancel()
        runCatching { loginServer?.close() }
        val request = auth.newRequest()
        waitingForLogin = true
        loginJob = viewModelScope.launch {
            val thisJob = coroutineContext[Job]
            var server: ServerSocket? = null
            try {
                val listener = withContext(Dispatchers.IO) { receiver.open() }
                server = listener
                loginServer = listener
                context.startActivity(
                    Intent(Intent.ACTION_VIEW, request.url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                val params = receiver.awaitCallback(listener)
                val error = params["error"]
                when {
                    error == "access_denied" -> errorText = "Spotify login was cancelled."
                    error != null -> errorText = "Spotify login failed ($error)."
                    params["state"] != request.state -> errorText = "That login didn't come from this app. Try again."
                    else -> {
                        auth.exchangeCode(params.getValue("code"), request.verifier)
                        loggedIn = true
                        loadRemotePlaylists()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (isActive) handle(e)
            } finally {
                runCatching { server?.close() }
                if (loginJob === thisJob) waitingForLogin = false
            }
        }
    }

    fun logout() {
        auth.logout()
        loggedIn = false
        remote = null
    }

    fun loadRemotePlaylists() = task("Loading your Spotify playlists…") {
        remote = api.libraryPlaylists()
    }

    fun importSelected(ids: Set<String>) {
        val summaries = remote.orEmpty().filter { it.id in ids && it.canImport }
        if (summaries.isEmpty()) return
        task("Importing…") {
            for (s in summaries) {
                busy = "Importing ${s.name}…"
                val tracks = api.playlistTracks(s.id)
                upsert(SavedPlaylist(s.id, s.name, s.imageUrl, tracks, System.currentTimeMillis()))
            }
            persist()
            rematch()
            if (stack.lastOrNull() == Screen.Import) pop()
        }
    }

    /** Pulls the latest song list for one playlist from Spotify. */
    fun resync(id: String) {
        val existing = playlists.find { it.id == id } ?: return
        if (id.startsWith(MINE_PREFIX)) {
            errorText = "This is your own playlist: add songs from the Songs tab or the player."
            return
        }
        if (id.startsWith(FILE_PREFIX)) {
            errorText = "This playlist came from a file. Import the file again to update it."
            return
        }
        val public = id.startsWith(ALBUM_PREFIX) || (!loggedIn && id != dev.mixtape.player.data.LIKED_ID)
        if (!public && !loggedIn) {
            errorText = "Connect Spotify first: tap + on the Playlists tab."
            return
        }
        task("Syncing ${existing.name}…") {
            val tracks = if (public) {
                val kind = if (id.startsWith(ALBUM_PREFIX)) "album" else "playlist"
                val r = withContext(Dispatchers.IO) { SpotifyPublic.fetch(kind, id.removePrefix(ALBUM_PREFIX)) }
                r.note?.let { errorText = it }
                r.tracks
            } else {
                api.playlistTracks(id)
            }
            val image = if (public && existing.imageUrl == null) {
                val kind = if (id.startsWith(ALBUM_PREFIX)) "album" else "playlist"
                withContext(Dispatchers.IO) { runCatching { SpotifyPublic.coverOf(kind, id.removePrefix(ALBUM_PREFIX)) }.getOrNull() }
            } else {
                existing.imageUrl
            }
            upsert(existing.copy(tracks = tracks, imageUrl = image, importedAt = System.currentTimeMillis()))
            persist()
            rematch()
        }
    }

    /** Fills in covers that earlier versions missed for imported Spotify albums and playlists. */
    private fun fixMissingCovers() {
        val missing = playlists.filter {
            it.imageUrl == null && !it.id.startsWith(FILE_PREFIX) && it.id != dev.mixtape.player.data.LIKED_ID
        }
        if (missing.isEmpty()) return
        viewModelScope.launch {
            var changed = false
            missing.forEach { p ->
                val kind = if (p.id.startsWith(ALBUM_PREFIX)) "album" else "playlist"
                val url = withContext(Dispatchers.IO) {
                    runCatching { SpotifyPublic.coverOf(kind, p.id.removePrefix(ALBUM_PREFIX)) }.getOrNull()
                }
                if (url != null) {
                    playlists.find { it.id == p.id }?.let { upsert(it.copy(imageUrl = url)) }
                    changed = true
                }
            }
            if (changed) persist()
        }
    }

    /** Imports a public playlist or album from its Spotify link. No login needed. */
    fun importFromLink(link: String) {
        val parsed = SpotifyPublic.parseLink(link)
        if (parsed == null || parsed.first == "track") {
            errorText = "Paste a Spotify playlist or album link."
            return
        }
        task("Reading playlist…") {
            val r = withContext(Dispatchers.IO) { SpotifyPublic.fetch(parsed.first, parsed.second) }
            val id = if (r.kind == "album") ALBUM_PREFIX + r.id else r.id
            upsert(SavedPlaylist(id, r.name, r.imageUrl, r.tracks, System.currentTimeMillis()))
            persist()
            rematch()
            if (stack.lastOrNull() == Screen.Import) pop()
            push(Screen.Playlist(id))
            r.note?.let { errorText = it }
        }
    }

    /**
     * Imports playlists from a file, fully offline: Spotify's "Download your data" zip (liked songs and
     * every playlist, private ones included), its JSON files, a CSV export, or "Artist - Title" lines.
     * Importing the same playlist again updates it instead of adding a copy.
     */
    fun importFromFile(uri: Uri, fileName: String?) {
        task("Reading file…") {
            val bytes = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            } ?: throw java.io.IOException("Couldn't open that file.")
            val lists = withContext(Dispatchers.Default) { LibraryImport.read(bytes, fileName) }
            if (lists.isEmpty()) {
                throw java.io.IOException(
                    "No songs found. Pick Spotify's data zip, YourLibrary.json / Playlist1.json, a CSV, or a text list.",
                )
            }
            val now = System.currentTimeMillis()
            var firstId: String? = null
            lists.forEachIndexed { n, list ->
                val existing = playlists.firstOrNull { it.id.startsWith(FILE_PREFIX) && it.name == list.name }
                val id = existing?.id ?: "$FILE_PREFIX$now:$n"
                upsert(SavedPlaylist(id, list.name, existing?.imageUrl, list.tracks, now))
                if (firstId == null) firstId = id
            }
            persist()
            rematch()
            if (stack.lastOrNull() == Screen.Import) pop()
            if (lists.size == 1) {
                firstId?.let { push(Screen.Playlist(it)) }
            } else {
                tab = HomeTab.Playlists
                errorText = "Imported ${lists.size} playlists (${lists.sumOf { it.tracks.size }} songs)."
            }
        }
    }

    // ---------- Downloads ----------

    fun chooseQuality(q: Quality) {
        quality = q
        prefs.edit().putString("quality", q.name).apply()
    }

    /** Album search results on the Download tab. */
    var albumResults by mutableStateOf<List<AlbumHit>>(emptyList()); private set
    var searchingAlbums by mutableStateOf(false); private set

    /** A link downloads; anything else searches albums. */
    fun startDownload() {
        val link = extractLink(linkDraft)
        if (link != null) {
            DownloadQueue.addLink(link, quality)
            linkDraft = ""
            albumResults = emptyList()
            return
        }
        val query = linkDraft.trim()
        if (query.isEmpty()) return
        searchingAlbums = true
        viewModelScope.launch {
            try {
                albumResults = DownloadQueue.searchAlbums(query)
                if (albumResults.isEmpty()) errorText = "No albums found for \"$query\"."
            } catch (e: Exception) {
                errorText = "Album search failed: ${e.message?.lines()?.firstOrNull().orEmpty()}"
            } finally {
                searchingAlbums = false
            }
        }
    }

    fun downloadAlbum(hit: AlbumHit) {
        DownloadQueue.addLink(hit.url, quality)
        albumResults = emptyList()
        linkDraft = ""
    }

    /** Downloads the whole album of a song on the phone (from the player). */
    fun downloadAlbumOf(track: LocalTrack) {
        if (track.album.isBlank()) return
        errorText = "Looking for ${track.album}…"
        viewModelScope.launch {
            try {
                val hit = DownloadQueue.searchAlbums("${track.artist} ${track.album}").firstOrNull()
                if (hit == null) {
                    errorText = "Couldn't find the album ${track.album}."
                } else {
                    DownloadQueue.addLink(hit.url, quality)
                    errorText = "Downloading the album ${hit.title}. Progress is in the Download tab."
                }
            } catch (e: Exception) {
                errorText = "Album search failed: ${e.message?.lines()?.firstOrNull().orEmpty()}"
            }
        }
    }

    /** Finds each song of the playlist that isn't on the phone yet and downloads it. */
    fun downloadMissing(id: String) {
        val missing = rows[id].orEmpty().filter { it.local == null }.map { it.track }
        if (missing.isEmpty()) return
        DownloadQueue.addSongs(missing.map { SongRequest(it.title, it.artists.joinToString(", "), it.durationMs, it.id) }, quality)
        errorText = "Downloading ${missing.size} songs. They fill in here as they finish."
    }

    fun trackById(mediaId: String?): LocalTrack? = mediaId?.toLongOrNull()?.let { libraryById[it] }

    /** Other files of the same song on the phone (e.g. MP3 and FLAC), current one included. */
    fun versionsOf(track: LocalTrack): List<LocalTrack> {
        fun key(t: LocalTrack) = (t.title + "|" + t.artist).lowercase().filter { it.isLetterOrDigit() || it == '|' }
        val k = key(track)
        return library.filter { key(it) == k }.sortedBy { it.fileName.lowercase() }
    }

    fun playVersion(track: LocalTrack) = player.replaceCurrent(track)

    /** Downloads the playing song again in another quality, next to the existing file. */
    fun downloadVersion(track: LocalTrack, q: Quality) {
        val sameType = versionsOf(track).any { it.fileName.endsWith(".${q.ext}", ignoreCase = true) }
        val suffix = if (sameType) " [${q.label}]" else ""
        DownloadQueue.addSongs(listOf(SongRequest(track.title, track.artist, track.durationMs)), q, suffix)
        errorText = "Getting ${q.label}. Pick it here when it's done (see the Download tab)."
    }

    fun showMessage(text: String) {
        errorText = text
    }

    /** Called when a link is shared to Mixtape from another app. */
    fun receiveShared(text: String?) {
        val link = extractLink(text.orEmpty()) ?: return
        while (stack.size > 1) stack.removeAt(stack.lastIndex)
        val kind = SpotifyPublic.parseLink(link)?.first
        if (kind == "playlist" || kind == "album") {
            // Spotify playlist or album: ask "import" or "download".
            sharedSpotify = link
        } else {
            linkDraft = link
            tab = HomeTab.Download
        }
    }

    /** Deletes files directly (Android 10, which has no system delete dialog). */
    fun deleteDirect(uris: List<Uri>) {
        viewModelScope.launch {
            var failed = 0
            withContext(Dispatchers.IO) {
                uris.forEach { uri ->
                    try {
                        context.contentResolver.delete(uri, null, null)
                    } catch (e: Exception) {
                        failed++
                    }
                }
            }
            if (failed > 0) errorText = "Android didn't allow deleting $failed of those songs."
        }
    }

    private fun extractLink(text: String): String? =
        Regex("""https?://\S+""").find(text)?.value?.trimEnd('.', ',', ')', '"', '\'')

    fun removePlaylist(id: String) {
        playlists = playlists.filterNot { it.id == id }
        if (stack.lastOrNull() == Screen.Playlist(id)) pop()
        viewModelScope.launch {
            persist()
            rematch()
        }
    }

    /** Use [localId] for this Spotify song everywhere, or null to go back to automatic matching. */
    fun setManualMatch(spotifyTrackId: String, localId: Long?) {
        overrides = if (localId == null) overrides - spotifyTrackId else overrides + (spotifyTrackId to localId)
        viewModelScope.launch {
            persist()
            rematch()
        }
    }

    // ---------- Playback ----------

    /** Plays the songs of a playlist that are on this phone, in Spotify order. */
    fun playPlaylist(id: String, fromRow: Int? = null, shuffle: Boolean? = null) {
        val list = sortedRows(id)
        val queue = ArrayList<LocalTrack>()
        var start = 0
        list.forEachIndexed { i, row ->
            val local = row.local ?: return@forEachIndexed
            if (i == fromRow) start = queue.size
            queue += local
        }
        if (queue.isEmpty()) return
        if (shuffle == true) start = queue.indices.random()
        player.setContext(playlists.find { it.id == id }?.name ?: "Playlist")
        player.play(queue, start, shuffle)
        rememberLastPlaylist(id)
    }

    fun playSongs(tracks: List<LocalTrack>, index: Int) {
        if (tracks.isNotEmpty()) {
            player.setContext("Songs")
            player.play(tracks, index, shuffle = null)
        }
    }

    // ---------- Helpers ----------

    private fun upsert(p: SavedPlaylist) {
        val i = playlists.indexOfFirst { it.id == p.id }
        playlists = if (i >= 0) playlists.toMutableList().also { it[i] = p } else playlists + p
    }

    private suspend fun persist() {
        val data = PlaylistStore.Data(playlists, overrides)
        withContext(Dispatchers.IO) { store.save(data) }
    }

    private fun task(label: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            busy = label
            errorText = null
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                handle(e)
            } finally {
                busy = null
            }
        }
    }

    private fun handle(e: Throwable) {
        if (e is NotLoggedInException) {
            loggedIn = false
            remote = null
        }
        errorText = when (e) {
            is NotLoggedInException -> "Your Spotify login expired. Tap Connect Spotify to log in again."
            is SpotifyException -> when (e.code) {
                400 -> "Spotify didn't accept the login. Check the Client ID and Redirect URI (README, step 1)."
                401 -> "Spotify rejected the login. Connect again."
                403 -> "Spotify refused access. The app owner needs Spotify Premium, and other accounts must be added under User Management."
                404 -> "Spotify couldn't find that playlist. It may have been deleted."
                429 -> "Spotify is limiting requests right now. Wait a minute and try again."
                else -> "Spotify returned error ${e.code}. Try again."
            }
            is UnknownHostException -> "No internet connection."
            is SocketTimeoutException -> if (waitingForLogin) "Spotify login timed out. Tap Connect Spotify to try again." else "Spotify took too long to answer. Try again."
            is BindException -> "Couldn't start the login listener on port ${Config.REDIRECT_PORT}. Restart the app and try again."
            else -> e.message ?: "Something went wrong."
        }
    }

    private companion object {
        const val ALBUM_PREFIX = "album:"
        const val FILE_PREFIX = "file:"
        const val MINE_PREFIX = "mine:"
    }

    override fun onCleared() {
        context.contentResolver.unregisterContentObserver(mediaObserver)
        runCatching { loginServer?.close() }
        player.release()
    }
}
