package dev.mixtape.player.playback

import kotlinx.coroutines.flow.first
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import dev.mixtape.player.library.LocalTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class NowPlaying(
    val mediaId: String? = null,
    val title: String = "",
    val artist: String = "",
    val artworkUri: Uri? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
)

/** One song in the play queue. [index] is its place in the player's list. */
data class QueueEntry(
    val index: Int,
    val mediaId: String,
    val title: String,
    val artist: String,
    val current: Boolean,
    /** Added by you ("Next in queue"), not part of the playlist/album that's playing. */
    val queued: Boolean = false,
)

/** Talks to [PlaybackService] and exposes what's playing as a StateFlow. Use from the main thread. */
class PlayerConnection(context: Context, scope: CoroutineScope) {

    private val _state = MutableStateFlow(NowPlaying())
    val state: StateFlow<NowPlaying> = _state.asStateFlow()

    /** The current song followed by what plays next, in play order (shuffle included). */
    private val _queue = MutableStateFlow<List<QueueEntry>>(emptyList())
    val queue: StateFlow<List<QueueEntry>> = _queue.asStateFlow()

    /** What's playing, for "Next from: …" in the queue. */
    private val _context = MutableStateFlow("")
    val context: StateFlow<String> = _context.asStateFlow()
    fun setContext(name: String) {
        _context.value = name
    }

    /*
     * Spotify-style queue. Shuffle is done by Mixtape itself (the list is re-ordered), so the play
     * order is always simply the list order. Songs you queue sit right after the current one
     * ([userQueued] of them), ahead of the rest of the playlist, shuffle or not.
     */
    private var shuffled = false
    private var unshuffled: List<MediaItem>? = null
    private var userQueued = 0
    private var lastIndex = -1

    private val visible = MutableStateFlow(false)

    /** True while the app is on screen. */
    val isVisible: Boolean get() = visible.value

    /** Things to do when the app comes back on screen (e.g. a rescan that was put off). */
    var onBecameVisible: (() -> Unit)? = null

    /**
     * Fast progress updates (twice a second) only where they show: the player, lyrics and
     * clock screens. Elsewhere the small progress bar updates once a second.
     */
    @Volatile var fastProgress = false

    /** Called by the app when it comes on screen / goes away. */
    fun setVisible(on: Boolean) {
        visible.value = on
        if (on) {
            refresh()
            onBecameVisible?.invoke()
        }
    }

    private var controller: MediaController? = null
    private val pending = mutableListOf<(MediaController) -> Unit>()
    private val future: ListenableFuture<MediaController>

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (events.contains(Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                // Moving forward uses up songs you queued.
                val now = player.currentMediaItemIndex
                if (lastIndex >= 0 && now > lastIndex) userQueued = (userQueued - (now - lastIndex)).coerceAtLeast(0)
                lastIndex = now
            }
            refresh()
            if (events.containsAny(
                    Player.EVENT_TIMELINE_CHANGED,
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED,
                )
            ) {
                refreshQueue()
            }
        }
    }

    init {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            val c = runCatching { future.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(listener)
            refresh()
            refreshQueue()
            pending.forEach { it(c) }
            pending.clear()
        }, ContextCompat.getMainExecutor(context))

        // Keep the progress bar moving while music plays, but only while the app is on screen:
        // with the app in the background (or the screen off) this sleeps completely.
        scope.launch {
            while (true) {
                visible.first { it }
                delay(if (fastProgress) 500 else 1000)
                if (controller?.isPlaying == true) refresh()
            }
        }
    }

    /** Replaces the queue with [tracks] and starts at [startIndex]. [shuffle] null keeps the current setting. */
    fun play(tracks: List<LocalTrack>, startIndex: Int, shuffle: Boolean?) = withController { c ->
        if (tracks.isEmpty()) return@withController
        val items = tracks.map { it.toMediaItem() }
        val start = startIndex.coerceIn(0, items.lastIndex)
        shuffled = shuffle ?: shuffled
        c.shuffleModeEnabled = false
        userQueued = 0
        if (shuffled) {
            unshuffled = items
            val rest = items.toMutableList().apply { removeAt(start) }.shuffled()
            c.setMediaItems(listOf(items[start]) + rest, 0, 0L)
        } else {
            unshuffled = null
            c.setMediaItems(items, start, 0L)
        }
        lastIndex = c.currentMediaItemIndex
        c.prepare()
        c.play()
    }

    /** Swaps the playing song for another file (e.g. a different quality), keeping the position. */
    fun replaceCurrent(track: LocalTrack) = withController { c ->
        val index = c.currentMediaItemIndex
        val position = c.currentPosition
        val wasPlaying = c.isPlaying
        c.replaceMediaItem(index, track.toMediaItem())
        c.seekTo(index, position)
        if (wasPlaying) c.play()
    }

    /** Puts [tracks] right after the current song (ahead of anything you queued before). */
    fun playNext(tracks: List<LocalTrack>) = withController { c ->
        if (tracks.isEmpty()) return@withController
        if (c.mediaItemCount == 0) return@withController startWith(c, tracks)
        c.addMediaItems(c.currentMediaItemIndex + 1, tracks.map { it.toMediaItem() })
        userQueued += tracks.size
    }

    /** Adds [tracks] to "Next in queue": after the current song and your earlier picks, before the playlist continues. */
    fun addToQueue(tracks: List<LocalTrack>) = withController { c ->
        if (tracks.isEmpty()) return@withController
        if (c.mediaItemCount == 0) return@withController startWith(c, tracks)
        val at = (c.currentMediaItemIndex + 1 + userQueued).coerceAtMost(c.mediaItemCount)
        c.addMediaItems(at, tracks.map { it.toMediaItem() })
        userQueued += tracks.size
    }

    private fun startWith(c: MediaController, tracks: List<LocalTrack>) {
        c.setMediaItems(tracks.map { it.toMediaItem() }, 0, 0L)
        userQueued = 0
        lastIndex = 0
        c.prepare()
        c.play()
    }

    fun jumpTo(index: Int) = withController { c ->
        if (index in 0 until c.mediaItemCount) {
            c.seekTo(index, 0L)
            c.play()
        }
    }

    /** Moves a song in the queue (positions in the play order). Crossing into / out of your picks updates them. */
    fun moveInQueue(from: Int, to: Int) = withController { c ->
        if (from !in 0 until c.mediaItemCount || to !in 0 until c.mediaItemCount || from == to) return@withController
        val current = c.currentMediaItemIndex
        val boundary = current + 1 + userQueued // first song of the playlist part
        val fromQueued = from > current && from < boundary
        if (fromQueued && to >= boundary) userQueued--
        else if (!fromQueued && from >= boundary && to > current && to < boundary + 0) userQueued++
        userQueued = userQueued.coerceIn(0, c.mediaItemCount)
        c.moveMediaItem(from, to)
    }

    fun removeFromQueue(index: Int) = withController { c ->
        if (index !in 0 until c.mediaItemCount || index == c.currentMediaItemIndex) return@withController
        val current = c.currentMediaItemIndex
        if (index > current && index <= current + userQueued) userQueued--
        c.removeMediaItem(index)
    }

    /** "Clear queue": removes the songs you queued; the playlist carries on. */
    fun clearQueue() = withController { c ->
        val current = c.currentMediaItemIndex
        val end = (current + 1 + userQueued).coerceAtMost(c.mediaItemCount)
        if (end > current + 1) c.removeMediaItems(current + 1, end)
        userQueued = 0
    }

    private fun refreshQueue() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            _queue.value = emptyList()
            return
        }
        val current = c.currentMediaItemIndex
        _queue.value = (current until c.mediaItemCount).map { i ->
            val item = c.getMediaItemAt(i)
            QueueEntry(
                index = i,
                mediaId = item.mediaId,
                title = item.mediaMetadata.title?.toString().orEmpty(),
                artist = item.mediaMetadata.artist?.toString().orEmpty(),
                current = i == current,
                queued = i > current && i <= current + userQueued,
            )
        }
    }

    /** Back to the song played before (not just the start of this one). */
    fun previousSong() = withController { it.seekToPreviousMediaItem() }

    fun toggle() = withController { c -> if (c.isPlaying) c.pause() else c.play() }
    fun next() = withController { it.seekToNext() }
    fun previous() = withController { it.seekToPrevious() }
    fun seekTo(ms: Long) = withController { it.seekTo(ms) }
    /** Shuffle the rest of the playlist (your queued songs stay next), or put it back in order. */
    fun toggleShuffle() = withController { c ->
        val current = c.currentMediaItemIndex
        val from = (current + 1 + userQueued).coerceAtMost(c.mediaItemCount)
        val rest = (from until c.mediaItemCount).map { c.getMediaItemAt(it) }
        if (!shuffled) {
            unshuffled = (0 until c.mediaItemCount).map { c.getMediaItemAt(it) }
            if (rest.size > 1) {
                c.removeMediaItems(from, c.mediaItemCount)
                c.addMediaItems(from, rest.shuffled())
            }
            shuffled = true
        } else {
            // Back to the original order for what hasn't played yet.
            val original = unshuffled
            val nowId = c.currentMediaItem?.mediaId
            if (original != null && rest.isNotEmpty()) {
                val pos = original.indexOfFirst { it.mediaId == nowId }
                val restIds = rest.map { it.mediaId }.toMutableList()
                val ordered = (if (pos >= 0) original.drop(pos + 1) + original.take(pos) else original)
                    .filter { item -> restIds.remove(item.mediaId) }
                // Anything that wasn't in the original list keeps its place at the end.
                val leftovers = rest.filter { it.mediaId in restIds }
                c.removeMediaItems(from, c.mediaItemCount)
                c.addMediaItems(from, ordered + leftovers)
            }
            shuffled = false
        }
        refresh()
        refreshQueue()
    }

    fun cycleRepeat() = withController { c ->
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun release() {
        controller?.removeListener(listener)
        controller = null
        MediaController.releaseFuture(future)
    }

    private fun withController(action: (MediaController) -> Unit) {
        val c = controller
        if (c != null) action(c) else pending += action
    }

    private fun refresh() {
        val c = controller ?: return
        val md = c.mediaMetadata
        val duration = c.duration
        _state.value = NowPlaying(
            mediaId = c.currentMediaItem?.mediaId,
            title = md.title?.toString().orEmpty(),
            artist = md.artist?.toString().orEmpty(),
            artworkUri = md.artworkUri,
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = if (duration == C.TIME_UNSET) 0L else duration.coerceAtLeast(0L),
            shuffle = shuffled || c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
        )
    }

    private fun LocalTrack.toMediaItem(): MediaItem =
        MediaItem.Builder()
            .setMediaId(id.toString())
            .setUri(uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(title)
                    .setArtist(artist.ifEmpty { null })
                    .setAlbumTitle(album.ifEmpty { null })
                    .setArtworkUri(artUri)
                    .build()
            )
            .build()
}
