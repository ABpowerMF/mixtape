package dev.mixtape.player.wrapped

import dev.mixtape.player.playback.ListenStats
import java.util.Calendar
import java.util.Locale

/** Periods a recap can cover. */
enum class WrapPeriod(val label: String) { THIS_MONTH("This month"), LAST_MONTH("Last month"), THIS_YEAR("This year"), ALL_TIME("All time") }

data class WrapSong(val id: String, val title: String, val artist: String, val ms: Long, val plays: Int)
data class WrapArtist(val name: String, val ms: Long, val plays: Int)

/** A listening recap for one period. */
data class Wrapped(
    val period: WrapPeriod,
    val label: String,
    val totalMs: Long,
    val plays: Int,
    val differentSongs: Int,
    val topSongs: List<WrapSong>,
    val topArtists: List<WrapArtist>,
    /** Most-listened day of the week (e.g. "Friday") and its time. */
    val topDay: Pair<String, Long>?,
    /** Listening time per hour of the day, 0–23. */
    val hours: LongArray,
    val activeDays: Int,
)

object WrappedMaker {

    fun make(period: WrapPeriod, now: Long = System.currentTimeMillis()): Wrapped {
        val (from, to, label) = range(period, now)
        val sessions = ListenStats.sessions(from, to)
        val songs = sessions.groupBy { it.id }.map { (id, list) ->
            WrapSong(id, list.last().title, list.last().artist, list.sumOf { it.ms }, list.count { it.played })
        }.sortedByDescending { it.ms }
        val artists = sessions.filter { it.artist.isNotBlank() }
            .groupBy { it.artist.substringBefore(",").trim() }
            .map { (name, list) -> WrapArtist(name, list.sumOf { it.ms }, list.count { it.played }) }
            .sortedByDescending { it.ms }
        val cal = Calendar.getInstance()
        val hours = LongArray(24)
        val byDay = LongArray(8)
        val days = HashSet<Int>()
        sessions.forEach { s ->
            cal.timeInMillis = s.at
            hours[cal.get(Calendar.HOUR_OF_DAY)] += s.ms
            byDay[cal.get(Calendar.DAY_OF_WEEK)] += s.ms
            days += cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
        }
        val topDayIndex = (1..7).maxByOrNull { byDay[it] }
        val topDay = topDayIndex?.takeIf { byDay[it] > 0 }?.let { d ->
            cal.set(Calendar.DAY_OF_WEEK, d)
            (cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()) ?: "") to byDay[d]
        }
        return Wrapped(
            period = period,
            label = label,
            totalMs = sessions.sumOf { it.ms },
            plays = sessions.count { it.played },
            differentSongs = songs.size,
            topSongs = songs.take(5),
            topArtists = artists.take(5),
            topDay = topDay,
            hours = hours,
            activeDays = days.size,
        )
    }

    private fun range(period: WrapPeriod, now: Long): Triple<Long, Long, String> {
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val locale = Locale.getDefault()
        fun startOfMonth(c: Calendar) = c.apply {
            set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        return when (period) {
            WrapPeriod.THIS_MONTH -> {
                val start = startOfMonth(cal).timeInMillis
                Triple(start, now + 1, "${cal.getDisplayName(Calendar.MONTH, Calendar.LONG, locale)} ${cal.get(Calendar.YEAR)}")
            }
            WrapPeriod.LAST_MONTH -> {
                val end = startOfMonth(cal).timeInMillis
                cal.add(Calendar.MONTH, -1)
                Triple(cal.timeInMillis, end, "${cal.getDisplayName(Calendar.MONTH, Calendar.LONG, locale)} ${cal.get(Calendar.YEAR)}")
            }
            WrapPeriod.THIS_YEAR -> {
                startOfMonth(cal).set(Calendar.MONTH, Calendar.JANUARY)
                Triple(cal.timeInMillis, now + 1, "${cal.get(Calendar.YEAR)}")
            }
            WrapPeriod.ALL_TIME -> Triple(0L, now + 1, "All time")
        }
    }
}
