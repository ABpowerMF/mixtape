package dev.mixtape.player.ui

import androidx.compose.runtime.saveable.rememberSaveable
import dev.mixtape.player.ui.theme.Ui
import dev.mixtape.player.ui.theme.AppFont
import androidx.compose.ui.graphics.toArgb
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import dev.mixtape.player.download.YouTubeCookies
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.download.MediaSaver
import dev.mixtape.player.ui.theme.Appearance
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Palette
import dev.mixtape.player.ui.theme.Swatches
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.ThemePreset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val version = runCatching {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName
    }.getOrNull().orEmpty()

    LaunchedEffect(Unit) { vm.refreshStats() }
    val saveBackup = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            runCatching { dev.mixtape.player.Backup.export(context, uri) }
                .onSuccess { vm.showMessage("Backup saved.") }
                .onFailure { vm.showMessage("Couldn't save the backup: ${it.message}") }
        }
    }
    var restoreFrom by remember { mutableStateOf<android.net.Uri?>(null) }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> restoreFrom = uri }
    restoreFrom?.let { uri ->
        AlertDialog(
            onDismissRequest = { restoreFrom = null },
            title = { Text(Ui.head("restore backup?")) },
            text = { Text("Your current playlists, stats and settings are replaced by the ones in the backup. Mixtape restarts.") },
            confirmButton = {
                TextButton(onClick = {
                    restoreFrom = null
                    runCatching { dev.mixtape.player.Backup.restore(context, uri) }
                        .onSuccess { dev.mixtape.player.Backup.restartApp(context) }
                        .onFailure { vm.showMessage("Couldn't restore: ${it.message}") }
                }) { Text("Restore", color = Mix.Alert) }
            },
            dismissButton = { TextButton(onClick = { restoreFrom = null }) { Text("Cancel", color = Mix.Paper) } },
            containerColor = Mix.Deep,
        )
    }
    var styleOpen by rememberSaveable { mutableStateOf(false) }
    var fontOpen by rememberSaveable { mutableStateOf(false) }
    var colorsOpen by rememberSaveable { mutableStateOf(false) }
    val importFont = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && !Appearance.importFont(context, uri)) {
            vm.showMessage("That file isn't a font Android can read. Try a .ttf or .otf.")
        }
    }
    var youTubeSignedIn by remember { mutableStateOf(YouTubeCookies.isSignedIn(context)) }
    val youTubeLogin = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        youTubeSignedIn = YouTubeCookies.isSignedIn(context)
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("settings"), style = MaterialTheme.typography.titleLarge) },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            // ---------- Stats ----------
            item { Section("stats") }
            item {
                Column {
                    SettingRow(
                        "Listening time: ${formatListened(vm.stats.sumOf { it.listenedMs })}",
                        vm.stats.filter { it.listenedMs > 0 }.maxByOrNull { it.listenedMs }
                            ?.let { "Most listened: ${it.title.ifEmpty { "Unknown song" }}" }
                            ?: "Your most listened songs and artists",
                    ) {
                        OutlinedButton(
                            onClick = { vm.push(Screen.Stats) },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(Ui.btn("open"), color = Mix.Tape) }
                    }
                }
            }

            // ---------- Look ----------
            item { Section("theme") }
            item {
                Column {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(ThemePreset.entries) { preset ->
                            ThemeTile(
                                label = preset.label,
                                palette = preset.palette ?: Appearance.custom,
                                selected = Appearance.preset == preset,
                                onClick = { Appearance.choose(context, preset) },
                            )
                        }
                    }
                }
            }
            item { FoldSection("custom colours", if (Appearance.preset == ThemePreset.CUSTOM) "in use" else "tap to open", open = colorsOpen) { colorsOpen = !colorsOpen } }
            if (colorsOpen) {
                item {
                    Column {
                        SwatchRow("accent", Appearance.customPicks.third) { Appearance.setCustom(context, accent = it) }
                        SwatchRow("background", Appearance.customPicks.first) { Appearance.setCustom(context, background = it) }
                        SwatchRow("text", Appearance.customPicks.second) { Appearance.setCustom(context, text = it) }
                        Text(
                            "Picking a colour switches to the Custom theme. Text and accent are adjusted if they'd be hard to read.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                        )
                    }
                }
            }
            item { FoldSection("style", if (Mix.rounded) "Rounded" else "Terminal", open = styleOpen) { styleOpen = !styleOpen } }
            if (styleOpen) {
                item {
                    Column {
                        Choice("Terminal · square corners, [ brackets ], ~/titles", selected = !Mix.rounded) {
                            Appearance.setRounded(context, false)
                        }
                        Choice("Rounded · soft corners and plain labels", selected = Mix.rounded) {
                            Appearance.setRounded(context, true)
                        }
                        SettingRow("Animations", "Smooth transitions between screens, lists and the player") {
                            Switch(
                                checked = Mix.animations,
                                onCheckedChange = { Appearance.setAnimations(context, it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Mix.Ink,
                                    checkedTrackColor = Mix.Tape,
                                    uncheckedThumbColor = Mix.Fog,
                                    uncheckedTrackColor = Mix.Raised,
                                    uncheckedBorderColor = Mix.Gap,
                                ),
                            )
                        }
                        Text(
                            "For an Apple-like look: Rounded + the Soft light or Soft dark theme + Inter.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }
                }
            }
            item { FoldSection("font", Mix.font.label, open = fontOpen) { fontOpen = !fontOpen } }
            if (fontOpen) {
                item {
                    Column {
                        AppFont.entries.forEach { font ->
                            if (font == AppFont.CUSTOM && Mix.customFont == null) return@forEach
                            val on = Mix.font == font
                            Text(
                                (if (on) "(•) " else "( ) ") + font.label,
                                fontFamily = font.family,
                                style = MaterialTheme.typography.bodyLarge.copy(fontFamily = font.family),
                                color = if (on) Mix.Tape else Mix.Paper,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { Appearance.setFont(context, font) }
                                    .padding(horizontal = 20.dp, vertical = 10.dp),
                            )
                        }
                        OutlinedButton(
                            onClick = { importFont.launch(arrayOf("font/ttf", "font/otf", "font/*", "application/x-font-ttf", "application/octet-stream")) },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                        ) { Text(Ui.btn("import a font (.ttf / .otf)"), color = Mix.Tape) }
                        Text(
                            "Free fonts: fonts.google.com, download a family and pick its .ttf file.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Mix.Fog,
                            modifier = Modifier.padding(horizontal = 20.dp),
                        )
                    }
                }
            }

            // ---------- Downloads ----------
            item { Section("downloads") }
            item {
                Column {
                    SettingRow("Default quality", "Used for new downloads and Download missing") {}
                    QualityPicker(
                        vm.quality,
                        vm::chooseQuality,
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                    )
                    Spacer(Modifier.height(12.dp))
                    SettingRow("Songs at the same time", "More is faster but uses more battery and data") {}
                    Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (1..4).forEach { n ->
                            val on = vm.parallelDownloads == n
                            Box(
                                Modifier
                                    .size(44.dp)
                                    .background(if (on) Mix.Tape else Mix.Raised, TermShape)
                                    .clickable { vm.chooseParallelDownloads(n) },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("$n", color = if (on) Mix.Ink else Mix.Paper, style = MaterialTheme.typography.titleMedium)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    SettingRow("Downloader", "Updates itself once a day. Update now if downloads start failing.") {}
                    OutlinedButton(
                        onClick = DownloadQueue::updateNow,
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                        modifier = Modifier.padding(horizontal = 20.dp),
                    ) { Text(Ui.btn("update now"), color = Mix.Tape) }
                    SettingRow(
                        "YouTube account",
                        if (youTubeSignedIn) "Signed in. Fixes \"not a bot\" and age errors."
                        else "Optional. Fixes \"Sign in to confirm\" errors. A spare account is safest.",
                    ) {
                        OutlinedButton(
                            onClick = {
                                if (youTubeSignedIn) {
                                    YouTubeCookies.signOut(context)
                                    youTubeSignedIn = false
                                } else {
                                    youTubeLogin.launch(Intent(context, YouTubeLoginActivity::class.java))
                                }
                            },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(if (youTubeSignedIn) Ui.btn("sign out") else Ui.btn("sign in"), color = Mix.Tape) }
                    }
                    Text(
                        "Songs are saved to ${MediaSaver.FOLDER}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    )
                }
            }

            // ---------- Library ----------
            item { Section("music folders") }
            item {
                Column {
                    LibraryScope.entries.forEach { scope ->
                        Choice(scope.label + " · " + scope.note, selected = vm.libraryScope == scope) {
                            vm.chooseLibraryScope(scope)
                        }
                    }
                }
            }

            // ---------- Player & library ----------
            item { Section("player") }
            item {
                Column {
                    SettingRow("Swipe to change songs", "On the mini player: left = next, right = previous") {
                        Switch(
                            checked = vm.swipeToSkip,
                            onCheckedChange = vm::chooseSwipeToSkip,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Mix.Ink,
                                checkedTrackColor = Mix.Tape,
                                uncheckedThumbColor = Mix.Fog,
                                uncheckedTrackColor = Mix.Raised,
                                uncheckedBorderColor = Mix.Gap,
                            ),
                        )
                    }
                    SettingRow(
                        "Sideways clock mode",
                        "With auto-rotate on, turn the phone sideways: big clock, date and what's playing.",
                    ) { Toggle(vm.dockMode, vm::chooseDockMode) }
                    if (vm.dockMode) ClockOptions(vm)
                    SettingRow("Video covers", "The song's music video plays silently instead of the cover, like Spotify") {
                        Toggle(vm.videoCovers, vm::chooseVideoCovers)
                    }
                    if (vm.videoCovers) {
                        SettingRow("Only on Wi-Fi", "Videos stream from YouTube (about 5–10 MB per song)") {
                            Toggle(vm.videoWifiOnly, vm::chooseVideoWifiOnly)
                        }
                    }
                    SettingRow("Artist info", "Short Wikipedia profile under the player (swipe up). Saved after the first time.") {
                        Toggle(vm.artistInfoOnline, vm::chooseArtistInfo)
                    }
                SettingRow("Equaliser", "Presets, 5 bands, bass, surround and volume boost") {
                    OutlinedButton(
                        onClick = { vm.push(Screen.Equalizer) },
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                    ) { Text(Ui.btn("open"), color = Mix.Tape) }
                }
                SettingRow("Find lyrics online", "Looks each song up once on LRCLIB, then keeps them offline") {
                    Switch(
                        checked = vm.lyricsOnline,
                        onCheckedChange = vm::chooseLyricsOnline,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Mix.Ink,
                            checkedTrackColor = Mix.Tape,
                            uncheckedThumbColor = Mix.Fog,
                            uncheckedTrackColor = Mix.Raised,
                            uncheckedBorderColor = Mix.Gap,
                        ),
                    )
                }
                SettingRow("Rescan music", "Find songs you copied to the phone") {
                        OutlinedButton(
                            onClick = vm::rescanMusic,
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(Ui.btn("scan"), color = Mix.Tape) }
                    }
                }
            }

            item { Section("backup") }
            item {
                Column {
                    SettingRow("Save a backup", "Playlists, stats, lyrics and settings in one file") {
                        OutlinedButton(
                            onClick = {
                                val day = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                                saveBackup.launch("mixtape-backup-$day.zip")
                            },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(Ui.btn("save"), color = Mix.Tape) }
                    }
                    SettingRow("Restore a backup", "Replaces what's here now; the app restarts") {
                        OutlinedButton(
                            onClick = { openBackup.launch(arrayOf("application/zip", "application/octet-stream")) },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(Ui.btn("restore"), color = Mix.Tape) }
                    }
                }
            }
            item { Section("about") }
            item {
                Column {
                    SettingRow("Tutorial", "The three intro pages again") {
                        OutlinedButton(
                            onClick = { vm.showTutorial = true },
                            shape = TermShape,
                            border = BorderStroke(1.dp, Mix.Gap),
                        ) { Text(Ui.btn("replay"), color = Mix.Tape) }
                    }
                    Text(
                        "mixtape v$version",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        Ui.head(title),
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 10.dp),
    )
}

/** A section header that folds its content away; shows the current choice when folded. */
@Composable
private fun FoldSection(title: String, summary: String, open: Boolean, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
            .padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            (if (open) "▾ " else "▸ ") + (if (Mix.rounded) title.replaceFirstChar { it.uppercase() } else title),
            style = MaterialTheme.typography.titleMedium,
            color = Mix.Tape,
        )
        Spacer(Modifier.width(10.dp))
        if (!open) {
            Text(summary, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        (if (selected) "(•) " else "( ) ") + label,
        style = MaterialTheme.typography.bodyLarge,
        color = if (selected) Mix.Tape else Mix.Paper,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 10.dp),
    )
}

/** A small preview of a theme: its background, text and accent. */
@Composable
private fun ThemeTile(label: String, palette: Palette, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .width(104.dp)
            .clickable(onClick = onClick),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(72.dp)
                .background(palette.ink, TermShape)
                .border(if (selected) 2.dp else 1.dp, if (selected) Mix.Tape else Mix.Fog.copy(alpha = 0.5f), TermShape)
                .padding(8.dp),
        ) {
            Column {
                Text(Ui.head("play"), color = palette.paper, style = MaterialTheme.typography.bodySmall)
                Text("  track", color = palette.fog, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier
                        .width(48.dp)
                        .height(6.dp)
                        .background(palette.tape),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.bodySmall,
            color = if (selected) Mix.Tape else Mix.Fog,
            maxLines = 1,
        )
    }
}

@Composable
private fun SwatchRow(label: String, current: Color, onPick: (Color) -> Unit) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(
            label,
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Paper,
            modifier = Modifier.padding(horizontal = 20.dp),
        )
        Spacer(Modifier.height(6.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(Swatches) { color ->
                val on = color == current
                Box(
                    Modifier
                        .size(34.dp)
                        .background(color, TermShape)
                        .border(if (on) 3.dp else 1.dp, if (on) Mix.Tape else Mix.Fog.copy(alpha = 0.5f), TermShape)
                        .clickable { onPick(color) },
                )
            }
            // Any colour: opens the colour picker.
            item {
                var picking by remember { mutableStateOf(false) }
                Box(
                    Modifier
                        .size(34.dp)
                        .background(Mix.Raised, TermShape)
                        .border(1.dp, Mix.Gap, TermShape)
                        .clickable { picking = true },
                    contentAlignment = Alignment.Center,
                ) { Text("+", color = Mix.Tape, style = MaterialTheme.typography.titleMedium) }
                if (picking) {
                    ColorPickerDialog(
                        initial = current,
                        onDismiss = { picking = false },
                        onPick = {
                            picking = false
                            onPick(it)
                        },
                    )
                }
            }
        }
    }
}

/** Pick any colour: hue, saturation and brightness sliders, or type a hex code. */
@Composable
private fun ColorPickerDialog(initial: Color, onDismiss: () -> Unit, onPick: (Color) -> Unit) {
    val start = remember {
        FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toArgb(), it) }
    }
    var hue by remember { mutableStateOf(start[0]) }
    var sat by remember { mutableStateOf(start[1]) }
    var value by remember { mutableStateOf(start[2]) }
    val color = Color.hsv(hue.coerceIn(0f, 360f), sat.coerceIn(0f, 1f), value.coerceIn(0f, 1f))
    var hex by remember { mutableStateOf(String.format("%06X", initial.toArgb() and 0xFFFFFF)) }

    fun setFromHex(text: String) {
        hex = text.uppercase().filter { it.isLetterOrDigit() }.take(6)
        if (hex.length == 6) {
            val argb = hex.toLongOrNull(16)?.toInt() ?: return
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(argb or 0xFF000000.toInt(), hsv)
            hue = hsv[0]; sat = hsv[1]; value = hsv[2]
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Ui.head("pick a colour")) },
        text = {
            Column {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .background(color, TermShape)
                        .border(1.dp, Mix.Gap, TermShape),
                )
                Spacer(Modifier.height(12.dp))
                Text("hue", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                Slider(
                    value = hue,
                    onValueChange = { hue = it; hex = String.format("%06X", Color.hsv(it, sat, value).toArgb() and 0xFFFFFF) },
                    valueRange = 0f..360f,
                    colors = SliderDefaults.colors(thumbColor = Color.hsv(hue, 1f, 1f), activeTrackColor = Color.hsv(hue, 1f, 1f)),
                )
                Text("saturation", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                Slider(
                    value = sat,
                    onValueChange = { sat = it; hex = String.format("%06X", Color.hsv(hue, it, value).toArgb() and 0xFFFFFF) },
                    colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
                )
                Text("brightness", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                Slider(
                    value = value,
                    onValueChange = { value = it; hex = String.format("%06X", Color.hsv(hue, sat, it).toArgb() and 0xFFFFFF) },
                    colors = SliderDefaults.colors(thumbColor = color, activeTrackColor = color),
                )
                OutlinedTextField(
                    value = hex,
                    onValueChange = ::setFromHex,
                    singleLine = true,
                    prefix = { Text("#") },
                    label = { Text("hex") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(color) }) { Text("Use", color = Mix.Tape) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

@Composable
private fun Toggle(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Mix.Ink,
            checkedTrackColor = Mix.Tape,
            uncheckedThumbColor = Mix.Fog,
            uncheckedTrackColor = Mix.Raised,
            uncheckedBorderColor = Mix.Gap,
        ),
    )
}

/** Clock mode look and battery options. */
@Composable
private fun ClockOptions(vm: MainViewModel) {
    val context = LocalContext.current
    Column(Modifier.padding(start = 16.dp)) {
        SettingRow("Seconds", "Show seconds (uses a bit more battery)") { Toggle(vm.clockSeconds) { vm.setClock(seconds = it) } }
        SettingRow("Date", "Show the day and date") { Toggle(vm.clockDate) { vm.setClock(date = it) } }
        SettingRow("Cover", "Show the cover of what's playing") { Toggle(vm.clockCover) { vm.setClock(cover = it) } }
        SettingRow("Accent colour", "Clock in your accent colour instead of the text colour") { Toggle(vm.clockAccent) { vm.setClock(accent = it) } }
        SettingRow("Clock size", "") {
            Row {
                listOf("S", "M", "L").forEachIndexed { i, label ->
                    Text(
                        label,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (vm.clockSize == i) Mix.Tape else Mix.Fog,
                        modifier = Modifier
                            .clickable { vm.setClock(size = i) }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
        }
        SettingRow("Brightness", "Lower saves battery, great at night") {
            Row {
                listOf("normal", "dim", "night").forEachIndexed { i, label ->
                    Text(
                        label,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (vm.clockDim == i) Mix.Tape else Mix.Fog,
                        modifier = Modifier
                            .clickable { vm.setClock(dim = i) }
                            .padding(horizontal = 6.dp, vertical = 6.dp),
                    )
                }
            }
        }
        SettingRow("Notifications", "Bell with how many you have (needs notification access)") {
            Toggle(vm.clockNotifications) { on ->
                vm.setClock(notifications = on)
                if (on && !dev.mixtape.player.clock.NotificationCounter.hasAccess(context)) {
                    runCatching {
                        context.startActivity(
                            android.content.Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    }
                    vm.showMessage("Allow Mixtape in the list, then come back.")
                }
            }
        }
    }
}
