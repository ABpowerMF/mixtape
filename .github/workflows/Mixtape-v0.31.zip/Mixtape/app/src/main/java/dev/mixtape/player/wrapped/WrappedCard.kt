package dev.mixtape.player.wrapped

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.util.Size
import androidx.core.content.FileProvider
import dev.mixtape.player.library.LocalLibrary
import java.io.File

/** Draws a 1080×1920 story card of a recap and shares it. */
object WrappedCard {

    data class Colors(val background: Int, val text: Int, val dim: Int, val accent: Int)

    fun render(context: Context, w: Wrapped, c: Colors): Bitmap {
        val width = 1080
        val height = 1920
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(c.background)
        val mono = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        val monoBold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        fun paint(size: Float, color: Int, bold: Boolean = false) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = if (bold) monoBold else mono
        }
        fun fit(text: String, p: Paint, max: Float): String {
            if (p.measureText(text) <= max) return text
            var t = text
            while (t.isNotEmpty() && p.measureText("$t…") > max) t = t.dropLast(1)
            return "$t…"
        }
        val left = 80f
        var y = 150f
        canvas.drawText("> MIXTAPE WRAPPED", left, y, paint(48f, c.accent, bold = true))
        y += 64f
        canvas.drawText(w.label, left, y, paint(40f, c.dim))

        // Top song cover
        y += 50f
        val coverSize = 420
        val cover = w.topSongs.firstOrNull()?.id?.toLongOrNull()?.let { id ->
            runCatching { context.contentResolver.loadThumbnail(LocalLibrary.contentUri(id), Size(coverSize, coverSize), null) }.getOrNull()
        }
        val coverRect = RectF(left, y, left + coverSize, y + coverSize)
        if (cover != null) {
            canvas.drawBitmap(Bitmap.createScaledBitmap(cover, coverSize, coverSize, true), null, coverRect, null)
        } else {
            canvas.drawRect(coverRect, Paint().apply { color = c.dim; alpha = 60 })
        }
        // Big numbers next to the cover
        val nx = left + coverSize + 50f
        val hours = w.totalMs / 3_600_000
        val minutes = w.totalMs / 60_000
        canvas.drawText(if (hours >= 1) "$hours h" else "$minutes m", nx, y + 150f, paint(120f, c.text, bold = true))
        canvas.drawText("listened", nx, y + 205f, paint(38f, c.dim))
        canvas.drawText("${w.plays} plays", nx, y + 290f, paint(44f, c.text))
        canvas.drawText("${w.differentSongs} songs", nx, y + 350f, paint(44f, c.text))
        canvas.drawText("${w.activeDays} days", nx, y + 410f, paint(44f, c.text))
        y += coverSize + 110f

        canvas.drawText("> top songs", left, y, paint(46f, c.accent, bold = true))
        y += 20f
        val maxText = width - left * 2 - 60f
        w.topSongs.forEachIndexed { i, s ->
            y += 72f
            canvas.drawText("${i + 1}", left, y, paint(44f, c.dim, bold = true))
            canvas.drawText(fit(s.title, paint(44f, c.text, bold = true), maxText), left + 60f, y, paint(44f, c.text, bold = true))
            canvas.drawText(fit(s.artist, paint(32f, c.dim), maxText), left + 60f, y + 38f, paint(32f, c.dim))
            y += 20f
        }
        y += 90f
        canvas.drawText("> top artists", left, y, paint(46f, c.accent, bold = true))
        w.topArtists.forEachIndexed { i, a ->
            y += 62f
            canvas.drawText("${i + 1}", left, y, paint(42f, c.dim, bold = true))
            canvas.drawText(fit(a.name, paint(42f, c.text), maxText), left + 60f, y, paint(42f, c.text))
        }

        // Listening by hour
        val chartTop = height - 330f
        val chartBottom = height - 170f
        canvas.drawText("> when you listen", left, chartTop - 30f, paint(40f, c.accent, bold = true))
        val max = (w.hours.maxOrNull() ?: 0L).coerceAtLeast(1L)
        val barW = (width - left * 2) / 24f
        val bar = Paint().apply { color = c.accent }
        for (h in 0 until 24) {
            val hgt = (chartBottom - chartTop) * w.hours[h] / max
            canvas.drawRect(left + h * barW + 4f, chartBottom - hgt.coerceAtLeast(3f), left + (h + 1) * barW - 4f, chartBottom, bar)
        }
        listOf(0 to "0h", 6 to "6h", 12 to "12h", 18 to "18h").forEach { (h, label) ->
            canvas.drawText(label, left + h * barW, chartBottom + 44f, paint(30f, c.dim))
        }
        w.topDay?.let { (day, _) ->
            canvas.drawText("favourite day: $day", left, height - 60f, paint(36f, c.text))
        }
        return bmp
    }

    /** Saves the card and opens the share sheet (stories, chats…). */
    fun share(context: Context, bitmap: Bitmap) {
        val dir = File(context.cacheDir, "share").apply { mkdirs() }
        val file = File(dir, "mixtape-wrapped.png")
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
        val send = Intent(Intent.ACTION_SEND)
            .setType("image/png")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "Share your Mixtape Wrapped").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
