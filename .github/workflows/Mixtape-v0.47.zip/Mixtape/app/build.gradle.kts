plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "dev.mixtape.player"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.mixtape.player"
        minSdk = 29
        targetSdk = 35
        versionCode = 48
        versionName = "0.47"

        // The downloader ships native Python/ffmpeg binaries; 64-bit ARM covers modern phones.
        ndk {
            abiFilters += "arm64-v8a"
        }
    }

    // One fixed key, so each new APK installs over the previous one.
    signingConfigs {
        create("mixtape") {
            storeFile = rootProject.file("mixtape.keystore")
            storePassword = "mixtape"
            keyAlias = "mixtape"
            keyPassword = "mixtape"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("mixtape")
        }
        debug {
            signingConfig = signingConfigs.getByName("mixtape")
        }
    }

    packaging {
        // youtubedl-android needs its native files unpacked on the phone.
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "/META-INF/{AL2.0,LGPL2.1}",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Playback + lock-screen / notification controls
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")

    // Drag-to-reorder in the queue
    implementation("sh.calvin.reorderable:reorderable:2.4.3")

    // Cover art loading
    implementation("io.coil-kt:coil-compose:2.7.0")

    // "Add from link": yt-dlp + Python + ffmpeg + QuickJS, bundled for Android
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")

    // Lyrics translation, on the phone (models download once per language, then work offline)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    // Tapes: QR codes to share a playlist (make them, and scan them with the camera)
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-view:1.4.1")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")

    // Vault: open with a fingerprint (checked by Android against the phone's saved fingerprints)
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")
}
