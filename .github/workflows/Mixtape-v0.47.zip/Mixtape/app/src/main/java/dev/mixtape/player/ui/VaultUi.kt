package dev.mixtape.player.ui

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** True when the phone has a fingerprint saved and a sensor Android trusts for this. */
fun fingerprintReady(context: Context): Boolean =
    BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
        BiometricManager.BIOMETRIC_SUCCESS

/**
 * Asks Android to check a fingerprint. Android compares it with the fingerprints saved in the
 * phone's settings (Mixtape never sees the fingerprint itself); only a real match unlocks.
 */
fun askFingerprint(activity: FragmentActivity, onMatch: () -> Unit) {
    val prompt = BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onMatch()
        },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Open the vault")
        .setSubtitle("Mixtape")
        .setNegativeButtonText("Use PIN")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .build()
    runCatching { prompt.authenticate(info) }
}

/** Making the vault PIN: numbers only, 4 to 10 of them, typed twice. It can't be changed later. */
@Composable
fun VaultSetupDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val canFinger = remember { fingerprintReady(context) }
    var pin by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var finger by remember { mutableStateOf(canFinger) }
    val valid = pin.length in 4..10
    val same = valid && pin == again
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Ui.head("make a vault PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Albums and playlists in the vault only open from Settings → vault, with this PIN" +
                        if (canFinger) " or your fingerprint." else ".",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(10) },
                    label = { Text("PIN (4 to 10 numbers)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
                OutlinedTextField(
                    value = again,
                    onValueChange = { v -> again = v.filter { it.isDigit() }.take(10) },
                    label = { Text("type it again") },
                    singleLine = true,
                    isError = again.isNotEmpty() && again != pin && again.length >= pin.length,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
                if (canFinger) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Also open with fingerprint", style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, modifier = Modifier.weight(1f))
                        Switch(
                            checked = finger,
                            onCheckedChange = { finger = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Mix.Ink, checkedTrackColor = Mix.Tape),
                        )
                    }
                }
                Text(
                    "⚠ You won't be able to change this PIN later. If you forget it, the vault stays locked " +
                        "(the songs stay on your phone).",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Alert,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = same,
                onClick = {
                    vm.createVaultPin(pin, finger && canFinger)
                    onDismiss()
                },
            ) { Text("Make PIN", color = if (same) Mix.Tape else Mix.Fog) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

/** Settings → vault: the lock (PIN pad + fingerprint), then what's inside. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("vault"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            actions = {
                if (vm.vaultOpen) {
                    IconButton(onClick = {
                        vm.lockVault()
                        vm.pop()
                    }) { Icon(Icons.Filled.Lock, contentDescription = "Lock the vault") }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        when {
            !vm.vaultSetUp -> Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("No vault yet. Make a PIN to start.", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
                OutlinedButton(onClick = { vm.vaultSetupFor = "" }, shape = TermShape, border = BorderStroke(1.dp, Mix.Gap)) {
                    Text(Ui.btn("make a PIN"), color = Mix.Tape)
                }
            }
            !vm.vaultOpen -> VaultLock(vm)
            else -> VaultContents(vm)
        }
    }
}

@Composable
private fun VaultLock(vm: MainViewModel) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val scope = rememberCoroutineScope()
    val canFinger = remember { vm.vaultFingerprint && fingerprintReady(context) }
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }

    // Offer the fingerprint straight away.
    LaunchedEffect(Unit) {
        if (canFinger && activity != null) askFingerprint(activity) { vm.unlockVaultWithFingerprint() }
    }

    fun submit() {
        if (pin.length < 4 || checking) return
        checking = true
        val tried = pin
        scope.launch {
            val ok = vm.unlockVault(tried)
            checking = false
            if (!ok) {
                wrong = true
                pin = ""
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Icon(Icons.Filled.Lock, contentDescription = null, tint = Mix.Paper, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(12.dp))
        val waiting = vm.vaultWaitUntil > System.currentTimeMillis()
        Text(
            when {
                waiting -> "Too many tries. Wait 30 seconds."
                wrong -> "Wrong PIN, try again."
                else -> "Type your PIN"
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (wrong || waiting) Mix.Alert else Mix.Fog,
        )
        Spacer(Modifier.height(16.dp))
        // The PIN as dots.
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(16.dp)) {
            repeat(pin.length) { Box(Modifier.size(12.dp).background(Mix.Paper, CircleShape)) }
            if (pin.isEmpty()) Text("—", color = Mix.Gap)
        }
        Spacer(Modifier.height(24.dp))
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "finger", "0", "back")
        keys.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                row.forEach { k ->
                    Box(
                        Modifier
                            .size(68.dp)
                            .then(
                                if (k.length == 1) Modifier.border(BorderStroke(1.dp, Mix.Gap), CircleShape) else Modifier,
                            )
                            .clickable(enabled = k != "finger" || canFinger) {
                                wrong = false
                                when (k) {
                                    "back" -> pin = pin.dropLast(1)
                                    "finger" -> activity?.let { askFingerprint(it) { vm.unlockVaultWithFingerprint() } }
                                    else -> {
                                        if (pin.length < 10) pin += k
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        when (k) {
                            "back" -> Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "Delete", tint = Mix.Fog)
                            "finger" -> if (canFinger) Icon(Icons.Filled.Fingerprint, contentDescription = "Use fingerprint", tint = Mix.Tape)
                            else -> Text(k, style = MaterialTheme.typography.headlineSmall, color = Mix.Paper)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        TextButton(onClick = { submit() }, enabled = pin.length >= 4 && !checking && !waiting) {
            Text(Ui.btn("open"), color = if (pin.length >= 4) Mix.Tape else Mix.Fog)
        }
    }
    // Clears the "wait" message when the 30 seconds are up.
    LaunchedEffect(vm.vaultWaitUntil) {
        val left = vm.vaultWaitUntil - System.currentTimeMillis()
        if (left > 0) {
            delay(left)
            wrong = false
        }
    }
}

/** What's in the vault: tap to open and play; hold to take it back out. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VaultContents(vm: MainViewModel) {
    val albums = remember(vm.library) { vm.localAlbums() }
    val entries = vm.hidden.sorted().mapNotNull { key ->
        when {
            key.startsWith("pl:") -> vm.playlists.find { it.id == key.removePrefix("pl:") }?.let { p ->
                VaultEntry(key, p.name, if (p.id.startsWith("album:")) "album" else "playlist · ${p.tracks.size} songs", p.imageUrl, true)
            }
            key.startsWith("al:") -> albums.find { it.folder == key.removePrefix("al:") }?.let { a ->
                VaultEntry(key, a.name, "album · ${a.artist} · ${a.tracks.size} songs", a.tracks.first().artUri, false)
            }
            else -> null
        }
    }
    if (entries.isEmpty()) {
        Column { FingerprintToggle(vm) }
        Text(
            "The vault is empty. Hold an album or playlist in the Playlists tab (or use its ⋮ menu) → Move to vault.",
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Fog,
            modifier = Modifier.padding(20.dp),
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        item {
            Column { FingerprintToggle(vm) }
        }
        item {
            Text(
                "Hold one to take it back out. The vault locks when you leave the app.",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
        }
        items(entries, key = { it.key }) { e ->
            var menu by remember { mutableStateOf(false) }
            Box {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = {
                                if (e.key.startsWith("pl:")) vm.push(Screen.Playlist(e.key.removePrefix("pl:")))
                                else vm.push(Screen.Album(e.key.removePrefix("al:")))
                            },
                            onLongClick = { menu = true },
                        )
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Artwork(e.cover, Modifier.size(64.dp), fallback = if (e.playlist) Icons.Filled.MusicNote else Icons.Filled.Album)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, style = MaterialTheme.typography.titleMedium, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(e.note, style = MaterialTheme.typography.bodyMedium, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Take out of the vault") },
                        onClick = {
                            menu = false
                            vm.takeOutOfVault(e.key)
                        },
                    )
                }
            }
        }
    }
}

private data class VaultEntry(val key: String, val name: String, val note: String, val cover: Any?, val playlist: Boolean)

/** Settings → vault row. */
@Composable
fun VaultSettings(vm: MainViewModel) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("Vault", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
            Text(
                if (!vm.vaultSetUp) {
                    "Keep albums and playlists behind a PIN" + (if (fingerprintReady(LocalContext.current)) " or fingerprint" else "") + "."
                } else {
                    val n = vm.hidden.size
                    "$n " + (if (n == 1) "album or playlist" else "albums and playlists") + " inside."
                },
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
            )
        }
        Spacer(Modifier.width(12.dp))
        OutlinedButton(
            onClick = {
                if (vm.vaultSetUp) {
                    vm.push(Screen.Vault)
                } else {
                    vm.vaultSetupFor = ""
                }
            },
            shape = TermShape,
            border = BorderStroke(1.dp, Mix.Gap),
        ) { Text(Ui.btn(if (vm.vaultSetUp) "open" else "set up"), color = Mix.Tape) }
    }
}

/** Only shown inside the open vault, so nobody can switch it on without the PIN. */
@Composable
private fun FingerprintToggle(vm: MainViewModel) {
    if (fingerprintReady(LocalContext.current)) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Open with fingerprint", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
                Text("Uses the fingerprints saved in the phone's settings", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
            }
            Switch(
                checked = vm.vaultFingerprint,
                onCheckedChange = vm::chooseVaultFingerprint,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Mix.Ink,
                    checkedTrackColor = Mix.Tape,
                    uncheckedThumbColor = Mix.Fog,
                    uncheckedTrackColor = Mix.Raised,
                    uncheckedBorderColor = Mix.Gap,
                ),
            )
        }
    }
}
