Mixtape v0.47

- Updates from inside the app: Settings → updates, or the pop-up when a new version is out.
- Last.fm: Settings → last.fm → connect (your own Last.fm account).
- New tutorial covering everything (Settings → about → replay).
- Vault: albums and playlists behind a PIN or fingerprint (hold → Move to vault).
- Delete albums, keep or delete their songs.
- Share playlists as a tape with a QR code, scan a friend's tape.
- Karaoke with a vocals slider, ASCII visualiser, tape stop, listen together, library cleanup.
