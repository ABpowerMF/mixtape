# Mixtape

A music player for the songs on your phone that rebuilds your Spotify playlists from them,
and can download the songs you're missing.

- **Import** a Spotify playlist or album by pasting its link (no login needed). Mixtape lines the
  songs up with the files on your phone, in the same order.
- **Download missing** fetches only the songs of a playlist you don't have yet.
- **Download tab**: paste (or share to Mixtape) any YouTube or Spotify link: a song, album or
  playlist. Pick the quality: MP3 128/192/320, M4A original, MX original (Opus), or FLAC.
  Files go to `Music/Mixtape`. Songs are matched on YouTube Music, closest in length to the
  Spotify version, so you get the album cut (no video intros) with the square album cover.
- **Settings tab**: themes (Terminal, Black & white, White & black, Green & white, Amber,
  Night drive) or your own colours, terminal or clean font, default quality, songs downloaded at
  once, swipe on/off, update the downloader, rescan music.
- **Stats** (Settings → stats): total listening time, most listened songs and top artists.
- **Playlist order**: ⋮ menu on a playlist → sort by playlist order, title, artist or length,
  or *Edit order* to move songs up, down or to the top.
- **Albums**: paste an album link (Spotify or YouTube Music), or type an album name in the
  Download tab and tap Search. On the player, the quality menu has *get the whole album*.
  Albums go in their own folder (Music/Mixtape/Artist - Album) with album name and track numbers,
  and show up in the collapsible *albums* section below your playlists.
- **Import from a file (offline)**: Spotify's "Download your data" zip (liked songs + every playlist,
  private ones too), CSV/TXT from TuneMyMusic or Soundiiz (any service), or "Artist - Title" lines.
  Import → *how do I get a file?* explains each.
- **Queue**: on the player tap *[ queue ]*; in Songs, hold songs → *play next* / *add to queue*.
- **Music folders** (Settings): all music, only the Music folder, or only Mixtape's folder.
  Voice notes, recordings and ringtones are skipped.
- **Playlist search**, and a colour picker (the + after the colour swatches) for any custom colour.
- **Lyrics**: on the player tap *[ lyrics ]*. Synced lyrics light up line by line (tap a line to jump
  there); otherwise plain text. Found once on LRCLIB, then kept on the phone for offline use. You can
  also paste your own (plain or LRC). Online lookup can be turned off in Settings.
  The translate button (文A) shows a translation under each line, done on the phone with Google ML Kit:
  each language downloads once (~30 MB), then works offline.
- **Equaliser**: the sliders icon on the player (or Settings → player). 13 presets, 5 bands,
  bass/depth, surround/width and a volume boost. Uses Android's built-in audio effects.
- **Sideways clock mode** (Settings → player): turn the phone sideways for a smart-display style
  screen with a big clock, the date, the cover, the song and controls. Full screen, stays on.
  The screen also stays on while you read lyrics.
- **Look** (Settings): style *Terminal* (square, [ brackets ]) or *Rounded* (soft corners, plain labels);
  11 fonts (monospace, JetBrains Mono, VT323, 8-bit, Inter, Nunito, Barlow, Space Grotesk, Playfair…)
  or import your own .ttf/.otf; new themes Soft light, Soft dark and Rose.
- **Your own playlists**: Playlists → folder-plus icon, or add songs from the Songs tab (hold → add to
  playlist) and from the player (+ icon). Edit songs to reorder or remove.
- **Player**: swipe up for artist info (Wikipedia, with photos), your stats and their albums. Video covers: the
  song's music video plays silently instead of the cover (Settings → player; Wi-Fi only by default).
- **Fade in & out** between songs (Equaliser → fade).
- **Effects** (Equaliser): slowed / sped up (with vinyl pitch), reverb and bitcrush sliders; they work
  with the equaliser switched off too.
- **Clock mode** follows the phone's auto-rotate switch; options for seconds, date, cover, colour, size,
  brightness (normal / dim / night) and a notification bell (needs notification access).
- **Mixtape Wrapped** (Stats → wrapped): recap for this month, last month, this year or all time,
  shareable as a story image.
- **Smart playlists**: Most played, Recently added, Forgotten favourites, Never played.
- **Crossfade** (Equaliser → fade): the next song starts while the current one fades out.
- **Edit song**: title, artist, album and cover, saved into the file (player quality menu, or hold a song).
- **Backup & restore** (Settings → backup): playlists, stats, lyrics and settings in one file.
- **Home screen shortcuts**: long-press the icon for Clock mode and your last playlist.
- **Android Auto**: playlists, albums, smart playlists and all songs in the car. For an app not from the
  Play Store, turn on Android Auto → developer settings → Unknown sources.
- **Tutorial** on first install; replay it from Settings → about.
- **Background picture or video** (Settings → background picture), with darken and blur sliders.
- **Battery**: the app only updates the screen while it's visible; fades/crossfade sleep between songs;
  video covers and background videos pause when the app is in the background.
- **Concerts** (Playlists tab, under smart playlists): upcoming shows of your top 30 artists from
  Spotify, the ones near you first (set your area: location or a city; 50/150/500 km), and every
  tour date by date or by artist. Tap a show for tickets. Checked once a day.
- **Widgets**: long-press the home screen → Widgets → Mixtape: *now playing* (cover, song,
  play/pause, next), *cover*, or *cover + clock*.
- **Scroll bar**: drag the right edge of any long list to jump through it.
- **Covers**: songs from Spotify get Spotify's own album cover.
- **Mini player**: swipe left for the next song, right for the one before.
- **Versions**: on the player, tap the `[ quality ▾ ]` button to switch between downloaded
  versions of a song, or get it in another quality.
- **Full playlists**: link import reads every song, not just the first 100. If Spotify blocks that,
  the app says where it failed; importing a CSV or "Artist - Title" text file always works.
- **Delete songs**: in the Songs tab, hold a song to start selecting, tap *Select all* to pick
  everything shown (use search to narrow it), then the bin icon.
- **Share as a tape** (v0.40): the share icon next to ⋮ on a playlist shows it as a cassette with a
  QR code. Spotify playlists fit in one code; long own playlists show several codes in a row.
  *Share tape* sends a picture (plus a song list for long tapes), *Save image* puts it in Pictures/Mixtape.
- **Scan a tape**: Playlists → + → *Scan a tape*. Shows how many of its songs are already on your phone;
  *Import + download missing* or *Import only*.
- **Karaoke**: the microphone next to translate on the lyrics screen. The line being sung is big and
  fills in white; a *vocals* slider turns the voice down (0% = instrumental, 100% = normal song).
  Works best on stereo songs with the voice in the middle; the timing is per line (LRCLIB has no word timings).
- **ASCII visualiser**: a low strip of moving characters above the mini player. Settings → player →
  Visualiser: bars, dots, wave or off (off saves a little battery).
- **Tape stop** (Settings → player, off by default): pausing slows the song down like a tape deck,
  play winds it back up.
- **Spotify auto-sync** (Settings → spotify sync): imported Spotify playlists are checked once a day;
  new songs are added, and downloaded on Wi-Fi.
- **Library cleanup** (Settings → library cleanup): duplicates, missing covers (found on the iTunes
  catalogue), messy names ("Official Video", no artist) and broken files. Review, untick, then fix.
- **Albums from Spotify** (v0.41) look like the albums on your phone: big cover, artist, length, a cover on every song.
- **Delete an album** (v0.42): its ⋮ menu, or hold it in the Playlists tab → *Delete album*. Choose to keep
  the songs or delete them too; it tells you if any are in your playlists and can take them out of yours.
- **Vault** (v0.43): hold an album or playlist (or its ⋮ menu) → *Move to vault*. It leaves the Playlists tab
  (an album's songs also leave the Songs tab) and opens only from Settings → vault with your PIN (4 to 10 numbers,
  can't be changed later) or a fingerprint saved in the phone's settings. Hold one inside the vault → *Take out of the vault*.
  The vault locks again when you leave the app.
- **Continue widget**: your last three playlists (tap to play) and *shuffle all*.
- **Listen together** (people icon on the player): both phones on the same Wi-Fi with that screen open
  (phones only show up to each other there, and song links only work for the phone you joined).
  Play on both phones at the same second, or use one phone as the speaker and the other as a remote.
  A song only one of you has is streamed over the Wi-Fi (or downloaded for the other, or skipped).
- **Send to 3DS** (playlist ⋮ menu): sends the songs Mixtape DS doesn't have yet, their lyrics (.lrc) and the
  playlist (.m3u) over Wi-Fi. Non-MP3 songs are converted to MP3 192 kbps with the bundled ffmpeg. On the 3DS:
  Mixtape DS → SELECT → receive from phone. Finds the 3DS by UDP broadcast on port 8081, or type its address.
- **Last.fm scrobbling**: every song you play goes to your Last.fm profile.
  1. No account? Make a free one at https://www.last.fm/join.
  2. In Mixtape: Settings → last.fm → *connect*, then your Last.fm name and password (once; only the login key is kept).
  3. Play a song for half its length (or 4 minutes) and it shows on your profile. Offline plays are sent later.
  Everyone connects their own account; the app's API key comes from the repo's secrets at build time.
- Link import works for public playlists and albums. Very long playlists may stop at 100 songs
  if Spotify doesn't allow reading the rest.
- When logged in, Spotify only shares the songs of playlists **you created or collaborate on**,
  plus your **Liked Songs**.
- If the app owner's Premium lapses, Spotify stops the connection until it's renewed.
  Playlists you already imported keep working.
- Spotify logins expire after a while. When that happens, Mixtape asks you to connect again.

## Signing key and secrets (not in this project)

The APK's signing key and the Last.fm key are **not** in this code, so the zip is safe to share.
GitHub Actions gets them from the repo's secrets (Settings → Secrets and variables → Actions):

| Secret | What it is |
|---|---|
| `MIXTAPE_KEYSTORE_BASE64` | the signing key file, as text (base64) |
| `MIXTAPE_KEYSTORE_PASSWORD` | its password |
| `LASTFM_API_KEY`, `LASTFM_SECRET` | from https://www.last.fm/api/account/create |
| `RELEASES_TOKEN` | lets the build post the APK to mixtape-releases |

Keep a copy of the keystore and its password somewhere safe (a password manager): without that exact
key, new versions can't install over the old ones. Someone building this code without the secrets
gets an APK signed with a throwaway key: it works, but it's not the official Mixtape and can't update it.

## Updates from inside the app

Mixtape checks for a new version once a day (Settings → updates, or a pop-up) and installs it over
the old one. It reads the public repo **ABpowerMF/mixtape-releases**, so this code repo can stay private.
One-time setup:

1. Create a new **public** repository called `mixtape-releases` (tick "Add a README").
2. GitHub → your picture → Settings → Developer settings → Personal access tokens → **Fine-grained tokens**
   → Generate new token. Repository access: *Only select repositories* → `mixtape-releases`.
   Permissions → Repository permissions → **Contents: Read and write**. Generate, copy the token.
3. In **this** repo: Settings → Secrets and variables → Actions → New repository secret.
   Name `RELEASES_TOKEN`, paste the token.
4. Use the workflow `android.yml` as `.github/workflows/build.yml` (replacing the old one).

Every build then posts `Mixtape-vX.apk` to both repos; `WHATSNEW.md` is the text the update pop-up shows.
The first time, Android asks to "Allow from this source" for Mixtape.

## Troubleshooting

| What you see | Fix |
|---|---|
| Browser shows **INVALID_CLIENT: Invalid redirect URI** | In the Spotify dashboard, the Redirect URI must be exactly `http://127.0.0.1:43821/callback` (no `localhost`, no trailing slash). Click **Save** after editing. |
| Browser shows **INVALID_CLIENT: Invalid client** | The Client ID in `Config.kt` has a typo or extra spaces. |
| "Spotify refused access" (403) | The app owner needs Premium, and any other account must be added in **User Management**. |
| "Add your Spotify Client ID in Config.kt first" | See *Optional: logging in to Spotify*. |
| Browser can't open `127.0.0.1` | Go back to Mixtape and tap **Connect Spotify** again. Mixtape must stay open in the background while you log in. |
| A song shows Missing but the file is on the phone | Hold the song and pick the file. Fixing the file's title/artist tags also helps. |
| A download fails with a YouTube error | Mixtape updates its downloader once a day. Wait a bit, then tap the failed song to retry. |
| The APK won't install over the old one | Uninstall the old Mixtape first (only needed once, if it was built on a different computer). |
| A file doesn't appear in **Songs** at all | Android only indexes files in normal folders (Music, Download). Files in hidden folders or with a `.nomedia` file nearby are skipped. |

---

## Project layout

```
app/src/main/java/dev/mixtape/player/
  Config.kt               Spotify Client ID and redirect address
  MainActivity.kt
  spotify/                Login (PKCE), Web API calls, public link reader
  download/               Download queue (yt-dlp), quality options, saving to Music/Mixtape
  library/                Scans the phone's music, fuzzy matching
  data/                   Playlist storage (JSON in app storage)
  playback/               Background playback service (Media3/ExoPlayer)
  ui/                     Compose screens
```

Font: Barlow, SIL Open Font License (see `FONT_LICENSE_OFL.txt`).

Downloader: youtubedl-android (yt-dlp, Python, ffmpeg, QuickJS), GPL-3.0.
