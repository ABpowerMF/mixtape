Mixtape v0.50

- Send to 3DS: a playlist's ⋮ menu → Send to 3DS. Sends the songs Mixtape DS doesn't have yet, their lyrics and the playlist itself over Wi-Fi. Songs that aren't MP3 are turned into MP3 first (the 3DS only plays MP3). On the 3DS: Mixtape DS → SELECT → receive from phone.
