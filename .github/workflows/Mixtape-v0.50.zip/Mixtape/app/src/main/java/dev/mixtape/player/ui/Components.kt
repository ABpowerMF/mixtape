package dev.mixtape.player.ui

import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.gestures.horizontalDrag
import androidx.compose.foundation.gestures.awaitHorizontalTouchSlopOrCancellation
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.blur
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalContext
import dev.mixtape.player.ui.theme.Ui
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.text.BasicTextField
import dev.mixtape.player.ui.theme.TermShape
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.lazy.LazyListState
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix

/** Cover art with a quiet placeholder icon underneath (shown when there's no art). */
@Composable
fun Artwork(
    model: Any?,
    modifier: Modifier,
    corner: Dp = 6.dp,
    fallback: ImageVector = Icons.Filled.MusicNote,
    iconSize: Dp = 24.dp,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(corner))
            .background(Mix.Raised),
        contentAlignment = Alignment.Center,
    ) {
        Icon(fallback, contentDescription = null, tint = Mix.Fog, modifier = Modifier.size(iconSize))
        if (model != null) {
            AsyncImage(
                model = model,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/**
 * One tick per song in playlist order: yellow if the song is on this phone, dark if missing.
 * Shows at a glance where the gaps are.
 */
@Composable
fun MatchStrip(found: List<Boolean>, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Canvas(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(height / 2)),
    ) {
        val n = found.size
        if (n == 0) {
            drawRect(Mix.Gap)
            return@Canvas
        }
        val gap = if (n <= 60) 2.dp.toPx() else 0f
        val w = ((size.width - gap * (n - 1)) / n).coerceAtLeast(1f)
        found.forEachIndexed { i, ok ->
            drawRect(
                color = if (ok) Mix.Tape else Mix.Gap,
                topLeft = Offset(i * (w + gap), 0f),
                size = Size(w, size.height),
            )
        }
    }
}

fun foundLabel(found: Int, total: Int): String = when {
    total == 0 -> "Empty playlist"
    found == total -> "All $total songs on this phone"
    found == 0 -> "None of the $total songs are on this phone yet"
    else -> "$found of $total songs on this phone"
}

fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSec / 60, totalSec % 60)
}

/** A song file on the phone, used in the Songs tab and the match picker. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LocalTrackRow(
    track: LocalTrack,
    highlighted: Boolean,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Mix.Raised else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (selected) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Mix.Tape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Check, contentDescription = "Selected", tint = Mix.Ink, modifier = Modifier.size(24.dp))
            }
        } else {
            Artwork(track.artUri, Modifier.size(44.dp), corner = 4.dp, iconSize = 20.dp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                track.title,
                style = MaterialTheme.typography.titleMedium,
                color = if (highlighted) Mix.Tape else Mix.Paper,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                listOf(track.artist, track.album).filter { it.isNotEmpty() }.joinToString(", ").ifEmpty { "Unknown artist" },
                style = MaterialTheme.typography.bodyMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(formatTime(track.durationMs), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
    }
}

@Composable
fun MiniPlayer(
    now: NowPlaying,
    onOpen: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit = {},
    swipeEnabled: Boolean = true,
) {
    // Swipe left for the next song, right for the one before. The row follows the finger a little.
    val scope = rememberCoroutineScope()
    val drag = remember { Animatable(0f) }
    val next by rememberUpdatedState(onNext)
    val previous by rememberUpdatedState(onPrevious)
    val swipe = Modifier.pointerInput(Unit) {
        val threshold = 72.dp.toPx()
        var total = 0f
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragEnd = {
                when {
                    total < -threshold -> next()
                    total > threshold -> previous()
                }
                total = 0f
                scope.launch { drag.animateTo(0f) }
            },
            onDragCancel = {
                total = 0f
                scope.launch { drag.animateTo(0f) }
            },
            onHorizontalDrag = { change, amount ->
                change.consume()
                total += amount
                scope.launch { drag.snapTo(total * 0.35f) }
            },
        )
    }
    Surface(color = Mix.Deep) {
        Column {
            val progress = if (now.durationMs > 0) now.positionMs.toFloat() / now.durationMs else 0f
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(Mix.Gap),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(progress.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(Mix.Tape),
                )
            }
            Row(
                Modifier
                    .fillMaxWidth()
                    .then(if (swipeEnabled) swipe else Modifier)
                    .clickable(onClick = onOpen)
                    .offset { IntOffset(drag.value.roundToInt(), 0) }
                    .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Artwork(now.artworkUri, Modifier.size(44.dp), corner = 4.dp, iconSize = 20.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(now.title, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (now.artist.isNotEmpty()) {
                        Text(
                            now.artist,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Mix.Fog,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                IconButton(onClick = onToggle) {
                    Icon(
                        if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (now.isPlaying) "Pause" else "Play",
                    )
                }
                IconButton(onClick = onNext) {
                    Icon(Icons.Filled.SkipNext, contentDescription = "Next song")
                }
            }
        }
    }
}

@Composable
fun BusyBar(text: String) {
    Column(Modifier.fillMaxWidth()) {
        LinearProgressIndicator(Modifier.fillMaxWidth(), color = Mix.Tape, trackColor = Mix.Gap)
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Fog,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        )
    }
}

/** Centered message with one action, for empty screens. */
@Composable
fun EmptyState(title: String, body: String, action: (@Composable () -> Unit)? = null) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(body, style = MaterialTheme.typography.bodyLarge, color = Mix.Fog)
        if (action != null) {
            Spacer(Modifier.height(24.dp))
            action()
        }
    }
}

/**
 * A draggable scroll bar for long lists. Drag the thumb (or anywhere on the right edge) to jump through
 * the list; while dragging it shows where you are, e.g. "42 / 99".
 */
@Composable
fun FastScrollbar(state: LazyListState, modifier: Modifier = Modifier) {
    val info = state.layoutInfo
    val total = info.totalItemsCount
    val visible = info.visibleItemsInfo.size
    if (total == 0 || visible == 0 || visible >= total) return

    val scope = rememberCoroutineScope()
    var dragging by remember { mutableStateOf(false) }
    BoxWithConstraints(
        modifier
            .fillMaxHeight()
            .width(24.dp),
    ) {
        val density = LocalDensity.current
        val trackPx = constraints.maxHeight.toFloat()
        val thumbPx = maxOf(trackPx * visible / total, with(density) { 40.dp.toPx() }).coerceAtMost(trackPx)
        val maxFirst = (total - visible).coerceAtLeast(1)
        val progress = (state.firstVisibleItemIndex.toFloat() / maxFirst).coerceIn(0f, 1f)
        val thumbTop = (trackPx - thumbPx) * progress
        val latestTotal by rememberUpdatedState(total)
        val latestTrack by rememberUpdatedState(trackPx)

        fun jumpTo(y: Float) {
            val fraction = (y / latestTrack).coerceIn(0f, 1f)
            val index = (fraction * (latestTotal - 1)).roundToInt()
            scope.launch { state.scrollToItem(index) }
        }

        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            dragging = true
                            jumpTo(offset.y)
                        },
                        onDragEnd = { dragging = false },
                        onDragCancel = { dragging = false },
                        onVerticalDrag = { change, _ ->
                            change.consume()
                            jumpTo(change.position.y)
                        },
                    )
                },
        )
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .offset { IntOffset(0, thumbTop.roundToInt()) }
                .padding(end = 4.dp)
                .width(if (dragging) 8.dp else 4.dp)
                .height(with(density) { thumbPx.toDp() })
                .background(if (dragging) Mix.Tape else Mix.Fog.copy(alpha = 0.7f), TermShape),
        )
        if (dragging) {
            Text(
                "${state.firstVisibleItemIndex + 1} / $total",
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Ink,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset { IntOffset(-with(density) { 20.dp.roundToPx() }, thumbTop.roundToInt()) }
                    .wrapContentWidth(unbounded = true)
                    .background(Mix.Tape, TermShape)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

/** A slim search box (36 dp high, 1 px border), for lists. */
@Composable
fun CompactSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        enabled = enabled,
        singleLine = true,
        textStyle = MaterialTheme.typography.bodyMedium.copy(color = Mix.Paper),
        cursorBrush = SolidColor(Mix.Tape),
        modifier = modifier.height(36.dp),
        decorationBox = { inner ->
            Row(
                Modifier
                    .fillMaxSize()
                    .border(1.dp, Mix.Gap, TermShape)
                    .padding(horizontal = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Search, contentDescription = null, tint = Mix.Fog, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) {
                        Text(placeholder, style = MaterialTheme.typography.bodyMedium, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    inner()
                }
                if (value.isNotEmpty()) {
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Clear search",
                        tint = Mix.Fog,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { onValueChange("") },
                    )
                }
            }
        },
    )
}

/** Stops the screen from turning off while this is on screen. */
@Composable
fun KeepScreenOn() {
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
}

/**
 * Swipe a song to the right to add it to the queue (like Spotify), but only when the swipe starts
 * on the left edge of the row (the number / cover, the first [edge] of the row). Swipes that start
 * anywhere else are ignored, so scrolling or tapping a song never queues it by accident.
 * The row springs back; a short message confirms it.
 */
@Composable
fun SwipeToQueue(onQueue: () -> Unit, enabled: Boolean = true, edge: Dp = 72.dp, content: @Composable () -> Unit) {
    if (!enabled) {
        content()
        return
    }
    val latest by rememberUpdatedState(onQueue)
    val scope = rememberCoroutineScope()
    val haptics = LocalHapticFeedback.current
    val offset = remember { Animatable(0f) }
    var width by remember { mutableIntStateOf(0) }
    val edgePx = with(LocalDensity.current) { edge.toPx() }
    val threshold = width * 0.3f

    Box(
        Modifier
            .onSizeChanged { width = it.width }
            .pointerInput(edgePx) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    // Started outside the left edge: not ours, let the row and the list handle it.
                    if (down.position.x > edgePx) return@awaitEachGesture
                    var x = 0f
                    var passed = false
                    val limit = size.width * 0.3f // a third of the row
                    fun move(dx: Float) {
                        x = (x + dx).coerceIn(0f, size.width.toFloat())
                        if (!passed && x >= limit) {
                            passed = true
                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        } else if (passed && x < limit) {
                            passed = false
                        }
                        val target = x
                        scope.launch { offset.snapTo(target) }
                    }
                    val start = awaitHorizontalTouchSlopOrCancellation(down.id) { change, over ->
                        if (over > 0f) {
                            change.consume()
                            move(over)
                        }
                    } ?: return@awaitEachGesture
                    horizontalDrag(start.id) { change ->
                        change.consume()
                        move(change.positionChange().x)
                    }
                    if (passed) latest()
                    scope.launch { offset.animateTo(0f, tween(220)) }
                }
            },
    ) {
        if (offset.value > 0f) {
            Row(
                Modifier
                    .matchParentSize()
                    .background(Mix.Tape.copy(alpha = if (offset.value >= threshold) 0.35f else 0.18f))
                    .padding(start = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.AutoMirrored.Filled.PlaylistAdd, contentDescription = null, tint = Mix.Tape)
                Spacer(Modifier.width(10.dp))
                Text(Ui.btn("add to queue"), color = Mix.Tape, style = MaterialTheme.typography.labelLarge)
            }
        }
        Box(
            Modifier
                .offset { IntOffset(offset.value.roundToInt(), 0) }
                .background(if (offset.value > 0f) Mix.Ink else Color.Transparent),
        ) { content() }
    }
}

/**
 * The app's background: the theme colour, or your picture / video, blurred and darkened by the
 * chosen amounts. A video only plays while the app is on screen (battery).
 */
@Composable
fun AppBackground(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxSize()
            .background(Mix.Ink),
    ) {
        val path = Mix.wallpaper ?: return@Box
        val blur = Mix.wallpaperBlur
        // Real blur on Android 12+; older phones get a soft low-resolution picture instead.
        val canBlur = android.os.Build.VERSION.SDK_INT >= 31
        val blurModifier = if (canBlur && blur > 0f) Modifier.blur(blur.dp) else Modifier
        if (Mix.wallpaperVideo) {
            val context = LocalContext.current
            val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
            val state by lifecycle.currentStateFlow.collectAsState()
            val video = remember(path) {
                androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
                    volume = 0f
                    repeatMode = androidx.media3.common.Player.REPEAT_MODE_ONE
                    setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(java.io.File(path))))
                    prepare()
                }
            }
            LaunchedEffect(video, state) { video.playWhenReady = state.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED) }
            DisposableEffect(video) { onDispose { video.release() } }
            // A TextureView (not a SurfaceView) so the video can be blurred like the rest of the screen.
            androidx.compose.ui.viewinterop.AndroidView(
                factory = { ctx ->
                    android.view.TextureView(ctx).also { view ->
                        var videoW = 0
                        var videoH = 0
                        fun crop() {
                            if (videoW == 0 || videoH == 0 || view.width == 0 || view.height == 0) return
                            val s = maxOf(view.width / videoW.toFloat(), view.height / videoH.toFloat())
                            val m = android.graphics.Matrix()
                            m.setScale(videoW * s / view.width, videoH * s / view.height, view.width / 2f, view.height / 2f)
                            view.setTransform(m)
                        }
                        view.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> crop() }
                        video.addListener(object : androidx.media3.common.Player.Listener {
                            override fun onVideoSizeChanged(videoSize: androidx.media3.common.VideoSize) {
                                videoW = (videoSize.width * videoSize.pixelWidthHeightRatio).toInt()
                                videoH = videoSize.height
                                crop()
                            }
                        })
                        video.setVideoTextureView(view)
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .then(blurModifier),
            )
        } else {
            val context = LocalContext.current
            val request = remember(path, blur, canBlur) {
                coil.request.ImageRequest.Builder(context)
                    .data(java.io.File(path))
                    .apply { if (!canBlur && blur > 0f) size((900 / (1f + blur / 2f)).toInt().coerceAtLeast(24)) }
                    .build()
            }
            coil.compose.AsyncImage(
                model = request,
                contentDescription = null,
                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
                modifier = Modifier
                    .fillMaxSize()
                    .then(blurModifier),
            )
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(Mix.Ink.copy(alpha = Mix.wallpaperDim)),
        )
    }
}
