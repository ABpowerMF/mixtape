plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "dev.mixtape.player"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.mixtape.player"
        minSdk = 29
        targetSdk = 35
        versionCode = 51
        versionName = "0.50"

        // The downloader ships native Python/ffmpeg binaries; 64-bit ARM covers modern phones.
        ndk {
            abiFilters += "arm64-v8a"
        }

        // Last.fm key: from the repo's secrets at build time (empty = the Last.fm setting stays hidden).
        buildConfigField("String", "LASTFM_API_KEY", "\"" + (System.getenv("LASTFM_API_KEY") ?: "") + "\"")
        buildConfigField("String", "LASTFM_SECRET", "\"" + (System.getenv("LASTFM_SECRET") ?: "") + "\"")
    }

    // The signing key is NOT in this project. GitHub Actions gets it from the repo's secrets
    // (MIXTAPE_KEYSTORE_BASE64, MIXTAPE_KEYSTORE_PASSWORD) and passes it in here. Every official
    // build is signed with that same key, so each new APK installs over the previous one.
    // Without those (someone else building this code), the APK is signed with a throwaway debug key:
    // it works, but it can't install over the official Mixtape.
    val keystorePath = System.getenv("MIXTAPE_KEYSTORE")
    val keystorePassword = System.getenv("MIXTAPE_KEYSTORE_PASSWORD")
    val officialKey = !keystorePath.isNullOrBlank() && !keystorePassword.isNullOrBlank() && file(keystorePath).exists()
    signingConfigs {
        if (officialKey) {
            create("mixtape") {
                storeFile = file(keystorePath!!)
                storePassword = keystorePassword
                keyAlias = System.getenv("MIXTAPE_KEY_ALIAS")?.ifBlank { null } ?: "mixtape"
                keyPassword = keystorePassword
                storeType = "pkcs12"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (officialKey) signingConfigs.getByName("mixtape") else signingConfigs.getByName("debug")
        }
        debug {
            if (officialKey) signingConfig = signingConfigs.getByName("mixtape")
        }
    }

    packaging {
        // youtubedl-android needs its native files unpacked on the phone.
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf(
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "/META-INF/{AL2.0,LGPL2.1}",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    // Playback + lock-screen / notification controls
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-ui:1.5.1")

    // Drag-to-reorder in the queue
    implementation("sh.calvin.reorderable:reorderable:2.4.3")

    // Cover art loading
    implementation("io.coil-kt:coil-compose:2.7.0")

    // "Add from link": yt-dlp + Python + ffmpeg + QuickJS, bundled for Android
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")

    // Lyrics translation, on the phone (models download once per language, then work offline)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    // Tapes: QR codes to share a playlist (make them, and scan them with the camera)
    implementation("com.google.zxing:core:3.5.3")
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-view:1.4.1")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")

    // Vault: open with a fingerprint (checked by Android against the phone's saved fingerprints)
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.fragment:fragment-ktx:1.8.5")

    // Checks for app updates about once a day, even with the app closed
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
