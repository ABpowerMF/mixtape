package dev.mixtape.player.ui

import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.library.CleanupItem
import dev.mixtape.player.library.CleanupKind
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.launch

/**
 * Review what the library cleanup found, untick anything to keep as it is, then fix.
 * Android asks once before Mixtape changes or deletes files another app made.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleanupScreen(vm: MainViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = vm.cleanupFocus
    val all = vm.cleanup.items.filter { focus == null || it.kind == focus }
    var skipped by remember { mutableStateOf(setOf<Pair<CleanupKind, Long>>()) }
    val chosen = all.filter { (it.kind to it.track.id) !in skipped }

    // Step 2: delete duplicates / broken files.
    var pendingDeletes by remember { mutableStateOf<List<CleanupItem>>(emptyList()) }
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) vm.cleanupDeleted(pendingDeletes)
        pendingDeletes = emptyList()
    }
    fun deleteNow(items: List<CleanupItem>) {
        if (items.isEmpty()) return
        val uris = items.map { it.track.uri }.distinct()
        pendingDeletes = items
        if (Build.VERSION.SDK_INT >= 30) {
            val request = MediaStore.createDeleteRequest(context.contentResolver, uris)
            deleteLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
        } else {
            vm.deleteDirect(uris)
            vm.cleanupDeleted(items)
        }
    }

    // Step 1: fix names and covers (Android may ask first).
    var pendingFixes by remember { mutableStateOf<List<CleanupItem>>(emptyList()) }
    var thenDelete by remember { mutableStateOf<List<CleanupItem>>(emptyList()) }
    val writeLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) vm.fixCleanup(pendingFixes)
        pendingFixes = emptyList()
        deleteNow(thenDelete)
        thenDelete = emptyList()
    }

    fun fixChosen() {
        val deletes = chosen.filter { it.kind == CleanupKind.DUPLICATES || it.kind == CleanupKind.BROKEN }
        val fixes = chosen.filter { it.kind == CleanupKind.TAGS || it.kind == CleanupKind.COVERS }
        scope.launch {
            val ask = if (fixes.isEmpty()) emptyList() else vm.cleanup.needsPermission(fixes.map { it.track }.distinct())
            if (ask.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
                pendingFixes = fixes
                thenDelete = deletes
                val request = MediaStore.createWriteRequest(context.contentResolver, ask)
                writeLauncher.launch(IntentSenderRequest.Builder(request.intentSender).build())
            } else {
                vm.fixCleanup(fixes)
                deleteNow(deletes)
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("cleanup"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        vm.cleanupWork?.let { BusyBar(it) }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            CleanupKind.entries.filter { focus == null || it == focus }.forEach { kind ->
                val group = all.filter { it.kind == kind }
                if (group.isEmpty()) return@forEach
                item(key = "head:" + kind.name) {
                    Column(Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 6.dp)) {
                        Text(Ui.head(kind.title.lowercase()) + " (${group.size})", style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
                        Text("Fix: ${kind.action}", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                    }
                }
                items(group, key = { kind.name + ":" + it.track.id }) { item ->
                    val key = item.kind to item.track.id
                    val on = key !in skipped
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { skipped = if (on) skipped + key else skipped - key }
                            .padding(horizontal = 12.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Checkbox(
                            checked = on,
                            onCheckedChange = { skipped = if (on) skipped + key else skipped - key },
                            colors = CheckboxDefaults.colors(checkedColor = Mix.Tape, checkmarkColor = Mix.Ink, uncheckedColor = Mix.Fog),
                        )
                        Spacer(Modifier.width(4.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                item.track.title.ifEmpty { item.track.fileName },
                                style = MaterialTheme.typography.bodyLarge,
                                color = Mix.Paper,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(item.detail, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            if (all.isEmpty()) {
                item { Text("Nothing to fix here.", color = Mix.Fog, modifier = Modifier.padding(20.dp)) }
            }
        }
        Button(
            onClick = { fixChosen() },
            enabled = chosen.isNotEmpty() && vm.cleanupWork == null,
            shape = TermShape,
            colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp)
                .height(48.dp),
        ) { Text(if (chosen.isEmpty()) "Nothing picked" else "Fix ${chosen.size}") }
    }
}
