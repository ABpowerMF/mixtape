package dev.mixtape.player.playback

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Look of the ASCII visualiser above the mini player. */
enum class VisualiserStyle(val label: String) {
    BARS("bars"),
    DOTS("dots"),
    WAVE("wave"),
    OFF("off"),
}

/**
 * Settings shared by the screens and the playback service (they run in the same app):
 * the visualiser, karaoke (vocals slider) and tape stop.
 */
object Extras {

    var visualiser by mutableStateOf(VisualiserStyle.BARS)
        private set

    /** Pausing slows the song down like a tape winding to a stop; play winds it back up. */
    var tapeStop by mutableStateOf(false)
        private set

    /** Karaoke mode (microphone button on the lyrics screen). Off again each time the app starts. */
    var karaoke by mutableStateOf(false)
        private set

    /** Vocals while karaoke is on: 0 = instrumental, 1 = the normal song. */
    var vocals by mutableFloatStateOf(0.2f)
        private set

    /** The playback service's processors. */
    var karaokeFx: KaraokeProcessor? = null
        set(value) {
            field = value
            apply()
        }
    var levels: LevelTap? = null

    /** The playback service listens (to switch the low-power "offload" mode on or off). */
    var onChanged: (() -> Unit)? = null

    private var loaded = false

    private fun prefs(context: Context) = context.getSharedPreferences("extras", Context.MODE_PRIVATE)

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(context)
        visualiser = runCatching { VisualiserStyle.valueOf(p.getString("visualiser", null) ?: "BARS") }
            .getOrDefault(VisualiserStyle.BARS)
        tapeStop = p.getBoolean("tapeStop", false)
        vocals = p.getFloat("vocals", 0.2f).coerceIn(0f, 1f)
        apply()
    }

    fun chooseVisualiser(context: Context, style: VisualiserStyle) {
        visualiser = style
        prefs(context).edit().putString("visualiser", style.name).apply()
        changed()
    }

    fun chooseTapeStop(context: Context, on: Boolean) {
        tapeStop = on
        prefs(context).edit().putBoolean("tapeStop", on).apply()
        changed()
    }

    fun chooseKaraoke(on: Boolean) {
        karaoke = on
        apply()
        changed()
    }

    fun chooseVocals(context: Context, value: Float) {
        vocals = value.coerceIn(0f, 1f)
        prefs(context).edit().putFloat("vocals", vocals).apply()
        apply()
    }

    /** True when the sound has to pass through Mixtape's own processing (no low-power mode). */
    fun needsProcessing(): Boolean = visualiser != VisualiserStyle.OFF || karaoke || tapeStop

    private fun apply() {
        karaokeFx?.vocals = if (karaoke) vocals else 1f
    }

    private fun changed() {
        onChanged?.invoke()
    }
}
