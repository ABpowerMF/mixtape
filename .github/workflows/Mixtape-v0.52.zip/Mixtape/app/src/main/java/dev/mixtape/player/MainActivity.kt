package dev.mixtape.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import dev.mixtape.player.ui.theme.Appearance
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import android.app.KeyguardManager
import android.view.KeyEvent
import android.os.Handler
import android.os.Looper
import dev.mixtape.player.rotate.Rotate
import dev.mixtape.player.ui.HomeTab
import dev.mixtape.player.ui.Screen
import dev.mixtape.player.ui.cocoonTabs
import dev.mixtape.player.ui.MainViewModel
import dev.mixtape.player.ui.MixtapeApp
import dev.mixtape.player.ui.theme.MixtapeTheme

/** A FragmentActivity (a kind of ComponentActivity) so the fingerprint prompt can show. */
class MainActivity : FragmentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The app is always dark, so keep light status/navigation bar icons.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )
        Appearance.load(this)
        Rotate.load(this)
        setShowWhenLocked(Rotate.active(this))
        setContent {
            MixtapeTheme { MixtapeApp(vm) }
        }
        if (savedInstanceState == null) handleShare(intent)
    }

    // RG Rotate: watch for the screen being closed (locked with the screen on) while Mixtape is up.
    private val closedHandler = Handler(Looper.getMainLooper())
    private val closedTick = object : Runnable {
        override fun run() {
            updateClosedScreen()
            closedHandler.postDelayed(this, 400)
        }
    }

    private var lockScreenAllowed: Boolean? = null

    private fun allowOverLockScreen(on: Boolean) {
        if (lockScreenAllowed == on) return
        lockScreenAllowed = on
        setShowWhenLocked(on)
    }

    /** Shows the closed-screen player while the console is shut, the normal app otherwise. */
    private fun updateClosedScreen() {
        val active = Rotate.active(this)
        val closed = active && Rotate.isClosed(this)
        val now = vm.player.state.value
        val show = closed && (now.isPlaying || vm.closedScreen || Rotate.idleClock)
        if (closed && !show) {
            // Nothing playing and the console's own clock was chosen: step aside.
            allowOverLockScreen(false)
        } else {
            allowOverLockScreen(active)
        }
        if (vm.closedScreen != show) vm.closedScreen = show
        Rotate.showing = show
        if (show) Rotate.cancelNotification(this)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val down = event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0
        if (vm.closedScreen) {
            if (down) {
                when (event.keyCode) {
                    // The shoulder buttons sit on the back, so they still work with the screen shut.
                    KeyEvent.KEYCODE_BUTTON_L1 -> { vm.player.previousSong(); return true }
                    KeyEvent.KEYCODE_BUTTON_R1 -> { vm.player.next(); return true }
                }
                if (isConsoleKey(event.keyCode)) {
                    // The controls are out, so the screen was opened: unlock and go back to the app.
                    getSystemService(KeyguardManager::class.java)?.requestDismissKeyguard(this, null)
                    return true
                }
            }
            return super.dispatchKeyEvent(event)
        }
        if (down) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_L1 -> if (stepTab(-1)) return true
                KeyEvent.KEYCODE_BUTTON_R1 -> if (stepTab(1)) return true
                KeyEvent.KEYCODE_BUTTON_X -> {
                    val x = dev.mixtape.player.ui.ConsoleKeys.onX
                    if (x != null) x() else vm.player.toggle()
                    return true
                }
                KeyEvent.KEYCODE_BUTTON_Y -> {
                    if (vm.stack.last() == Screen.NowPlaying) vm.pop()
                    else if (vm.player.state.value.mediaId != null) vm.push(Screen.NowPlaying)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    /** L / R switch tabs on the main screen. */
    private fun stepTab(dir: Int): Boolean {
        if (vm.stack.last() != Screen.Home) return false
        val order = if (dev.mixtape.player.ui.theme.Mix.cocoon) cocoonTabs
        else listOf(HomeTab.Playlists, HomeTab.Songs, HomeTab.Download, HomeTab.Settings)
        val i = order.indexOf(vm.tab).coerceAtLeast(0)
        vm.tab = order[(i + dir + order.size) % order.size]
        return true
    }

    private fun isConsoleKey(code: Int): Boolean = when (code) {
        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X,
        KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT,
        KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR -> true
        else -> false
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    /** A link shared from YouTube, Spotify or a browser goes to the Download tab. */
    private fun handleShare(intent: Intent?) {
        when (intent?.action) {
            Shortcuts.ACTION_CLOCK -> vm.forcedClock = true
            Shortcuts.ACTION_LAST_PLAYLIST -> vm.requestLastPlaylist()
            dev.mixtape.player.update.UpdateWorker.ACTION_OPEN_UPDATES -> vm.openSettings()
            dev.mixtape.player.widget.ContinueWidget.ACTION_PLAY ->
                vm.playFromWidget(intent.getStringExtra(dev.mixtape.player.widget.ContinueWidget.EXTRA_ID))
        }
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            vm.receiveShared(intent.getStringExtra(Intent.EXTRA_TEXT))
        }
    }

    override fun onStart() {
        super.onStart()
        vm.player.setVisible(true)
        closedHandler.removeCallbacks(closedTick)
        closedHandler.post(closedTick)
    }

    override fun onStop() {
        closedHandler.removeCallbacks(closedTick)
        if (vm.closedScreen) vm.closedScreen = false
        Rotate.showing = false
        vm.player.setVisible(false)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        // Also rescans the music on this phone, so newly added files fill playlist gaps.
        vm.onPermission(ContextCompat.checkSelfPermission(this, audioPermission) == PackageManager.PERMISSION_GRANTED)
    }

    companion object {
        val audioPermission: String
            get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
    }
}
