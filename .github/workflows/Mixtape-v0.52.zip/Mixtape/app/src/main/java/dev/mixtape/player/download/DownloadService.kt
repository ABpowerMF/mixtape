package dev.mixtape.player.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import dev.mixtape.player.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Keeps the app alive while songs download, with a progress notification. */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watching = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this,
            ONGOING_ID,
            build("Getting ready…", 0, 0, ongoing = true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!watching) {
            watching = true
            scope.launch { watch() }
        }
        return START_NOT_STICKY
    }

    private suspend fun watch() {
        val manager = getSystemService(NotificationManager::class.java)
        var idleSince = 0L
        combine(DownloadQueue.jobs, DownloadQueue.reading) { jobs, reading -> jobs to reading }
            .collect { (jobs, reading) ->
                val finished = jobs.count { it.finished }
                val working = reading > 0 || finished < jobs.size
                if (working) {
                    idleSince = 0L
                    val text = if (jobs.isEmpty()) "Reading link…" else "$finished of ${jobs.size} songs"
                    // Battery: progress ticks many times a second; redraw the notification only when it changes.
                    if (text != lastText) {
                        lastText = text
                        manager.notify(ONGOING_ID, build(text, finished, jobs.size, ongoing = true))
                    }
                } else if (idleSince == 0L) {
                    idleSince = System.currentTimeMillis()
                    scope.launch {
                        delay(1500)
                        if (!DownloadQueue.isWorking) finish(jobs)
                    }
                }
            }
    }

    private var lastText: String? = null

    private fun finish(jobs: List<DownloadJob>) {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        val saved = jobs.count { it.status == JobStatus.Done }
        val failed = jobs.count { it.status == JobStatus.Failed }
        if (jobs.isNotEmpty()) {
            val text = buildString {
                append("$saved saved to Music/Mixtape")
                if (failed > 0) append(", $failed failed")
            }
            getSystemService(NotificationManager::class.java)
                .notify(DONE_ID, build(text, 0, 0, ongoing = false))
        }
        stopSelf()
    }

    private fun build(text: String, done: Int, total: Int, ongoing: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(if (ongoing) android.R.drawable.stat_sys_download else android.R.drawable.stat_sys_download_done)
            .setContentTitle(if (ongoing) "Downloading music" else "Downloads finished")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(ongoing)
            .setAutoCancel(!ongoing)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .apply { if (ongoing && total > 0) setProgress(total, done, false) }
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private companion object {
        const val CHANNEL = "downloads"
        const val ONGOING_ID = 7301
        const val DONE_ID = 7302
    }
}
