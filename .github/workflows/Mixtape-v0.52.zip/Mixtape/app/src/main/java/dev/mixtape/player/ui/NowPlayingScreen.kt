package dev.mixtape.player.ui

import androidx.compose.runtime.collectAsState
import androidx.compose.material.icons.filled.Edit
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material.icons.filled.LibraryAdd
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Person
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.BoxWithConstraints
import dev.mixtape.player.ui.theme.Ui
import dev.mixtape.player.playback.AudioFx
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.download.Quality
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.mixtape.player.playback.NowPlaying
import dev.mixtape.player.ui.theme.Mix

@Composable
fun NowPlayingScreen(vm: MainViewModel, now: NowPlaying) {
    // While dragging the slider, show the drag position instead of the live one.
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = now.durationMs.coerceAtLeast(1L)
    val fraction = dragging ?: (now.positionMs.toFloat() / duration).coerceIn(0f, 1f)
    val shownPosition = if (dragging != null) (fraction * duration).toLong() else now.positionMs

    var addingToPlaylist by remember { mutableStateOf(false) }
    var editingTags by remember { mutableStateOf(false) }
    BoxWithConstraints(Modifier.fillMaxSize()) {
    val pageHeight = maxHeight
    // Square screens (RG Rotate) and landscape: cover on the left, everything fits on one screen.
    val compact = maxHeight < maxWidth * 1.4f
    val pageWidth = maxWidth
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
    if (compact) CompactPlayerPage(
        vm = vm,
        now = now,
        pageHeight = pageHeight,
        pageWidth = pageWidth,
        fraction = fraction,
        shownPosition = shownPosition,
        onDrag = { dragging = it },
        onDragEnd = {
            dragging?.let { vm.player.seekTo((it * duration).toLong()) }
            dragging = null
        },
        onEdit = { editingTags = true },
        onAdd = { addingToPlaylist = true },
    ) else Column(
        Modifier
            .height(pageHeight)
            .systemBarsPadding()
            .padding(horizontal = 28.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::pop, modifier = Modifier.offset(x = (-12).dp)) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close player", modifier = Modifier.size(32.dp))
            }
            if (vm.together.active) {
                Text(
                    "● with ${vm.together.peerName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Tape,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .offset(x = (-8).dp)
                        .clickable { vm.push(Screen.Together) }
                        .padding(vertical = 8.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            // Evenly spaced icons; the group lines up with the right edge.
            Row(
                Modifier.offset(x = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (vm.trackById(now.mediaId) != null) {
                    IconButton(onClick = { editingTags = true }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit song (title, artist, cover)", modifier = Modifier.size(24.dp))
                    }
                    IconButton(onClick = { addingToPlaylist = true }) {
                        Icon(Icons.Filled.LibraryAdd, contentDescription = "Add to a playlist", modifier = Modifier.size(24.dp))
                    }
                }
                // Listen together (same Wi-Fi).
                IconButton(onClick = { vm.push(Screen.Together) }) {
                    Icon(
                        Icons.Filled.Groups,
                        contentDescription = "Listen together",
                        tint = if (vm.together.active) Mix.Tape else Mix.Paper,
                        modifier = Modifier.size(24.dp),
                    )
                }
                IconButton(onClick = { vm.push(Screen.Equalizer) }) {
                    Icon(
                        Icons.Filled.Equalizer,
                        contentDescription = "Equaliser",
                        tint = if (AudioFx.settings.enabled) Mix.Tape else Mix.Paper,
                        modifier = Modifier.size(24.dp),
                    )
                }
            }
        }

        Spacer(Modifier.weight(1f))

        LaunchedEffect(now.mediaId, vm.videoCovers) { vm.loadVideoCover(now.mediaId) }
        PlayerCover(
            model = now.artworkUri,
            videoUrl = vm.videoCover?.takeIf { it.first == now.mediaId }?.second,
            playing = now.isPlaying,
            startAtMs = now.positionMs,
            status = vm.videoStatus.takeIf { vm.videoCovers },
        )

        Spacer(Modifier.height(32.dp))

        Text(
            now.title.ifEmpty { "Nothing playing" },
            style = MaterialTheme.typography.displaySmall,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (now.artist.isNotEmpty()) {
            Spacer(Modifier.height(4.dp))
            Text(
                now.artist,
                style = MaterialTheme.typography.titleMedium,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }

        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            VersionPicker(vm, now, Modifier.weight(1.3f))
            OutlinedButton(
                onClick = { vm.push(Screen.Queue) },
                shape = TermShape,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier.weight(1f),
            ) {
                Text(Ui.btn("queue"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape, maxLines = 1, softWrap = false)
            }
            OutlinedButton(
                onClick = { vm.push(Screen.Lyrics) },
                shape = TermShape,
                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
                modifier = Modifier.weight(1f),
            ) {
                Text(Ui.btn("lyrics"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape, maxLines = 1, softWrap = false)
            }
        }
        Spacer(Modifier.height(12.dp))

        Slider(
            value = fraction,
            onValueChange = { dragging = it },
            onValueChangeFinished = {
                dragging?.let { vm.player.seekTo((it * duration).toLong()) }
                dragging = null
            },
            colors = SliderDefaults.colors(
                thumbColor = Mix.Tape,
                activeTrackColor = Mix.Tape,
                inactiveTrackColor = Mix.Gap,
            ),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shownPosition), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
            Text(formatTime(now.durationMs), style = MaterialTheme.typography.labelMedium, color = Mix.Fog)
        }

        Spacer(Modifier.height(20.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = vm.player::toggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = if (now.shuffle) "Shuffle on" else "Shuffle off",
                    tint = if (now.shuffle) Mix.Tape else Mix.Fog,
                )
            }
            IconButton(onClick = vm.player::previous, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous song", modifier = Modifier.size(36.dp))
            }
            FilledIconButton(
                shape = TermShape,
                onClick = vm.player::toggle,
                modifier = Modifier.size(76.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) {
                Icon(
                    if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (now.isPlaying) "Pause" else "Play",
                    modifier = Modifier.size(40.dp),
                )
            }
            IconButton(onClick = vm.player::next, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next song", modifier = Modifier.size(36.dp))
            }
            IconButton(onClick = vm.player::cycleRepeat) {
                Icon(
                    if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = when (now.repeatMode) {
                        Player.REPEAT_MODE_ONE -> "Repeat this song"
                        Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    tint = if (now.repeatMode == Player.REPEAT_MODE_OFF) Mix.Fog else Mix.Tape,
                )
            }
        }

        Spacer(Modifier.weight(1f))
        if (now.artist.isNotBlank()) {
            Text(
                "▾ " + (if (Mix.rounded) "About the artist" else "about the artist"),
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Fog,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 6.dp),
            )
        }
    }
    ArtistSection(vm, now)
    }
    }

    if (editingTags) {
        vm.trackById(now.mediaId)?.let { EditTagsDialog(vm, it) { editingTags = false } } ?: run { editingTags = false }
    }
    if (addingToPlaylist) {
        vm.trackById(now.mediaId)?.let { track ->
            AddToPlaylistDialog(vm, listOf(track)) { addingToPlaylist = false }
        } ?: run { addingToPlaylist = false }
    }
}

/**
 * The player for square or wide screens: cover on the left with the song beside it, then the
 * seek bar and the buttons, all on one screen. Scroll down for the artist, like the tall layout.
 */
@Composable
private fun CompactPlayerPage(
    vm: MainViewModel,
    now: NowPlaying,
    pageHeight: Dp,
    pageWidth: Dp,
    fraction: Float,
    shownPosition: Long,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onEdit: () -> Unit,
    onAdd: () -> Unit,
) {
    val insets = WindowInsets.systemBars.asPaddingValues()
    val inner = pageHeight - insets.calculateTopPadding() - insets.calculateBottomPadding()
    val cover = (inner - 190.dp).coerceIn(96.dp, pageWidth * 0.5f)
    Column(
        Modifier
            .height(pageHeight)
            .systemBarsPadding()
            .padding(horizontal = 20.dp),
    ) {
        Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::pop, modifier = Modifier.offset(x = (-10).dp)) {
                Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Close player", modifier = Modifier.size(30.dp))
            }
            if (vm.together.active) {
                Text(
                    "● with ${vm.together.peerName}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Tape,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable { vm.push(Screen.Together) },
                )
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.offset(x = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                if (vm.trackById(now.mediaId) != null) {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit song (title, artist, cover)", modifier = Modifier.size(22.dp))
                    }
                    IconButton(onClick = onAdd) {
                        Icon(Icons.Filled.LibraryAdd, contentDescription = "Add to a playlist", modifier = Modifier.size(22.dp))
                    }
                }
                IconButton(onClick = { vm.push(Screen.Together) }) {
                    Icon(
                        Icons.Filled.Groups,
                        contentDescription = "Listen together",
                        tint = if (vm.together.active) Mix.Tape else Mix.Paper,
                        modifier = Modifier.size(22.dp),
                    )
                }
                IconButton(onClick = { vm.push(Screen.Equalizer) }) {
                    Icon(
                        Icons.Filled.Equalizer,
                        contentDescription = "Equaliser",
                        tint = if (AudioFx.settings.enabled) Mix.Tape else Mix.Paper,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }

        Spacer(Modifier.weight(1f))

        LaunchedEffect(now.mediaId, vm.videoCovers) { vm.loadVideoCover(now.mediaId) }
        Row(Modifier.fillMaxWidth().height(cover)) {
            Box(Modifier.size(cover)) {
                PlayerCover(
                    model = now.artworkUri,
                    videoUrl = vm.videoCover?.takeIf { it.first == now.mediaId }?.second,
                    playing = now.isPlaying,
                    startAtMs = now.positionMs,
                    status = vm.videoStatus.takeIf { vm.videoCovers },
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Text(
                    now.title.ifEmpty { "Nothing playing" },
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                if (now.artist.isNotEmpty()) {
                    Text(
                        now.artist,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.weight(1f))
                VersionPicker(vm, now, Modifier.fillMaxWidth().height(30.dp))
                Spacer(Modifier.height(4.dp))
                Row(Modifier.height(30.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { vm.push(Screen.Queue) },
                        shape = TermShape,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) {
                        Text(Ui.btn("queue"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape, maxLines = 1, softWrap = false)
                    }
                    OutlinedButton(
                        onClick = { vm.push(Screen.Lyrics) },
                        shape = TermShape,
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                    ) {
                        Text(Ui.btn("lyrics"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape, maxLines = 1, softWrap = false)
                    }
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(formatTime(shownPosition), style = MaterialTheme.typography.labelMedium, color = Mix.Fog, modifier = Modifier.width(44.dp))
            Slider(
                value = fraction,
                onValueChange = onDrag,
                onValueChangeFinished = onDragEnd,
                colors = SliderDefaults.colors(
                    thumbColor = Mix.Tape,
                    activeTrackColor = Mix.Tape,
                    inactiveTrackColor = Mix.Gap,
                ),
                modifier = Modifier.weight(1f),
            )
            Text(
                formatTime(now.durationMs),
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Fog,
                textAlign = TextAlign.End,
                modifier = Modifier.width(44.dp),
            )
        }

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = vm.player::toggleShuffle) {
                Icon(
                    Icons.Filled.Shuffle,
                    contentDescription = if (now.shuffle) "Shuffle on" else "Shuffle off",
                    tint = if (now.shuffle) Mix.Tape else Mix.Fog,
                )
            }
            IconButton(onClick = vm.player::previous, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous song", modifier = Modifier.size(32.dp))
            }
            FilledIconButton(
                shape = TermShape,
                onClick = vm.player::toggle,
                modifier = Modifier.size(62.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
            ) {
                Icon(
                    if (now.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = if (now.isPlaying) "Pause" else "Play",
                    modifier = Modifier.size(34.dp),
                )
            }
            IconButton(onClick = vm.player::next, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Filled.SkipNext, contentDescription = "Next song", modifier = Modifier.size(32.dp))
            }
            IconButton(onClick = vm.player::cycleRepeat) {
                Icon(
                    if (now.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    contentDescription = when (now.repeatMode) {
                        Player.REPEAT_MODE_ONE -> "Repeat this song"
                        Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    tint = if (now.repeatMode == Player.REPEAT_MODE_OFF) Mix.Fog else Mix.Tape,
                )
            }
        }

        Spacer(Modifier.weight(1f))
        if (now.artist.isNotBlank()) {
            Text(
                "▾ " + (if (Mix.rounded) "About the artist" else "about the artist"),
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Fog,
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(bottom = 4.dp),
            )
        }
    }
}

/**
 * The cover, or, with video covers on, the song's music video playing silently on top of it
 * (it fades in once the first frame is ready and pauses with the music).
 */
@Composable
private fun PlayerCover(model: Any?, videoUrl: String?, playing: Boolean, startAtMs: Long, status: String? = null) {
    val context = LocalContext.current
    var videoReady by remember(videoUrl) { mutableStateOf(false) }
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clip(RoundedCornerShape(if (Mix.rounded) 16.dp else 12.dp)),
    ) {
        Artwork(model, Modifier.fillMaxSize(), corner = 0.dp, iconSize = 72.dp)
        if (videoUrl != null) {
            val video = remember(videoUrl) {
                androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
                    volume = 0f
                    repeatMode = Player.REPEAT_MODE_ONE
                    setMediaItem(androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(java.io.File(videoUrl))))
                    addListener(object : Player.Listener {
                        override fun onRenderedFirstFrame() {
                            videoReady = true
                        }
                    })
                    prepare()
                }
            }
            val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
            val appState by lifecycle.currentStateFlow.collectAsState()
            LaunchedEffect(video, playing, appState) {
                // Only decode video while you can see it.
                video.playWhenReady = playing && appState.isAtLeast(androidx.lifecycle.Lifecycle.State.STARTED)
            }
            DisposableEffect(video) { onDispose { video.release() } }
            val alpha by animateFloatAsState(if (videoReady) 1f else 0f, tween(600), label = "video")
            AndroidView(
                factory = { ctx ->
                    androidx.media3.ui.PlayerView(ctx).apply {
                        useController = false
                        resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        setShutterBackgroundColor(android.graphics.Color.TRANSPARENT)
                        player = video
                    }
                },
                update = { it.player = video },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { this.alpha = alpha },
            )
        }
        // Small status while the video is being found (or why there's none).
        if (status != null && !videoReady) {
            Text(
                status,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.85f),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
    }
}

/** Below the player: artist header photo, your numbers, bio, photos and their albums on the phone. */
@Composable
private fun ArtistSection(vm: MainViewModel, now: NowPlaying) {
    val name = now.artist.substringBefore(",").substringBefore(" & ").substringBefore(" feat").trim()
    if (name.isEmpty()) return
    LaunchedEffect(name) {
        vm.loadArtist(name)
        vm.refreshStats()
    }
    val context = LocalContext.current
    val info = vm.artistInfo.takeIf { vm.artistInfoFor == name }
    val mine = remember(vm.stats, name) { vm.stats.filter { it.artist.contains(name, ignoreCase = true) } }
    val onPhone = remember(vm.library, name) { vm.library.count { it.artist.contains(name, ignoreCase = true) } }
    val albums = remember(vm.library, name) { vm.localAlbums().filter { it.artist.contains(name, ignoreCase = true) } }
    var bioOpen by remember(name) { mutableStateOf(false) }
    val corner = if (Mix.rounded) 16.dp else 2.dp

    Column(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(vertical = 16.dp),
    ) {
        // Header: big photo with the name over it.
        Box(
            Modifier
                .padding(horizontal = 20.dp)
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(corner))
                .background(Mix.Raised),
        ) {
            val photo = vm.artistPhoto.takeIf { vm.artistInfoFor == name } ?: info?.heroUrl ?: info?.imageUrl
            Artwork(photo?.let { java.io.File(it) }, Modifier.fillMaxSize(), corner = 0.dp, fallback = Icons.Filled.Person, iconSize = 64.dp)
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(0.45f to Color.Transparent, 1f to Mix.Ink.copy(alpha = 0.92f))),
            )
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp),
            ) {
                Text(Ui.head("about the artist"), style = MaterialTheme.typography.labelMedium, color = Mix.Tape)
                Text(info?.name ?: name, style = MaterialTheme.typography.displaySmall, color = Mix.Paper, maxLines = 2, overflow = TextOverflow.Ellipsis)
                info?.description?.takeIf { it.isNotBlank() }?.let {
                    Text(it.replaceFirstChar { c -> c.uppercase() }, style = MaterialTheme.typography.bodyMedium, color = Mix.Paper.copy(alpha = 0.85f))
                }
            }
        }

        // Your numbers
        Row(
            Modifier
                .padding(horizontal = 20.dp, vertical = 14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            StatChip("$onPhone", "on phone", Modifier.weight(1f))
            StatChip("${mine.sumOf { it.plays }}", "plays", Modifier.weight(1f))
            StatChip(formatListened(mine.sumOf { it.listenedMs }), "listened", Modifier.weight(1f))
        }

        // Bio
        if (info != null && info.extract.isNotBlank()) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(
                    info.extract,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mix.Paper,
                    maxLines = if (bioOpen) Int.MAX_VALUE else 5,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (bioOpen) "show less" else "read more",
                        style = MaterialTheme.typography.labelLarge,
                        color = Mix.Tape,
                        modifier = Modifier
                            .clickable { bioOpen = !bioOpen }
                            .padding(vertical = 8.dp),
                    )
                    Spacer(Modifier.weight(1f))
                    info.pageUrl?.let { url ->
                        Text(
                            "Wikipedia ↗",
                            style = MaterialTheme.typography.labelMedium,
                            color = Mix.Fog,
                            modifier = Modifier
                                .clickable {
                                    runCatching {
                                        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                                    }
                                }
                                .padding(vertical = 8.dp),
                        )
                    }
                }
            }
        } else if (!vm.artistInfoOnline) {
            Text(
                "Artist info from Wikipedia is off (Settings → player).",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                modifier = Modifier.padding(horizontal = 20.dp),
            )
        }

        // Their albums on this phone
        if (albums.isNotEmpty()) {
            Text(
                Ui.head("albums on this phone"),
                style = MaterialTheme.typography.titleMedium,
                color = Mix.Tape,
                modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 8.dp),
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(albums, key = { it.folder }) { a ->
                    Column(
                        Modifier
                            .width(120.dp)
                            .clickable {
                                vm.pop()
                                vm.push(Screen.Album(a.folder))
                            },
                    ) {
                        Artwork(a.tracks.first().artUri, Modifier.size(120.dp), corner = corner, fallback = Icons.Filled.Album)
                        Text(a.name, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatChip(value: String, label: String, modifier: Modifier = Modifier) {
    Column(
        modifier
            .background(Mix.Raised, TermShape)
            .padding(horizontal = 10.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = Mix.Paper, maxLines = 1)
        Text(label, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
    }
}

/** Shows the playing file's quality; switch to another downloaded version or download a new one. */
@Composable
private fun VersionPicker(vm: MainViewModel, now: NowPlaying, modifier: Modifier = Modifier) {
    val current = vm.trackById(now.mediaId) ?: return
    val versions = remember(vm.library, current.id) { vm.versionsOf(current) }
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        OutlinedButton(
            onClick = { open = true },
            shape = TermShape,
            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(
Ui.btn(Quality.describe(current.fileName, current.bitrateKbps) + " ▾"),
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelMedium,
                color = Mix.Tape,
            )
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            versions.forEach { v ->
                val playing = v.id == current.id
                DropdownMenuItem(
                    text = {
                        Text(
                            (if (playing) "> " else "  ") + Quality.describe(v.fileName, v.bitrateKbps),
                            color = if (playing) Mix.Tape else Mix.Paper,
                        )
                    },
                    onClick = {
                        open = false
                        if (!playing) vm.playVersion(v)
                    },
                )
            }
            HorizontalDivider(color = Mix.Gap)
            if (current.album.isNotBlank()) {
                DropdownMenuItem(
                    text = { Text("  get the whole album", color = Mix.Tape) },
                    onClick = {
                        open = false
                        vm.downloadAlbumOf(current)
                    },
                )
            }
            Quality.entries.forEach { q ->
                DropdownMenuItem(
                    text = { Text("  get ${q.label}", color = Mix.Fog) },
                    onClick = {
                        open = false
                        vm.downloadVersion(current, q)
                    },
                )
            }
        }
    }
}
