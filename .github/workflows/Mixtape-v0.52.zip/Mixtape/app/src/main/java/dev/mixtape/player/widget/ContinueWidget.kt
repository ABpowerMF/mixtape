package dev.mixtape.player.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.view.View
import android.widget.RemoteViews
import dev.mixtape.player.MainActivity
import dev.mixtape.player.R
import org.json.JSONArray
import org.json.JSONObject

/** "continue" widget: your last three playlists (tap one to play it) and shuffle all. */
class ContinueWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) = draw(context)

    companion object {
        const val ACTION_PLAY = "dev.mixtape.player.widget.PLAY"
        const val EXTRA_ID = "playlist"

        private fun prefs(context: Context) = context.getSharedPreferences("widgets", Context.MODE_PRIVATE)

        /** Called by the app when you play a playlist: (id, name), newest first. */
        fun save(context: Context, recent: List<Pair<String, String>>) {
            val arr = JSONArray()
            recent.forEach { (id, name) -> arr.put(JSONObject().put("id", id).put("name", name)) }
            prefs(context).edit().putString("recent", arr.toString()).apply()
            draw(context)
        }

        fun draw(context: Context) {
            val app = context.applicationContext
            val arr = runCatching { JSONArray(prefs(app).getString("recent", "[]")) }.getOrDefault(JSONArray())
            val views = RemoteViews(app.packageName, R.layout.widget_continue)
            val slots = listOf(R.id.w_p1, R.id.w_p2, R.id.w_p3)
            slots.forEachIndexed { i, slot ->
                val o = arr.optJSONObject(i)
                if (o == null) {
                    views.setViewVisibility(slot, View.GONE)
                } else {
                    views.setViewVisibility(slot, View.VISIBLE)
                    views.setTextViewText(slot, o.optString("name"))
                    views.setOnClickPendingIntent(slot, open(app, o.optString("id"), 10 + i))
                }
            }
            views.setOnClickPendingIntent(R.id.w_shuffle, open(app, null, 20))
            views.setOnClickPendingIntent(android.R.id.background, open(app, "", 21))
            AppWidgetManager.getInstance(app).updateAppWidget(ComponentName(app, ContinueWidget::class.java), views)
        }

        /** id: a playlist to play; null: shuffle everything; "": just open the app. */
        private fun open(context: Context, id: String?, code: Int): PendingIntent {
            val intent = Intent(context, MainActivity::class.java)
            if (id != "") intent.action = ACTION_PLAY
            if (!id.isNullOrEmpty()) intent.putExtra(EXTRA_ID, id)
            return PendingIntent.getActivity(
                context, code, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
        }
    }
}
