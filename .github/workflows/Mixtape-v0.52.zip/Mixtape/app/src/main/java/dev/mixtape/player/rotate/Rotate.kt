package dev.mixtape.player.rotate

import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import dev.mixtape.player.MainActivity
import dev.mixtape.player.R

/**
 * Anbernic RG Rotate: when the screen is swivelled shut the console locks and shows a clock.
 * Mixtape shows its own player there instead (cover, song, seek bar, controls, lyrics).
 *
 * How it works: MainActivity may show over the lock screen. While the console is locked with the
 * screen on (= closed), it draws [dev.mixtape.player.ui.ClosedScreen] instead of the app. If Mixtape
 * isn't on screen when it's closed, the playback service brings it up with a full-screen notification.
 */
object Rotate {
    /** Show the player when the screen is closed (instead of the console's clock). */
    var closedPlayer by mutableStateOf(true); private set

    /** With nothing playing: true = big clock + resume card, false = the console's own clock. */
    var idleClock by mutableStateOf(true); private set

    /** Seconds the closed screen stays on after the last touch. 0 = the whole time music plays. */
    var screenOnSeconds by mutableIntStateOf(120); private set

    /** True on the RG Rotate (or any square screen, where this layout fits). */
    var device by mutableStateOf(false); private set

    private var loaded = false

    fun load(context: Context) {
        if (loaded) return
        loaded = true
        device = detect(context)
        val p = prefs(context)
        closedPlayer = p.getBoolean("rotateClosed", device)
        idleClock = p.getBoolean("rotateIdleClock", true)
        screenOnSeconds = p.getInt("rotateScreenOn", 120)
    }

    /** The closed-screen player is switched on (and this console can use it). */
    fun active(context: Context): Boolean {
        load(context)
        return closedPlayer
    }

    fun setClosedPlayer(context: Context, on: Boolean) {
        closedPlayer = on
        prefs(context).edit().putBoolean("rotateClosed", on).apply()
    }

    fun setIdleClock(context: Context, on: Boolean) {
        idleClock = on
        prefs(context).edit().putBoolean("rotateIdleClock", on).apply()
    }

    fun setScreenOnSeconds(context: Context, seconds: Int) {
        screenOnSeconds = seconds
        prefs(context).edit().putInt("rotateScreenOn", seconds).apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences("mixtape", Context.MODE_PRIVATE)

    private fun detect(context: Context): Boolean {
        val names = listOf(Build.MODEL, Build.DEVICE, Build.PRODUCT, Build.BOARD).joinToString(" ").lowercase()
        if ("rotate" in names) return true
        val m = context.resources.displayMetrics
        val big = maxOf(m.widthPixels, m.heightPixels)
        val small = minOf(m.widthPixels, m.heightPixels)
        // A square screen (the status bar may take a few pixels).
        return big > 0 && small.toFloat() / big > 0.9f
    }

    /** Locked with the screen on: on the Rotate that means the screen was swivelled shut. */
    fun isClosed(context: Context): Boolean {
        val km = context.getSystemService(KeyguardManager::class.java) ?: return false
        val pm = context.getSystemService(PowerManager::class.java) ?: return false
        return pm.isInteractive && km.isKeyguardLocked
    }

    /** True while MainActivity is showing the closed-screen player. */
    @Volatile var showing = false

    // ---------- Bringing Mixtape up when it's closed while another app was open ----------

    const val ACTION_CLOSED = "dev.mixtape.player.CLOSED_SCREEN"
    private const val CHANNEL = "closed_screen"
    private const val NOTIFICATION_ID = 4711

    fun cancelNotification(context: Context) {
        context.getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
    }

    private fun showOverLockScreen(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL, "Player on the closed screen", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "RG Rotate: shows the player when you close the screen"
                    setSound(null, null)
                    enableVibration(false)
                    setShowBadge(false)
                },
            )
        }
        val open = Intent(context, MainActivity::class.java)
            .setAction(ACTION_CLOSED)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pending = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID,
            open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_launcher_monochrome)
            .setContentTitle("Mixtape")
            .setContentText("Tap to show the player")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setSilent(true)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setFullScreenIntent(pending, true)
            .build()
        runCatching { manager.notify(NOTIFICATION_ID, notification) }
    }

    /**
     * Runs inside the playback service. While music plays it checks twice a second whether the
     * console got closed; if Mixtape isn't the one showing, it asks Android to bring it up.
     */
    class Watcher(private val context: Context, private val isPlaying: () -> Boolean) {
        private val handler = Handler(Looper.getMainLooper())
        private var askedThisLock = false
        private var closedTicks = 0
        private var running = false

        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                check()
                handler.postDelayed(this, 500)
            }
        }

        fun start() {
            if (running) return
            running = true
            handler.post(tick)
        }

        fun stop() {
            running = false
            handler.removeCallbacks(tick)
        }

        private fun check() {
            if (!active(context)) return
            if (!isPlaying()) {
                closedTicks = 0
                if (!isClosed(context)) askedThisLock = false
                return
            }
            val closed = isClosed(context)
            if (!closed) {
                askedThisLock = false
                closedTicks = 0
                return
            }
            // Give Mixtape a moment to show it by itself if it was already on screen.
            closedTicks++
            if (showing || askedThisLock || closedTicks < 3 || !isPlaying()) return
            askedThisLock = true
            showOverLockScreen(context)
        }
    }
}
