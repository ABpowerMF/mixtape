package dev.mixtape.player.ui

import androidx.compose.ui.text.input.ImeAction

import androidx.compose.foundation.text.KeyboardActions

import androidx.compose.runtime.rememberUpdatedState

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** True when the phone has a fingerprint saved and a sensor Android trusts for this. */
fun fingerprintReady(context: Context): Boolean =
    BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
        BiometricManager.BIOMETRIC_SUCCESS

/**
 * Asks Android to check a fingerprint. Android compares it with the fingerprints saved in the
 * phone's settings (Mixtape never sees the fingerprint itself); only a real match unlocks.
 */
fun askFingerprint(activity: FragmentActivity, onMatch: () -> Unit, onUsePin: () -> Unit = {}) {
    val prompt = BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onMatch()

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                // "Use PIN", or the fingerprint is locked after too many tries: type the PIN instead.
                if (errorCode == BiometricPrompt.ERROR_NEGATIVE_BUTTON ||
                    errorCode == BiometricPrompt.ERROR_LOCKOUT ||
                    errorCode == BiometricPrompt.ERROR_LOCKOUT_PERMANENT
                ) {
                    onUsePin()
                }
            }
        },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Open the vault")
        .setSubtitle("Mixtape")
        .setNegativeButtonText("Use PIN")
        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
        .build()
    runCatching { prompt.authenticate(info) }.onFailure { onUsePin() }
}

/**
 * Opening the vault: the fingerprint prompt (if it's on), with "Use PIN" for the PIN box; or
 * straight to the PIN box. Returns the function that starts it; [onOpened] runs once it's open.
 */
@Composable
fun rememberVaultUnlock(vm: MainViewModel, onOpened: () -> Unit): () -> Unit {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    var pinPrompt by remember { mutableStateOf(false) }
    val opened by rememberUpdatedState(onOpened)
    val canFinger = vm.vaultFingerprint && activity != null && fingerprintReady(context)
    fun fingerprint() {
        activity?.let { a ->
            askFingerprint(a, onMatch = {
                vm.unlockVaultWithFingerprint()
                opened()
            }, onUsePin = { pinPrompt = true })
        }
    }
    if (pinPrompt) {
        VaultPinDialog(
            vm,
            canFinger = canFinger,
            onFingerprint = {
                pinPrompt = false
                fingerprint()
            },
            onDismiss = { pinPrompt = false },
            onOpened = {
                pinPrompt = false
                opened()
            },
        )
    }
    return {
        if (vm.vaultOpen) {
            opened()
        } else if (canFinger) {
            fingerprint()
        } else {
            pinPrompt = true
        }
    }
}

/** The PIN box: numbers only, 4 to 10. */
@Composable
private fun VaultPinDialog(
    vm: MainViewModel,
    canFinger: Boolean,
    onFingerprint: () -> Unit,
    onDismiss: () -> Unit,
    onOpened: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    val waiting = vm.vaultWaitUntil > now
    LaunchedEffect(vm.vaultWaitUntil) {
        while (vm.vaultWaitUntil > System.currentTimeMillis()) {
            now = System.currentTimeMillis()
            delay(500)
        }
        now = System.currentTimeMillis()
    }
    fun submit() {
        if (pin.length < 4 || checking || waiting) return
        checking = true
        val tried = pin
        scope.launch {
            val ok = vm.unlockVault(tried)
            checking = false
            if (ok) {
                onOpened()
            } else {
                wrong = true
                pin = ""
            }
        }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = { Icon(Icons.Filled.Lock, contentDescription = null, tint = Mix.Paper) },
        title = { Text(Ui.head("open the vault")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v ->
                        wrong = false
                        pin = v.filter { it.isDigit() }.take(10)
                    },
                    label = { Text("PIN") },
                    singleLine = true,
                    enabled = !waiting,
                    isError = wrong,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
                when {
                    waiting -> Text("Too many tries. Wait ${((vm.vaultWaitUntil - now) / 1000) + 1} seconds.", style = MaterialTheme.typography.bodySmall, color = Mix.Alert)
                    wrong -> Text("Wrong PIN, try again.", style = MaterialTheme.typography.bodySmall, color = Mix.Alert)
                }
                if (canFinger) {
                    TextButton(onClick = onFingerprint) {
                        Icon(Icons.Filled.Fingerprint, contentDescription = null, tint = Mix.Tape)
                        Spacer(Modifier.width(8.dp))
                        Text("Use fingerprint", color = Mix.Tape)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { submit() }, enabled = pin.length >= 4 && !checking && !waiting) {
                Text(if (checking) "…" else "Open", color = if (pin.length >= 4) Mix.Tape else Mix.Fog)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

/** Making the vault PIN: numbers only, 4 to 10 of them, typed twice. It can't be changed later. */
@Composable
fun VaultSetupDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val canFinger = remember { fingerprintReady(context) }
    var pin by remember { mutableStateOf("") }
    var again by remember { mutableStateOf("") }
    var finger by remember { mutableStateOf(canFinger) }
    val valid = pin.length in 4..10
    val same = valid && pin == again
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(Ui.head("make a vault PIN")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Albums and playlists in the vault only open from Settings → vault, with this PIN" +
                        if (canFinger) " or your fingerprint." else ".",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { v -> pin = v.filter { it.isDigit() }.take(10) },
                    label = { Text("PIN (4 to 10 numbers)") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
                OutlinedTextField(
                    value = again,
                    onValueChange = { v -> again = v.filter { it.isDigit() }.take(10) },
                    label = { Text("type it again") },
                    singleLine = true,
                    isError = again.isNotEmpty() && again != pin && again.length >= pin.length,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                )
                if (canFinger) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Also open with fingerprint", style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, modifier = Modifier.weight(1f))
                        Switch(
                            checked = finger,
                            onCheckedChange = { finger = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = Mix.Ink, checkedTrackColor = Mix.Tape),
                        )
                    }
                }
                Text(
                    "⚠ You won't be able to change this PIN later. If you forget it, the vault stays locked " +
                        "(the songs stay on your phone).",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Alert,
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = same,
                onClick = {
                    vm.createVaultPin(pin, finger && canFinger)
                    onDismiss()
                },
            ) { Text("Make PIN", color = if (same) Mix.Tape else Mix.Fog) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}

/** Settings → vault: the lock (PIN pad + fingerprint), then what's inside. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VaultScreen(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("vault"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            actions = {
                if (vm.vaultOpen) {
                    IconButton(onClick = {
                        vm.lockVault()
                        vm.pop()
                    }) { Icon(Icons.Filled.Lock, contentDescription = "Lock the vault") }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        when {
            !vm.vaultSetUp -> Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("No vault yet. Make a PIN to start.", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
                OutlinedButton(onClick = { vm.vaultSetupFor = "" }, shape = TermShape, border = BorderStroke(1.dp, Mix.Gap)) {
                    Text(Ui.btn("make a PIN"), color = Mix.Tape)
                }
            }
            !vm.vaultOpen -> VaultLock(vm)
            else -> VaultContents(vm)
        }
    }
}

/** Locked (e.g. coming back to this screen): asks right away, and has a button to ask again. */
@Composable
private fun VaultLock(vm: MainViewModel) {
    val unlock = rememberVaultUnlock(vm) {}
    LaunchedEffect(Unit) { unlock() }
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(40.dp))
        Icon(Icons.Filled.Lock, contentDescription = null, tint = Mix.Paper, modifier = Modifier.size(40.dp))
        Spacer(Modifier.height(12.dp))
        Text("The vault is locked.", style = MaterialTheme.typography.bodyLarge, color = Mix.Fog)
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = unlock, shape = TermShape, border = BorderStroke(1.dp, Mix.Gap)) {
            Text(Ui.btn("unlock"), color = Mix.Tape)
        }
    }
}

/** What's in the vault: tap to open and play; hold to take it back out. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VaultContents(vm: MainViewModel) {
    val albums = remember(vm.library) { vm.localAlbums() }
    val entries = vm.hidden.sorted().mapNotNull { key ->
        when {
            key.startsWith("pl:") -> vm.playlists.find { it.id == key.removePrefix("pl:") }?.let { p ->
                VaultEntry(key, p.name, if (p.id.startsWith("album:")) "album" else "playlist · ${p.tracks.size} songs", p.imageUrl, true)
            }
            key.startsWith("al:") -> albums.find { it.folder == key.removePrefix("al:") }?.let { a ->
                VaultEntry(key, a.name, "album · ${a.artist} · ${a.tracks.size} songs", a.tracks.first().artUri, false)
            }
            else -> null
        }
    }
    if (entries.isEmpty()) {
        Column { FingerprintToggle(vm) }
        Text(
            "The vault is empty. Hold an album or playlist in the Playlists tab (or use its ⋮ menu) → Move to vault.",
            style = MaterialTheme.typography.bodyMedium,
            color = Mix.Fog,
            modifier = Modifier.padding(20.dp),
        )
        return
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        item {
            Column { FingerprintToggle(vm) }
        }
        item {
            Text(
                "Hold one to take it back out. The vault locks when you leave the app.",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
            )
        }
        items(entries, key = { it.key }) { e ->
            var menu by remember { mutableStateOf(false) }
            Box {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = {
                                if (e.key.startsWith("pl:")) vm.push(Screen.Playlist(e.key.removePrefix("pl:")))
                                else vm.push(Screen.Album(e.key.removePrefix("al:")))
                            },
                            onLongClick = { menu = true },
                        )
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Artwork(e.cover, Modifier.size(64.dp), fallback = if (e.playlist) Icons.Filled.MusicNote else Icons.Filled.Album)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.name, style = MaterialTheme.typography.titleMedium, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(e.note, style = MaterialTheme.typography.bodyMedium, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Take out of the vault") },
                        onClick = {
                            menu = false
                            vm.takeOutOfVault(e.key)
                        },
                    )
                }
            }
        }
    }
}

private data class VaultEntry(val key: String, val name: String, val note: String, val cover: Any?, val playlist: Boolean)

/** Settings → vault row. */
@Composable
fun VaultSettings(vm: MainViewModel) {
    // [ open ] asks for the fingerprint or PIN first, then opens the vault.
    val unlock = rememberVaultUnlock(vm) { vm.push(Screen.Vault) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text("Vault", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
            Text(
                if (!vm.vaultSetUp) {
                    "Keep albums and playlists behind a PIN" + (if (fingerprintReady(LocalContext.current)) " or fingerprint" else "") + "."
                } else {
                    val n = vm.hidden.size
                    "$n " + (if (n == 1) "album or playlist" else "albums and playlists") + " inside."
                },
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
            )
        }
        Spacer(Modifier.width(12.dp))
        OutlinedButton(
            onClick = {
                if (vm.vaultSetUp) {
                    unlock()
                } else {
                    vm.vaultSetupFor = ""
                }
            },
            shape = TermShape,
            border = BorderStroke(1.dp, Mix.Gap),
        ) { Text(Ui.btn(if (vm.vaultSetUp) "open" else "set up"), color = Mix.Tape) }
    }
}

/** Only shown inside the open vault, so nobody can switch it on without the PIN. */
@Composable
private fun FingerprintToggle(vm: MainViewModel) {
    if (fingerprintReady(LocalContext.current)) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Open with fingerprint", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
                Text("Uses the fingerprints saved in the phone's settings", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
            }
            Switch(
                checked = vm.vaultFingerprint,
                onCheckedChange = vm::chooseVaultFingerprint,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Mix.Ink,
                    checkedTrackColor = Mix.Tape,
                    uncheckedThumbColor = Mix.Fog,
                    uncheckedTrackColor = Mix.Raised,
                    uncheckedBorderColor = Mix.Gap,
                ),
            )
        }
    }
}
