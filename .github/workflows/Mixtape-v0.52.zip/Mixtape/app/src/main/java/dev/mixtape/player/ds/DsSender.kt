package dev.mixtape.player.ds

import android.content.Context
import android.net.wifi.WifiManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import dev.mixtape.player.data.PlaylistRow
import dev.mixtape.player.download.DownloadQueue
import dev.mixtape.player.library.LocalTrack
import dev.mixtape.player.lyrics.LyricsRepo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** A 3DS running Mixtape DS on its "receive from phone" screen. */
data class DsDevice(val host: String, val port: Int, val version: String)

/**
 * Sends a playlist to Mixtape DS over Wi-Fi: the songs the 3DS doesn't have yet (converted to MP3
 * when needed, since the 3DS only plays MP3), their lyrics as .lrc files and the playlist as .m3u.
 * Talks to the 3DS over plain sockets (the 3DS has no HTTPS), so Android's cleartext rules don't apply.
 */
class DsSender(private val context: Context, private val scope: CoroutineScope) {

    private val prefs = context.getSharedPreferences("ds", Context.MODE_PRIVATE)

    var devices by mutableStateOf<List<DsDevice>>(emptyList()); private set
    var searching by mutableStateOf(false); private set
    var sending by mutableStateOf(false); private set
    var current by mutableStateOf(""); private set
    var currentStep by mutableStateOf(""); private set
    var fileProgress by mutableFloatStateOf(0f); private set
    var done by mutableIntStateOf(0); private set
    var total by mutableIntStateOf(0); private set
    var result by mutableStateOf<String?>(null); private set
    var error by mutableStateOf<String?>(null); private set
    var lastHost by mutableStateOf(prefs.getString("host", "").orEmpty()); private set

    private var searchJob: Job? = null
    private var sendJob: Job? = null

    /* ---------------- finding the 3DS ---------------- */

    fun search() {
        if (searching) return
        searchJob = scope.launch {
            searching = true
            error = null
            val found = withContext(Dispatchers.IO) { runCatching { discover() }.getOrDefault(emptyList()) }
            devices = found
            searching = false
        }
    }

    private fun broadcastAddresses(): List<InetAddress> {
        val list = mutableListOf(InetAddress.getByName("255.255.255.255"))
        runCatching {
            @Suppress("DEPRECATION")
            val dhcp = (context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).dhcpInfo
            if (dhcp != null && dhcp.ipAddress != 0) {
                val bc = (dhcp.ipAddress and dhcp.netmask) or dhcp.netmask.inv()
                val bytes = ByteArray(4) { k -> (bc shr (k * 8) and 0xFF).toByte() }
                list += InetAddress.getByAddress(bytes)
            }
        }
        return list
    }

    private fun discover(): List<DsDevice> {
        val found = LinkedHashMap<String, DsDevice>()
        DatagramSocket().use { s ->
            s.broadcast = true
            s.soTimeout = 400
            val ask = "MIXTAPE-DS?".toByteArray()
            val buf = ByteArray(128)
            repeat(4) {
                broadcastAddresses().forEach { addr ->
                    runCatching { s.send(DatagramPacket(ask, ask.size, addr, DISCOVERY_PORT)) }
                }
                val until = System.currentTimeMillis() + 500
                while (System.currentTimeMillis() < until) {
                    val p = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(p)
                    } catch (_: SocketTimeoutException) {
                        break
                    }
                    val msg = String(p.data, 0, p.length).trim()
                    if (msg.startsWith("MIXTAPE-DS ")) {
                        val parts = msg.split(' ')
                        val host = p.address.hostAddress ?: continue
                        found[host] = DsDevice(host, parts.getOrNull(1)?.toIntOrNull() ?: 8080, parts.getOrNull(2).orEmpty())
                    }
                }
            }
        }
        return found.values.toList()
    }

    /* ---------------- sending ---------------- */

    fun cancel() {
        sendJob?.cancel()
    }

    fun clearResult() {
        result = null
        error = null
    }

    /** address = "192.168.1.20" or "192.168.1.20:8080" */
    fun send(address: String, playlistName: String, rows: List<PlaylistRow>, withLyrics: Boolean, fetchLyrics: Boolean) {
        if (sending) return
        val (host, port) = parseAddress(address) ?: run { error = "That address doesn't look right."; return }
        prefs.edit().putString("host", address.trim()).apply()
        lastHost = address.trim()
        sendJob = scope.launch {
            sending = true
            result = null
            error = null
            done = 0
            fileProgress = 0f
            try {
                withContext(Dispatchers.IO) { runSend(host, port, playlistName, rows, withLyrics, fetchLyrics) }
            } catch (e: kotlinx.coroutines.CancellationException) {
                result = "Stopped. $done of $total songs sent."
            } catch (e: Exception) {
                error = "Lost the 3DS: ${e.message ?: e.javaClass.simpleName}. Is the receive screen still open?"
            } finally {
                sending = false
                current = ""
                currentStep = ""
                File(context.cacheDir, "ds-send").deleteRecursively()
            }
        }
    }

    private fun parseAddress(a: String): Pair<String, Int>? {
        val s = a.trim().removePrefix("http://").trimEnd('/')
        if (s.isEmpty()) return null
        val host = s.substringBefore(':')
        val port = s.substringAfter(':', "8080").toIntOrNull() ?: return null
        if (host.isBlank()) return null
        return host to port
    }

    private suspend fun runSend(host: String, port: Int, name: String, rows: List<PlaylistRow>, withLyrics: Boolean, fetchLyrics: Boolean) {
        val ctx = kotlin.coroutines.coroutineContext
        currentStep = "Checking what the 3DS has…"
        val (code, listing) = request(host, port, "GET", "/api/list")
        if (code != 200) throw IllegalStateException("the 3DS answered $code")
        val onDs = listing.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.toHashSet()

        val locals = rows.mapNotNull { it.local }.distinctBy { it.id }
        val missingOnPhone = rows.count { it.local == null }
        total = locals.size
        var sent = 0
        var already = 0
        var lyricsSent = 0
        var failed = 0
        val names = ArrayList<String>()

        for (t in locals) {
            ctx.ensureActive()
            val mp3Name = dsName(t)
            names += mp3Name
            current = t.title.ifBlank { mp3Name }
            fileProgress = 0f
            if (mp3Name.lowercase() !in onDs) {
                val ok = sendSong(host, port, t, mp3Name)
                if (ok) { sent++; onDs += mp3Name.lowercase() } else failed++
            } else {
                already++
            }
            if (withLyrics) {
                val lrcName = mp3Name.substringBeforeLast('.') + ".lrc"
                if (lrcName.lowercase() !in onDs) {
                    val lrc = lyricsFor(t, fetchLyrics)
                    if (lrc != null) {
                        currentStep = "Lyrics…"
                        val bytes = lrc.toByteArray()
                        val (c, _) = request(host, port, "PUT", "/api/file?path=" + enc("$FOLDER/$lrcName"), bytes.size.toLong()) { it.write(bytes) }
                        if (c == 200) { lyricsSent++; onDs += lrcName.lowercase() }
                    }
                }
            }
            done++
        }

        // The playlist: file names only; Mixtape DS matches them by name.
        currentStep = "Playlist…"
        current = name
        val m3u = buildString {
            append("#EXTM3U\n")
            names.forEach { append(it).append('\n') }
        }.toByteArray()
        val listName = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "mixtape" }
        request(host, port, "PUT", "/api/file?path=" + enc("playlists/$listName.m3u"), m3u.size.toLong()) { it.write(m3u) }
        request(host, port, "POST", "/api/done", 0) {}

        result = buildString {
            append("Sent $sent song${if (sent == 1) "" else "s"}")
            if (already > 0) append(", $already already on the 3DS")
            if (lyricsSent > 0) append(", lyrics for $lyricsSent")
            append(".")
            if (failed > 0) append(" $failed couldn't be sent.")
            if (missingOnPhone > 0) append(" $missingOnPhone aren't on this phone.")
            append(" Press B on the 3DS to add them.")
        }
    }

    /** The name the song gets on the 3DS: the phone's file name, always ending in .mp3. */
    private fun dsName(t: LocalTrack): String {
        val base = t.fileName.substringBeforeLast('.', t.fileName).ifBlank {
            listOf(t.artist, t.title).filter { it.isNotBlank() }.joinToString(" - ").ifBlank { "song ${t.id}" }
        }
        return base.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(150) + ".mp3"
    }

    private suspend fun sendSong(host: String, port: Int, t: LocalTrack, mp3Name: String): Boolean {
        val ext = t.fileName.substringAfterLast('.', "mp3").lowercase()
        val resolver = context.contentResolver
        if (ext == "mp3") {
            val size = resolver.openFileDescriptor(t.uri, "r")?.use { it.statSize } ?: return false
            if (size <= 0) return false
            currentStep = "Sending…"
            val input = resolver.openInputStream(t.uri) ?: return false
            return input.use { i ->
                request(host, port, "PUT", "/api/file?path=" + enc("$FOLDER/$mp3Name"), size) { out -> copy(i, out, size) }.first == 200
            }
        }
        // Not an MP3 (M4A, MX original/Opus, FLAC…): convert with the ffmpeg Mixtape already has.
        currentStep = "Converting to MP3…"
        val mp3 = convertToMp3(t, ext) ?: return false
        currentStep = "Sending…"
        return try {
            mp3.inputStream().use { i ->
                request(host, port, "PUT", "/api/file?path=" + enc("$FOLDER/$mp3Name"), mp3.length()) { out -> copy(i, out, mp3.length()) }.first == 200
            }
        } finally {
            mp3.delete()
        }
    }

    private suspend fun convertToMp3(t: LocalTrack, ext: String): File? {
        runCatching { DownloadQueue.prepareTools() }.onFailure { return null }
        val dir = File(context.cacheDir, "ds-send").apply { mkdirs() }
        val input = File(dir, "in.$ext")
        val output = File(dir, "out.mp3")
        output.delete()
        context.contentResolver.openInputStream(t.uri)?.use { i -> input.outputStream().use { i.copyTo(it) } } ?: return null
        val cmd = listOf(
            File(context.applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath,
            "-y", "-i", input.absolutePath,
            "-map", "0:a", "-map", "0:v?", "-c:v", "mjpeg", "-disposition:v", "attached_pic",
            "-c:a", "libmp3lame", "-b:a", "192k", "-map_metadata", "0", "-id3v2_version", "3",
            output.absolutePath,
        )
        return try {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).apply {
                environment()["LD_LIBRARY_PATH"] =
                    File(context.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib").absolutePath
            }.start()
            p.inputStream.bufferedReader().readText()
            if (!p.waitFor(180, TimeUnit.SECONDS)) { p.destroy(); null }
            else if (p.exitValue() == 0 && output.length() > 0) output else retryWithoutCover(input, output)
        } catch (e: Exception) {
            null
        } finally {
            input.delete()
        }
    }

    /** Some files have cover streams ffmpeg can't re-encode; the audio is what matters. */
    private fun retryWithoutCover(input: File, output: File): File? {
        if (!input.exists()) return null
        val cmd = listOf(
            File(context.applicationInfo.nativeLibraryDir, "libffmpeg.so").absolutePath,
            "-y", "-i", input.absolutePath, "-map", "0:a",
            "-c:a", "libmp3lame", "-b:a", "192k", "-map_metadata", "0", "-id3v2_version", "3",
            output.absolutePath,
        )
        val p = ProcessBuilder(cmd).redirectErrorStream(true).apply {
            environment()["LD_LIBRARY_PATH"] =
                File(context.noBackupFilesDir, "youtubedl-android/packages/ffmpeg/usr/lib").absolutePath
        }.start()
        p.inputStream.bufferedReader().readText()
        if (!p.waitFor(180, TimeUnit.SECONDS)) { p.destroy(); return null }
        return if (p.exitValue() == 0 && output.length() > 0) output else null
    }

    private fun lyricsFor(t: LocalTrack, fetch: Boolean): String? {
        val id = t.id.toString()
        LyricsRepo.lrcText(context, id)?.let { return it }
        if (!fetch) return null
        runCatching { LyricsRepo.fetch(context, id, t.title, t.artist, t.album, t.durationMs) }
        return LyricsRepo.lrcText(context, id)
    }

    private fun copy(input: InputStream, out: OutputStream, size: Long) {
        val buf = ByteArray(64 * 1024)
        var sent = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
            sent += n
            if (size > 0) fileProgress = (sent.toFloat() / size).coerceIn(0f, 1f)
        }
    }

    /** One HTTP request on a plain socket. Returns the status code and the (small) reply body. */
    private fun request(
        host: String,
        port: Int,
        method: String,
        path: String,
        length: Long = 0,
        body: ((OutputStream) -> Unit)? = null,
    ): Pair<Int, String> {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), 5000)
            s.soTimeout = 60_000
            val out = s.getOutputStream().buffered(64 * 1024)
            val head = buildString {
                append("$method $path HTTP/1.1\r\n")
                append("Host: $host:$port\r\n")
                append("User-Agent: Mixtape\r\n")
                if (method != "GET") append("Content-Length: $length\r\n")
                append("Connection: close\r\n\r\n")
            }
            out.write(head.toByteArray())
            body?.invoke(out)
            out.flush()
            val reply = s.getInputStream().readBytes().toString(Charsets.UTF_8)
            val code = reply.substringBefore("\r\n").split(' ').getOrNull(1)?.toIntOrNull() ?: 0
            return code to reply.substringAfter("\r\n\r\n", "")
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    companion object {
        const val DISCOVERY_PORT = 8081
        /** Songs go to sdmc:/music/Mixtape/ on the 3DS. */
        const val FOLDER = "Mixtape"
    }
}
