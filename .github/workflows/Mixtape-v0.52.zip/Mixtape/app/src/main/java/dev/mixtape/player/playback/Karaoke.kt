package dev.mixtape.player.playback

import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sin

/**
 * Karaoke: turns the vocals down. In most songs the voice sits in the middle (the same in left and
 * right), so the middle is lowered while the sides stay. The bass and kick drum are also in the
 * middle, so everything below ~160 Hz is kept. [vocals] 1 = normal song, 0 = as instrumental as it gets.
 * Mono songs can't be split and pass through unchanged.
 */
@OptIn(UnstableApi::class)
class KaraokeProcessor : BaseAudioProcessor() {
    @Volatile var vocals = 1f

    // Low-pass filter (biquad) for the middle, so the bass survives.
    private var b0 = 0f
    private var b1 = 0f
    private var b2 = 0f
    private var a1 = 0f
    private var a2 = 0f
    private var x1 = 0f
    private var x2 = 0f
    private var y1 = 0f
    private var y2 = 0f

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        val w = 2.0 * PI * 160.0 / inputAudioFormat.sampleRate
        val q = 0.7071
        val alpha = sin(w) / (2 * q)
        val cosw = cos(w)
        val a0 = 1 + alpha
        b0 = ((1 - cosw) / 2 / a0).toFloat()
        b1 = ((1 - cosw) / a0).toFloat()
        b2 = b0
        a1 = (-2 * cosw / a0).toFloat()
        a2 = ((1 - alpha) / a0).toFloat()
        x1 = 0f; x2 = 0f; y1 = 0f; y2 = 0f
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val v = vocals
        val channels = inputAudioFormat.channelCount
        if (v >= 0.999f || channels < 2) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        val frames = size / (2 * channels)
        for (f in 0 until frames) {
            val l = inputBuffer.short / 32768f
            val r = inputBuffer.short / 32768f
            val mid = (l + r) * 0.5f
            val side = (l - r) * 0.5f
            val low = b0 * mid + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = mid
            y2 = y1; y1 = low
            val m = low + v * (mid - low)
            // A little extra level on the sides makes up for the quieter middle.
            val s = side * (1f + (1f - v) * 0.4f)
            out.putShort(((m + s).coerceIn(-1f, 0.99997f) * 32768f).toInt().toShort())
            out.putShort(((m - s).coerceIn(-1f, 0.99997f) * 32768f).toInt().toShort())
            // Surround channels (rare) pass through.
            for (c in 2 until channels) out.putShort(inputBuffer.short)
        }
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }

    override fun onFlush() {
        x1 = 0f; x2 = 0f; y1 = 0f; y2 = 0f
    }
}

/**
 * Listens to the sound on its way to the speaker and keeps how loud each frequency band is,
 * for the ASCII visualiser. It only does the maths while a visualiser is on screen ([active]).
 * The sound itself passes through untouched.
 */
@OptIn(UnstableApi::class)
class LevelTap : BaseAudioProcessor() {

    @Volatile var active = false

    private val n = FFT_SIZE
    private val ring = FloatArray(n)
    private var ringPos = 0
    private var sinceLast = 0
    private var hop = 735
    private var sampleRate = 44_100

    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val window = FloatArray(n) { i -> (0.5 - 0.5 * cos(2 * PI * i / (n - 1))).toFloat() }
    private var edges = IntArray(BANDS + 1)

    // Snapshots, stamped with when they were made; the screen shows the one that's being heard.
    private val snaps = Array(SNAPS) { FloatArray(BANDS) }
    private val stamps = LongArray(SNAPS)
    @Volatile private var head = -1

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        sampleRate = inputAudioFormat.sampleRate
        hop = sampleRate / 60
        // Log-spaced bands from 40 Hz to 14 kHz.
        val binHz = sampleRate.toFloat() / n
        edges = IntArray(BANDS + 1) { i ->
            val hz = 40.0 * (14_000.0 / 40.0).pow(i.toDouble() / BANDS)
            (hz / binHz).toInt().coerceIn(1, n / 2 - 1)
        }
        for (i in 1..BANDS) if (edges[i] <= edges[i - 1]) edges[i] = (edges[i - 1] + 1).coerceAtMost(n / 2)
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        if (active) {
            val channels = inputAudioFormat.channelCount
            val frames = size / (2 * channels)
            val start = inputBuffer.position()
            for (f in 0 until frames) {
                var sum = 0f
                for (c in 0 until channels) sum += inputBuffer.getShort(start + (f * channels + c) * 2)
                ring[ringPos] = sum / (channels * 32768f)
                ringPos = (ringPos + 1) % n
                if (++sinceLast >= hop) {
                    sinceLast = 0
                    analyse()
                }
            }
        }
        val out = replaceOutputBuffer(size)
        out.put(inputBuffer)
        out.flip()
    }

    private fun analyse() {
        for (i in 0 until n) {
            re[i] = ring[(ringPos + i) % n] * window[i]
            im[i] = 0f
        }
        fft(re, im)
        val slot = (head + 1).mod(SNAPS)
        val dst = snaps[slot]
        for (b in 0 until BANDS) {
            var peak = 0f
            for (k in edges[b] until max(edges[b + 1], edges[b] + 1)) {
                val m = re[k] * re[k] + im[k] * im[k]
                if (m > peak) peak = m
            }
            val db = 10f * log10(peak + 1e-9f) // power in dB
            // Rough tilt so the highs aren't always flat (music has much less energy up there).
            val tilt = b * 0.4f
            dst[b] = ((db + tilt) / 55f).coerceIn(0f, 1f)
        }
        stamps[slot] = SystemClock.uptimeMillis()
        head = slot
    }

    /** Copies the levels heard [delayMs] ago into [out]; false if there's nothing recent. */
    fun read(out: FloatArray, delayMs: Long = LATENCY_MS): Boolean {
        val h = head
        if (h < 0) return false
        val want = SystemClock.uptimeMillis() - delayMs
        var i = h
        repeat(SNAPS) {
            if (stamps[i] <= want) {
                if (want - stamps[i] > 400) return false
                snaps[i].copyInto(out, 0, 0, minOf(out.size, BANDS))
                return true
            }
            i = (i - 1).mod(SNAPS)
        }
        return false
    }

    override fun onFlush() {
        ring.fill(0f)
        sinceLast = 0
    }

    companion object {
        const val BANDS = 48
        const val FFT_SIZE = 1024
        private const val SNAPS = 64
        /** Roughly how long the sound takes from here to the speaker. */
        const val LATENCY_MS = 260L

        /** In-place radix-2 FFT. */
        fun fft(re: FloatArray, im: FloatArray) {
            val n = re.size
            var j = 0
            for (i in 1 until n) {
                var bit = n shr 1
                while (j and bit != 0) {
                    j = j xor bit
                    bit = bit shr 1
                }
                j = j xor bit
                if (i < j) {
                    val tr = re[i]; re[i] = re[j]; re[j] = tr
                    val ti = im[i]; im[i] = im[j]; im[j] = ti
                }
            }
            var len = 2
            while (len <= n) {
                val ang = -2 * PI / len
                val wr = cos(ang).toFloat()
                val wi = sin(ang).toFloat()
                var i = 0
                while (i < n) {
                    var cr = 1f
                    var ci = 0f
                    for (k in 0 until len / 2) {
                        val a = i + k
                        val b = a + len / 2
                        val xr = re[b] * cr - im[b] * ci
                        val xi = re[b] * ci + im[b] * cr
                        re[b] = re[a] - xr
                        im[b] = im[a] - xi
                        re[a] += xr
                        im[a] += xi
                        val ncr = cr * wr - ci * wi
                        ci = cr * wi + ci * wr
                        cr = ncr
                    }
                    i += len
                }
                len = len shl 1
            }
        }
    }
}
