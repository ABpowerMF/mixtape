package dev.mixtape.player.lyrics

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Lyrics for a song: synced lines when available, else plain text. */
data class Lyrics(
    val synced: List<LyricLine>,
    val plain: String?,
    val instrumental: Boolean,
    /** "lrclib" or "you" (pasted). */
    val source: String,
)

/**
 * Finds lyrics once and keeps them on the phone, so after the first time they work offline.
 * Online source: LRCLIB, a free community lyrics database. Blocking: use Dispatchers.IO.
 */
object LyricsRepo {

    private const val UA = "Mixtape (Android music player)"

    private fun file(context: Context, id: String) =
        File(File(context.filesDir, "lyrics").apply { mkdirs() }, id.filter { it.isLetterOrDigit() } + ".json")

    fun cached(context: Context, id: String): Lyrics? = runCatching {
        val f = file(context, id)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        build(o.optString("synced"), o.optString("plain"), o.optBoolean("instrumental"), o.optString("source", "lrclib"))
    }.getOrNull()

    fun save(context: Context, id: String, syncedText: String?, plain: String?, instrumental: Boolean, source: String) {
        val o = JSONObject()
            .put("synced", syncedText.orEmpty())
            .put("plain", plain.orEmpty())
            .put("instrumental", instrumental)
            .put("source", source)
        file(context, id).writeText(o.toString())
    }

    /** The saved lyrics as an .lrc file (synced) or plain lines, for Mixtape DS. Null if none. */
    fun lrcText(context: Context, id: String): String? = runCatching {
        val f = file(context, id)
        if (!f.exists()) return null
        val o = JSONObject(f.readText())
        if (o.optBoolean("instrumental")) return null
        o.optString("synced").takeIf { it.isNotBlank() } ?: o.optString("plain").takeIf { it.isNotBlank() }
    }.getOrNull()

    fun delete(context: Context, id: String) {
        file(context, id).delete()
    }

    /** Text the user pasted: LRC becomes synced lyrics, anything else plain. */
    fun savePasted(context: Context, id: String, text: String): Lyrics? {
        val clean = text.trim()
        if (clean.isEmpty()) return null
        if (Lrc.isLrc(clean)) save(context, id, clean, null, false, "you") else save(context, id, null, clean, false, "you")
        return cached(context, id)
    }

    /** Looks the song up on LRCLIB and saves what it finds. Null when there are no lyrics. */
    fun fetch(context: Context, id: String, title: String, artist: String, album: String, durationMs: Long): Lyrics? {
        val params = buildString {
            append("track_name=").append(enc(title))
            append("&artist_name=").append(enc(artist))
            if (album.isNotBlank()) append("&album_name=").append(enc(album))
            if (durationMs > 0) append("&duration=").append(durationMs / 1000)
        }
        var hit = get("https://lrclib.net/api/get?$params")?.let { JSONObject(it) }
        if (hit == null) {
            // Looser search: best result whose length is close to ours.
            val list = get("https://lrclib.net/api/search?q=" + enc("$artist $title"))?.let { JSONArray(it) } ?: JSONArray()
            val results = (0 until list.length()).mapNotNull { list.optJSONObject(it) }
            hit = results.minByOrNull { r ->
                val d = r.optDouble("duration", 0.0) * 1000
                if (durationMs > 0 && d > 0) kotlin.math.abs(d - durationMs) else 0.0
            }
        }
        hit ?: return null
        val synced = hit.optString("syncedLyrics").takeIf { it != "null" }.orEmpty()
        val plain = hit.optString("plainLyrics").takeIf { it != "null" }.orEmpty()
        val instrumental = hit.optBoolean("instrumental")
        if (synced.isBlank() && plain.isBlank() && !instrumental) return null
        save(context, id, synced, plain, instrumental, "lrclib")
        return cached(context, id)
    }

    private fun build(synced: String, plain: String, instrumental: Boolean, source: String): Lyrics? {
        val lines = if (synced.isNotBlank()) Lrc.parse(synced) else emptyList()
        if (lines.isEmpty() && plain.isBlank() && !instrumental) return null
        return Lyrics(lines, plain.ifBlank { null }, instrumental, source)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Body of a 200 answer, null for 404, exception for anything else. */
    private fun get(url: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10_000
            readTimeout = 15_000
            setRequestProperty("User-Agent", UA)
        }
        try {
            return when (val code = conn.responseCode) {
                200 -> conn.inputStream.bufferedReader().use { it.readText() }
                404 -> null
                else -> throw IOException("Lyrics service answered $code")
            }
        } finally {
            conn.disconnect()
        }
    }
}
