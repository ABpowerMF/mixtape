package dev.mixtape.player.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Updates Mixtape from inside the app: looks at the newest release on GitHub (the public
 * releases repo, so the code can stay private), downloads the APK and hands it to Android's
 * installer. Every build is signed with the same key, so it installs over this one and keeps
 * your playlists and settings.
 */
object Updater {

    /** Where the APKs are published (a public repo with only releases in it). */
    const val REPO = "ABpowerMF/mixtape-releases"

    data class Release(val version: String, val notes: String, val apkUrl: String, val sizeBytes: Long, val page: String)

    /** The newest release, once checked (null = not checked, or nothing found). */
    var latest by mutableStateOf<Release?>(null)
        private set
    var checking by mutableStateOf(false)
        private set
    /** 0–1 while downloading, else null. */
    var progress by mutableStateOf<Float?>(null)
        private set
    /** "up to date", "no internet"… after a check. */
    var status by mutableStateOf<String?>(null)
        private set

    fun currentVersion(context: Context): String =
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty()

    fun hasUpdate(context: Context): Boolean = latest?.let { isNewer(it.version, currentVersion(context)) } == true

    private fun prefs(context: Context) = context.getSharedPreferences("updates", Context.MODE_PRIVATE)

    /** "0.47" > "0.46", "0.100" > "0.99", "1.0" > "0.99". */
    fun isNewer(candidate: String, current: String): Boolean {
        val a = candidate.split('.', '-').map { it.toIntOrNull() ?: 0 }
        val b = current.split('.', '-').map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** Checks at most once a day on its own; [force] checks now (the Settings button). */
    suspend fun check(context: Context, force: Boolean = false): Release? {
        val p = prefs(context)
        if (!force && System.currentTimeMillis() - p.getLong("lastCheck", 0L) < 20 * 60 * 60 * 1000L) return latest
        if (checking) return latest
        checking = true
        try {
            val r = withContext(Dispatchers.IO) { fetchLatest() }
            p.edit().putLong("lastCheck", System.currentTimeMillis()).apply()
            latest = r
            status = when {
                r == null -> "no releases yet"
                isNewer(r.version, currentVersion(context)) -> "v${r.version} is out"
                else -> "up to date"
            }
            return r
        } catch (e: Exception) {
            status = if (e is java.net.UnknownHostException) "no internet" else "couldn't check (${e.message ?: "error"})"
            return latest
        } finally {
            checking = false
        }
    }

    private fun fetchLatest(): Release? {
        val conn = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 20_000
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("User-Agent", "Mixtape-Android")
        try {
            if (conn.responseCode == 404) return null
            if (conn.responseCode !in 200..299) throw java.io.IOException("GitHub said ${conn.responseCode}")
            val o = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            val tag = o.optString("tag_name")
            val version = Regex("""\d+(\.\d+)+""").find(tag)?.value ?: return null
            val assets = o.optJSONArray("assets") ?: return null
            for (i in 0 until assets.length()) {
                val a = assets.optJSONObject(i) ?: continue
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    return Release(
                        version = version,
                        notes = o.optString("body").trim(),
                        apkUrl = a.optString("browser_download_url"),
                        sizeBytes = a.optLong("size"),
                        page = o.optString("html_url"),
                    )
                }
            }
            return null
        } finally {
            conn.disconnect()
        }
    }

    /** True once you were told about this version (pop-up or notification): it's only said once. */
    fun alreadyTold(context: Context, version: String) = prefs(context).getString("told", null) == version

    fun markTold(context: Context, version: String) {
        prefs(context).edit().putString("told", version).apply()
    }

    /** Android asks once: "Allow Mixtape to install apps?" */
    fun canInstall(context: Context): Boolean = context.packageManager.canRequestPackageInstalls()

    fun openInstallPermission(context: Context) {
        runCatching {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    }

    /** Downloads the APK (with progress) and opens Android's installer. Returns an error, or null. */
    suspend fun downloadAndInstall(context: Context, r: Release): String? {
        if (progress != null) return null
        progress = 0f
        try {
            val file = withContext(Dispatchers.IO) {
                val dir = File(context.cacheDir, "share").apply { mkdirs() }
                dir.listFiles()?.filter { it.name.startsWith("Mixtape-update") }?.forEach { it.delete() }
                val out = File(dir, "Mixtape-update-v${r.version}.apk")
                val conn = URL(r.apkUrl).openConnection() as HttpURLConnection
                conn.instanceFollowRedirects = true
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.setRequestProperty("User-Agent", "Mixtape-Android")
                try {
                    val total = conn.contentLengthLong.takeIf { it > 0 } ?: r.sizeBytes
                    conn.inputStream.use { input ->
                        out.outputStream().use { output ->
                            val buf = ByteArray(64 * 1024)
                            var done = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                done += n
                                if (total > 0) progress = (done.toFloat() / total).coerceIn(0f, 1f)
                            }
                        }
                    }
                } finally {
                    conn.disconnect()
                }
                out
            }
            val uri = FileProvider.getUriForFile(context, context.packageName + ".files", file)
            context.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return null
        } catch (e: Exception) {
            return if (e is java.net.UnknownHostException) "No internet." else "The download failed: ${e.message ?: "error"}"
        } finally {
            progress = null
        }
    }
}
