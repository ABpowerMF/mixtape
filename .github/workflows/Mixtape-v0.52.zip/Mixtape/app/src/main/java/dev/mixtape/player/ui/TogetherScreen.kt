package dev.mixtape.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.together.MissingRule
import dev.mixtape.player.together.SharedSong
import dev.mixtape.player.together.TogetherMode
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui

/** Listen together: pick a phone on the same Wi-Fi and where the music plays, then the live view. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TogetherScreen(vm: MainViewModel) {
    val t = vm.together
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("listen-together"), style = MaterialTheme.typography.titleLarge, color = Mix.Fog) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        if (t.active) LiveTogether(vm) else StartTogether(vm)
    }
}

/** "(•)" / "( )": a fixed-width mark that never breaks over two lines. */
@Composable
private fun RadioMark(on: Boolean) {
    Text(
        if (on) "(•)" else "( )",
        style = MaterialTheme.typography.bodyLarge,
        color = Mix.Paper,
        maxLines = 1,
        softWrap = false,
        modifier = Modifier.width(36.dp),
    )
}

@Composable
private fun StartTogether(vm: MainViewModel) {
    val t = vm.together
    DisposableEffect(Unit) {
        t.startDiscovery()
        onDispose { t.stopDiscovery() }
    }
    var picked by remember { mutableStateOf<String?>(null) }
    var how by remember { mutableStateOf(TogetherMode.BOTH) }
    val peer = t.peers.firstOrNull { it.id == picked } ?: t.peers.firstOrNull()

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
    ) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(Ui.head("nearby (same Wi-Fi)"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
            if (t.peers.isEmpty()) {
                Text(
                    "Looking… On the other phone, open Mixtape → player → people icon (this same screen), on the same Wi-Fi.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mix.Fog,
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                t.peers.forEach { p ->
                    val on = p.id == peer?.id
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .then(
                                if (on) {
                                    Modifier
                                        .background(Mix.Deep, RoundedCornerShape(3.dp))
                                        .border(BorderStroke(1.dp, Mix.Paper), RoundedCornerShape(3.dp))
                                } else {
                                    Modifier
                                },
                            )
                            .clickable { picked = p.id }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier
                                .size(10.dp)
                                .then(
                                    if (on) Modifier.background(Mix.Paper, CircleShape)
                                    else Modifier.border(BorderStroke(1.dp, Mix.Fog), CircleShape),
                                ),
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper)
                            Text("Mixtape open · ${p.platform}", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                        }
                        if (on) Text("selected", style = MaterialTheme.typography.bodySmall, color = Mix.Paper)
                    }
                }
            }

            Column(
                Modifier
                    .fillMaxWidth()
                    .background(Mix.Deep, RoundedCornerShape(3.dp))
                    .border(BorderStroke(1.dp, Mix.Gap), RoundedCornerShape(3.dp))
                    .padding(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Text("Where should the music play?", style = MaterialTheme.typography.titleSmall, color = Mix.Paper, fontWeight = FontWeight.Bold)
                val other = peer?.name ?: "the other phone"
                ModeOption(
                    on = how == TogetherMode.BOTH,
                    title = "On both phones",
                    body = "Same song, same second, each phone plays it out loud or in its own headphones.",
                ) { how = TogetherMode.BOTH }
                ModeOption(
                    on = how == TogetherMode.SPEAKER,
                    title = "Only on my phone",
                    body = "Your phone is the speaker. $other becomes a remote: skip, pause, add songs to the queue.",
                ) { how = TogetherMode.SPEAKER }
            }
            t.status?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = Mix.Fog) }
        }
        Button(
            onClick = { peer?.let { t.invite(it, how) } },
            enabled = peer != null && t.status == null,
            shape = RoundedCornerShape(3.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Mix.Paper, contentColor = Mix.Ink),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 16.dp)
                .height(50.dp),
        ) { Text(if (peer != null) "Invite ${peer.name}" else "Invite", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun ModeOption(on: Boolean, title: String, body: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .border(BorderStroke(1.dp, if (on) Mix.Paper else Mix.Gap), RoundedCornerShape(3.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.Top,
    ) {
        RadioMark(on)
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper, fontWeight = FontWeight.Bold)
            Text(body, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        }
    }
}

@Composable
private fun LiveTogether(vm: MainViewModel) {
    val t = vm.together
    var adding by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
    ) {
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(Modifier.fillMaxWidth().height(44.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).background(Mix.Paper, CircleShape))
                Spacer(Modifier.width(8.dp))
                Text(
                    "with ${t.peerName}" + (t.status?.let { " · $it" } ?: ""),
                    style = MaterialTheme.typography.titleSmall,
                    color = Mix.Paper,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                OutlinedButton(
                    onClick = { t.leave() },
                    shape = RoundedCornerShape(3.dp),
                    border = BorderStroke(1.dp, Mix.Gap),
                ) { Text("Leave", color = Mix.Paper) }
            }
            Text(
                if (t.mode == TogetherMode.BOTH) "Playing on both phones." else if (t.isHost) "Playing on your phone; ${t.peerName} is the remote." else "Playing on ${t.peerName}'s phone; you're the remote.",
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
            )

            val song = t.current
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Mix.Deep, RoundedCornerShape(3.dp))
                    .border(BorderStroke(1.dp, Mix.Gap), RoundedCornerShape(3.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val local = song?.key?.takeIf { it.startsWith("h:") && t.isHost }?.let { vm.trackById(it.removePrefix("h:")) }
                Artwork(local?.artUri, Modifier.size(64.dp), corner = 3.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(song?.title ?: "Nothing playing", style = MaterialTheme.typography.titleMedium, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (song != null) {
                        Text(song.artist, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val label = t.labelFor(song).let { if (it == "✓ both") "both have it ✓" else it }
                        if (label.isNotEmpty()) Text(label, style = MaterialTheme.typography.bodySmall, color = Mix.Paper)
                    }
                }
                if (song != null) Text(formatTime(t.positionMs), style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
            }

            // The guest's remote buttons (in "both phones" the normal player buttons work too).
            if (!t.isHost) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton(onClick = { t.control("prev") }) { Icon(Icons.Filled.SkipPrevious, contentDescription = "Previous") }
                    IconButton(onClick = { t.control("toggle") }) {
                        Icon(if (t.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, contentDescription = "Play or pause")
                    }
                    IconButton(onClick = { t.control("next") }) { Icon(Icons.Filled.SkipNext, contentDescription = "Next") }
                }
                TextButton(onClick = { adding = !adding }) { Text(Ui.btn(if (adding) "done adding" else "add a song"), color = Mix.Tape) }
                if (adding) AddSongs(vm)
            }

            Text(Ui.head("up next"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
            if (t.upNext.isEmpty()) Text("Nothing queued.", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
            Column {
                t.upNext.forEach { s -> NextRow(vm, s) }
            }
        }
        if (t.mode == TogetherMode.BOTH) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(Mix.Deep, RoundedCornerShape(3.dp))
                    .border(BorderStroke(1.dp, Mix.Gap), RoundedCornerShape(3.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text("When one of you doesn't have a song", style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, fontWeight = FontWeight.Bold)
                MissingRule.entries.forEach { r ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { t.chooseRule(r) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RadioMark(t.rule == r)
                        Text(r.label, style = MaterialTheme.typography.bodyMedium, color = if (t.rule == r) Mix.Paper else Mix.Fog)
                    }
                }
            }
        }
    }
}

@Composable
private fun NextRow(vm: MainViewModel, s: SharedSong) {
    val t = vm.together
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(s.title, style = MaterialTheme.typography.bodyLarge, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                s.artist + (s.addedBy?.let { " · added by $it" } ?: ""),
                style = MaterialTheme.typography.bodySmall,
                color = Mix.Fog,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(
            t.labelFor(s).replace("streams to ", "streams to\n"),
            style = MaterialTheme.typography.bodySmall,
            color = if (t.labelFor(s) == "✓ both") Mix.Paper else Mix.Fog,
            textAlign = TextAlign.End,
        )
    }
}

/** Guest: search your own songs and put them in the shared queue. */
@Composable
private fun AddSongs(vm: MainViewModel) {
    var query by remember { mutableStateOf("") }
    OutlinedTextField(
        value = query,
        onValueChange = { query = it },
        singleLine = true,
        placeholder = { Text("search your songs") },
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
    )
    if (query.isNotBlank()) {
        Column {
            vm.searchLibrary(query, limit = 8).forEach { track ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.together.addSong(track) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(track.title, style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text("+", style = MaterialTheme.typography.titleMedium, color = Mix.Tape)
                }
            }
        }
    }
}
