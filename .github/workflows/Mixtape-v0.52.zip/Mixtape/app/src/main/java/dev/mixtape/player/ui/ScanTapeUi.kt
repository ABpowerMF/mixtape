package dev.mixtape.player.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import dev.mixtape.player.tape.Tape
import dev.mixtape.player.tape.TapeCodec
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui
import java.util.concurrent.Executors

private sealed interface ScanState {
    data object Looking : ScanState
    data class Reading(val got: Int, val of: Int) : ScanState
    data class Loading(val tape: Tape) : ScanState
    data class Found(val preview: MainViewModel.TapePreview) : ScanState
    data class Failed(val reason: String) : ScanState
}

/** Scan a friend's tape: camera, then what's on it and how much of it is already on this phone. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanTapeScreen(vm: MainViewModel) {
    val context = LocalContext.current
    var allowed by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var asked by remember { mutableStateOf(false) }
    val askCamera = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        allowed = it
        asked = true
    }
    LaunchedEffect(Unit) { if (!allowed) askCamera.launch(Manifest.permission.CAMERA) }

    var state by remember { mutableStateOf<ScanState>(ScanState.Looking) }
    val collector = remember { TapeCodec.Collector() }

    // Once the whole tape is read: get its songs and count what's already here.
    val loading = state as? ScanState.Loading
    LaunchedEffect(loading) {
        val tape = loading?.tape ?: return@LaunchedEffect
        state = runCatching { ScanState.Found(vm.previewTape(tape)) }
            .getOrElse { ScanState.Failed("Couldn't read the songs: ${it.message ?: "no internet?"}") }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("scan-tape"), style = MaterialTheme.typography.titleLarge, color = Mix.Fog) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            val hint = when (val s = state) {
                is ScanState.Reading -> "reading the tape… ${s.got}/${s.of}, keep it in view"
                is ScanState.Loading -> "tape read, looking at the songs…"
                else -> "point the camera at a tape's QR code"
            }
            Text(hint, style = MaterialTheme.typography.bodyMedium, color = Mix.Fog, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Box(Modifier.size(260.dp), contentAlignment = Alignment.Center) {
                val scanning = state is ScanState.Looking || state is ScanState.Reading
                if (allowed && scanning) {
                    CameraScanner(
                        Modifier
                            .size(220.dp)
                            .clip(RoundedCornerShape(6.dp)),
                    ) { text ->
                        if (state !is ScanState.Looking && state !is ScanState.Reading) return@CameraScanner
                        if (!TapeCodec.isTape(text)) return@CameraScanner
                        val tape = collector.add(text)
                        state = if (tape != null) {
                            ScanState.Loading(tape)
                        } else {
                            val (got, of) = collector.progress
                            ScanState.Reading(got, of)
                        }
                    }
                } else {
                    Box(
                        Modifier
                            .size(220.dp)
                            .background(Mix.Raised, RoundedCornerShape(6.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (!allowed) {
                            Text(
                                if (asked) "Mixtape needs the camera to scan. Allow it in the phone's settings." else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Mix.Fog,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(16.dp),
                            )
                        }
                    }
                }
                ScanFrame(moving = scanning && allowed)
            }
            Spacer(Modifier.height(28.dp))
            when (val s = state) {
                is ScanState.Found -> TapeFoundCard(s.preview)
                is ScanState.Failed -> Text(s.reason, style = MaterialTheme.typography.bodyMedium, color = Mix.Alert)
                else -> Unit
            }
        }
        val found = state as? ScanState.Found
        if (found != null) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                val missing = found.preview.tracks.size - found.preview.have
                if (missing > 0) {
                    Button(
                        onClick = { vm.importTape(found.preview, download = true) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(3.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Mix.Paper, contentColor = Mix.Ink),
                    ) { Text("Import + download missing", fontWeight = FontWeight.Bold) }
                }
                OutlinedButton(
                    onClick = { vm.importTape(found.preview, download = false) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(3.dp),
                    border = BorderStroke(1.dp, Mix.Gap),
                ) { Text(if (missing > 0) "Import only" else "Import", color = Mix.Paper) }
            }
        } else if (state is ScanState.Failed) {
            OutlinedButton(
                onClick = {
                    collector.reset()
                    state = ScanState.Looking
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 20.dp, bottom = 16.dp)
                    .height(48.dp),
                shape = RoundedCornerShape(3.dp),
                border = BorderStroke(1.dp, Mix.Gap),
            ) { Text("Scan again", color = Mix.Paper) }
        }
    }
}

/** "> tape found": compact, with room above the text. */
@Composable
private fun TapeFoundCard(p: MainViewModel.TapePreview) {
    val total = p.tracks.size
    Column(
        Modifier
            .fillMaxWidth()
            .background(Mix.Deep, RoundedCornerShape(3.dp))
            .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(Ui.head("tape found"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
        Row(verticalAlignment = Alignment.CenterVertically) {
            MiniTape(p.tape.name)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(
                    p.tape.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = Mix.Paper,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    listOf(p.tape.from.takeIf { it.isNotBlank() }?.let { "from $it" }, "$total songs")
                        .filterNotNull()
                        .joinToString(" · "),
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                )
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth()) {
                Text("already on your phone", style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, modifier = Modifier.weight(1f))
                Text("${p.have}", style = MaterialTheme.typography.bodyMedium, color = Mix.Paper, fontWeight = FontWeight.Bold)
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .background(Mix.Gap, RoundedCornerShape(3.dp)),
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(if (total > 0) p.have.toFloat() / total else 0f)
                        .fillMaxHeight()
                        .background(Mix.Paper, RoundedCornerShape(3.dp)),
                )
            }
            Row(Modifier.fillMaxWidth()) {
                Text("missing (can download)", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog, modifier = Modifier.weight(1f))
                Text("${total - p.have}", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
            }
        }
    }
}

/** The four corners around the camera, and a line that sweeps up and down while looking. */
@Composable
private fun ScanFrame(moving: Boolean) {
    val sweep = rememberInfiniteTransition(label = "scan")
    val y by sweep.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "line",
    )
    val color = Mix.Paper
    Canvas(Modifier.size(260.dp)) {
        val w = 4.dp.toPx()
        val len = 40.dp.toPx()
        val e = w / 2
        val s = size.width
        // top left, top right, bottom left, bottom right
        drawLine(color, Offset(e, e), Offset(len, e), w, StrokeCap.Square)
        drawLine(color, Offset(e, e), Offset(e, len), w, StrokeCap.Square)
        drawLine(color, Offset(s - len, e), Offset(s - e, e), w, StrokeCap.Square)
        drawLine(color, Offset(s - e, e), Offset(s - e, len), w, StrokeCap.Square)
        drawLine(color, Offset(e, s - len), Offset(e, s - e), w, StrokeCap.Square)
        drawLine(color, Offset(e, s - e), Offset(len, s - e), w, StrokeCap.Square)
        drawLine(color, Offset(s - e, s - len), Offset(s - e, s - e), w, StrokeCap.Square)
        drawLine(color, Offset(s - len, s - e), Offset(s - e, s - e), w, StrokeCap.Square)
        if (moving) {
            drawLine(color.copy(alpha = 0.9f), Offset(s * 0.08f, s * y), Offset(s * 0.92f, s * y), 2.dp.toPx())
        }
    }
}

/** The back camera, reading QR codes with ML Kit (on the phone, no internet needed). */
@Composable
@androidx.annotation.OptIn(ExperimentalGetImage::class)
private fun CameraScanner(modifier: Modifier, onCode: (String) -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val latest = remember { arrayOf(onCode) }
    latest[0] = onCode
    val preview = remember { PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }

    DisposableEffect(owner) {
        val executor = Executors.newSingleThreadExecutor()
        val scanner = BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build(),
        )
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        future.addListener({
            val p = runCatching { future.get() }.getOrNull() ?: return@addListener
            provider = p
            val view = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(executor) { image ->
                val media = image.image
                if (media == null) {
                    image.close()
                    return@setAnalyzer
                }
                val input = InputImage.fromMediaImage(media, image.imageInfo.rotationDegrees)
                scanner.process(input)
                    .addOnSuccessListener(ContextCompat.getMainExecutor(context)) { codes ->
                        codes.forEach { c -> c.rawValue?.let { latest[0](it) } }
                    }
                    .addOnCompleteListener { image.close() }
            }
            runCatching {
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, view, analysis)
            }
        }, ContextCompat.getMainExecutor(context))
        onDispose {
            runCatching { provider?.unbindAll() }
            scanner.close()
            executor.shutdown()
        }
    }
    AndroidView(factory = { preview }, modifier = modifier)
}
