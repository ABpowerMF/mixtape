package dev.mixtape.player.playback

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.roundToInt

/**
 * Bitcrush: fewer bits per sample (grittier) and a lower sample rate (more "digital"), both from
 * one amount, 0 = off, 1 = heavily crushed. Changes apply instantly while playing.
 */
@OptIn(UnstableApi::class)
class CrushProcessor : BaseAudioProcessor() {
    @Volatile var amount = 0f
    private var held = ShortArray(2)
    private var counter = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        held = ShortArray(inputAudioFormat.channelCount)
        counter = 0
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val a = amount
        if (a <= 0f) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        val channels = inputAudioFormat.channelCount
        val bits = (16 - a * 12).roundToInt().coerceIn(4, 16)
        val shift = 16 - bits
        val hold = 1 + (a * a * 15).toInt()
        val frames = size / (2 * channels)
        for (f in 0 until frames) {
            for (c in 0 until channels) {
                val s = inputBuffer.short.toInt()
                if (counter == 0) held[c] = ((s shr shift) shl shift).toShort()
                out.putShort(held[c])
            }
            counter = (counter + 1) % hold
        }
        // Anything odd left over passes through untouched.
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }

    override fun onFlush() {
        counter = 0
    }
}

/**
 * Reverb (a small "Freeverb"-style room): 4 comb filters and 2 all-pass filters per channel.
 * One amount sets both the room size and how much of it you hear. 0 = off.
 */
@OptIn(UnstableApi::class)
class ReverbProcessor : BaseAudioProcessor() {
    @Volatile var amount = 0f

    private class Channel(scale: Double, spread: Int) {
        val combs = intArrayOf(1116, 1188, 1277, 1356).map { FloatArray(((it + spread) * scale).toInt().coerceAtLeast(1)) }
        val combIndex = IntArray(4)
        val combStore = FloatArray(4)
        val allpasses = intArrayOf(556, 441).map { FloatArray(((it + spread) * scale).toInt().coerceAtLeast(1)) }
        val allIndex = IntArray(2)
    }

    private var channels: List<Channel> = emptyList()

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) return AudioProcessor.AudioFormat.NOT_SET
        val scale = inputAudioFormat.sampleRate / 44100.0
        channels = List(inputAudioFormat.channelCount) { c -> Channel(scale, if (c % 2 == 1) 23 else 0) }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val a = amount
        if (a <= 0f || channels.isEmpty()) {
            out.put(inputBuffer)
            out.flip()
            return
        }
        val feedback = 0.70f + 0.27f * a
        val damp = 0.25f
        val wet = a * 2.2f
        val dry = 1f - a * 0.35f
        val n = channels.size
        val frames = size / (2 * n)
        for (f in 0 until frames) {
            for (c in 0 until n) {
                val ch = channels[c]
                val x = inputBuffer.short / 32768f
                val input = x * 0.015f
                var sum = 0f
                for (k in 0 until 4) {
                    val buf = ch.combs[k]
                    val i = ch.combIndex[k]
                    val o = buf[i]
                    ch.combStore[k] = o * (1 - damp) + ch.combStore[k] * damp
                    buf[i] = input + ch.combStore[k] * feedback
                    ch.combIndex[k] = if (i + 1 >= buf.size) 0 else i + 1
                    sum += o
                }
                for (k in 0 until 2) {
                    val buf = ch.allpasses[k]
                    val i = ch.allIndex[k]
                    val b = buf[i]
                    val o = -sum + b
                    buf[i] = sum + b * 0.5f
                    ch.allIndex[k] = if (i + 1 >= buf.size) 0 else i + 1
                    sum = o
                }
                val y = (x * dry + sum * wet).coerceIn(-1f, 0.99997f)
                out.putShort((y * 32768f).toInt().toShort())
            }
        }
        while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        out.flip()
    }

    override fun onReset() {
        channels = emptyList()
    }
}
