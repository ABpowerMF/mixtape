package dev.mixtape.player.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.Ui

/** Send a playlist to Mixtape DS on a 3DS (same Wi-Fi, "receive from phone" screen open). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendToDsScreen(vm: MainViewModel, id: String) {
    val playlist = vm.playlists.find { it.id == id }
    if (playlist == null) {
        LaunchedEffect(id) { vm.pop() }
        return
    }
    val ds = vm.ds
    val rows = vm.sortedRows(id)
    val onPhone = rows.count { it.local != null }
    val notOnPhone = rows.size - onPhone

    var picked by remember { mutableStateOf<String?>(null) }
    var typed by rememberSaveable { mutableStateOf(ds.lastHost) }
    var withLyrics by rememberSaveable { mutableStateOf(true) }
    var fetchLyrics by rememberSaveable { mutableStateOf(vm.lyricsOnline) }

    LaunchedEffect(Unit) {
        ds.clearResult()
        ds.search()
    }
    val device = ds.devices.firstOrNull { it.host == picked } ?: ds.devices.firstOrNull()
    val address = when {
        picked == MANUAL || device == null -> typed
        else -> "${device.host}:${device.port}"
    }
    if (ds.sending) KeepScreenOn()

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("send-to-3ds"), style = MaterialTheme.typography.titleLarge, color = Mix.Fog) },
            navigationIcon = {
                IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(playlist.name, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        "$onPhone song${if (onPhone == 1) "" else "s"} on this phone" +
                            if (notOnPhone > 0) " · $notOnPhone not downloaded (skipped)" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = Mix.Fog,
                    )
                }

                Text(Ui.head("on the 3DS"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
                Text(
                    "Open Mixtape DS → SELECT → receive from phone. Both need to be on the same Wi-Fi. " +
                        "Only songs the 3DS doesn't have yet are sent; non-MP3 songs are turned into MP3 first.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mix.Fog,
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(Ui.head("found"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper, modifier = Modifier.weight(1f))
                    TextButton(onClick = { ds.search() }, enabled = !ds.searching && !ds.sending) {
                        Text(Ui.btn(if (ds.searching) "looking…" else "search again"), color = Mix.Tape)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    if (ds.devices.isEmpty() && !ds.searching) {
                        Text("No 3DS found. Check the receive screen is open, or type the address it shows.", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                    }
                    ds.devices.forEach { d ->
                        val on = picked != MANUAL && d.host == device?.host
                        PickRow(on, "3DS at ${d.host}", "Mixtape DS ${d.version}") { picked = d.host }
                    }
                    PickRow(picked == MANUAL || ds.devices.isEmpty(), "Type the address", "shown on the 3DS screen") { picked = MANUAL }
                }
                if (picked == MANUAL || ds.devices.isEmpty()) {
                    OutlinedTextField(
                        value = typed,
                        onValueChange = { typed = it },
                        singleLine = true,
                        placeholder = { Text("192.168.1.20:8080") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                    )
                }

                Text(Ui.head("options"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
                CheckRow(withLyrics, "Send lyrics", "Saved lyrics go along as .lrc files") { withLyrics = !withLyrics }
                if (withLyrics) {
                    CheckRow(fetchLyrics, "Look up missing lyrics", "From LRCLIB, for songs you haven't opened lyrics for") { fetchLyrics = !fetchLyrics }
                }

                if (ds.sending || ds.result != null || ds.error != null) {
                    Text(Ui.head("progress"), style = MaterialTheme.typography.titleSmall, color = Mix.Paper)
                }
                if (ds.sending) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${ds.done} / ${ds.total}", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                        Text(ds.current, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(ds.currentStep, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
                        Bar(ds.fileProgress)
                        Bar(if (ds.total > 0) ds.done.toFloat() / ds.total else 0f)
                    }
                }
                ds.result?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = Mix.Paper) }
                ds.error?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = Mix.Alert) }
            }

            if (ds.sending) {
                OutlinedButton(
                    onClick = { ds.cancel() },
                    shape = RoundedCornerShape(3.dp),
                    border = BorderStroke(1.dp, Mix.Gap),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp).height(50.dp),
                ) { Text("Stop", color = Mix.Paper) }
            } else {
                Button(
                    onClick = { ds.send(address, playlist.name, rows, withLyrics, withLyrics && fetchLyrics) },
                    enabled = onPhone > 0 && address.isNotBlank(),
                    shape = RoundedCornerShape(3.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Mix.Paper, contentColor = Mix.Ink),
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp).height(50.dp),
                ) { Text("Send to 3DS", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

private const val MANUAL = "manual"

@Composable
private fun PickRow(on: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(56.dp)
            .then(
                if (on) {
                    Modifier
                        .background(Mix.Deep, RoundedCornerShape(3.dp))
                        .border(BorderStroke(1.dp, Mix.Paper), RoundedCornerShape(3.dp))
                } else {
                    Modifier
                },
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (on) "(•)" else "( )", style = MaterialTheme.typography.bodyLarge, color = Mix.Paper, maxLines = 1, softWrap = false, modifier = Modifier.width(36.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
        }
    }
}

@Composable
private fun CheckRow(on: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (on) "[x]" else "[ ]", style = MaterialTheme.typography.bodyLarge, color = if (on) Mix.Tape else Mix.Fog, maxLines = 1, softWrap = false, modifier = Modifier.width(36.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
        }
    }
}

@Composable
private fun Bar(p: Float) {
    Box(Modifier.fillMaxWidth().height(4.dp).background(Mix.Gap)) {
        Box(Modifier.fillMaxWidth(p.coerceIn(0f, 1f)).height(4.dp).background(Mix.Tape))
    }
}
