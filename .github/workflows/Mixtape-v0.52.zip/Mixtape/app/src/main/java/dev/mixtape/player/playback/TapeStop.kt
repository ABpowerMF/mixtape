package dev.mixtape.player.playback

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi

/**
 * The player the notification, lock screen, widgets and the app talk to. With "Tape stop" on,
 * pause slows the song down (speed and pitch together, like a tape deck losing power) before it
 * really pauses, and play winds it back up to speed.
 */
@OptIn(UnstableApi::class)
class TapePlayer(private val inner: Player) : ForwardingPlayer(inner) {

    private val handler = Handler(Looper.getMainLooper())
    private var ramp: Runnable? = null

    /** The speed you chose (Equaliser → slowed / sped up); the ramp always comes back to it. */
    private fun base(): PlaybackParameters {
        val fx = AudioFx.settings
        val speed = fx.speed.coerceIn(0.5f, 1.5f)
        return PlaybackParameters(speed, if (fx.vinylPitch) speed else 1f)
    }

    private fun cancelRamp() {
        ramp?.let(handler::removeCallbacks)
        ramp = null
    }

    override fun pause() {
        if (Extras.tapeStop && inner.isPlaying && ramp == null) {
            windDown()
        } else {
            cancelRamp()
            inner.playbackParameters = base()
            inner.pause()
        }
    }

    override fun play() {
        if (ramp != null) {
            // Pressed play again while it was winding down: back up from where it is.
            cancelRamp()
            windUp(from = inner.playbackParameters.speed / base().speed)
            return
        }
        if (Extras.tapeStop && !inner.playWhenReady && inner.mediaItemCount > 0) {
            windUp(from = LOWEST)
        } else {
            inner.play()
        }
    }

    override fun setPlayWhenReady(playWhenReady: Boolean) {
        if (playWhenReady) play() else pause()
    }

    private fun windDown() {
        val b = base()
        val start = SystemClock.uptimeMillis()
        val r = object : Runnable {
            override fun run() {
                val t = ((SystemClock.uptimeMillis() - start).toFloat() / DOWN_MS).coerceIn(0f, 1f)
                // Eases in: slow at first, then drops off, like a motor losing power.
                val f = 1f - (1f - LOWEST) * t * t
                applyFactor(b, f)
                if (t < 1f) {
                    handler.postDelayed(this, STEP_MS)
                } else {
                    // The slowed sound still in the speaker's buffer plays out, then it stops.
                    val tail = Runnable {
                        ramp = null
                        inner.pause()
                        inner.playbackParameters = b
                    }
                    ramp = tail
                    handler.postDelayed(tail, TAIL_MS)
                }
            }
        }
        ramp = r
        handler.post(r)
    }

    private fun windUp(from: Float) {
        val b = base()
        val start = SystemClock.uptimeMillis()
        val begin = from.coerceIn(LOWEST, 1f)
        applyFactor(b, begin)
        val r = object : Runnable {
            override fun run() {
                val t = ((SystemClock.uptimeMillis() - start).toFloat() / UP_MS).coerceIn(0f, 1f)
                val e = 1f - (1f - t) * (1f - t) // fast at first, settles into speed
                applyFactor(b, begin + (1f - begin) * e)
                if (t < 1f) {
                    handler.postDelayed(this, STEP_MS)
                } else {
                    ramp = null
                    inner.playbackParameters = b
                }
            }
        }
        ramp = r
        handler.postDelayed(r, STEP_MS)
        if (!inner.playWhenReady) inner.play()
    }

    private fun applyFactor(b: PlaybackParameters, factor: Float) {
        val f = factor.coerceIn(LOWEST, 1f)
        inner.playbackParameters = PlaybackParameters(b.speed * f, b.pitch * f)
    }

    private companion object {
        const val LOWEST = 0.2f
        const val DOWN_MS = 650f
        const val UP_MS = 450f
        const val STEP_MS = 25L
        const val TAIL_MS = 220L
    }
}
