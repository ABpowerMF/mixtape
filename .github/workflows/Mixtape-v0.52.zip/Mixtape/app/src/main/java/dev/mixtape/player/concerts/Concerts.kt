package dev.mixtape.player.concerts

import android.content.Context
import android.location.Geocoder
import dev.mixtape.player.spotify.SpotifyWeb
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** One upcoming show. */
data class Concert(
    val id: String,
    val title: String,
    /** The artist from your playlists this show belongs to. */
    val artist: String,
    /** ISO date-time as Spotify gives it, e.g. 2026-11-20T21:00+00:00. */
    val start: String,
    val city: String,
    val lineup: List<String>,
) {
    val url: String get() = "https://open.spotify.com/concert/$id"
}

/**
 * Upcoming concerts of the artists in your playlists, from Spotify's artist pages (the same list
 * the Spotify app shows). Saved for a day per artist, so it only goes online when it's stale.
 * Blocking: call from Dispatchers.IO.
 */
object ConcertRepo {

    private const val OPERATION = "ArtistConcerts"
    private const val KNOWN_HASH = "ef53c43b865496b9890b7167eab1dc614a8949ef9451b3c41184ea888de8bd2b"
    private const val DAY = 24 * 3600 * 1000L

    private fun dir(context: Context) = File(context.filesDir, "concerts").apply { mkdirs() }

    /** Cached shows for an artist (null if never fetched or older than a day). */
    fun cached(context: Context, artistId: String, maxAge: Long = DAY): List<Concert>? = runCatching {
        val f = File(dir(context), "$artistId.json")
        if (!f.exists() || System.currentTimeMillis() - f.lastModified() > maxAge) return null
        parseSaved(JSONArray(f.readText()))
    }.getOrNull()

    fun fetch(context: Context, artistId: String, artistName: String): List<Concert> {
        val json = SpotifyWeb.runQuery(
            OPERATION,
            KNOWN_HASH,
            JSONObject().put("artistUri", "spotify:artist:$artistId").put("includeNearby", false),
        )
        val shows = LinkedHashMap<String, Concert>()
        collect(json, artistName, shows)
        val today = java.time.LocalDate.now().toString()
        val list = shows.values.filter { it.start.take(10) >= today }.sortedBy { it.start }
        val out = JSONArray()
        list.forEach { c ->
            out.put(
                JSONObject().put("id", c.id).put("title", c.title).put("artist", c.artist).put("start", c.start)
                    .put("city", c.city).put("lineup", JSONArray(c.lineup)),
            )
        }
        File(dir(context), "$artistId.json").writeText(out.toString())
        return list
    }

    /** Finds every concert in the answer, wherever Spotify puts it. */
    private fun collect(node: Any?, artist: String, out: MutableMap<String, Concert>) {
        when (node) {
            is JSONObject -> {
                val uri = node.optString("uri")
                if (uri.startsWith("spotify:concert:") && node.has("startDateIsoString")) {
                    val id = uri.substringAfterLast(':')
                    val lineup = ArrayList<String>()
                    node.optJSONObject("artists")?.optJSONArray("items")?.let { items ->
                        for (i in 0 until items.length()) {
                            items.optJSONObject(i)?.optJSONObject("data")?.optJSONObject("profile")?.optString("name")
                                ?.takeIf { it.isNotBlank() }?.let { lineup += it }
                        }
                    }
                    out[id] = Concert(
                        id = id,
                        title = node.optString("title").ifBlank { lineup.joinToString(", ") },
                        artist = artist,
                        start = node.optString("startDateIsoString"),
                        city = node.optJSONObject("location")?.optString("city").orEmpty(),
                        lineup = lineup,
                    )
                } else {
                    node.keys().forEach { collect(node.opt(it), artist, out) }
                }
            }
            is JSONArray -> for (i in 0 until node.length()) collect(node.opt(i), artist, out)
        }
    }

    private fun parseSaved(arr: JSONArray): List<Concert> = (0 until arr.length()).mapNotNull { i ->
        val o = arr.optJSONObject(i) ?: return@mapNotNull null
        val lineup = o.optJSONArray("lineup")
        Concert(
            o.optString("id"), o.optString("title"), o.optString("artist"), o.optString("start"), o.optString("city"),
            (0 until (lineup?.length() ?: 0)).map { lineup!!.optString(it) },
        )
    }

    // ---------- Where things are ----------

    /** A city's coordinates, looked up once and remembered. */
    fun locate(context: Context, city: String): Pair<Double, Double>? {
        if (city.isBlank()) return null
        val prefs = context.getSharedPreferences("concert_places", Context.MODE_PRIVATE)
        prefs.getString(city.lowercase(), null)?.let { saved ->
            if (saved == "none") return null
            val (lat, lon) = saved.split(',').map { it.toDouble() }
            return lat to lon
        }
        if (!Geocoder.isPresent()) return null
        @Suppress("DEPRECATION")
        val hit = runCatching { Geocoder(context, Locale.ENGLISH).getFromLocationName(city, 1)?.firstOrNull() }.getOrNull()
        prefs.edit().putString(city.lowercase(), hit?.let { "${it.latitude},${it.longitude}" } ?: "none").apply()
        return hit?.let { it.latitude to it.longitude }
    }

    /** The city name for a place (for "Near Lisbon"). */
    fun cityAt(context: Context, lat: Double, lon: Double): String? {
        if (!Geocoder.isPresent()) return null
        @Suppress("DEPRECATION")
        return runCatching { Geocoder(context, Locale.getDefault()).getFromLocation(lat, lon, 1)?.firstOrNull()?.locality }.getOrNull()
    }

    fun distanceKm(a: Pair<Double, Double>, b: Pair<Double, Double>): Double {
        val r = 6371.0
        val dLat = Math.toRadians(b.first - a.first)
        val dLon = Math.toRadians(b.second - a.second)
        val h = sin(dLat / 2).pow(2) + cos(Math.toRadians(a.first)) * cos(Math.toRadians(b.first)) * sin(dLon / 2).pow(2)
        return 2 * r * asin(sqrt(h))
    }
}
