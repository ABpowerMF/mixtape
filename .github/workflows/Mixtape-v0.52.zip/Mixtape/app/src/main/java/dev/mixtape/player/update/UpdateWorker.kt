package dev.mixtape.player.update

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dev.mixtape.player.MainActivity
import dev.mixtape.player.R
import java.util.concurrent.TimeUnit

/**
 * Checks GitHub for a new Mixtape about once a day, even with the app closed, and tells you
 * with a phone notification. Only once per version, so it never nags.
 */
class UpdateWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val r = Updater.check(applicationContext, force = true) ?: return Result.success()
        if (Updater.isNewer(r.version, Updater.currentVersion(applicationContext))) {
            notifyOnce(applicationContext, r)
        }
        return Result.success()
    }

    companion object {
        const val ACTION_OPEN_UPDATES = "dev.mixtape.player.OPEN_UPDATES"
        private const val CHANNEL = "updates"
        private const val NOTIFICATION_ID = 4711

        /** Called when the app starts; keeps the existing schedule if there is one. */
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<UpdateWorker>(1, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            runCatching {
                WorkManager.getInstance(context)
                    .enqueueUniquePeriodicWork("update-check", ExistingPeriodicWorkPolicy.KEEP, request)
            }
        }

        /** The phone notification, once per version. */
        @SuppressLint("MissingPermission")
        fun notifyOnce(context: Context, r: Updater.Release) {
            if (Updater.alreadyTold(context, r.version)) return
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                return // notifications are off for Mixtape: the app shows it when you open it instead
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(
                NotificationChannel(CHANNEL, "App updates", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Tells you once when a new Mixtape is out"
                },
            )
            val open = PendingIntent.getActivity(
                context,
                NOTIFICATION_ID,
                Intent(context, MainActivity::class.java).setAction(ACTION_OPEN_UPDATES),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val first = r.notes.lineSequence().map { it.trim().removePrefix("-").trim() }
                .firstOrNull { it.isNotEmpty() && !it.startsWith("Mixtape v", ignoreCase = true) }
            val notification = NotificationCompat.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_launcher_monochrome)
                .setContentTitle("Mixtape v${r.version} is out")
                .setContentText(first ?: "Tap to update. Your playlists and settings stay.")
                .setStyle(NotificationCompat.BigTextStyle().bigText(r.notes.ifBlank { "Tap to update. Your playlists and settings stay." }))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            runCatching { NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification) }
            Updater.markTold(context, r.version)
        }
    }
}
