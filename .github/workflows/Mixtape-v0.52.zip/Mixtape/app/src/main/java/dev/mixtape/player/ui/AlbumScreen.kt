package dev.mixtape.player.ui

import dev.mixtape.player.ui.theme.Ui
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumScreen(vm: MainViewModel, folder: String) {
    val album = remember(vm.library, folder) { vm.localAlbums().firstOrNull { it.folder == folder } }
    val now by vm.player.state.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    if (deleting) AlbumDeleteDialog(vm, playlistId = null, folder = folder) { deleting = false }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("albums"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = {
                IconButton(onClick = vm::pop) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                if (album != null) {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More options") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        val key = "al:$folder"
                        DropdownMenuItem(
                            text = { Text(if (vm.isHidden(key)) "Take out of the vault" else "Move to vault") },
                            leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = null) },
                            onClick = {
                                menuOpen = false
                                if (vm.isHidden(key)) vm.takeOutOfVault(key) else vm.moveToVault(key)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Delete album…", color = Mix.Alert) },
                            leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null, tint = Mix.Alert) },
                            onClick = {
                                menuOpen = false
                                deleting = true
                            },
                        )
                    }
                }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        if (album == null) {
            EmptyState(title = "Album not found", body = "Its songs may have been deleted.")
        } else {
        val totalMs = album.tracks.sumOf { it.durationMs }
        val listState = rememberLazyListState()
        Box(Modifier.fillMaxSize()) {
            LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    if (Mix.cocoon) CocoonHero(
                        model = album.tracks.first().artUri,
                        fallback = Icons.Filled.Album,
                        chip = "album",
                        title = album.name,
                        subtitle = album.artist,
                        info = "${album.tracks.size} songs · ${formatListened(totalMs)}",
                        enabled = true,
                        onPlay = { vm.playAlbum(folder, 0, shuffle = false) },
                        onShuffle = { vm.playAlbum(folder, 0, shuffle = true) },
                    ) else Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Artwork(
                                album.tracks.first().artUri,
                                Modifier.size(140.dp),
                                fallback = Icons.Filled.Album,
                                iconSize = 48.dp,
                            )
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    album.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Text(album.artist, style = MaterialTheme.typography.bodyLarge, color = Mix.Fog, maxLines = 1)
                                Text(
                                    "${album.tracks.size} songs · ${formatListened(totalMs)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Mix.Fog,
                                )
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row {
                            Button(
                                shape = TermShape,
                                onClick = { vm.playAlbum(folder, 0, shuffle = false) },
                                colors = ButtonDefaults.buttonColors(containerColor = Mix.Tape, contentColor = Mix.Ink),
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Play")
                            }
                            Spacer(Modifier.width(12.dp))
                            OutlinedButton(shape = TermShape, onClick = { vm.playAlbum(folder, 0, shuffle = true) }) {
                                Icon(Icons.Filled.Shuffle, contentDescription = null, tint = Mix.Tape)
                                Spacer(Modifier.width(6.dp))
                                Text("Shuffle", color = Mix.Tape)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                }
                itemsIndexed(album.tracks, key = { _, t -> t.id }) { i, t ->
                    SwipeToQueue(onQueue = {
                        vm.player.addToQueue(listOf(t))
                        vm.showMessage("Added to queue: ${t.title}")
                    }) {
                        LocalTrackRow(t, highlighted = now.mediaId == t.id.toString()) {
                            vm.playAlbum(folder, i, shuffle = false)
                        }
                    }
                }
            }
            FastScrollbar(listState, Modifier.align(Alignment.CenterEnd))
        }
        }
    }
}
