package dev.mixtape.player.library

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class CleanupKind(val title: String, val note: String, val action: String) {
    DUPLICATES("Duplicates", "same song twice, keeps the better copy", "delete the extra copies"),
    COVERS("Missing covers", "finds them online and puts them in the file", "add covers"),
    TAGS("Messy tags", "\"Official Video\", \"(Audio)\", no artist", "clean the names"),
    BROKEN("Broken files", "won't play, 0 seconds long", "delete them"),
}

/** One thing to fix. For tags, [newTitle]/[newArtist] are the cleaned names. */
data class CleanupItem(
    val kind: CleanupKind,
    val track: LocalTrack,
    val detail: String,
    val newTitle: String? = null,
    val newArtist: String? = null,
)

/**
 * Settings → library cleanup: finds duplicate songs, songs without a cover, messy names from
 * YouTube ("Official Video", "Artist - Title" with no artist) and files that won't play.
 */
class LibraryCleanup(private val context: Context) {

    var items by mutableStateOf<List<CleanupItem>>(emptyList())
        private set
    var scannedAt by mutableLongStateOf(0L)
        private set
    var scannedSongs by mutableStateOf(0)
        private set
    /** "checking covers… 120/1284" while scanning, else null. */
    var progress by mutableStateOf<String?>(null)
        private set

    /** Per file: does it have a cover / does it open at all. Kept between scans. */
    private class FileCheck(val hasCover: Boolean, val opens: Boolean)
    private val checked = HashMap<Long, FileCheck>()

    fun count(kind: CleanupKind) = items.count { it.kind == kind }

    suspend fun scan(library: List<LocalTrack>) {
        if (progress != null) return
        progress = "looking…"
        try {
            val found = ArrayList<CleanupItem>()
            withContext(Dispatchers.Default) {
                found += duplicates(library)
                library.forEach { t -> messyTags(t)?.let(found::add) }
            }
            // Covers and broken files need each file opened: slower, so it shows progress.
            withContext(Dispatchers.IO) {
                library.forEachIndexed { i, t ->
                    if (i % 25 == 0) progress = "checking files… $i/${library.size}"
                    val c = checked.getOrPut(t.id) { check(t) }
                    when {
                        // Only when neither Android nor the file itself knows a length: a real dud.
                        !c.opens && t.durationMs <= 0 -> found += CleanupItem(CleanupKind.BROKEN, t, "${t.fileName} doesn't play")
                        !c.hasCover && canHoldCover(t) -> found += CleanupItem(CleanupKind.COVERS, t, "${t.title} · ${t.artist.ifEmpty { "unknown artist" }}")
                    }
                }
            }
            items = found
            scannedAt = System.currentTimeMillis()
            scannedSongs = library.size
        } finally {
            progress = null
        }
    }

    /** Forget fixed things (after a fix, before the next scan). */
    fun drop(done: Collection<CleanupItem>) {
        val ids = done.map { it.kind to it.track.id }.toSet()
        items = items.filterNot { (it.kind to it.track.id) in ids }
        done.forEach { checked.remove(it.track.id) }
    }

    private fun canHoldCover(t: LocalTrack) =
        t.fileName.substringAfterLast('.', "").lowercase() in setOf("mp3", "m4a", "mp4", "aac", "flac")

    private fun check(t: LocalTrack): FileCheck {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, t.uri)
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            FileCheck(hasCover = r.embeddedPicture != null, opens = duration > 0)
        } catch (e: Exception) {
            FileCheck(hasCover = true, opens = false)
        } finally {
            runCatching { r.release() }
        }
    }

    /** Same title and artist, about the same length: keep the best copy, list the others. */
    private fun duplicates(library: List<LocalTrack>): List<CleanupItem> {
        val out = ArrayList<CleanupItem>()
        library
            .filter { it.title.isNotBlank() }
            .groupBy { Text.normalizeTitle(it.title) + "|" + Text.normalize(it.artist) }
            .values
            .filter { it.size > 1 }
            .forEach { group ->
                // Within a group, only files of about the same length are the same recording.
                val left = group.toMutableList()
                while (left.size > 1) {
                    val first = left.first()
                    val same = left.filter { kotlin.math.abs(it.durationMs - first.durationMs) <= 4_000 }
                    left.removeAll(same)
                    if (same.size < 2) continue
                    val keep = same.maxWith(compareBy<LocalTrack>({ quality(it) }, { it.bitrateKbps }, { -it.addedAt }))
                    same.filter { it.id != keep.id }.forEach { t ->
                        out += CleanupItem(CleanupKind.DUPLICATES, t, "${t.fileName} (keeps ${keep.fileName})")
                    }
                }
            }
        return out
    }

    private fun quality(t: LocalTrack): Int = when (t.fileName.substringAfterLast('.', "").lowercase()) {
        "flac", "wav" -> 3
        "m4a", "opus", "ogg" -> 2
        else -> 1
    }

    /** "Song (Official Video)" → "Song"; no artist + "Artist - Song" → artist "Artist", title "Song". */
    private fun messyTags(t: LocalTrack): CleanupItem? {
        var title = t.title
        var artist = t.artist
        if (artist.isBlank() || artist.equals("<unknown>", true)) {
            val dash = title.indexOf(" - ")
            if (dash > 0) {
                artist = title.substring(0, dash).trim()
                title = title.substring(dash + 3).trim()
            } else {
                artist = ""
            }
        }
        title = title.replace(NOISE, "").replace(Regex("\\s{2,}"), " ").trim().trimEnd('-', '|', ' ')
        artist = artist.replace(TOPIC, "").replace(VEVO, "").trim()
        if (title.isEmpty()) return null
        if (title == t.title && artist == t.artist) return null
        val before = listOf(t.artist, t.title).filter { it.isNotBlank() }.joinToString(" · ")
        val after = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" · ")
        return CleanupItem(CleanupKind.TAGS, t, "$before → $after", newTitle = title, newArtist = artist)
    }

    /** Files Android must ask about before Mixtape can change them (made by another app). */
    suspend fun needsPermission(tracks: List<LocalTrack>): List<Uri> = withContext(Dispatchers.IO) {
        tracks.filter { t ->
            try {
                context.contentResolver.openFileDescriptor(t.uri, "rw")?.close()
                false
            } catch (e: SecurityException) {
                true
            } catch (e: Exception) {
                false
            }
        }.map { it.uri }
    }

    /** Fixes tags and covers, one file at a time. Returns how many failed. */
    suspend fun fix(fixes: List<CleanupItem>, onProgress: (String) -> Unit): Int {
        var failed = 0
        fixes.forEachIndexed { i, item ->
            onProgress("fixing ${i + 1}/${fixes.size}…")
            val t = item.track
            val ok = when (item.kind) {
                CleanupKind.TAGS -> TagEditor.save(
                    context, t, item.newTitle ?: t.title, item.newArtist ?: t.artist, t.album, null,
                ) is TagEditor.Result.Done
                CleanupKind.COVERS -> {
                    val cover = withContext(Dispatchers.IO) { findCover(t) }
                    cover != null && TagEditor.save(context, t, t.title, t.artist, t.album, Uri.fromFile(cover)) is TagEditor.Result.Done
                }
                else -> true
            }
            if (!ok) failed++
        }
        return failed
    }

    /** Looks the song up on the iTunes catalogue (free, no account) and downloads its cover. */
    private fun findCover(t: LocalTrack): File? = runCatching {
        val term = URLEncoder.encode(listOf(t.artist, Text.normalizeTitle(t.title)).filter { it.isNotBlank() }.joinToString(" "), "UTF-8")
        val conn = URL("https://itunes.apple.com/search?term=$term&entity=song&limit=1").openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 15_000
        val body = try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
        val art = JSONObject(body).optJSONArray("results")?.optJSONObject(0)?.optString("artworkUrl100")
            ?.takeIf { it.isNotBlank() } ?: return null
        val big = art.replace("100x100bb", "600x600bb")
        val file = File(context.cacheDir, "cover-${t.id}.jpg")
        URL(big).openStream().use { input -> file.outputStream().use { input.copyTo(it) } }
        file
    }.getOrNull()

    private companion object {
        val NOISE = Regex(
            "\\s*[(\\[][^)\\]]*\\b(official|lyrics?|audio|video|visuali[sz]er|hd|hq|4k|mv|m/v)\\b[^)\\]]*[)\\]]",
            RegexOption.IGNORE_CASE,
        )
        val TOPIC = Regex("\\s*-\\s*Topic$", RegexOption.IGNORE_CASE)
        val VEVO = Regex("VEVO$")
    }
}
