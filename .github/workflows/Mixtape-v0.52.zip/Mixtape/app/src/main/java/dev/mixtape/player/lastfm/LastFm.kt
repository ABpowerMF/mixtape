package dev.mixtape.player.lastfm

import android.content.Context
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import dev.mixtape.player.Config
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Last.fm: saves every song you play to your Last.fm profile ("scrobbling"). Plays are kept on
 * the phone first and sent when there's internet, so it works offline too.
 * Needs an API key in [Config.LASTFM_API_KEY]; without one this stays off and hidden.
 */
object LastFm {

    private const val API = "https://ws.audioscrobbler.com/2.0/"

    val available: Boolean get() = Config.LASTFM_API_KEY.isNotBlank() && Config.LASTFM_SECRET.isNotBlank()

    /** Your Last.fm user name while connected, else null. */
    var user by mutableStateOf<String?>(null)
        private set

    /** Plays waiting to be sent. */
    var pending by mutableStateOf(0)
        private set

    private var sessionKey: String? = null
    private var appContext: Context? = null
    private val worker = Executors.newSingleThreadExecutor()
    private val lock = Any()

    private fun prefs(context: Context) = context.getSharedPreferences("lastfm", Context.MODE_PRIVATE)
    private fun queueFile(context: Context) = File(context.filesDir, "lastfm-queue.json")

    fun init(context: Context) {
        if (appContext != null) return
        appContext = context.applicationContext
        val p = prefs(context)
        sessionKey = p.getString("sk", null)
        user = if (sessionKey != null) p.getString("user", null) else null
        pending = readQueue(context).length()
    }

    /** Logs in with your Last.fm name and password (only the session it returns is kept). Call off the main thread. */
    fun connect(context: Context, username: String, password: String): String? {
        if (!available) return "Last.fm isn't set up in this version."
        val reply = runCatching {
            call(mapOf("method" to "auth.getMobileSession", "username" to username.trim(), "password" to password), post = true)
        }.getOrElse { return "Couldn't reach Last.fm: ${it.message}" }
        val session = reply.optJSONObject("session")
            ?: return reply.optString("message").ifEmpty { "Last.fm said no. Check the name and password." }
        val sk = session.optString("key")
        val name = session.optString("name", username.trim())
        prefs(context).edit().putString("sk", sk).putString("user", name).apply()
        sessionKey = sk
        user = name
        flushQueue()
        return null
    }

    fun disconnect(context: Context) {
        prefs(context).edit().clear().apply()
        sessionKey = null
        user = null
    }

    /** "Now playing" on your profile. */
    fun nowPlaying(artist: String, title: String, album: String, durationMs: Long) {
        val sk = sessionKey ?: return
        if (!available || artist.isBlank() || title.isBlank()) return
        worker.execute {
            runCatching {
                val params = mutableMapOf("method" to "track.updateNowPlaying", "artist" to artist, "track" to title, "sk" to sk)
                if (album.isNotBlank()) params["album"] = album
                if (durationMs > 0) params["duration"] = (durationMs / 1000).toString()
                call(params, post = true)
            }
        }
    }

    /** Keeps a finished play and sends it (now, or later when online). */
    fun scrobble(artist: String, title: String, album: String, durationMs: Long, startedAtSec: Long) {
        val context = appContext ?: return
        if (!available || sessionKey == null || artist.isBlank() || title.isBlank()) return
        worker.execute {
            synchronized(lock) {
                val q = readQueue(context)
                q.put(
                    JSONObject()
                        .put("artist", artist)
                        .put("track", title)
                        .put("album", album)
                        .put("duration", durationMs / 1000)
                        .put("timestamp", startedAtSec),
                )
                writeQueue(context, q)
                pending = q.length()
            }
            sendQueued()
        }
    }

    /** Tries to send what's waiting (e.g. when the app opens). */
    fun flushQueue() {
        if (sessionKey == null) return
        worker.execute { sendQueued() }
    }

    private fun sendQueued() {
        val context = appContext ?: return
        val sk = sessionKey ?: return
        while (true) {
            val batch = synchronized(lock) {
                val q = readQueue(context)
                (0 until minOf(50, q.length())).map { q.getJSONObject(it) }
            }
            if (batch.isEmpty()) return
            val params = mutableMapOf("method" to "track.scrobble", "sk" to sk)
            batch.forEachIndexed { i, o ->
                params["artist[$i]"] = o.optString("artist")
                params["track[$i]"] = o.optString("track")
                params["timestamp[$i]"] = o.optLong("timestamp").toString()
                o.optString("album").takeIf { it.isNotBlank() }?.let { params["album[$i]"] = it }
                o.optLong("duration").takeIf { it > 0 }?.let { params["duration[$i]"] = it.toString() }
            }
            val reply = runCatching { call(params, post = true) }.getOrNull() ?: return // offline: try later
            if (reply.has("error")) {
                when (reply.optInt("error")) {
                    9 -> disconnect(context) // session no longer valid: connect again
                    11, 16, 29 -> return // Last.fm busy: try later
                }
                // Anything else means these plays can't be sent: drop them rather than retry forever.
            }
            synchronized(lock) {
                val q = readQueue(context)
                val rest = JSONArray()
                for (i in batch.size until q.length()) rest.put(q.get(i))
                writeQueue(context, rest)
                pending = rest.length()
            }
        }
    }

    private fun readQueue(context: Context): JSONArray =
        runCatching { JSONArray(queueFile(context).readText()) }.getOrDefault(JSONArray())

    private fun writeQueue(context: Context, q: JSONArray) {
        runCatching { queueFile(context).writeText(q.toString()) }
    }

    /** Signed Last.fm API call: api_sig = md5 of the sorted parameters + the shared secret. */
    private fun call(params: Map<String, String>, post: Boolean): JSONObject {
        val all = params + ("api_key" to Config.LASTFM_API_KEY)
        val sig = md5(all.toSortedMap().entries.joinToString("") { (k, v) -> k + v } + Config.LASTFM_SECRET)
        val body = (all + ("api_sig" to sig) + ("format" to "json")).entries.joinToString("&") { (k, v) ->
            URLEncoder.encode(k, "UTF-8") + "=" + URLEncoder.encode(v, "UTF-8")
        }
        val conn = (URL(if (post) API else "$API?$body").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("User-Agent", "Mixtape for Android")
            if (post) {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            }
        }
        try {
            if (post) conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            return runCatching { JSONObject(text) }.getOrElse { JSONObject().put("error", code).put("message", "HTTP $code") }
        } finally {
            conn.disconnect()
        }
    }

    private fun md5(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

/**
 * Watches the player (inside the playback service) and scrobbles songs you listened to:
 * at least half of the song or 4 minutes, and only songs longer than 30 seconds (Last.fm's rules).
 */
class Scrobbler(context: Context, private val player: Player) : Player.Listener {

    private var item: MediaItem? = null
    private var startedAtSec = 0L
    private var playingSince = 0L
    private var listened = 0L
    private var done = false
    private var knownDuration = 0L

    init {
        LastFm.init(context)
        LastFm.flushQueue()
        begin(player.currentMediaItem)
        if (player.isPlaying) playingSince = SystemClock.elapsedRealtime()
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (isPlaying) {
            if (playingSince == 0L) playingSince = SystemClock.elapsedRealtime()
            noteDuration()
            if (listened == 0L) announce()
        } else {
            flush()
        }
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        flush()
        begin(mediaItem)
        if (player.isPlaying) {
            playingSince = SystemClock.elapsedRealtime()
            announce()
        }
    }

    override fun onPlaybackStateChanged(playbackState: Int) {
        if (playbackState == Player.STATE_READY) noteDuration()
    }

    private fun noteDuration() {
        val d = player.duration
        if (d > 0 && player.currentMediaItem?.mediaId == item?.mediaId) knownDuration = d
    }

    /** Adds up the time played so far and scrobbles once the song qualifies. */
    fun flush() {
        if (playingSince != 0L) {
            listened += SystemClock.elapsedRealtime() - playingSince
            playingSince = 0L
        }
        val it = item ?: return
        if (done || it.mediaId.startsWith("net:")) return
        val duration = knownDuration
        val enough = if (duration > 0) listened >= minOf(duration / 2, 240_000L) else listened >= 240_000L
        if (enough && (duration == 0L || duration > 30_000)) {
            done = true
            val md = it.mediaMetadata
            LastFm.scrobble(
                md.artist?.toString().orEmpty(),
                md.title?.toString().orEmpty(),
                md.albumTitle?.toString().orEmpty(),
                duration,
                startedAtSec,
            )
        }
    }

    private fun begin(mediaItem: MediaItem?) {
        item = mediaItem
        startedAtSec = System.currentTimeMillis() / 1000
        listened = 0L
        done = false
        knownDuration = 0L
    }

    private fun announce() {
        val it = item ?: return
        if (it.mediaId.startsWith("net:")) return
        val md = it.mediaMetadata
        LastFm.nowPlaying(
            md.artist?.toString().orEmpty(),
            md.title?.toString().orEmpty(),
            md.albumTitle?.toString().orEmpty(),
            player.duration.coerceAtLeast(0L),
        )
    }
}
