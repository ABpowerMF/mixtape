package dev.mixtape.player.tape

import android.util.Base64
import dev.mixtape.player.data.SpotifyTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * A playlist shared as a "tape": its name, who made it, and either where it lives on Spotify
 * (then the code is tiny) or the songs themselves (title, artists, length).
 */
data class Tape(
    val name: String,
    val from: String,
    val count: Int,
    /** "playlist:ID" or "album:ID" when the playlist is on Spotify, else null. */
    val spotify: String? = null,
    val tracks: List<SpotifyTrack> = emptyList(),
)

/**
 * Turns a tape into QR code texts and back. A short tape fits in one code. A long one is split
 * into parts that the share screen shows one after another; the scanner collects them all.
 *
 * Each code reads: MXT1|set|part|parts|data   (data = compressed JSON, base64)
 */
object TapeCodec {
    private const val PREFIX = "MXT1"
    private const val CHUNK = 600

    fun isTape(text: String) = text.startsWith("$PREFIX|")

    fun encode(tape: Tape): List<String> {
        val o = JSONObject()
            .put("n", tape.name)
            .put("f", tape.from)
            .put("c", tape.count)
        if (tape.spotify != null) {
            o.put("s", tape.spotify)
        } else {
            o.put("t", JSONArray().apply {
                tape.tracks.forEach { t ->
                    put(JSONArray().put(t.title).put(t.artists.joinToString(";")).put(t.durationMs / 1000))
                }
            })
        }
        val data = Base64.encodeToString(deflate(o.toString().toByteArray()), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val parts = data.chunked(CHUNK)
        val set = (1..4).map { "abcdefghijkmnpqrstuvwxyz23456789".random() }.joinToString("")
        return parts.mapIndexed { i, chunk -> "$PREFIX|$set|${i + 1}|${parts.size}|$chunk" }
    }

    /** Collects scanned codes until a whole tape has been read. */
    class Collector {
        private var set: String? = null
        private var parts: Array<String?> = emptyArray()

        /** How many parts are read, and how many there are (0 before the first code). */
        val progress: Pair<Int, Int> get() = parts.count { it != null } to parts.size

        /** Adds one scanned code. Returns the tape once it's complete, else null. */
        fun add(text: String): Tape? {
            if (!isTape(text)) return null
            val bits = text.split('|', limit = 5)
            if (bits.size != 5) return null
            val s = bits[1]
            val index = bits[2].toIntOrNull() ?: return null
            val total = bits[3].toIntOrNull() ?: return null
            if (total !in 1..500 || index !in 1..total) return null
            if (s != set || parts.size != total) {
                set = s
                parts = arrayOfNulls(total)
            }
            parts[index - 1] = bits[4]
            if (parts.any { it == null }) return null
            return runCatching { decode(parts.joinToString("")) }.getOrNull()
        }

        fun reset() {
            set = null
            parts = emptyArray()
        }
    }

    private fun decode(data: String): Tape {
        val json = String(inflate(Base64.decode(data, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)))
        val o = JSONObject(json)
        val arr = o.optJSONArray("t") ?: JSONArray()
        val tracks = (0 until arr.length()).mapNotNull { i ->
            val t = arr.optJSONArray(i) ?: return@mapNotNull null
            SpotifyTrack(
                id = "tape:$i:" + t.optString(0).hashCode().toString(16),
                title = t.optString(0),
                artists = t.optString(1).split(';').map { it.trim() }.filter { it.isNotEmpty() },
                album = "",
                durationMs = t.optLong(2) * 1000,
            )
        }
        return Tape(
            name = o.optString("n", "Tape"),
            from = o.optString("f"),
            count = o.optInt("c", tracks.size),
            spotify = o.optString("s").ifEmpty { null },
            tracks = tracks,
        )
    }

    private fun deflate(bytes: ByteArray): ByteArray {
        val d = Deflater(Deflater.BEST_COMPRESSION)
        d.setInput(bytes)
        d.finish()
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        while (!d.finished()) out.write(buf, 0, d.deflate(buf))
        d.end()
        return out.toByteArray()
    }

    private fun inflate(bytes: ByteArray): ByteArray {
        val i = Inflater()
        i.setInput(bytes)
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        while (!i.finished()) {
            val n = i.inflate(buf)
            if (n == 0 && (i.needsInput() || i.needsDictionary())) break
            out.write(buf, 0, n)
        }
        i.end()
        return out.toByteArray()
    }
}
