package dev.mixtape.player.spotify

import android.content.Context
import android.util.Base64
import dev.mixtape.player.data.SpotifyTrack
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom

/**
 * Reads complete public playlists the way open.spotify.com does for visitors who aren't logged in:
 * an anonymous web-player token plus the web player's own "fetchPlaylist" query, paged 100 songs at
 * a time. No account, Premium or developer app needed. Blocking: call from Dispatchers.IO.
 *
 * Spotify changes these internals now and then, so every step reports what failed.
 */
object SpotifyWeb {

    class StepException(val step: String, message: String) : IOException("$step: $message")

    private const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"
    private const val SECRETS_URL =
        "https://code.thetadev.de/ThetaDev/spotify-secrets/raw/branch/main/secrets/secretDict.json"
    private const val PAGE = 100

    // Used when the community list of current secrets can't be reached.
    private const val FALLBACK_SECRET_VERSION = 61
    private val FALLBACK_SECRET = intArrayOf(
        44, 55, 47, 42, 70, 40, 34, 114, 76, 74, 50, 111, 120, 97, 75, 76, 94, 102, 43, 69, 49, 120, 118, 80, 64, 78,
    )

    private data class Session(
        val accessToken: String,
        val clientToken: String?,
        val clientVersion: String,
        val jsPackUrl: String?,
        val expiresAt: Long,
    )

    data class Playlist(val name: String?, val imageUrl: String?, val total: Int, val tracks: List<SpotifyTrack>)

    private var appContext: Context? = null
    @Volatile private var session: Session? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    /** All songs of a public playlist. [embedToken] (from the embed page) is tried if the web token fails. */
    @Synchronized
    fun playlist(id: String, embedToken: String? = null): Playlist {
        var s = currentSession(embedToken)
        var hash = cachedHash() ?: discoverHash(s)

        val tracks = ArrayList<SpotifyTrack>()
        var name: String? = null
        var image: String? = null
        var total = Int.MAX_VALUE
        var offset = 0
        var retriedHash = false
        var retriedAuth = false

        while (offset < total && offset < 10_000) {
            val json = try {
                query(s, hash, id, offset)
            } catch (e: StepException) {
                when {
                    e.message.orEmpty().contains("PersistedQueryNotFound", ignoreCase = true) && !retriedHash -> {
                        retriedHash = true
                        forgetHash()
                        hash = discoverHash(s)
                        continue
                    }
                    (e.message.orEmpty().contains("HTTP 401") || e.message.orEmpty().contains("HTTP 403")) && !retriedAuth -> {
                        retriedAuth = true
                        session = null
                        s = currentSession(embedToken)
                        continue
                    }
                    else -> throw e
                }
            }
            val playlist = json.optJSONObject("data")?.optJSONObject("playlistV2")
                ?: throw StepException("playlist", "unexpected answer from Spotify")
            if (playlist.optString("__typename") == "NotFound") {
                throw StepException("playlist", "Spotify says this playlist doesn't exist or is private")
            }
            if (name == null) {
                name = playlist.optString("name").ifEmpty { null }
                image = firstImage(playlist)
            }
            val content = playlist.optJSONObject("content") ?: throw StepException("playlist", "no song list in answer")
            total = content.optInt("totalCount", 0)
            val items = content.optJSONArray("items") ?: JSONArray()
            if (items.length() == 0) break
            for (i in 0 until items.length()) {
                parseItem(items.optJSONObject(i))?.let { tracks += it }
            }
            offset += items.length()
        }
        return Playlist(name, image, if (total == Int.MAX_VALUE) tracks.size else total, tracks)
    }

    // ---------- Session ----------

    private fun currentSession(embedToken: String?): Session {
        session?.takeIf { it.expiresAt > System.currentTimeMillis() + 60_000 }?.let { return it }

        val home = request("https://open.spotify.com/", step = "home page")
        val html = home.body
        val clientVersion = Regex("""<script id="appServerConfig" type="text/plain">([^<]+)</script>""")
            .find(html)?.groupValues?.get(1)
            ?.let { runCatching { JSONObject(String(Base64.decode(it, Base64.DEFAULT))).optString("clientVersion") }.getOrNull() }
            ?.ifEmpty { null }
            ?: Regex(""""clientVersion":"([^"]+)"""").find(html)?.groupValues?.get(1)
            ?: "1.2.70.0"
        val jsPack = Regex("""src="([^"]*web-player/web-player[^"]*\.js)"""").find(html)?.groupValues?.get(1)
            ?.let { if (it.startsWith("//")) "https:$it" else it }
        val deviceId = home.cookies["sp_t"] ?: randomHex(32)

        var token: String? = null
        var clientId: String? = null
        var expires = System.currentTimeMillis() + 50 * 60_000L
        var tokenError = ""
        try {
            val (version, secret) = latestSecret()
            val code = WebParsing.totp(secret, System.currentTimeMillis())
            val url = "https://open.spotify.com/api/token?reason=init&productType=web-player" +
                "&totp=$code&totpServer=$code&totpVer=$version"
            val res = JSONObject(request(url, step = "token", cookie = home.cookieHeader).body)
            token = res.optString("accessToken").ifEmpty { null }
            clientId = res.optString("clientId").ifEmpty { null }
            res.optLong("accessTokenExpirationTimestampMs").takeIf { it > 0 }?.let { expires = it }
        } catch (e: Exception) {
            tokenError = e.message.orEmpty()
        }
        if (token == null) token = embedToken
        if (token == null) throw StepException("token", tokenError.ifEmpty { "Spotify gave no access token" })

        val clientToken = clientId?.let { runCatching { clientToken(it, clientVersion, deviceId) }.getOrNull() }
        return Session(token, clientToken, clientVersion, jsPack, expires).also { session = it }
    }

    private fun latestSecret(): Pair<Int, IntArray> = try {
        val json = JSONObject(request(SECRETS_URL, step = "secrets", timeoutMs = 6_000).body)
        var bestVersion = -1
        var best: IntArray? = null
        val keys = json.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val v = k.toIntOrNull() ?: continue
            val arr = json.optJSONArray(k) ?: continue
            if (v > bestVersion) {
                bestVersion = v
                best = IntArray(arr.length()) { arr.optInt(it) }
            }
        }
        if (best != null) bestVersion to best else FALLBACK_SECRET_VERSION to FALLBACK_SECRET
    } catch (e: Exception) {
        FALLBACK_SECRET_VERSION to FALLBACK_SECRET
    }

    private fun clientToken(clientId: String, clientVersion: String, deviceId: String): String? {
        val body = JSONObject().put(
            "client_data",
            JSONObject()
                .put("client_version", clientVersion)
                .put("client_id", clientId)
                .put(
                    "js_sdk_data",
                    JSONObject()
                        .put("device_brand", "unknown")
                        .put("device_model", "unknown")
                        .put("os", "windows")
                        .put("os_version", "NT 10.0")
                        .put("device_id", deviceId)
                        .put("device_type", "computer"),
                ),
        )
        val res = JSONObject(
            request(
                "https://clienttoken.spotify.com/v1/clienttoken",
                step = "client token",
                method = "POST",
                body = body.toString(),
                headers = mapOf("Content-Type" to "application/json", "Accept" to "application/json"),
            ).body,
        )
        return res.optJSONObject("granted_token")?.optString("token")?.ifEmpty { null }
    }

    // ---------- Query hash ----------

    private fun prefs() = appContext?.getSharedPreferences("spotify_web", Context.MODE_PRIVATE)

    private fun cachedHash(): String? = prefs()?.getString("fetchPlaylist", null)

    private fun forgetHash() {
        prefs()?.edit()?.remove("fetchPlaylist")?.apply()
    }

    private fun discoverHash(s: Session): String {
        val pack = s.jsPackUrl ?: throw StepException("query id", "couldn't find the web player code")
        val main = request(pack, step = "query id")
        WebParsing.findQueryHash(main.body, "fetchPlaylist")?.let { return saveHash(it) }

        val base = pack.substringBeforeLast('/')
        val files = WebParsing.chunkFiles(main.body)
        if (files.isEmpty()) throw StepException("query id", "couldn't read the web player's file list")
        for (file in files.take(250)) {
            val js = runCatching { request("$base/$file", step = "query id").body }.getOrNull() ?: continue
            WebParsing.findQueryHash(js, "fetchPlaylist")?.let { return saveHash(it) }
        }
        throw StepException("query id", "fetchPlaylist not found in ${files.size} web player files")
    }

    private fun saveHash(hash: String): String {
        prefs()?.edit()?.putString("fetchPlaylist", hash)?.apply()
        return hash
    }

    // ---------- Query ----------

    private fun query(s: Session, hash: String, id: String, offset: Int): JSONObject {
        val variables = JSONObject()
            .put("uri", "spotify:playlist:$id")
            .put("offset", offset)
            .put("limit", PAGE)
            .put("enableWatchFeedEntrypoint", false)
        val extensions = JSONObject().put(
            "persistedQuery",
            JSONObject().put("version", 1).put("sha256Hash", hash),
        )
        val headers = buildMap {
            put("Authorization", "Bearer ${s.accessToken}")
            put("Spotify-App-Version", s.clientVersion)
            put("App-Platform", "WebPlayer")
            put("Accept", "application/json")
            put("Accept-Language", "en")
            s.clientToken?.let { put("Client-Token", it) }
        }

        // Newer web player: JSON body on /v2. Older: query string on /v1. Try both.
        val v2Body = JSONObject()
            .put("variables", variables)
            .put("operationName", "fetchPlaylist")
            .put("extensions", extensions)
        val first = runCatching {
            request(
                "https://api-partner.spotify.com/pathfinder/v2/query",
                step = "playlist",
                method = "POST",
                body = v2Body.toString(),
                headers = headers + ("Content-Type" to "application/json;charset=UTF-8"),
            ).body
        }
        val text = first.getOrElse { v2Error ->
            val url = "https://api-partner.spotify.com/pathfinder/v1/query?operationName=fetchPlaylist" +
                "&variables=${enc(variables.toString())}&extensions=${enc(extensions.toString())}"
            try {
                request(url, step = "playlist", method = "GET", headers = headers).body
            } catch (v1Error: StepException) {
                // Report the more useful of the two errors.
                if (v2Error is StepException && v2Error.message.orEmpty().contains("HTTP 4")) throw v2Error
                throw v1Error
            }
        }
        val json = JSONObject(text)
        json.optJSONArray("errors")?.let { errors ->
            val msg = errors.optJSONObject(0)?.optString("message").orEmpty()
            throw StepException("playlist", msg.ifEmpty { "Spotify returned an error" })
        }
        return json
    }

    private fun parseItem(item: JSONObject?): SpotifyTrack? {
        val data = item?.optJSONObject("itemV2")?.optJSONObject("data") ?: return null
        if (data.optString("__typename", "Track") != "Track") return null
        val title = data.optString("name").trim()
        if (title.isEmpty()) return null
        val artistItems = data.optJSONObject("artists")?.optJSONArray("items") ?: JSONArray()
        val artists = (0 until artistItems.length()).mapNotNull { i ->
            artistItems.optJSONObject(i)?.optJSONObject("profile")?.optString("name")?.trim()?.ifEmpty { null }
        }
        val uri = data.optString("uri")
        val id = uri.substringAfterLast(':').ifEmpty { "web:$title|${artists.joinToString(",")}" }
        val duration = data.optJSONObject("trackDuration")?.optLong("totalMilliseconds")
            ?: data.optJSONObject("duration")?.optLong("totalMilliseconds") ?: 0L
        val album = data.optJSONObject("albumOfTrack")?.optString("name").orEmpty()
        return SpotifyTrack(id, title, artists, album, duration)
    }

    private fun firstImage(playlist: JSONObject): String? {
        val items = playlist.optJSONObject("images")?.optJSONArray("items") ?: return null
        val sources = items.optJSONObject(0)?.optJSONArray("sources") ?: return null
        return sources.optJSONObject(0)?.optString("url")?.ifEmpty { null }
    }

    // ---------- HTTP ----------

    private class Response(val body: String, val cookies: Map<String, String>) {
        val cookieHeader: String? get() = cookies.entries.joinToString("; ") { "${it.key}=${it.value}" }.ifEmpty { null }
    }

    // ---------- Other web-player queries (concerts) ----------

    /**
     * Runs any web-player query by name. The query id is looked up in the web player's code once
     * (like fetchPlaylist); [knownHash] is used if that lookup fails.
     */
    fun runQuery(operation: String, knownHash: String, variables: JSONObject): JSONObject {
        var s = currentSession(null)
        val key = "hash:$operation"
        // Saved id, then the known one; the slow search through the web player's code only if that fails.
        var hash = prefs()?.getString(key, null) ?: knownHash
        var retried = false
        while (true) {
            try {
                return runOperation(s, operation, hash, variables)
            } catch (e: StepException) {
                val msg = e.message.orEmpty()
                if (retried) throw e
                retried = true
                if (msg.contains("PersistedQueryNotFound", ignoreCase = true)) {
                    prefs()?.edit()?.remove(key)?.apply()
                    hash = if (hash != knownHash) knownHash else runCatching { discoverOperation(s, operation) }.getOrNull() ?: throw e
                } else if (msg.contains("401") || msg.contains("403")) {
                    session = null
                    s = currentSession(null)
                } else {
                    throw e
                }
            }
        }
    }

    /**
     * The profile picture of the artist called [name] on Spotify (searching like the Spotify app),
     * or null when no artist has exactly that name (so we never show the wrong person).
     */
    fun searchArtistImage(name: String): String? {
        val v = JSONObject()
            .put("searchTerm", name).put("offset", 0).put("limit", 10).put("numberOfTopResults", 5)
            .put("includeAudiobooks", false).put("includePreReleases", true).put("includeAlbumPreReleases", false)
            .put("includeAuthors", false).put("includeEpisodeContentRatingsV2", false)
        val json = runQuery("searchDesktop", "eff59fa0a3d026b88b56fddbcf4bdfa16a186b8175a5c1a358c072e053c2e5b0", v)
        val items = json.optJSONObject("data")?.optJSONObject("searchV2")?.optJSONObject("artists")?.optJSONArray("items") ?: return null
        fun norm(s: String) = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "").replace(Regex("[^a-z0-9]+"), "")
        val want = norm(name)
        val artists = (0 until items.length()).mapNotNull { i ->
            val o = items.optJSONObject(i) ?: return@mapNotNull null
            (o.optJSONObject("data") ?: o.optJSONObject("item")?.optJSONObject("data"))?.takeIf { it.optString("uri").startsWith("spotify:artist:") }
        }
        val hit = artists.firstOrNull { norm(it.optJSONObject("profile")?.optString("name").orEmpty()) == want } ?: return null
        val sources = hit.optJSONObject("visuals")?.optJSONObject("avatarImage")?.optJSONArray("sources") ?: return null
        return (0 until sources.length()).mapNotNull { sources.optJSONObject(it) }
            .maxByOrNull { it.optInt("width") }?.optString("url")?.ifEmpty { null }
    }

    private fun discoverOperation(s: Session, operation: String): String? {
        val pack = s.jsPackUrl ?: return null
        val main = request(pack, step = "query id")
        WebParsing.findQueryHash(main.body, operation)?.let { return remember(operation, it) }
        val base = pack.substringBeforeLast('/')
        for (file in WebParsing.chunkFiles(main.body).take(250)) {
            val js = runCatching { request("$base/$file", step = "query id").body }.getOrNull() ?: continue
            WebParsing.findQueryHash(js, operation)?.let { return remember(operation, it) }
        }
        return null
    }

    private fun remember(operation: String, hash: String): String {
        prefs()?.edit()?.putString("hash:$operation", hash)?.apply()
        return hash
    }

    private fun runOperation(s: Session, operation: String, hash: String, variables: JSONObject): JSONObject {
        val extensions = JSONObject().put("persistedQuery", JSONObject().put("version", 1).put("sha256Hash", hash))
        val headers = buildMap {
            put("Authorization", "Bearer ${s.accessToken}")
            put("Spotify-App-Version", s.clientVersion)
            put("App-Platform", "WebPlayer")
            put("Accept", "application/json")
            put("Accept-Language", "en")
            s.clientToken?.let { put("Client-Token", it) }
        }
        val body = JSONObject().put("variables", variables).put("operationName", operation).put("extensions", extensions)
        val text = runCatching {
            request(
                "https://api-partner.spotify.com/pathfinder/v2/query",
                step = operation,
                method = "POST",
                body = body.toString(),
                headers = headers + ("Content-Type" to "application/json;charset=UTF-8"),
            ).body
        }.getOrElse {
            val url = "https://api-partner.spotify.com/pathfinder/v1/query?operationName=$operation" +
                "&variables=${enc(variables.toString())}&extensions=${enc(extensions.toString())}"
            request(url, step = operation, method = "GET", headers = headers).body
        }
        val json = JSONObject(text)
        json.optJSONArray("errors")?.let { errors ->
            val msg = errors.optJSONObject(0)?.optString("message").orEmpty()
            throw StepException(operation, msg.ifEmpty { "Spotify returned an error" })
        }
        return json
    }

    private fun request(
        url: String,
        step: String,
        method: String = "GET",
        body: String? = null,
        headers: Map<String, String> = emptyMap(),
        cookie: String? = null,
        timeoutMs: Int = 20_000,
    ): Response {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Accept-Language", "en")
            cookie?.let { setRequestProperty("Cookie", it) }
            headers.forEach { (k, v) -> setRequestProperty(k, v) }
        }
        try {
            if (body != null) {
                conn.doOutput = true
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) {
                throw StepException(step, "HTTP $code ${text.take(120).replace('\n', ' ')}".trim())
            }
            val cookies = HashMap<String, String>()
            conn.headerFields["Set-Cookie"]?.forEach { c ->
                val pair = c.substringBefore(';')
                val k = pair.substringBefore('=').trim()
                if (k.isNotEmpty() && pair.contains('=')) cookies[k] = pair.substringAfter('=')
            }
            return Response(text, cookies)
        } catch (e: StepException) {
            throw e
        } catch (e: IOException) {
            throw StepException(step, e.message ?: e.javaClass.simpleName)
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun randomHex(len: Int): String {
        val bytes = ByteArray((len + 1) / 2)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }.take(len)
    }
}
