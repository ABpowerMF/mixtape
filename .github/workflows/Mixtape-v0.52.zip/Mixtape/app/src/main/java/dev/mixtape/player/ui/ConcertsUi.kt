package dev.mixtape.player.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.mixtape.player.concerts.Concert
import dev.mixtape.player.ui.theme.Mix
import dev.mixtape.player.ui.theme.TermShape
import dev.mixtape.player.ui.theme.Ui
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

/** The concerts block on the Playlists tab: your area, shows near you, and a link to every tour date. */
@Composable
fun ConcertsSection(vm: MainViewModel) {
    LaunchedEffect(vm.concertsOpen) { if (vm.concertsOpen && vm.concerts.isEmpty()) vm.refreshConcerts() }
    val near = vm.nearConcerts()
    var askCity by remember { mutableStateOf(false) }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.setAreaFromLocation() else askCity = true
    }
    if (askCity) CityDialog(vm) { askCity = false }

    Column(Modifier.fillMaxWidth()) {
        if (vm.areaName == null) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
                Text("Set your area to see concerts near you.", style = MaterialTheme.typography.bodyMedium, color = Mix.Fog)
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { locationPermission.launch(Manifest.permission.ACCESS_COARSE_LOCATION) },
                        shape = TermShape,
                        border = BorderStroke(1.dp, Mix.Gap),
                    ) { Text(Ui.btn("use my location"), color = Mix.Tape, maxLines = 1) }
                    OutlinedButton(onClick = { askCity = true }, shape = TermShape, border = BorderStroke(1.dp, Mix.Gap)) {
                        Text(Ui.btn("type a city"), color = Mix.Tape, maxLines = 1)
                    }
                }
            }
        } else {
            Row(
                Modifier.padding(start = 20.dp, end = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    "Near ${vm.areaName} · ${vm.radiusKm} km",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mix.Fog,
                    modifier = Modifier.weight(1f),
                )
                TextButton(onClick = { askCity = true }) { Text(Ui.btn("change"), color = Mix.Tape) }
            }
        }
        vm.concertStatus?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp))
        }
        if (vm.areaName != null && vm.concertStatus == null) {
            if (near.isEmpty()) {
                Text(
                    "No concerts near you from your artists right now.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Mix.Fog,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                )
            } else {
                near.take(5).forEach { ConcertRow(it, vm.cityDistances[it.city]) }
            }
        }
        if (vm.concerts.isNotEmpty()) {
            val touring = vm.concerts.map { it.artist }.distinct().size
            Text(
                Ui.btn("all tour dates · ${vm.concerts.size} shows, $touring artists"),
                style = MaterialTheme.typography.labelLarge,
                color = Mix.Tape,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { vm.push(Screen.Concerts) }
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            )
        }
    }
}

/** Every upcoming show of your artists, nearest first when your area is set, or by artist. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConcertsScreen(vm: MainViewModel) {
    var byArtist by rememberSaveable { mutableStateOf(false) }
    var askCity by remember { mutableStateOf(false) }
    if (askCity) CityDialog(vm) { askCity = false }
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(Ui.path("concerts"), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = { IconButton(onClick = vm::pop) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
            actions = {
                IconButton(onClick = { vm.refreshConcerts(force = true) }) { Icon(Icons.Filled.Refresh, contentDescription = "Check again") }
            },
            windowInsets = WindowInsets(0, 0, 0, 0),
        )
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(false to "By date", true to "By artist").forEach { (value, label) ->
                val on = byArtist == value
                Text(
                    label,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (on) Mix.Ink else Mix.Paper,
                    modifier = Modifier
                        .background(if (on) Mix.Tape else Mix.Raised, TermShape)
                        .clickable { byArtist = value }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (vm.areaName != null) {
                listOf(50, 150, 500).forEach { km ->
                    Text(
                        "$km km",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (vm.radiusKm == km) Mix.Tape else Mix.Fog,
                        modifier = Modifier
                            .clickable { vm.chooseRadius(km) }
                            .padding(horizontal = 4.dp, vertical = 8.dp),
                    )
                }
            }
        }
        vm.concertStatus?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = Mix.Fog, modifier = Modifier.padding(20.dp, 8.dp))
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
            val near = vm.nearConcerts()
            if (!byArtist && near.isNotEmpty()) {
                item { SectionTitle("near ${vm.areaName}") }
                items(near, key = { "n:" + it.id + it.artist }) { ConcertRow(it, vm.cityDistances[it.city]) }
            }
            if (byArtist) {
                vm.concerts.groupBy { it.artist }.toSortedMap(String.CASE_INSENSITIVE_ORDER).forEach { (artist, shows) ->
                    item(key = "a:$artist") { SectionTitle("$artist · ${shows.size}") }
                    items(shows, key = { "a:" + it.id + it.artist }) { ConcertRow(it, vm.cityDistances[it.city]) }
                }
            } else {
                item { SectionTitle("everywhere") }
                items(vm.concerts, key = { "e:" + it.id + it.artist }) { ConcertRow(it, vm.cityDistances[it.city]) }
            }
            if (vm.concerts.isEmpty() && vm.concertStatus == null) {
                item {
                    Text(
                        "None of your top artists have announced shows right now.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mix.Fog,
                        modifier = Modifier.padding(20.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        Ui.head(text),
        style = MaterialTheme.typography.titleMedium,
        color = Mix.Tape,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 4.dp),
    )
}

/** One show: date block, artist and title, city (and how far), taps through to the tickets page. */
@Composable
fun ConcertRow(c: Concert, distanceKm: Double?) {
    val context = LocalContext.current
    val date = runCatching { OffsetDateTime.parse(c.start) }.getOrNull()
        ?: runCatching { OffsetDateTime.parse(c.start, DateTimeFormatter.ISO_OFFSET_DATE_TIME) }.getOrNull()
    val locale = Locale.getDefault()
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.url))) } }
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(
            Modifier
                .size(56.dp)
                .background(Mix.Raised, TermShape),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(date?.dayOfMonth?.toString() ?: c.start.drop(8).take(2), style = MaterialTheme.typography.titleLarge, color = Mix.Paper)
            Text(
                date?.month?.getDisplayName(TextStyle.SHORT, locale)?.uppercase(locale) ?: c.start.drop(5).take(2),
                style = MaterialTheme.typography.labelSmall,
                color = Mix.Tape,
            )
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.artist, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (c.title.isNotBlank() && !c.title.equals(c.artist, ignoreCase = true)) {
                Text(c.title, style = MaterialTheme.typography.bodySmall, color = Mix.Paper, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val bits = listOfNotNull(
                c.city.ifBlank { null },
                date?.let { it.dayOfWeek.getDisplayName(TextStyle.SHORT, locale) + " " + "%02d:%02d".format(it.hour, it.minute) },
                distanceKm?.let { "${it.toInt()} km" },
                if (date != null && date.year != java.time.LocalDate.now().year) date.year.toString() else null,
            )
            Text(bits.joinToString(" · "), style = MaterialTheme.typography.bodySmall, color = Mix.Fog, maxLines = 1)
        }
    }
}

@Composable
private fun CityDialog(vm: MainViewModel, onDone: () -> Unit) {
    var city by remember { mutableStateOf(vm.areaName.orEmpty()) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(Ui.head("your area")) },
        text = {
            Column {
                OutlinedTextField(
                    value = city,
                    onValueChange = { city = it },
                    singleLine = true,
                    placeholder = { Text("City, e.g. Lisbon") },
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Mix.Tape, cursorColor = Mix.Tape),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Text("Concerts within ${vm.radiusKm} km show as near you (change it on the concerts page).", style = MaterialTheme.typography.bodySmall, color = Mix.Fog)
            }
        },
        confirmButton = {
            TextButton(enabled = city.isNotBlank(), onClick = {
                vm.setAreaFromCity(city)
                onDone()
            }) { Text("Save", color = Mix.Tape) }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Mix.Paper) } },
        containerColor = Mix.Deep,
    )
}
