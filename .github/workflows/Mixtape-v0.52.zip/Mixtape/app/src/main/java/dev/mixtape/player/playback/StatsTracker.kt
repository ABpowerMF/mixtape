package dev.mixtape.player.playback

import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.Player

/** Measures how long each song actually plays, for the stats screen. Runs inside the playback service. */
class StatsTracker(private val player: Player) : Player.Listener {

    private var id: String? = null
    private var title = ""
    private var artist = ""
    private var startedAt = 0L          // when the current stretch of playing began, 0 = not playing
    private var listenedThisSong = 0L
    private var counted = false

    init {
        setSong(player.currentMediaItem)
        if (player.isPlaying) startedAt = SystemClock.elapsedRealtime()
    }

    override fun onIsPlayingChanged(isPlaying: Boolean) {
        if (isPlaying) {
            if (startedAt == 0L) startedAt = SystemClock.elapsedRealtime()
        } else {
            flush()
        }
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        flush()
        setSong(mediaItem)
        if (player.isPlaying) startedAt = SystemClock.elapsedRealtime()
    }

    /** Saves the time played since the last save. */
    fun flush() {
        val current = id
        if (current == null || startedAt == 0L) {
            startedAt = 0L
            return
        }
        val ms = SystemClock.elapsedRealtime() - startedAt
        startedAt = 0L
        listenedThisSong += ms
        val countPlay = !counted && listenedThisSong >= ListenStats.PLAY_AFTER_MS
        if (countPlay) counted = true
        ListenStats.add(current, title, artist, ms, countPlay)
    }

    private fun setSong(item: MediaItem?) {
        // Songs streamed from a friend's phone (listen together) aren't yours: not counted.
        id = item?.mediaId?.ifEmpty { null }?.takeUnless { it.startsWith("net:") }
        title = item?.mediaMetadata?.title?.toString().orEmpty()
        artist = item?.mediaMetadata?.artist?.toString().orEmpty()
        listenedThisSong = 0L
        counted = false
    }
}
