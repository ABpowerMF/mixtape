package dev.mixtape.player.ui.theme

import java.io.File
import android.net.Uri
import android.graphics.Typeface
import android.app.Activity
import android.content.Context
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import dev.mixtape.player.R

/** The app's colours. Background, panels, highlights, lines, text, dim text, accent, errors. */
data class Palette(
    val ink: Color,
    val deep: Color,
    val raised: Color,
    val gap: Color,
    val paper: Color,
    val fog: Color,
    val tape: Color,
    val alert: Color = Color(0xFFFF5F56),
) {
    val isLight: Boolean get() = ink.luminance() > 0.5f

    companion object {
        /**
         * Builds a full palette from the three colours people pick. Text and accent are nudged until
         * they stand out from the background, so a custom theme can never make the app unreadable.
         */
        fun from(background: Color, text: Color, accent: Color): Palette {
            val readableText = if (contrast(text, background) >= 4.5f) {
                text
            } else if (background.luminance() > 0.5f) {
                Color(0xFF111111)
            } else {
                Color(0xFFF2F2F2)
            }
            var readableAccent = accent
            var step = 0
            while (contrast(readableAccent, background) < 2.5f && step < 10) {
                readableAccent = lerp(readableAccent, readableText, 0.2f)
                step++
            }
            return Palette(
                ink = background,
                deep = lerp(background, readableText, 0.05f),
                raised = lerp(background, readableText, 0.10f),
                gap = lerp(background, readableText, 0.20f),
                paper = readableText,
                fog = lerp(background, readableText, 0.55f),
                tape = readableAccent,
            )
        }

        /** WCAG contrast ratio, 1 (none) to 21 (black on white). */
        fun contrast(a: Color, b: Color): Float {
            val la = a.luminance() + 0.05f
            val lb = b.luminance() + 0.05f
            return if (la > lb) la / lb else lb / la
        }
    }
}

enum class ThemePreset(val label: String, val palette: Palette?) {
    TERMINAL("Terminal", Palette.from(Color(0xFF050805), Color(0xFFCFF5CF), Color(0xFF39FF6A))),
    MONO("Black & white", Palette.from(Color(0xFF000000), Color(0xFFF2F2F2), Color(0xFFFFFFFF))),
    PAPER("White & black", Palette.from(Color(0xFFFFFFFF), Color(0xFF111111), Color(0xFF000000))),
    GREEN_WHITE("Green & white", Palette.from(Color(0xFFFFFFFF), Color(0xFF102010), Color(0xFF16A34A))),
    AMBER("Amber", Palette.from(Color(0xFF0A0700), Color(0xFFFFE2A8), Color(0xFFFFB000))),
    NIGHT("Night drive", Palette.from(Color(0xFF16202E), Color(0xFFEAF0F7), Color(0xFFF2C14E))),
    SOFT_LIGHT("Soft light", Palette.from(Color(0xFFF2F2F7), Color(0xFF1C1C1E), Color(0xFF007AFF))),
    SOFT_DARK("Soft dark", Palette.from(Color(0xFF000000), Color(0xFFF2F2F7), Color(0xFF0A84FF))),
    ROSE("Rose", Palette.from(Color(0xFF1A1014), Color(0xFFF7E8EE), Color(0xFFFF6FA3))),
    CUSTOM("Custom", null),
}

/** Colours people can pick for a custom theme. */
val Swatches = listOf(
    0xFF000000, 0xFF050805, 0xFF0B1220, 0xFF16202E, 0xFF1E1E1E, 0xFF3A3A3A,
    0xFFFFFFFF, 0xFFF2F2F2, 0xFFFFF7E6, 0xFFCFF5CF, 0xFFEAF0F7,
    0xFF39FF6A, 0xFF16A34A, 0xFF00E5FF, 0xFF3B82F6, 0xFF8B5CF6, 0xFFFF4FD8,
    0xFFFF5F56, 0xFFFF8A00, 0xFFFFB000, 0xFFF2C14E, 0xFFFFEB3B,
).map { Color(it) }

/** Current look. Reading these from a composable redraws it when the theme changes. */
object Mix {
    var palette by mutableStateOf(ThemePreset.TERMINAL.palette!!)
    var font by mutableStateOf(AppFont.MONO)
    /** Rounded (soft, plain labels) instead of the square terminal look. */
    var rounded by mutableStateOf(false)
    /** Cocoon style (console frontend look): rounded tiles, glass panels, button hints. Implies rounded. */
    var cocoon by mutableStateOf(false)
    /** Smooth transitions between screens and in lists (Settings → style). */
    var animations by mutableStateOf(true)

    /** Background picture or video (a file in the app), how much it's darkened (0–0.9). */
    var wallpaper by mutableStateOf<String?>(null)
    var wallpaperVideo by mutableStateOf(false)
    var wallpaperDim by mutableStateOf(0.55f)
    /** Blur of the background picture/video, 0–30 (0 = sharp). */
    var wallpaperBlur by mutableStateOf(0f)

    /** A font the user imported (Settings → font → import). */
    var customFont by mutableStateOf<FontFamily?>(null)

    val mono: Boolean get() = font == AppFont.MONO || font == AppFont.JETBRAINS || font == AppFont.VT323 || font == AppFont.PIXEL

    val Ink: Color get() = palette.ink         // background
    val Deep: Color get() = palette.deep       // sheets, player bar
    val Raised: Color get() = palette.raised   // artwork placeholders, chips, selection
    val Gap: Color get() = palette.gap         // lines, missing songs in the match strip
    val Paper: Color get() = palette.paper     // main text
    val Fog: Color get() = palette.fog         // secondary text
    val Tape: Color get() = palette.tape       // accent: songs found, play
    val Alert: Color get() = palette.alert
}

/** Saves and restores the look. */
object Appearance {
    private fun prefs(context: Context) = context.getSharedPreferences("mixtape", Context.MODE_PRIVATE)

    var preset by mutableStateOf(ThemePreset.TERMINAL)
        private set
    var custom by mutableStateOf(ThemePreset.TERMINAL.palette!!)
        private set

    /** The colours exactly as picked (the palette may adjust them for readability). */
    var customPicks by mutableStateOf(Triple(Color(0xFF050805), Color(0xFFCFF5CF), Color(0xFF39FF6A)))
        private set

    fun load(context: Context) {
        val p = prefs(context)
        preset = ThemePreset.entries.firstOrNull { it.name == p.getString("theme", null) } ?: ThemePreset.TERMINAL
        customPicks = Triple(
            Color(p.getInt("customBackground", Color(0xFF050805).toArgb())),
            Color(p.getInt("customText", Color(0xFFCFF5CF).toArgb())),
            Color(p.getInt("customAccent", Color(0xFF39FF6A).toArgb())),
        )
        custom = Palette.from(customPicks.first, customPicks.second, customPicks.third)
        Mix.font = AppFont.entries.firstOrNull { it.name == p.getString("font", null) }
            ?: if (p.getBoolean("monoFont", true)) AppFont.MONO else AppFont.BARLOW
        Mix.cocoon = p.getBoolean("cocoon", false)
        Mix.rounded = p.getBoolean("rounded", false) || Mix.cocoon
        Mix.animations = p.getBoolean("animations", true)
        Mix.wallpaper = p.getString("wallpaper", null)?.takeIf { File(it).exists() }
        Mix.wallpaperVideo = p.getBoolean("wallpaperVideo", false)
        Mix.wallpaperDim = p.getFloat("wallpaperDim", 0.55f)
        Mix.wallpaperBlur = p.getFloat("wallpaperBlur", 0f)
        Mix.customFont = loadCustomFont(context)
        if (Mix.font == AppFont.CUSTOM && Mix.customFont == null) Mix.font = AppFont.MONO
        apply()
    }

    fun choose(context: Context, preset: ThemePreset) {
        this.preset = preset
        prefs(context).edit().putString("theme", preset.name).apply()
        apply()
    }

    /** Changes one of the custom colours and switches to the custom theme. */
    fun setCustom(context: Context, background: Color? = null, text: Color? = null, accent: Color? = null) {
        val (bg, fg, ac) = customPicks
        customPicks = Triple(background ?: bg, text ?: fg, accent ?: ac)
        custom = Palette.from(customPicks.first, customPicks.second, customPicks.third)
        prefs(context).edit()
            .putInt("customBackground", customPicks.first.toArgb())
            .putInt("customText", customPicks.second.toArgb())
            .putInt("customAccent", customPicks.third.toArgb())
            .apply()
        choose(context, ThemePreset.CUSTOM)
    }

    fun setFont(context: Context, font: AppFont) {
        if (font == AppFont.CUSTOM && Mix.customFont == null) return
        Mix.font = font
        prefs(context).edit().putString("font", font.name).apply()
    }

    /** Copies a picture or video into the app and uses it as the background. */
    fun setWallpaper(context: Context, uri: Uri, video: Boolean): Boolean = runCatching {
        val dir = File(context.filesDir, "wallpaper").apply { deleteRecursively(); mkdirs() }
        val target = File(dir, if (video) "background.mp4" else "background.img")
        context.contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { input.copyTo(it) } }
            ?: return false
        Mix.wallpaper = target.absolutePath
        Mix.wallpaperVideo = video
        prefs(context).edit().putString("wallpaper", target.absolutePath).putBoolean("wallpaperVideo", video).apply()
        true
    }.getOrDefault(false)

    fun clearWallpaper(context: Context) {
        File(context.filesDir, "wallpaper").deleteRecursively()
        Mix.wallpaper = null
        prefs(context).edit().remove("wallpaper").apply()
    }

    fun setWallpaperBlur(context: Context, blur: Float) {
        Mix.wallpaperBlur = blur.coerceIn(0f, 30f)
        prefs(context).edit().putFloat("wallpaperBlur", Mix.wallpaperBlur).apply()
    }

    fun setWallpaperDim(context: Context, dim: Float) {
        Mix.wallpaperDim = dim.coerceIn(0f, 0.9f)
        prefs(context).edit().putFloat("wallpaperDim", Mix.wallpaperDim).apply()
    }

    fun setAnimations(context: Context, on: Boolean) {
        Mix.animations = on
        prefs(context).edit().putBoolean("animations", on).apply()
    }

    fun setRounded(context: Context, rounded: Boolean) {
        Mix.rounded = rounded
        Mix.cocoon = false
        prefs(context).edit().putBoolean("rounded", rounded).putBoolean("cocoon", false).apply()
    }

    /** Cocoon style: like the console frontend (rounded tiles, glass panels, button hints). */
    fun setCocoon(context: Context) {
        Mix.rounded = true
        Mix.cocoon = true
        prefs(context).edit().putBoolean("rounded", true).putBoolean("cocoon", true).apply()
    }

    private fun customFontFile(context: Context) = File(File(context.filesDir, "fonts").apply { mkdirs() }, "custom.ttf")

    private fun loadCustomFont(context: Context): FontFamily? = runCatching {
        val f = customFontFile(context)
        if (!f.exists() || f.length() == 0L) null else FontFamily(Typeface.createFromFile(f))
    }.getOrNull()

    /** Copies a .ttf/.otf the user picked into the app and switches to it. False if it isn't a usable font. */
    fun importFont(context: Context, uri: Uri): Boolean {
        val tmp = File(context.cacheDir, "font-import.tmp")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                ?: return false
            val face = Typeface.createFromFile(tmp)
            if (face == null || face == Typeface.DEFAULT) return false
            tmp.copyTo(customFontFile(context), overwrite = true)
            Mix.customFont = FontFamily(Typeface.createFromFile(customFontFile(context)))
            setFont(context, AppFont.CUSTOM)
            true
        } catch (e: Exception) {
            false
        } finally {
            tmp.delete()
        }
    }

    private fun apply() {
        Mix.palette = preset.palette ?: custom
    }
}

/** Square corners like a terminal window, or soft rounded ones (Settings → style). */
val TermShape: RoundedCornerShape
    get() = if (Mix.rounded) RoundedCornerShape(14.dp) else RoundedCornerShape(2.dp)

/** App fonts. [scale] evens out fonts that look much bigger or smaller at the same size. */
enum class AppFont(val label: String, val scale: Float) {
    MONO("Monospace (terminal)", 1f),
    JETBRAINS("JetBrains Mono", 0.95f),
    VT323("VT323 (retro screen)", 1.3f),
    PIXEL("Press Start (8-bit)", 0.72f),
    SYSTEM("Phone default", 1.05f),
    INTER("Inter (clean, Apple-like)", 1.02f),
    NUNITO("Nunito (round, friendly)", 1.05f),
    BARLOW("Barlow (tall)", 1.1f),
    SPACE("Space Grotesk (modern)", 1.02f),
    PLAYFAIR("Playfair Display (elegant)", 1.05f),
    CUSTOM("Your font", 1f);

    val family: FontFamily
        get() = when (this) {
            MONO -> FontFamily.Monospace
            JETBRAINS -> pair(R.font.jetbrainsmono_regular, R.font.jetbrainsmono_bold)
            VT323 -> FontFamily(Font(R.font.vt323_regular, FontWeight.Normal))
            PIXEL -> FontFamily(Font(R.font.pressstart_regular, FontWeight.Normal))
            SYSTEM -> FontFamily.Default
            INTER -> pair(R.font.inter_regular, R.font.inter_bold)
            NUNITO -> pair(R.font.nunito_regular, R.font.nunito_bold)
            BARLOW -> Barlow
            SPACE -> pair(R.font.spacegrotesk_regular, R.font.spacegrotesk_bold)
            PLAYFAIR -> pair(R.font.playfair_regular, R.font.playfair_bold)
            CUSTOM -> Mix.customFont ?: FontFamily.Default
        }
}

private fun pair(regular: Int, bold: Int) = FontFamily(
    Font(regular, FontWeight.Normal),
    Font(regular, FontWeight.Medium),
    Font(bold, FontWeight.SemiBold),
    Font(bold, FontWeight.Bold),
)

/** Labels in the terminal style ("~/songs", "[ open ]", "> albums") or plain ("Songs", "Open", "Albums"). */
object Ui {
    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }
    fun path(name: String) = if (Mix.rounded) cap(name) else "~/$name"
    fun btn(label: String) = if (Mix.rounded) cap(label) else "[ $label ]"
    fun head(text: String) = if (Mix.rounded) cap(text) else "> $text"
}

val Mono = FontFamily.Monospace

val Barlow = FontFamily(
    Font(R.font.barlow_regular, FontWeight.Normal),
    Font(R.font.barlow_medium, FontWeight.Medium),
    Font(R.font.barlow_semibold, FontWeight.SemiBold),
    Font(R.font.barlow_bold, FontWeight.Bold),
)

private fun schemeFor(p: Palette) = if (p.isLight) {
    lightColorScheme(
        primary = p.tape, onPrimary = p.ink, primaryContainer = p.raised, onPrimaryContainer = p.paper,
        secondary = p.fog, onSecondary = p.ink, secondaryContainer = p.raised, onSecondaryContainer = p.paper,
        background = p.ink, onBackground = p.paper, surface = p.ink, onSurface = p.paper,
        surfaceVariant = p.raised, onSurfaceVariant = p.fog,
        surfaceContainerLowest = p.ink, surfaceContainerLow = p.deep, surfaceContainer = p.deep,
        surfaceContainerHigh = p.raised, surfaceContainerHighest = p.raised,
        inverseSurface = p.paper, inverseOnSurface = p.ink, outline = p.gap, outlineVariant = p.gap,
        error = p.alert, onError = p.ink,
    )
} else {
    darkColorScheme(
        primary = p.tape, onPrimary = p.ink, primaryContainer = p.raised, onPrimaryContainer = p.paper,
        secondary = p.fog, onSecondary = p.ink, secondaryContainer = p.raised, onSecondaryContainer = p.paper,
        background = p.ink, onBackground = p.paper, surface = p.ink, onSurface = p.paper,
        surfaceVariant = p.raised, onSurfaceVariant = p.fog,
        surfaceContainerLowest = p.ink, surfaceContainerLow = p.deep, surfaceContainer = p.deep,
        surfaceContainerHigh = p.raised, surfaceContainerHighest = p.raised,
        inverseSurface = p.paper, inverseOnSurface = p.ink, outline = p.gap, outlineVariant = p.gap,
        error = p.alert, onError = p.ink,
    )
}

private fun typeFor(font: AppFont, family: FontFamily): Typography {
    val base = Typography()
    val scale = font.scale
    fun TextStyle.set(size: Int? = null, weight: FontWeight? = null, line: Int? = null) = copy(
        fontFamily = family,
        letterSpacing = 0.sp,
        fontSize = size?.let { (it * scale).sp } ?: fontSize,
        fontWeight = weight ?: fontWeight,
        lineHeight = line?.let { (it * scale).sp } ?: lineHeight,
    )
    return Typography(
        displayLarge = base.displayLarge.set(),
        displayMedium = base.displayMedium.set(),
        displaySmall = base.displaySmall.set(size = 24, weight = FontWeight.Bold, line = 30),
        headlineLarge = base.headlineLarge.set(weight = FontWeight.SemiBold),
        headlineMedium = base.headlineMedium.set(weight = FontWeight.SemiBold),
        headlineSmall = base.headlineSmall.set(weight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.set(size = 20, weight = FontWeight.Bold, line = 26),
        titleMedium = base.titleMedium.set(size = 15, weight = FontWeight.Medium, line = 20),
        titleSmall = base.titleSmall.set(weight = FontWeight.Medium),
        bodyLarge = base.bodyLarge.set(size = 15, line = 22),
        bodyMedium = base.bodyMedium.set(size = 13, line = 18),
        bodySmall = base.bodySmall.set(size = 12, line = 16),
        labelLarge = base.labelLarge.set(size = 14, weight = FontWeight.Bold),
        labelMedium = base.labelMedium.set(size = 13, weight = FontWeight.Medium),
        labelSmall = base.labelSmall.set(),
    )
}

private fun shapesFor(rounded: Boolean): Shapes = if (rounded) {
    Shapes(
        extraSmall = RoundedCornerShape(8.dp),
        small = RoundedCornerShape(12.dp),
        medium = RoundedCornerShape(16.dp),
        large = RoundedCornerShape(20.dp),
        extraLarge = RoundedCornerShape(28.dp),
    )
} else {
    Shapes(
        extraSmall = RoundedCornerShape(2.dp),
        small = RoundedCornerShape(2.dp),
        medium = RoundedCornerShape(2.dp),
        large = RoundedCornerShape(2.dp),
        extraLarge = RoundedCornerShape(2.dp),
    )
}

@Composable
fun MixtapeTheme(content: @Composable () -> Unit) {
    val palette = Mix.palette
    val font = Mix.font
    val custom = Mix.customFont
    val rounded = Mix.rounded
    val hasWallpaper = Mix.wallpaper != null
    val cocoon = Mix.cocoon
    val scheme = remember(palette, hasWallpaper, cocoon) {
        // With a background picture/video (or Cocoon's waves), screens are see-through so it shows behind everything.
        schemeFor(palette).let {
            if (hasWallpaper || cocoon) it.copy(background = Color.Transparent, surface = Color.Transparent) else it
        }
    }
    val type = remember(font, custom) { typeFor(font, font.family) }
    val shapes = remember(rounded) { shapesFor(rounded) }

    // Dark status/navigation bar icons on light themes, light icons on dark ones.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = palette.isLight
                isAppearanceLightNavigationBars = palette.isLight
            }
        }
    }
    MaterialTheme(colorScheme = scheme, typography = type, shapes = shapes, content = content)
}
